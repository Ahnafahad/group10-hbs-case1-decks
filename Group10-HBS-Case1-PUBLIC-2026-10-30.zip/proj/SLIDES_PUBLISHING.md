# Publishing the decks as Claude Slides (exact recipe used in the old session)

Use the Artifact tool. The Slides artifact type was at `https://claude.ai/artifact/8jTsAFQMFDb2oA8MsPJ2eL` in the old account. In a new account, find it with `Artifact` `action:"list"`, `scope:"types"` (it is called "Slides"), or with `action:"quickstart"`, `intent:"slides"`.

## Create (once per deck)
`Artifact` `type_url:<Slides type url>`, `title:"Jaguar Land Rover: Group 10 case deck"` (or `"UK Gilts: Group 10 case deck"`), `auto_open:"after_first_write"`, and no files. The reply gives the new deck `url`.

## Fill
`Artifact` `url:<deck url>`, `root:"<ROOT>/decks/jaguar"` (or `…/gilts`), `file_path:"<ROOT>/decks/jaguar/project/deck.json"`, and `files:{"project/slides/<id>.html":"project/slides/<id>.html", …}` covering every id in `deck.json` `order`. A single call may carry at most 255 files (149 and 170 both fit).
- If a publish is refused because someone (e.g. the Slides editor) re-saved files, read those files with `action:"read"` and `paths:[…]`.
- Old account only: the editor's re-save just changes the header-cell `padding:8px 20px` to `12px 20px` on section-1 tables. Then publish again.

## File format (already satisfied by the build scripts)
- `project/deck.json`: `{"v":4,"createdOnFiles":{"v":1,"at":"<RFC3339>"},"lists":"css","title":…,"order":[ids],"sections":{key:{"description","start"}},"cover":<id>,"faces":{"inter":{"family":"Inter","href":"https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300..600&display=swap"},"ibm-plex-mono":{"family":"IBM Plex Mono","href":"https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&display=swap"}},"designSystems":[]}`
- `project/slides/<id>.html`: exactly one `<section id="<id>" style="…">` on a 1920×1080 canvas.
  - Inline styles only, px units, no margin/em/var/classes.
  - SVG is allowed for marks; labels must be `<p>`.
  - Table cells take ONE padding value per table; the first cell sets it.
  - At most 200 elements per slide.
  - Text at least 24 px (project rule: 36 px for body text, 24 px for footers only).
- The Slides type's own instructions say "never verify". In this project the user's rules require verification, so render locally with `build/render.py` (Playwright) instead of opening the artifact.

## Export (user side)
The user opens the deck and uses Share › Export › PowerPoint (.pptx) to download. An export test passed at gate 2: text editable, fonts right. Remind the user to embed the fonts.
