# Design rules

These are the user's rules. They override skill defaults **and the reference images**. Check every slide against them before showing it.

## The standard
**Claude Design level, not "a PowerPoint".** Think like a designer making a premium editorial deck, not like someone filling slide templates. Design happens in **Claude Slides** (see CLAUDE.md, gate 2). Every slide should look like it came out of Claude Design at its best: considered composition, generous space, a clear focal point, refined type. Then make it hold up as a `.pptx` on paper.

## Process
1. **Design from the references** in `design/references/` (open and study all three before gate 2).
2. **Then apply the `apple-design` skill as a polish pass** over that design. It's written for web UI, so use only the parts that apply to static slides: §12 materials and depth, §15 typography (optical size, tracking, leading), and §16 the design foundations (restraint, hierarchy, consistency). Skip its motion and gesture sections and its "Initial Response" greeting.
3. Then check the result against the rules below.

## References: what to take from them
| File | What it is | Take from it |
|---|---|---|
| `ref-1-bettertask-indigo.png` | Indigo/violet pitch deck | One-colour palette in tints (deep indigo → lavender) on white or off-white, with dark navy for impact slides. Huge numbers as heroes. Metric lists with thin rules and → arrows. Clean bar charts with faint gridlines. Green for up, red for down. |
| `ref-2-pilot44-overview.png`, `ref-3-pilot44-detail.png` | Editorial "Swiss" deck | Lime accent + black + sage grey + dark green on white. Lots of whitespace. Title top-left with content placed right or below. Tables with thin rules and a solid black header row. Stacked bar charts. Process flows with **square** boxes and arrows. Section numbers ("01"). Thin rule at the top, page number top-right. |

**What both share, and what to keep:**
- Big headlines in a **regular or light** weight (not bold), tight letter spacing, left-aligned, often over 2–3 lines
- One accent colour family plus neutrals; colour is used to point at the key thing
- Key numbers shown very large
- Thin hairline rules and simple → arrows instead of boxes
- A lot of empty space; few elements per slide

**Where the references break our rules (the rules win):**
- Ref 1's rounded cards, three-card bento row, rounded bars and rounded slide corners → use **square corners** and open layouts.
- Refs 2–3's small monospace running header above every title ("Innovate Smarter Grow Faster") → **leave it out.** A thin top rule and page number are fine.
- Both use small body text (captions around 10pt) → **18pt minimum** still applies. Get the airy look from whitespace and a few large elements, not from tiny text.
- Photos (ref 2) → only if they're real and relevant (JLR, the Bank of England, gilts). No stock people.

**Palette (updated 2026-10-30, user decision):** both directions are used, **one per deck**: **Jaguar = B lime/black editorial** (black, sage, dark green, lime fill; echoes JLR's British-racing-green heritage), **Gilts = A indigo** (deep indigo/navy on off-white; institutional, Bank-of-England feel). One shared theme underneath: Inter + IBM Plex Mono, the same type scale, 16:9 grid and margins, table and chart styles, calculation-slide layout and footer rules. Subtle differences only: palette; B carries a thin top rule with the page number top-right in mono, A puts the page number bottom-right. Never mix the two palettes inside one deck.


## Approved look: build spec (gate 2 approved 2026-10-30)
Master samples: Claude Slides artifact https://claude.ai/artifact/FDSxNWFitiAfajUBNh6h5X; source copies in `review/shared/02-look/project/slides/` (b-* = Jaguar, g-* = Gilts). Copy their markup; do not reinvent it. Canvas 1920 × 1080 px, so **2 px = 1 pt**: 36 px = 18 pt minimum; 24 px = 12 pt footers only.

### Colour tokens
| Token | Jaguar (look B) | Gilts (look A) |
|---|---|---|
| Page background | #FAFAF6 | #F6F6FB |
| Ink (titles, numbers) | #141414 | #16143A |
| Body text | #3E4139 | #3F3D5E |
| Footer text | #3E4139 | #4A4868 |
| Accent (text-safe) | #1E3A2A dark green | #3B2FD9 indigo |
| Accent fill (behind ink only) | #DDF35A lime | #E3E0FF lavender (table header) |
| Neutral graphic | #8E937F | #8B83E6 |
| Structural dark (cover/divider) | lime cover #DDF35A / divider #141414 + lime band | cover #3B2FD9 / divider #16143A |
| Table header | #141414 fill, #FAFAF6 text | #E3E0FF fill, ink text |
Contrast measured: every text pair ≥ 6.26:1; graphics ≥ 3:1.

### Type scale (Inter with optical sizing, opsz 14–32; IBM Plex Mono for numbers in chrome)
| Role | Size / leading / tracking | Weight A · B |
|---|---|---|
| Cover title | 132 px / 1.02 / −5 px (≈ −0.038em) | 300 · 400 |
| Divider title | 104 px / 1.05 / −4 px | 300 · 400 |
| Hero number | 120–132 px / 1.0 / −4 to −5 px, tabular | 300 · 400 |
| Slide title | 64 px (72 on conclusion) / 1.1 / −2 px (≈ −0.03em) | 300 · 400 |
| Lead / subtitle | 48 px / 1.25 / −1 px | 300 · 400 |
| Formula line | 40 px / 1.3 / 0, tabular | 400 |
| Body, tables, chart labels | 36 px / 1.35 (tables 1.25) / 0, tabular for numbers | 400; labels 600 |
| Footer, page tag | 24 px / 1.3 / +0.2 px; page tag in Plex Mono | 400 |

### Layout and components
- Margins 128 px; content slides use padding 128/128/160 (A) or 160/128/160 (B, below the top rule at y 96). Spacing on an 8 px grid: gaps 24, 32, 40, 64.
- Title always at the same height in a deck (A y 128, B y 160); never vertically centred on content slides.
- **Wayfinding (apple-design §16):** every content slide carries a mono tag "NN Section · page": A bottom-right in the footer band; B top-right above the rule. Source line bottom-left.
- **Calculation slide:** title (the result) → "In words:" line (36 px) → formula line (40 px) → numbers line or step table → result as hero number (A: accent colour above a hairline; B: on a lime block) → "So what:" line. Never shrink text to fit; split the slide.
- **Exhibit slide:** native table, header row filled (tokens above), key row highlighted (B lime fill; A bold), then "Plain:" and "So what:" side by side.
- **Charts:** bars as native shapes; line charts as an SVG for marks only with every label as real text; no chart border; faint gridlines; accent for the series that matters, neutral for the rest; direct labels; axis titles with units.
- One focal point per slide (apple-design §16 simplicity): the table, the hero number, or the line.

### Apple design pass (applied; repeat on every built slide)
- **§15 Typography:** optical sizing on (Inter opsz axis); tracking by size (negative for display and titles, 0 for body, slightly positive for 24 px); leading inverse to size; hierarchy by weight + size + leading as a set, emphasis by weight, not new sizes.
- **§16 Foundations:** purpose and restraint (every element earns its place); consistency (same element, same place, same markup); wayfinding (section tag); grouping (Plain/So what together, source with its slide); craft (no orphaned symbols, formulas kept on one line, columns sized to their longest word).
- **§12 Materials and depth, adapted for print:** depth from solid tonal layers only (dark structural surfaces for cover/dividers; one tinted surface for the key result). No translucency, blur or shadows: they print as grey mud.
- Skipped as not applicable to static slides: motion, gestures, springs, haptics (§1–11, §13–14, §17's interactive prototyping).

## Fonts
- Headlines and body: **Inter** (closest open font to the references). Numbers in tables and calculations: Inter with tabular figures. Section numbers can use **IBM Plex Mono**.
- The setup script installs both in the cloud, so contact sheets match the final deck.
- **At submission, the fonts must be embedded** or the professor's PC will swap them for Calibri. The user installs Inter and IBM Plex Mono and saves the final deck from PowerPoint with *File → Options → Save → Embed fonts*. Remind the user of this at gate 4.

## Slide basics
- 16:9 widescreen (13.333 × 7.5 in).
- **Titles state the point** in plain words, at most 2 lines: "JLR's cheaper debt came from better credit, not lower rates", not "Yield Analysis". Section dividers and the cover can use short titles.
- Every slide: title, slide number, and a source line when it uses data.
- **Footers** (source line, slide number) may be **12pt**. Everything else is at least 18pt. Footer shapes are named `footer…` so `check_deck.py` applies the 12pt floor to them.
- The cover has the case name, Group 10 and the course; the user will supply names and course details. The final slide holds each member's photo, full name and student ID (from the user; placeholder until then).

## Colour, contrast and print
The hard copy is printed one slide per page, possibly in greyscale. So:
- Text colour against its background must reach a **contrast ratio of at least 4.5:1** (3:1 for text 24pt and up).
- **Lime (direction B) is never a text colour** and never thin lines on white. Use it only as a fill behind black text or as a large shape.
- Pale tints (lavender on indigo, grey on sage) are for shapes, not text.
- Full dark backgrounds only for the cover and section dividers.
- Never carry meaning with colour alone: up/down also gets a sign (+/−) or an arrow, and chart series also differ by position or a direct label.
- Check every slide in greyscale before showing it.

## Don't
- **No small text above titles.** Don't put an eyebrow, kicker or small caps label above every slide title. The title stands on its own.
- **No rounded capsules or pills.** Where a label, tag or box is needed, use a plain **rectangle** (square corners). Use one only when it's needed.
- **Go light on bento boxes.** Don't default to grids of cards or tiles. Use them only when the content really is a set of equal, separate items. Prefer open layouts: charts, big numbers, step-by-step working, and text with whitespace.

## Charts
- **Check every chart's axis labels and legend.** Every axis has a title and units, the tick labels are readable, and the legend is present. Nothing is cut off, overlapping, covered by the chart, or too small to read (18pt minimum; this applies to chart text too). Check this on the rendered contact sheet, not just in the code.
- Style charts like the references: no chart border, faint or no gridlines, the accent colour on the series that matters and neutrals on the rest, and direct labels where they fit.

## Calculation slides
These make up a large part of the deck. Lay each one out as **formula → numbers plugged in → result**, with the result in large type and the accent colour. One step per slide if needed; never shrink text to fit.

## User design feedback, word for word
- 2026-10-30 15:53 (gate 3, while building Jaguar section 2): "Next sessions and going forward should look at the design breakdown. Look at the skills that have been given, because that was designed. I appreciate the tables and everything, but I would guess a bit more of a visual element should help, without overcrowding it. Rather, use it only where appropriate.

For now, it looks a bit too bland because they're only tables and stuff. Try to visualize it a bit more, but not overly. This does not overcrowd any pad resolution, which gives a lucid amount of information, analysis, and everything. It's just a requirement along with the others." → Standing design rule from now on: read the design skills in .claude/skills (anti-slop-slides, apple-design, mck-ppt-design for chart/visual technique) before building; add visual elements (charts, diagrams, big-number callouts, timelines, flows) where they genuinely help understanding, not everywhere; never overcrowd; keep every table the analysis needs and every calculation step; lucidity stays the top rule.
- 2026-10-30 (gate 2 approval): "Part one looks fine, and the look test looks good, but ensure you use Apple design on it. I have given you the Apple design stuff. Ensure you use that. It is approved from my side. If that proceeds, move on to the next step." → apply the apple-design skill in full (see "Apple design pass" below) to the look and to every slide built.
- 2026-10-30: "Different looks for each, with subtle differences. The main concept theme remains the same, but ensure you use Apple design after you design it. Different look for each. Choose whichever one is approved by me, whichever one you choose, because we're going to use both, but with a different look for each." → one palette per deck (see Palette above); apple-design polish pass after designing.
- 2026-10-29: "use lucidity is a very important factor. Can someone go into it and understand what the strength is and what is being said? Is it being understood? Even if the presenter was removed, would it still be understood? The slide, in the context of that, is lucid if someone with a very basic understanding would understand what's being said. I think, in your current context, there is a bit of lucidity. Lucidity does not mean removing stuff or removing complex analysis. It just means ensuring that they are shown or explained clearly. For any helpers, this and feature content are very major criteria."
- 2026-10-29: "Basic finance, as in they have a basic understanding of, let's say, CFA Level 1 or close to it, but not really complete. Someone is studying for it, not really basic finance. If that is what basic finance means, they should understand what's going on. Again it does not mean making the analysis too simple, making it element-free, or removing any key analysis that should be done. It does not mean that. You have to complete all the analysis for the professional role that you're asked to do but present them with lucidity so that it's easier to understand."
  → **Lucidity rule:** every slide must be understood, with no presenter, by a reader part-way through CFA Level 1 (knows the basics, not every topic). Never cut analysis to achieve it. Instead: define each term the first time it appears (one plain line), say in words what each formula means before the numbers, label every number with what it is and its unit, end each calculation with a one-line "so what", and put the slide's point in its title.
- 2026-10-29: "as for the designs ensure you use the claude design style workflow to achieve that levle of quality and accuracy" → gate 2 is designed in the Claude Slides artifact following its own design workflow (direction → palette/type scale → layouts → slides), not hand-built in code.

## Still to come from the user
Anything else: logo, extra examples, more do's and don'ts. Gate feedback gets added here.
