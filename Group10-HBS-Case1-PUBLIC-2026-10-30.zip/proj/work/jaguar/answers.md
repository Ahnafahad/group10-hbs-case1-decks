# Jaguar Land Rover: answers (gate 1; aligned with storyline round 6, 2026-10-30)

All numbers come from `work/jaguar/calcs.py` (run it to see every step). Inputs: `work/jaguar/exhibits.csv`, `work/jaguar/sources.md`, `work/jaguar/sources_research.md`.

## Conventions and assumptions
- **Currency:** bond maths in **US$** (the notes' currency); £ only at the case's **1.50** (user decision). Exhibit 1's £263m implies 1.559 (31 Dec 2014 rate).
- **Prices:** per 100 face; semi-annual coupons (15 May / 15 Nov); **30/360** day count; clean = full − accrued (CFA FI LM06).
- **Settlement:** 17 Mar 2015 (early settlement); 31 Mar 2015 for late tenders. Source: JLR releases.
- **Call:** first call 15 May 2016 at **104.0625** (par + half coupon). The 2015 offering memorandum prints "104.663%", but only 104.0625 reproduces the published tender price (to within US$0.01 per US$1,000), so 104.663 is treated as a misprint.
- **Maturity:** the case says **15 May 2021**; Tata Motors' SEC filing says **15 Nov 2021**. User decision (gate 1): use the case date plus one note slide; this only affects the hold-to-maturity value (125.43 vs 127.26).
- **Tax:** UK main corporation tax rate 21% for FY2014 (1 Apr 2014 – 31 Mar 2015, so it applies at the 17 Mar 2015 settlement) and 20% from 1 Apr 2015 (21%: Finance Act 2013 s.4, quoted in sources_research; 20%: secondary summary, Pinsent Masons). Premium, accrued interest, coupons and call premium deductible; principal not (assumption).

## Q1. Why could JLR borrow at less than half the 2011 coupon? — *solid* (numbers) / *debatable* (weights)
- 2011: 8.125% = 3.15% (10-year UST, 16 May 2011) + **497bp**. 2015: 3.50% = 1.57% (5-year UST, 16 Mar 2015) + **193bp**.
- The total fall of **462bp** splits into:
  - credit spread **304bp (66%)**
  - Treasury level and shorter maturity **158bp (34%)**. How these 158bp divide depends on the order of the split: our order gives 105bp level + 53bp tenor; the checker's gives 26bp + 132bp. Both are valid, so the deck shows the 158bp as one block.
- Like for like at 5 years, the UST fell only **26bp** (1.83% → 1.57%).
- Same-bond evidence: the old 8.125% notes traded at 111.28 (4 Feb 2015) = **2.28% yield to call**, 5.94% to maturity.
- Test 1 in spreads (plan slide 57): 497bp at issue → **199bp** in Feb 2015 (2.28% − 0.29%, the 15-month Treasury interpolated between the 1-year 0.20% and 2-year 0.52%).
- Drivers of the narrower spread:
  - credit metrics (Exhibits 4–6): EBITDA margin 14.8% → 18.0%, net cash £456m → £1,604m, D/E 0.68 → 0.36, EBITDA/cash interest 12–30×
  - ratings (Ba3 → Ba2 in 2013; positive outlooks in 2014)
  - shorter tenor (5 vs 10 years)
  - the 2011 notes' call feature (investors were paid for it in the 8.125%)
  - market-wide high-yield spreads fell only about 40bp (BofA ~502bp, May 2011 → Fortune ~460bp, Mar 2015; different indices, indicative), vs 304bp for JLR, so about 260bp is JLR-specific (plan 59)

## Q2. Price holders would accept — *solid*
| Method | Discount rate (why) | Clean price | Premium |
|---|---|---|---|
| A: hold to May 2021 (naive) | 3.50% (JLR's new 5-year cost) | 125.43 | 25.4% |
| B: to May 2016 call | 3.50% | 109.11 | 9.1% |
| Market (Exhibit 2, 4 Feb 2015) | implied 2.28% to call | 111.28 | 11.3% |
| Actual tender (early) | 0.395% UST May-2016 + 0.50% = 0.895%, to call | 112.35 | 12.4% |
| Actual tender (late) | early price − US$30 early premium | 109.35 | 9.4% |

- Accrued interest: 122 days → **US$27.53** per US$1,000 (17 Mar); 136 days → **US$30.69** (31 Mar). Both match JLR's payments.
- **Answer:** about **110.6–112.4 clean** per 100 (US$453.5–460.6m for the issue), plus accrued interest, all measured on 17 Mar 2015. Floor = value to the call at the market's 2.28% (110.61); ceiling = the offer's 0.895% value (112.35), which is what JLR had to pay to win early tenders. The 4 Feb market price 111.28 sits inside. Each rate from 0.5% to 3.5% is worked on its own slide (plan 71–80).
- The hold-to-maturity value (125) ignores the call. On the same date the issuer's option is worth about **15 points** (125.43 − 110.61 = 14.82; approximate, because each horizon uses its own rate, 3.5% vs 2.28%).

## Q3. Incremental cash flows and savings — *solid* (numbers) / *debatable* (choice of baseline)
- Cash needed: 410 × (112.352 + 2.754)% = **US$471.9m**. New issue US$500m → surplus **US$28.1m** before fees.
- Accounting view:
  - interest US$33.3m/yr (8.125% × 410) → US$16.5m/yr (3.5% × 471.9), a saving of **US$16.8m/yr**
  - premium above face **US$50.6m** (incl. US$12.3m early premium) ≈ 3 years of savings
- The full dated incremental table is in the calcs output (old coupons avoided May/Nov to 2021; new coupons Mar/Sep to 2020).

| Baseline (discount rate and why) | Pre-tax NPV | After-tax NPV |
|---|---|---|
| Naive: old notes held to 2021 (3.50%, JLR's 5–6 year cost) | +US$53.6m | +US$45.4m (at 2.80%) |
| **Realistic: called May 2016, at the market's 14-month yield 2.28%** | **−US$7.1m** | **−US$4.9m** (at 1.82%) |
| Realistic, at the offer's own 0.895% | US$0.0m (zero by construction) | +US$0.7m (at 0.716%) |
| Against the stale 4 Feb market price (same 2.28% yield as the realistic row) | −US$4.4m | — |

- Revised at gate 1 round 3 (strict review B2). The earlier "−US$13.4m" valued the 14-month call path at 3.5%, which was inconsistent with Q2's own reasoning.
- New debt at par at 3.5% has PV ≈ the amount borrowed (472.0 vs 471.9), so NPV = PV of old debt avoided − cash paid.
- After tax: the premium AND the accrued interest paid at settlement (US$61.9m) are deductible at 21% (FY2014 rate; deal date 17 Mar 2015): tax saved US$13.0m, after-tax cash US$458.9m; later coupons and the call premium at 20%; principal not deductible. (Corrected 2026-10-30 after strict review r3: the earlier version left out the accrued-interest deduction and gave −7.3 / +43.0.)
- **Answer:** there is a real cash-interest saving but no economic saving. Against the realistic baseline JLR paid slightly more than the debt was worth (or exactly fair value at the offer's own rate). The "saving" only appears if you assume JLR would have kept 8.125% debt to 2021, which it would not.

## Q4. Other benefits; who gains — *debatable*
- **Benefits to JLR:**
  - higher reported profit and interest cover after a one-off charge
  - covenants stripped through the consent solicitation
  - US$28m of extra liquidity
  - locked in 3.5% before the Fed's first rise (Dec 2015)
  - signalling
- **Costs:** the premium, the early-tender payment and fees. **Refinancing risk, both views:** against the realistic baseline (call in May 2016) the deal lengthened funding to 2020 at a fixed 3.5%, cutting refinancing risk; against the naive baseline (2021) it brought repayment forward a year. The 2020 maturity then fell in the 2019–20 crisis, when new debt cost 5.875–7.75%.
- **Timing:** tendering now rather than waiting for the call cost 1.74 per 100 (US$7.1m); "locking in 3.5% before the Fed" was a rate bet (the 5-year Treasury was 1.26% on 16 May 2016, below 1.57% in March 2015).
- **Firm:** about zero value (MM; efficient market). A lower coupon means a slightly smaller interest tax shield.
- **Bondholders who tendered:** +1.74 per 100 over the value of their notes at the market's own 2.28% yield on 17 March (US$7.1m); against the stale 4 Feb price it shows as +1.08 (US$4.4m).
- **Tata Motors (sole shareholder):** about neutral to slightly negative.

## Independent check (sonnet helper, case only, no teaching note) — `work/jaguar/check/`
| Item | Ours | Checker | Why they differ |
|---|---|---|---|
| Q1 spread change | 304bp | 304bp | — |
| Q1 level/tenor split | 105 + 53 | 26 + 132 | order of decomposition; both valid; deck shows the 158bp combined |
| Q2 headline | 110.6–112.4 (to call, 17 Mar: floor at the market's 2.28%, ceiling at the offer's 0.895%) | 110.44 (to call at 2.24%, settle 31 Mar) | 0.17 below our floor only because it settles on 31 Mar (the clean value drifts toward the call price); at its 2.24% on our 17 Mar date it gives 110.66, inside our band |
| Q2 to maturity | 125.43 | 124.11 (at 3.69%) | the checker used a 6-year yield (3.69%) instead of 3.5% |
| Q3 NPV vs hold | +53.5 (+53.6 in the PV form the slides use; the 0.1 gap is the new debt's PV 472.0 vs 471.9 borrowed) | +53.8 | the checker included a 1.25% fee and different funding; same conclusion |
| Q3 NPV vs call | −7.1 at 2.28% (−13.4 at 3.5%) | −13.1 at 3.5% | the checker used 3.5% for the call path; at the same 3.5% we agree (−13.4 vs −13.1) |
| Conclusion | no economic saving | "little or no value created once compared with the call" | same |

## Teaching note comparison (for checking only; never cited on slides)
- Its Q2 answer is a 25–29% premium. That is our Method A (25.4%; its variant 2 uses a different discounting schedule). The difference from our answer (10.6–12.4%) is **the call option**, which the teaching note ignores. The actual tender (12.35%) and the market (11.3%) both support our answer. User decision at gate 0: lead with the call-aware value.
- It uses £263m (Dec-2014 FX) for the old notes and £333m (1.50) for the new notes. We stay in US$.
- Its NPV of 0.00 (variant 1) is zero by construction: it prices the notes at the same rate it discounts at.
- Its accrued interest of US$25.92 (to 15 Mar) vs ours of US$27.53 (to 17 Mar): different date. Ours matches the actual payment.
