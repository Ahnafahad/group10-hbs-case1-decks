# Jaguar: external sources

| # | Fact | URL | Accessed | Exact quote / data |
|---|---|---|---|---|
| 1 | US Treasury par yields, 16 Mar 2015 and 16 May 2011 (Exhibit 3 data) | https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2015/all?type=daily_treasury_yield_curve&field_tdr_date_value=2015&page&_format=csv (and /2011/) | 2026-10-29 | `03/16/2015,0.02,0.05,0.15,0.26,0.66,1.06,1.57,1.90,2.10,2.45,2.67` · `05/16/2011,0.02,0.04,0.07,0.18,0.54,0.93,1.83,2.50,3.15,3.99,4.28` (columns 1 Mo,3 Mo,6 Mo,1 Yr,2 Yr,3 Yr,5 Yr,7 Yr,10 Yr,20 Yr,30 Yr) |

## Added 2026-10-30 (strict review r3 fixes)
- **US Treasury daily par yield curve, 4 Feb 2015** (Test 1, slide 56: the 14-month Treasury on the Exhibit 2 price date). URL: https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2015/all?type=daily_treasury_yield_curve&field_tdr_date_value=2015&page&_format=csv · accessed 2026-10-30 (via WebFetch; shell blocked) · exact rows:
  `Date,"1 Mo","3 Mo","6 Mo","1 Yr","2 Yr","3 Yr","5 Yr","7 Yr","10 Yr","20 Yr","30 Yr"`
  `02/04/2015,0.01,0.01,0.06,0.20,0.52,0.86,1.29,1.61,1.81,2.17,2.39`
  `03/03/2015,0.01,0.02,0.08,0.26,0.68,1.09,1.61,1.94,2.12,2.49,2.71`
  `03/16/2015,0.02,0.05,0.15,0.26,0.66,1.06,1.57,1.90,2.10,2.45,2.67` (matches exhibits.csv rows 325–334)
- **US Treasury daily par yield curve, 16 May 2016** (slide 105: what waiting for the call would have cost on the Treasury part). URL: https://home.treasury.gov/resource-center/data-chart-center/interest-rates/daily-treasury-rates.csv/2016/all?type=daily_treasury_yield_curve&field_tdr_date_value=2016&page&_format=csv · accessed 2026-10-30 · exact row:
  `05/16/2016,0.21,0.28,0.38,0.57,0.79,0.94,1.26,1.55,1.75,2.18,2.59`
