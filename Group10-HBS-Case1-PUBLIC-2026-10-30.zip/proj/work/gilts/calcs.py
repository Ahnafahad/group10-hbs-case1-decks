"""UK Gilts: every calculation for the deck. Run: python3 work/gilts/calcs.py

Basis (user decision, gate 0): annual coupons as the main answer (as Exhibit 1),
plus one semi-annual comparison. Prices per GBP 100 face, valued on a coupon date.
All inputs come from work/gilts/exhibits.csv.
"""
import csv
from pathlib import Path

from scipy.optimize import brentq

HERE = Path(__file__).parent
SHIFT = 0.01  # Q4: every yield up by 1 percentage point (parallel shift)


# ---------- inputs ----------
def load_exhibit():
    rows = {}
    for r in csv.DictReader(open(HERE / "exhibits.csv")):
        if r["exhibit"] != "1" or not r["value"]:
            continue
        n = int(r["row"].split()[0])
        col = r["column"].strip().lower()
        try:
            rows.setdefault(n, {})[col] = float(r["value"])
        except ValueError:
            pass
    return dict(sorted(rows.items()))


# ---------- pricing ----------
def cash_flows(c, n, freq=1):
    """Coupon c in % of face; n years; returns [(t in years, cash flow)]."""
    k = int(n * freq)
    return [((i / freq), c / freq + (100 if i == k else 0)) for i in range(1, k + 1)]


def price(c, y, n, freq=1):
    """y = annual yield (decimal), compounded freq times a year."""
    return sum(cf / (1 + y / freq) ** (t * freq) for t, cf in cash_flows(c, n, freq))


def ytm(c, p, n, freq=1):
    return brentq(lambda y: price(c, y, n, freq) - p, -0.05, 0.50)


def macaulay(c, y, n, freq=1):
    p = price(c, y, n, freq)
    return sum(t * cf / (1 + y / freq) ** (t * freq) for t, cf in cash_flows(c, n, freq)) / p


def convexity(c, y, n):
    """Annual-pay convexity (CFA): sum t(t+1) PV(CF) / [P (1+y)^2]."""
    p = price(c, y, n)
    return sum(t * (t + 1) * cf / (1 + y) ** t for t, cf in cash_flows(c, n)) / (p * (1 + y) ** 2)


def main():
    ex = load_exhibit()
    print("=" * 78)
    print("EXHIBIT 1 INPUTS (per GBP 100 face)")
    for n, r in ex.items():
        print(f"  {n:>2}y  coupon {r['coupon']:.2f}%  price {r.get('price', '—')}  ytm {r.get('ytm', '—')}")

    # ---------- Q2: fill in the gaps (annual) ----------
    print("\n" + "=" * 78)
    print("Q2  MISSING VALUES, ANNUAL COUPONS")
    res = {}
    for n, r in ex.items():
        c = r["coupon"]
        if "price" in r:
            p = r["price"]
            y = ytm(c, p, n)
            src = "YTM solved"
        else:
            y = r["ytm"] / 100
            p = price(c, y, n)
            src = "price computed"
        res[n] = dict(c=c, p=p, y=y)
        tag = "premium" if p > 100.005 else "discount" if p < 99.995 else "par"
        print(f"  {n:>2}y  c={c:.2f}%  P={p:7.2f}  YTM={100*y:5.2f}%  ({src}; {tag}: YTM {'<' if y*100 < c else '>'} coupon)")

    # worked example 1: price from YTM (5-year 2.75% at 3.00%)
    print("\n  Worked example A: 5-year 2.75% gilt, YTM 3.00%  ->  price")
    c, y, n = 2.75, 0.03, 5
    tot = 0
    for t, cf in cash_flows(c, n):
        df = 1 / (1 + y) ** t
        tot += cf * df
        print(f"    year {t:.0f}: CF {cf:7.2f} x 1/1.03^{t:.0f} ({df:.4f}) = {cf*df:8.4f}   running {tot:8.4f}")
    print(f"    price = {tot:.4f} = {tot:.2f}")

    # worked example 2: YTM from price (1-year 3.25% at 102.50) - closed form
    print("\n  Worked example B: 1-year 3.25% gilt, price 102.50  ->  YTM")
    print(f"    102.50 = 103.25 / (1 + y)  ->  1 + y = 103.25 / 102.50 = {103.25/102.50:.6f}  ->  y = {100*(103.25/102.50-1):.2f}%")

    # worked example 3: YTM by trial (3-year 4.5% at 107.02)
    print("\n  Worked example C: 3-year 4.5% gilt, price 107.02  ->  YTM by trial and error")
    for g in (0.02, 0.021, res[3]["y"]):
        print(f"    try y = {100*g:.3f}%: price = {price(4.5, g, 3):.4f}")
    print(f"    YTM = {100*res[3]['y']:.2f}%")

    # ---------- Q3: yield curve ----------
    print("\n" + "=" * 78)
    print("Q3  YIELD CURVE POINTS (YTM, annual)")
    ys = [(n, 100 * v["y"]) for n, v in res.items()]
    for (n, y), (_, yp) in zip(ys, [(None, None)] + ys[:-1]):
        print(f"  {n:>2}y  {y:5.2f}%" + ("" if yp is None else f"   change vs previous {100*(y-yp):+5.0f}bp"))
    print(f"  slope 1y->10y: {100*(res[10]['y']-res[1]['y'])*100:+.0f}bp ; 10y->20y: {10000*(res[20]['y']-res[10]['y']):+.0f}bp ;"
          f" 20y->50y: {10000*(res[50]['y']-res[20]['y']):+.0f}bp")

    # ---------- Q4: +1% ----------
    print("\n" + "=" * 78)
    print("Q4  ALL YIELDS +1 PERCENTAGE POINT")
    print("  mat  P0      y0     y1     P1      dP      %dP     MacD   ModD   Conv     dur-only  dur+conv")
    for n, v in res.items():
        c, p0, y0 = v["c"], v["p"], v["y"]
        y1 = y0 + SHIFT
        p1 = price(c, y1, n)
        mac = macaulay(c, y0, n)
        mod = mac / (1 + y0)
        cvx = convexity(c, y0, n)
        est1 = -mod * SHIFT
        est2 = est1 + 0.5 * cvx * SHIFT ** 2
        v.update(p1=p1, mac=mac, mod=mod, cvx=cvx)
        print(f"  {n:>2}y {p0:7.2f} {100*y0:5.2f}% {100*y1:5.2f}% {p1:7.2f} {p1-p0:+7.2f} {100*(p1/p0-1):+7.2f}%"
              f"  {mac:5.2f}  {mod:5.2f} {cvx:7.2f}   {100*est1:+7.2f}%  {100*est2:+7.2f}%")

    print("\n  Worked example D: 10-year 3.75% gilt, YTM 4.04% -> 5.04%")
    c, n, y0 = 3.75, 10, res[10]["y"]
    print(f"    P0 = {res[10]['p']:.2f};  P1 = {res[10]['p1']:.2f};  change = {100*(res[10]['p1']/res[10]['p']-1):.2f}%")
    print(f"    Macaulay D = {res[10]['mac']:.2f} years; modified D = {res[10]['mac']:.2f}/(1+{y0:.4f}) = {res[10]['mod']:.2f}")
    print(f"    duration estimate = -{res[10]['mod']:.2f} x 1% = {-res[10]['mod']:.2f}%")
    print(f"    + convexity: 0.5 x {res[10]['cvx']:.2f} x 0.01^2 = +{100*0.5*res[10]['cvx']*1e-4:.2f}%  ->  {-res[10]['mod']+100*0.5*res[10]['cvx']*1e-4:.2f}%")
    extras(res)
    strict_extras(res)
    r4_extras(res)
    r5_displays(res)
    final_displays(res)


def extras(res):
    line = "=" * 78
    print("\n" + line)
    print("EXTRA (grader, gate 1)")
    # current yield vs coupon vs YTM
    print("  Coupon rate vs current yield vs YTM")
    for n, v in res.items():
        print(f"    {n:>2}y  coupon {v['c']:.2f}%  current yield {100*v['c']/v['p']:.2f}%  YTM {100*v['y']:.2f}%")
    # interpolation for yield search
    print("  Linear interpolation then reprice check (price-given bonds)")
    for n in (3, 7, 20, 50):
        c, p = res[n]["c"], res[n]["p"]
        lo = int(res[n]["y"] * 100) / 100       # bracket by whole percent
        hi = lo + 0.01
        plo, phi = price(c, lo, n), price(c, hi, n)
        yi = lo + (plo - p) / (plo - phi) * (hi - lo)
        print(f"    {n:>2}y  y={100*lo:.2f}% -> {plo:.2f};  y={100*hi:.2f}% -> {phi:.2f};  interpolate: {100*lo:.2f}% + ({plo:.2f}-{p:.2f})/({plo:.2f}-{phi:.2f}) x 1% = {100*yi:.3f}%"
              f"  | exact {100*res[n]['y']:.3f}%  | reprice at exact = {price(c, res[n]['y'], n):.2f}")
    # approximate convexity and duration from +/- 1bp... use CFA approximation with dy = 1%
    print("  CFA approximations with dy = 1%: ApproxModDur = (P- - P+)/(2 x P0 x dy); ApproxCon = (P- + P+ - 2P0)/(P0 x dy^2)")
    for n in (1, 10, 50):
        c, p0, y = res[n]["c"], res[n]["p"], res[n]["y"]
        pm, pp = price(c, y - 0.01, n), price(c, y + 0.01, n)
        print(f"    {n:>2}y  P- {pm:.2f}  P+ {pp:.2f}  P0 {p0:.2f}  ApproxModDur {(pm-pp)/(2*p0*0.01):.2f}  ApproxCon {(pm+pp-2*p0)/(p0*1e-4):.2f}")
    # money on a GBP 1m face holding and PVBP
    print("  Money change on GBP 1,000,000 face, and PVBP (price value of a basis point) per GBP 1m face")
    for n, v in res.items():
        c, p0, y = v["c"], v["p"], v["y"]
        dm = (price(c, y + 0.01, n) - p0) * 10000
        pvbp = (price(c, y - 0.0001, n) - price(c, y + 0.0001, n)) / 2 * 10000
        print(f"    {n:>2}y  value {p0*10000:,.0f}  change at +1% {dm:+,.0f}  PVBP {pvbp:,.0f}")
    # bootstrapped spot and implied forward rates from 1,2,3-year bonds
    z1 = res[1]["y"]
    c2, p2 = res[2]["c"], res[2]["p"]
    z2 = ((100 + c2) / (p2 - c2 / (1 + z1))) ** 0.5 - 1
    c3, p3 = res[3]["c"], res[3]["p"]
    z3 = ((100 + c3) / (p3 - c3 / (1 + z1) - c3 / (1 + z2) ** 2)) ** (1 / 3) - 1
    f11 = (1 + z2) ** 2 / (1 + z1) - 1
    f21 = (1 + z3) ** 3 / (1 + z2) ** 2 - 1
    print("  Bootstrapped spot rates and implied 1-year forwards")
    print(f"    z1 = {100*z1:.2f}%")
    print(f"    z2: {p2:.2f} = {c2}/(1+{z1:.4f}) + {100+c2}/(1+z2)^2  ->  z2 = {100*z2:.2f}%")
    print(f"    z3: {p3:.2f} = {c3}/(1+z1) + {c3}/(1+z2)^2 + {100+c3}/(1+z3)^3  ->  z3 = {100*z3:.2f}%")
    print(f"    1y forward in 1 year (1y1y) = (1+z2)^2/(1+z1) - 1 = {100*f11:.2f}%;  2y1y = {100*f21:.2f}%")

    # reinvestment risk: 20-year 4.75% bought at 104.93 (YTM 4.38%), held to maturity
    print("  Reinvestment risk: 20-year 4.75% gilt bought at 104.93, held 20 years")
    c, p0, n = 4.75, res[20]["p"], 20
    for r in (res[20]["y"], 0.02, 0.0):
        fv = sum(c * (1 + r) ** (n - t) for t in range(1, n + 1)) + 100
        print(f"    coupons reinvested at {100*r:.2f}%: end value {fv:.2f}; realised return ({fv:.2f}/{p0:.2f})^(1/20) - 1 = {100*((fv/p0)**(1/n)-1):.2f}%")
    # coupon effect: same maturity, different coupon (hypothetical 10y 0% and 8% at 4.04%)
    print("  Coupon effect on rate risk (hypothetical 10-year bonds at 4.04%)")
    for c in (0.0, 3.75, 8.0):
        y = res[10]["y"]
        p0, p1 = price(c, y, 10), price(c, y + 0.01, 10)
        print(f"    coupon {c:.2f}%  P0 {p0:.2f}  +1% {p1:.2f}  change {100*(p1/p0-1):+.2f}%  ModD {macaulay(c, y, 10)/(1+y):.2f}")


def strict_extras(res):
    print("\n" + "=" * 78)
    print("STRICT REVIEW ADDITIONS (gate 1)")
    # reinvestment FV formula
    c, p0, n = 4.75, res[20]["p"], 20
    for r in (res[20]["y"], 0.02):
        f = ((1 + r) ** n - 1) / r
        fv = c * f + 100
        print(f"  FV of coupons at {100*r:.4f}%: 4.75 x [(1+r)^20 - 1]/r = 4.75 x {f:.4f} = {c*f:.2f}; + 100 = {fv:.2f};"
              f" realised return = ({fv:.2f}/{p0:.2f})^(1/20) - 1 = {100*((fv/p0)**(1/n)-1):.2f}%")
    # semi-annual worked example: 2-year at 1.74%
    print("  Semi-annual worked example: 2-year 5.25% at 1.74% a year = 0.87% per half-year")
    tot = 0
    for k in range(1, 5):
        cf = 2.625 + (100 if k == 4 else 0)
        df = 1 / 1.0087 ** k
        tot += cf * df
        print(f"    half-year {k}: {cf:7.3f} x 1/1.0087^{k} ({df:.6f}) = {cf*df:7.3f}")
    print(f"    price = {tot:.2f} (annual-pay 106.84)")
    # Macaulay duration step tables for all nine
    for n, v in res.items():
        c, y, p0 = v["c"], v["y"], v["p"]
        rows = [(t, cf, cf / (1 + y) ** t) for t, cf in cash_flows(c, n)]
        mac = sum(t * pv for t, cf, pv in rows) / p0
        print(f"  Duration {n}y (c {c}%, y {100*y:.2f}%, P {p0:.2f}): MacD = sum(t x PV)/P = {sum(t*pv for t,cf,pv in rows):.2f}/{p0:.2f} = {mac:.2f};"
              f" ModD = {mac:.2f}/(1+{y:.4f}) = {mac/(1+y):.2f}")
        if n in (5, 50):
            show = rows if n == 5 else rows[:3] + rows[-2:]
            for t, cf, pv in show:
                print(f"      t={t:>4.0f}  CF {cf:7.2f}  PV {pv:7.2f}  weight {pv/p0:.4f}  t x weight {t*pv/p0:.4f}")
    # analytic convexity step: 10y and 50y
    for n in (10, 50):
        c, y, p0 = res[n]["c"], res[n]["y"], res[n]["p"]
        sm = sum(t * (t + 1) * cf / (1 + y) ** t for t, cf in cash_flows(c, n))
        print(f"  Convexity {n}y: sum[t(t+1) x PV(CF)] / [P x (1+y)^2] = {sm:.1f} / ({p0:.2f} x {(1+y)**2:.4f}) = {sm/(p0*(1+y)**2):.2f}")
    # -1% worked (50y) and money on GBP 100m face
    c, y, p0 = 4, res[50]["y"], res[50]["p"]
    ann = (1 - (1 + y - 0.01) ** -50) / (y - 0.01)
    print(f"  -1% worked, 50y: y = {100*(y-0.01):.2f}%: 4 x {ann:.4f} + 100/{(1+y-0.01)**50:.4f} = {4*ann:.2f} + {100/(1+y-0.01)**50:.2f} = {price(4, y-0.01, 50):.2f} ({100*(price(4,y-0.01,50)/p0-1):+.2f}%)")
    print("  Money on GBP 100m face: value, change at +1%, PVBP (GBP m)")
    for n, v in res.items():
        c, p0, y = v["c"], v["p"], v["y"]
        print(f"    {n:>2}y  value £{p0:.1f}m  +1%: £{price(c, y+0.01, n)-p0:+.1f}m  PVBP £{(price(c,y-0.0001,n)-price(c,y+0.0001,n))/2:.3f}m")
    c, y = 4, res[50]["y"]
    print(f"  PVBP worked, 50y: [P(y-0.01%) - P(y+0.01%)]/2 = [{price(c,y-0.0001,50):.4f} - {price(c,y+0.0001,50):.4f}]/2 = {(price(c,y-0.0001,50)-price(c,y+0.0001,50))/2:.4f} per £100 -> £{(price(c,y-0.0001,50)-price(c,y+0.0001,50))/2:.4f}m per £100m")

    # closed-form Macaulay duration (CFA): D = (1+y)/y - [(1+y) + N(c-y)] / [c((1+y)^N - 1) + y]
    # short t x PV tables for 2y and 3y; convexity table 10y
    for n in (2, 3):
        c, y, p0 = res[n]["c"], res[n]["y"], res[n]["p"]
        print(f"  {n}y duration table: " + "; ".join(f"t{t:.0f}: PV {cf/(1+y)**t:.4f}, t x PV {t*cf/(1+y)**t:.4f}" for t, cf in cash_flows(c, n)))
    c, y, p0 = res[10]["c"], res[10]["y"], res[10]["p"]
    print("  10y convexity table: t, CF, PV, t(t+1) x PV")
    for t, cf in cash_flows(c, 10):
        pv = cf / (1 + y) ** t
        print(f"    t={t:>2.0f}  {cf:7.2f}  {pv:7.4f}  {t*(t+1)*pv:9.2f}")
    # price-based convexity, 5bp step, 50y
    c, y, p0 = 4, res[50]["y"], res[50]["p"]
    pm, pp = price(c, y - 0.0005, 50), price(c, y + 0.0005, 50)
    print(f"  50y convexity, CFA price-based with 5bp step: ({pm:.4f} + {pp:.4f} - 2 x {p0:.2f}) / ({p0:.2f} x 0.0005^2) = {(pm+pp-2*p0)/(p0*0.0005**2):.2f}")
    print(f"  50y ApproxModDur with 1% step: ({price(c,y-0.01,50):.4f} - {price(c,y+0.01,50):.4f})/(2 x {p0:.2f} x 0.01) = {(price(c,y-0.01,50)-price(c,y+0.01,50))/(2*p0*0.01):.2f}")
    # annuity form with 4 dp
    for n in (5, 10):
        c, y = res[n]["c"], res[n]["y"]
        ann = (1 - (1 + y) ** -n) / y
        pass  # removed (round 8): superseded by final_displays()
    # real bond, like-for-like yields (both semi-annual)
    y0, ysa, md = 3.364984, 5.658, 22.24
    print(f"  4% 2060 like-for-like (semi-annual both): {y0:.3f}% -> {ysa:.3f}% = +{100*(ysa-y0):.0f}bp; duration-only -{md} x {(ysa-y0)/100:.5f} = {-md*(ysa-y0):.1f}%; actual -34.4%;"
          f" check annual-compounded equivalent (1+{ysa/100}/2)^2-1 = {100*((1+ysa/200)**2-1):.3f}%")


def r4_extras(res):
    """Strict review round 4 (Gilts): reproducible displays and one slide per bond for PVBP and -1%."""
    from datetime import date
    print("\n" + "=" * 78)
    print("STRICT REVIEW ROUND 4 ADDITIONS")
    c, p0 = 4.75, res[20]["p"]
    for r in (res[20]["y"], 0.02):
        f = ((1 + r) ** 20 - 1) / r
        pass  # removed (round 8): superseded by final_displays()
    # bootstrap with the rearrangement
    y1 = res[1]["y"]; z1 = y1
    a = res[2]["c"] / (1 + z1)
    rest = res[2]["p"] - a
    z2 = (105.25 / rest) ** 0.5 - 1
    print(f"  bootstrap 2y: 106.84 - 5.25/{1+z1:.6f} = 106.84 - {a:.2f} = {rest:.2f}; (1+z2)^2 = 105.25/{rest:.2f} = {105.25/rest:.4f}; z2 = {100*z2:.2f}%  (1+z2 = {1+z2:.6f})")
    b1, b2 = 4.5 / (1 + z1), 4.5 / (1 + z2) ** 2
    rest3 = res[3]["p"] - b1 - b2
    z3 = (104.5 / rest3) ** (1 / 3) - 1
    print(f"  bootstrap 3y: 107.02 - {b1:.4f} - {b2:.4f} = {rest3:.4f}; (1+z3)^3 = 104.5/{rest3:.4f} = {104.5/rest3:.4f}; z3 = {100*z3:.2f}%  (1+z3 = {1+z3:.6f})")
    f11 = (1 + z2) ** 2 / (1 + z1) - 1
    f21 = (1 + z3) ** 3 / (1 + z2) ** 2 - 1
    print(f"  1y1y = {1+z2:.6f}^2 / {1+z1:.6f} - 1 = {(1+z2)**2:.6f}/{1+z1:.6f} - 1 = {100*f11:.2f}%")
    print(f"  2y1y = {1+z3:.6f}^3 / {1+z2:.6f}^2 - 1 = {(1+z3)**3:.6f}/{(1+z2)**2:.6f} - 1 = {100*f21:.2f}%")
    c, y, p0 = res[7]["c"], res[7]["y"], res[7]["p"]
    stp = sum(t * cf / (1 + y) ** t for t, cf in cash_flows(c, 7))
    print(f"  7y check: sum(t x PV)/P = {stp:.2f}/{p0:.2f} = {stp/p0:.2f}")
    # convexity 50y with 6 dp prices
    c, y, p0 = 4, res[50]["y"], res[50]["p"]
    pm, pp = price(c, y - 0.0005, 50), price(c, y + 0.0005, 50)
    print(f"  50y convexity 6dp: yield {100*(y-0.0005):.4f}% -> {pm:.6f}; {100*(y+0.0005):.4f}% -> {pp:.6f}; ({pm:.6f} + {pp:.6f} - 2 x {p0:.6f}) = {pm+pp-2*p0:.6f}; / ({p0:.2f} x 0.0005^2 = {p0*0.0005**2:.8f}) = {(pm+pp-2*p0)/(p0*0.0005**2):.2f}")
    # one slide per bond: PVBP
    print("  PVBP per bond (per £100; £m on £100m face)")
    for n, v in res.items():
        c, y = v["c"], v["y"]
        lo, hi = price(c, y - 0.0001, n), price(c, y + 0.0001, n)
        print(f"    {n:>2}y: P at {100*(y-0.0001):.4f}% = {lo:.4f}; P at {100*(y+0.0001):.4f}% = {hi:.4f}; ({lo:.4f} - {hi:.4f})/2 = {(lo-hi)/2:.4f} -> £{(lo-hi)/2:.3f}m (£{1000*(lo-hi)/2:.1f} thousand)")
    # current yield and money rows with numbers
    for n, v in res.items():
        c, y, p0 = v["c"], v["y"], v["p"]
        pu = price(c, y + 0.01, n)
        print(f"    {n:>2}y current yield {c}/{p0:.2f} = {100*c/p0:.2f}%;  £100m face: value £{p0:.1f}m -> £{pu:.1f}m at +1% = £{pu-p0:+.1f}m")
    # 4% 2060 instant +229bp shock on the 2014 bond (semi-annual, settle 9 May 2014, matures 22 Jan 2060)
    settle, mat = date(2014, 5, 9), date(2060, 1, 22)
    last, nxt = date(2014, 1, 22), date(2014, 7, 22)
    frac = (nxt - settle).days / (nxt - last).days
    npay = 2 * (2060 - 2014)  # coupons from Jul 2014 to Jan 2060
    def dirty(ys):
        h = ys / 200
        return sum((2 + (100 if k == npay - 1 else 0)) / (1 + h) ** (k + frac) for k in range(npay))
    acc = 2 * (1 - frac)
    c0 = dirty(3.364984) - acc; c1 = dirty(5.658) - acc
    print(f"  4% 2060 instant shock (2014 bond, {npay} coupons, first in {frac:.4f} half-years): clean at 3.365% = {c0:.2f} (DMO 114.76); at 5.658% = {c1:.2f}; change {100*(c1/c0-1):.1f}% (vs duration-only -51.0%, actual -34.4% after 12 years)")


def r5_displays(res):
    """Strict review round 5: every per-bond display built from the ROUNDED numbers shown on the slide,
    so each line reproduces on a calculator; asserts the shown result equals the exact answer to 2 dp."""
    print("\n" + "=" * 78)
    print("ROUND 5 SLIDE DISPLAYS (each line reproduces from the numbers shown)")
    def disp(c, y_pct4, n, freq=1):
        y = round(y_pct4, 4) / 100
        cc, k, m = c / freq, y / freq, n * freq
        af = round((1 - (1 + k) ** -m) / k, 6) if k else float(m)
        dfac = round((1 + k) ** m, 6)
        t1, t2 = round(cc * af, 4), round(100 / dfac, 4)
        return af, dfac, t1, t2, round(t1 + t2, 2)
    for shift, lab in ((0.01, "+1%"), (-0.01, "-1%")):
        print(f"  {lab} per bond: P = C x [1-(1+y)^-N]/y + 100/(1+y)^N  (yield to 4 dp)")
        for n, v in res.items():
            c, p0 = v["c"], v["p"]
            yp = round(100 * (v["y"] + shift), 4)
            af, dfac, t1, t2, pr = disp(c, yp, n)
            exact = round(price(c, v["y"] + shift, n), 2)
            assert abs(pr - exact) < 0.0051, (n, lab, pr, exact)
            s4 = round(t1 + t2, 4); o4 = round(p0, 4)
            chg = round(100 * (s4 / o4 - 1), 2); ex = round(100 * (price(c, v["y"] + shift, n) / p0 - 1), 2)
            assert chg == ex, (n, lab, chg, ex)
            print(f"    {n:>2}y at {yp:.4f}%: {c} x {af:.6f} + 100/{dfac:.6f} = {t1:.4f} + {t2:.4f} = {s4:.4f} = {pr:.2f}; change {s4:.4f}/{o4:.4f} - 1 = {chg:+.2f}%")
    print("  semi-annual per bond: P = C/2 x [1-(1+y/2)^-2N]/(y/2) + 100/(1+y/2)^2N  (yield to 4 dp)")
    for n, v in res.items():
        c, p0 = v["c"], v["p"]
        given_price = n in (1, 3, 7, 20, 50)
        yp = round(100 * (ytm(c, p0, n, freq=2) if given_price else v["y"]), 4)
        af, dfac, t1, t2, pr = disp(c, yp, n, freq=2)
        tag = f"price {p0:.2f} given: solved semi-annual yield {yp:.4f}% (annual-pay {100*v['y']:.4f}%); check" if given_price else f"yield {yp:.4f}% given:"
        print(f"    {n:>2}y {tag} {c/2} x {af:.6f} + 100/{dfac:.6f} = {t1:.4f} + {t2:.4f} = {pr:.2f} (annual-pay {p0:.2f})")
    # bootstrap 3y to 4 dp
    z1 = res[1]["y"]; z2 = (105.25 / (res[2]["p"] - 5.25 / (1 + z1))) ** 0.5 - 1
    a, b = round(4.5 / (1 + z1), 4), round(4.5 / (1 + z2) ** 2, 4)
    rest = round(res[3]["p"] - a - b, 4)
    print(f"  bootstrap 3y 4dp: 107.02 - {a:.4f} - {b:.4f} = {rest:.4f}; (1+z3)^3 = 104.5/{rest:.4f} = {104.5/rest:.4f}; z3 = {100*((104.5/rest)**(1/3)-1):.2f}%")
    # closed form, 6 dp inputs
    for n in (7, 10, 20, 30, 50):
        cc, y = res[n]["c"] / 100, res[n]["y"]
        A = round((1 + y) / y, 4); num = round((1 + y) + n * (cc - y), 6); den = round(cc * ((1 + y) ** n - 1) + y, 6)
        q = round(num / den, 4)
        print(f"    closed form {n}y 6dp: {A:.4f} - {num:.6f}/{den:.6f} = {A:.4f} - {q:.4f} = {A-q:.2f}")
    # 10y annuity at 4 dp product
    y10 = res[10]["y"]; af10 = round((1 - (1 + y10) ** -10) / y10, 4)
    pass  # removed (round 8): superseded by final_displays()
    # coupon effect, 10-year at 4.04% -> 5.04%
    for c in (0, 3.75, 8):
        p0, p1 = price(c, 0.0404, 10) if c else 100 / 1.0404 ** 10, price(c, 0.0504, 10) if c else 100 / 1.0504 ** 10
        af0 = (1 - 1.0404 ** -10) / 0.0404; af1 = (1 - 1.0504 ** -10) / 0.0504
        pass  # removed (round 8): superseded by final_displays()
    # approximate convexity at +/-1%
    c, y, p0 = 4, res[50]["y"], res[50]["p"]
    pm, pp = price(c, y - 0.01, 50), price(c, y + 0.01, 50)
    # round 6: exact-yield labels for the 50-year, and 4-dp tables
    ye = res[50]["y"]
    print(f"  50y exact yield {100*ye:.6f}%")
    for d in (0.0005, 0.0001, 0.01):
        print(f"    50y at {100*(ye-d):.6f}% = {price(4, ye-d, 50):.6f}; at {100*(ye+d):.6f}% = {price(4, ye+d, 50):.6f}")
    pm, pp = round(price(4, ye-0.01, 50), 4), round(price(4, ye+0.01, 50), 4)
    print(f"  50y ApproxCon 4dp: ({pm:.4f} + {pp:.4f} - 189.9200) = {pm+pp-189.92:.4f}; / 0.009496 = {(pm+pp-189.92)/0.009496:.2f}")
    y20 = res[20]["y"]; f = ((1 + y20) ** 20 - 1) / y20
    pass  # removed (round 8): superseded by final_displays()
    y5 = res[5]["y"]
    print("  5y PVs 4dp: " + " + ".join(f"{(2.75+(100 if t==5 else 0))/1.03**t:.4f}" for t in range(1,6)) + f" = {sum((2.75+(100 if t==5 else 0))/1.03**t for t in range(1,6)):.4f}")
    pass  # removed (round 8): superseded by final_displays()
    for n in (7, 10, 20, 30, 50):
        print(f"    {n}y exact yield used {100*res[n]['y']:.6f}%")
    for c in (0, 3.75, 8):
        a = price(c, 0.0404, 10) if c else 100/1.0404**10; b = price(c, 0.0504, 10) if c else 100/1.0504**10
        pass  # removed (round 8): superseded by final_displays()
    pass  # removed (round 8): superseded by final_displays()
    print(f"  50y ApproxCon: ({pm:.4f} + {pp:.4f} - 2 x {p0:.2f}) / ({p0:.2f} x 0.01^2) = {pm+pp-2*p0:.4f}/{p0*0.0001:.6f} = {(pm+pp-2*p0)/(p0*0.0001):.2f}; half x 701.03 x 0.0001 = {0.5*701.03*0.0001*100:.2f}%")


def final_displays(res):
    """Round 8: the exact display lines used on slides 29, 30, 44, 45, 46, 47, 85 and 108.
    Each step is computed from the rounded numbers SHOWN, and asserted against the exact answer."""
    print("\n" + "=" * 78)
    print("FINAL SLIDE DISPLAYS (slides 29, 30, 44-47, 85, 108); every line reproduces from the numbers shown")
    def r(x, d): return round(x, d)
    # 29: FV of coupons on the 20-year at its YTM shown to 4 dp (4.3751%), and at 2%
    for yp in (4.3751, 2.0):
        y = yp / 100; f = r(((1 + y) ** 20 - 1) / y, 4); fv = r(4.75 * f, 2)
        print(f"  29: at {yp:.4f}%: 4.75 x {f:.4f} = {fv:.2f} (+100 = {fv+100:.2f})")
    assert r(4.75 * 30.9642, 2) == 147.08 and r(4.75 * 24.2974, 2) == 115.41
    print(f"  30: realised return (215.41/104.93)^(1/20) - 1 = {100*((215.41/104.93)**0.05-1):.2f}%; at 0%: 4.75 x 20 = 95, +100 = 195, (195/104.93)^(1/20) - 1 = {100*((195/104.93)**0.05-1):.2f}%")
    # 44-47: price from yield, factor 6 dp, terms 4 dp
    for slide, n in ((44, 5), (45, 2), (46, 10), (47, 30)):
        c, y, pex = res[n]["c"], res[n]["y"], res[n]["p"]
        af = r((1 - (1 + y) ** -n) / y, 6)
        t1, t2 = r(c * af, 4), r(100 / (1 + y) ** n, 4); tot = r(t1 + t2, 4)
        assert abs(tot - pex) < 0.00015 and r(tot, 2) == r(pex, 2), (slide, tot, pex)
        extra = f" (= 100/{(1+y)**n:.6f})" if slide == 47 else ""
        print(f"  {slide}: {n}y at {100*y:.2f}%: {c} x {af:.6f} = {t1:.4f}; + 100/{1+y:.4f}^{n}{extra} = {t2:.4f}; = {tot:.4f} = {tot:.2f}  (exact {pex:.4f})")
    # 85: money on GBP 100m face, using the +1% display prices of slides 75-83
    print("  85: GBP m on GBP 100m face, +1% prices as on slides 75-83:")
    for n, v in res.items():
        c = v["c"]; yp = r(100 * (v["y"] + 0.01), 4); y = yp / 100
        af = r((1 - (1 + y) ** -n) / y, 6); dfac = r((1 + y) ** n, 6)
        new = r(r(c * af, 4) + r(100 / dfac, 4), 4); old = r(v["p"], 4)
        assert abs(new - price(c, v["y"] + 0.01, n)) < 0.0006
        print(f"    {n:>2}y {old:.4f} -> {new:.4f} = {new-old:+.4f}  (GBP m: {new-old:+.1f})")
    # 108: coupon effect, 10-year, 4.04% -> 5.04%
    a0, a1 = r((1 - 1.0404 ** -10) / 0.0404, 6), r((1 - 1.0504 ** -10) / 0.0504, 6)
    d0, d1 = r(100 / 1.0404 ** 10, 4), r(100 / 1.0504 ** 10, 4)
    print(f"  108: annuity factors {a0:.6f} -> {a1:.6f}; PV of 100 {d0:.4f} -> {d1:.4f}")
    for c, want in ((0, -9.12), (3.75, -7.78), (8, -7.00)):
        p0 = r(r(c * a0, 4) + d0, 4); p1 = r(r(c * a1, 4) + d1, 4); ch = r(100 * (p1 / p0 - 1), 2)
        assert ch == want, (c, ch)
        print(f"    {c}%: {c} x {a0:.6f} = {r(c*a0,4):.4f}, + {d0:.4f} = {p0:.4f} -> {c} x {a1:.6f} = {r(c*a1,4):.4f}, + {d1:.4f} = {p1:.4f}; change {ch:+.2f}%")
    print(f"  70: real 9 May 2014 dip (DMO): 4.5% 2042 3.393% vs 4% 2060 3.365% = {100*(3.393-3.365):.1f}bp")


if __name__ == "__main__":
    main()
