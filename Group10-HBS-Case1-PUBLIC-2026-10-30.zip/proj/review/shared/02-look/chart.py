# Generates the Exhibit 3 change chart slide (bars as native divs) for both directions.
import sys
mats = ["1M","3M","6M","1Y","2Y","3Y","5Y","7Y","10Y","20Y","30Y"]
y11 = [0.02,0.04,0.07,0.18,0.54,0.93,1.83,2.50,3.15,3.99,4.28]   # 16 May 2011, exhibits.csv / Treasury CSV
y15 = [0.02,0.05,0.15,0.26,0.66,1.06,1.57,1.90,2.10,2.45,2.67]   # 16 Mar 2015
ch = [round((b-a)*100) for a,b in zip(y11,y15)]
assert ch[6]==-26 and ch[8]==-105, ch
def slide(sid, P, page):
    S = 1.75; UP = 64; DN = 324
    cols = []
    for m, c in zip(mats, ch):
        hi = m in ("5Y","10Y")
        col = P["hi"] if hi else P["bar"]
        lab = ("+" if c > 0 else ("−" if c < 0 else "")) + str(abs(c))
        h = max(round(abs(c)*S), 3)
        up = f'<div style="height:{UP}px;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;gap:4px">' + \
             (f'<p style="font-size:36px;line-height:1;color:{P["ink"]}{";font-weight:600" if hi else ""}">{lab}</p><div style="width:72px;height:{h}px;background:{col}"></div>' if c >= 0 else '') + '</div>'
        dn = f'<div style="height:{DN}px;display:flex;flex-direction:column;justify-content:flex-start;align-items:center;gap:4px;border-top:2px solid {P["ink"]}">' + \
             (f'<div style="width:72px;height:{h}px;background:{col}"></div><p style="font-size:36px;line-height:1;color:{P["ink"]}{";font-weight:600" if hi else ""}">{lab}</p>' if c < 0 else '') + '</div>'
        cols.append(f'<div style="flex:1;display:flex;flex-direction:column">{up}{dn}<p style="font-size:36px;text-align:center;color:{P["body"]}{";font-weight:600" if hi else ""}">{m}</p></div>')
    return f'''<section id="{sid}" style="background:{P["bg"]};color:{P["ink"]};font-family:Inter, Arial, sans-serif;padding:{P["pad"]};display:flex;flex-direction:column;gap:24px">
{P.get("top","")}<h2 style="font-family:Inter, Arial, sans-serif;font-size:64px;font-weight:{P["tw"]};line-height:1.1;letter-spacing:-2px;color:{P["ink"]}">The 10-year Treasury fell 105bp, the 5-year only 26bp</h2>
<p style="font-size:36px;line-height:1.3;color:{P["body"]}">Exhibit 3 as a change: Treasury yield change in bp (1bp = 0.01%), by time to maturity, May 2011 → Mar 2015</p>
<div style="display:flex;gap:0px">{"".join(cols)}</div>
<p style="font-size:36px;line-height:1.35;color:{P["ink"]}"><b>So what:</b> at JLR’s 5-year length, Treasuries explain only 26bp of the 462bp coupon fall.</p>
<p style="position:absolute;left:128px;bottom:64px;width:1400px;font-size:24px;letter-spacing:0.2px;color:{P["body"]}">Source: Exhibit 3, case; rebuilt from US Treasury daily par yields (home.treasury.gov), 16 May 2011 and 16 Mar 2015.</p>
{P.get("pn","")}
</section>
'''
A = dict(bg="#F6F6FB", ink="#16143A", body="#3F3D5E", hi="#3B2FD9", bar="#8B83E6", tw=300, pad="128px 128px 160px",
         pn='<p style="position:absolute;right:128px;bottom:64px;width:120px;font-size:24px;text-align:right;color:#3F3D5E">39</p>')
B = dict(bg="#FAFAF6", ink="#141414", body="#3E4139", hi="#1E3A2A", bar="#8E937F", tw=400, pad="160px 128px 160px",
         top='<div style="position:absolute;left:128px;top:96px;width:1664px;height:2px;background:#141414"></div><p style="position:absolute;right:128px;top:52px;width:200px;font-family:\'IBM Plex Mono\', \'Courier New\', monospace;font-size:24px;text-align:right;color:#141414">39</p>\n')
out = sys.argv[1]
open(f"{out}/a-chart.html","w").write(slide("a-chart", A, 39))
open(f"{out}/b-chart.html","w").write(slide("b-chart", B, 39))
print(ch)
