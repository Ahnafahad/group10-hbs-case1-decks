# Approximate local render of Slides-format sections: checks overflow past y=920 (flow content), min font size, and saves PNGs (+ greyscale).
import sys, glob, os, re, json
from playwright.sync_api import sync_playwright
src, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
CSS = """*{margin:0;padding:0;box-sizing:border-box} body{width:1920px;height:1080px;overflow:hidden}
section{position:relative;width:1920px;height:1080px;overflow:hidden}
table{border-collapse:collapse;width:100%} td,th{padding:12px 20px;border-bottom:1px solid rgba(0,0,0,.25);text-align:left}
ul,ol{padding-left:1.2em} x-connector,x-shape{display:none}"""
JS = """() => { const r=[]; const sec=document.querySelector('section');
 for (const el of sec.querySelectorAll('*')) { const cs=getComputedStyle(el); const b=el.getBoundingClientRect();
   const txt = el.childNodes && [...el.childNodes].some(n=>n.nodeType===3 && n.textContent.trim());
   const fs=parseFloat(cs.fontSize); const pinned=cs.position==='absolute';
   if (txt && fs<24) r.push('small font '+fs+'px: '+el.textContent.trim().slice(0,40));
   if (txt && fs<36 && !pinned) r.push('under 36px in flow '+fs+'px: '+el.textContent.trim().slice(0,40));
   if (!pinned && b.bottom>921 && b.height>0 && el.tagName!=='DIV') r.push('flow past 920: '+el.tagName+' bottom '+Math.round(b.bottom)+' '+el.textContent.trim().slice(0,40));
   if (txt && el.scrollWidth>el.clientWidth+2 && cs.whiteSpace!=='nowrap') r.push('h-overflow: '+el.textContent.trim().slice(0,40));
 } return r; }"""
with sync_playwright() as p:
    br = p.chromium.launch(); pg = br.new_page(viewport={"width":1920,"height":1080})
    for f in sorted(glob.glob(src+"/*.html")):
        html = open(f).read()
        pg.set_content(f"<html><head><style>{CSS}</style></head><body>{html}</body></html>")
        pg.wait_for_timeout(150)
        issues = pg.evaluate(JS)
        name = os.path.basename(f)[:-5]
        pg.screenshot(path=f"{out}/{name}.png")
        print(name, "OK" if not issues else issues)
    br.close()
