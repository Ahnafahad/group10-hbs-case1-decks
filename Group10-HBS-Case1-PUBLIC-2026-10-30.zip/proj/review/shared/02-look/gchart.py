# Gilts yield-curve sample (look A): SVG line + dots (no text), all labels as <p>. Data: Exhibit 1 + Q2 answers (calcs.py).
import sys
mats = [1, 2, 3, 5, 7, 10, 20, 30, 50]
ytm  = [0.73, 1.74, 2.06, 3.00, 3.54, 4.04, 4.38, 4.36, 4.24]
W, H, X0, Y0 = 1480, 330, 140, 56          # svg size and its position inside the host
x = lambda t: 12 + t / 50 * (W - 24)
y = lambda v: H - v / 5 * H
grid = "".join(f'<line x1="0" y1="{y(v):.1f}" x2="{W}" y2="{y(v):.1f}" stroke="#DCD9F2" stroke-width="2"/>' for v in (1, 2, 3, 4, 5))
pts = " ".join(f"{x(t):.1f},{y(v):.1f}" for t, v in zip(mats, ytm))
dots = "".join(f'<circle cx="{x(t):.1f}" cy="{y(v):.1f}" r="9" fill="#3B2FD9"/>' for t, v in zip(mats, ytm))
svg = (f'<svg aria-label="Yield curve of the nine gilts" width="{W}" height="{H}" viewBox="0 0 {W} {H}" style="position:absolute;left:{X0}px;top:{Y0}px;width:{W}px;height:{H}px">'
       f'{grid}<line x1="0" y1="{H}" x2="{W}" y2="{H}" stroke="#16143A" stroke-width="2"/>'
       f'<polyline points="{pts}" fill="none" stroke="#3B2FD9" stroke-width="5"/>{dots}</svg>')
P = []
P.append(f'<p style="position:absolute;left:0px;top:0px;width:700px;font-size:36px;color:#3F3D5E">Yield to maturity (%)</p>')
for v in (0, 1, 2, 3, 4, 5):
    P.append(f'<p style="position:absolute;left:0px;top:{Y0 + y(v) - 22:.0f}px;width:110px;font-size:36px;text-align:right;color:#3F3D5E">{v}</p>')
for t in (0, 10, 20, 30, 40, 50):
    P.append(f'<p style="position:absolute;left:{X0 + x(t) - 50:.0f}px;top:{Y0 + H + 10}px;width:100px;font-size:36px;text-align:center;color:#3F3D5E">{t}</p>')
P.append(f'<p style="position:absolute;left:{X0 + W - 520}px;top:{Y0 + H + 58}px;width:520px;font-size:36px;text-align:right;color:#3F3D5E">Years to maturity</p>')
for t, v, dx, dy in ((1, 0.73, 18, -10), (10, 4.04, -60, -70), (20, 4.38, -60, -70), (50, 4.24, -150, -70)):
    P.append(f'<p style="position:absolute;left:{X0 + x(t) + dx:.0f}px;top:{Y0 + y(v) + dy:.0f}px;width:140px;font-size:36px;font-weight:600;color:#16143A">{v:.2f}</p>')
host = f'<div style="position:relative;width:1664px;height:{Y0 + H + 106}px">{svg}{"".join(P)}</div>'
html = f'''<section id="g-chart" style="background:#F6F6FB;color:#16143A;font-family:Inter, Arial, sans-serif;padding:128px 128px 160px;display:flex;flex-direction:column;gap:24px">
<h2 style="font-family:Inter, Arial, sans-serif;font-size:64px;font-weight:300;line-height:1.1;letter-spacing:-2px;color:#16143A">Exhibit 1’s curve rises steeply to 10 years, is flat to 30, and dips to 4.24% at 50</h2>
{host}
<p style="font-size:36px;line-height:1.35;color:#16143A"><b style="color:#3B2FD9">So what:</b> +331bp of the +365bp rise to the 20-year peak comes in the first ten years.</p>
<p style="position:absolute;left:128px;bottom:64px;width:1400px;font-size:24px;letter-spacing:0.2px;color:#4A4868">Source: Exhibit 1, case; missing yields from our Q2 answers (calcs.py). Annual-pay yields. bp = 0.01%.</p>
<p style="position:absolute;right:128px;bottom:64px;width:120px;font-size:24px;letter-spacing:0.2px;text-align:right;color:#4A4868">60</p>
</section>
'''
open(sys.argv[1] + "/g-chart.html", "w").write(html)
print(len(html))
