NOT READY. Grade estimate B+ (A− once the blocking items below are fixed). The plan is much better than in round 2. Q2 now leads with the call value, the toolkit comes first, Q3 has PV tables, and the epilogue is sourced up to Q1 FY27. But it still has four finance errors in the Q3/Q4 numbers and arguments, a missing after-tax table, lucidity gaps, and several unsupported or label titles.

# Jaguar storyline: strict independent review, round 3 (gate 1)

Deliverable: `review/jaguar/01-storyline.md` (127 slides). I checked it against the rubric, the brief, `case-layout.txt`, CLAUDE.md, DESIGN.md, PROGRESS.md, the output of `python3 work/jaguar/calcs.py`, `exhibits.csv`, `answers.md`, `sources.md` and `sources_research.md` (all of it, including round 3). I also skimmed the G1 NESA benchmark. I did not take the plan's "Response to the strict review" on trust; every claim in it was checked against the plan itself.

## 0. Were the round-2 blocking items fixed?

| Item | Status | Evidence |
|---|---|---|
| B1 Lucidity | **PARTLY FIXED** | Fixed: a toolkit (18–24) now comes before the exhibits; NPV concept (84); MM and efficiency (103); the per-slide items listed in round 2 (tender/consent/covenant on 16, arrows on 17, ISIN jargon on 33, YTM vs YTC on 23/34, capitalising on 41, HY index on 58, 30/360 on 67, convexity picture on 75, 0.25% vs 0.395% on 72, zero-NPV proof on 89). **Not fixed:** the "every calculation line ends with a so-what" rule. About 26 calculation slides still have no "So what" (see blocking item 7), although the plan's header says every line carries the two tags. New gaps: slide 14 uses bp/spread before the toolkit defines them (19, 22); "yield curve" (37) is never defined; half-year discounting with a part-period (70) is never explained. |
| B2 Discount-rate inconsistency | **FIXED** | 93–95 value the call baseline at 2.28% and 0.895%. 3.5% is used only for the naive view (90–92). This matches calcs.py (−7.1 / 0.0). But fixing it exposed a new problem: the "vs market" row duplicates the 2.28% row (blocking item 2). |
| B3 Q3 calculation steps | **PARTLY FIXED** | PV tables with discount factors (90–91, 93), the proof slide (89) and the 21%/20% split (85, 96) are now in. **Not fixed:** the after-tax cash-flow table. Slide 97 gives only the rate and 98 gives only the results, so neither after-tax PV (454.0, 504.3) is shown step by step. Round 2 explicitly asked for "after-tax flows table → …". |
| B4 Factual title/number errors | **FIXED** | 30 retitled with 189bp and the 2014 rise. 123 now says S&P investment grade and Moody's one notch below. B1-in-2011 removed from 12. 1.08 on 112. |
| B5 Unsourced external facts | **MOSTLY FIXED** | Slides 4, 7, 9, 119–122, 124–125 now trace to round-3 rows with exact quotes. Slide 14 is reframed correctly (Fortune: 330→460bp). **Not fixed:** slide 8's title still claims premium makers "grew on SUVs and China", but `sources_research.md` R3-3 says industry SUV growth was "NOT FOUND". New problems: slide 4 calls Land Rover (1948) "a century old"; slide 123's "S&P's too (May 2026)" rests on a headline only. |
| B6 Q2 order | **FIXED** | The call-aware value comes first (64–74), then the naive value (76–78), then the reconciliation (80). |
| B7 Label and overlong titles | **PARTLY FIXED** | 17 is fixed. **Not fixed:** 85 is still "Assumptions" (round-2 slide 78) and 116 is still "What we found" (round-2 slide 105). 80 ("Five values side by side…") is still a label. Titles of 18–22 words remain: 23, 30, 105, 121, 126. |
| (round-2 H7c, carried over) "certain to call" | **NOT FIXED** | Slide 66 says "JLR will certainly repay in 2016". |

## 1. Verdict
**NOT READY. B+.** Fails H3, H4, H6, H7, H8 and H11. Q4 and Q5 score below 4.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 → Overview 3–17 (toolkit 18–24 is part of it, section "1b") → Exhibits 25–49 → Q1 50–61, Q2 62–81, Q3 82–100, Q4 101–114 → Epilogue 115–126 → Team 127 (placeholder; cover placeholder on 1). |
| H2 Every exhibit | PASS (minor) | Ex1 26–32, Ex2 33–36, Ex3 37–38 (rebuilt from the Treasury CSV, `sources.md` #1), Ex4 39–42, Ex5 43–45, Ex6 46–48, synthesis 49. All are native, labelled "Exhibit N", with numbers, meaning and implication. Minor: only slide 26 says "source line". Say it for 33, 37, 39, 43 and 46 too. |
| H3 Every question, all seven elements | **FAIL** | Q1 and Q2 have all seven. Q3: the after-tax PVs (98) have no cash-flow/discount-factor table. Slide 95 (0.895%) states only the total. Q2: 109.11 (to call at 3.5%), one of the "five values" on 80, is never worked on its own slide (it appears only inside the sensitivity table, 71). Q4: assumptions on 102 are only "assumptions", with no content. |
| H4 External, sourced, current | **FAIL** (narrow) | Most facts now trace to exact quotes (spot-check below). Failures: **8** (SUV/China growth claim not found), **4** ("a century old": Land Rover is from 1948, per JLR heritage page R3-1), **65** (cites [src] for 104.0625%, but the only source, the OM, prints 104.663%; the plan never says so on the slide), **112** ("repaid at 104.0625 in May 2016": `sources_research.md` C says the "actual redemption price and notice were not found"), **123** (S&P "May 2026": a Cbonds headline only, page 403, and it records an *affirmation* with a negative outlook, not when the outlook turned), **42** ("flattered by tax credits": no source for the cause). |
| H5 No teaching note | PASS | Nothing cites, quotes or refers to it. The naive 125.43 is framed as "the naive view" (76). |
| H6 Titles | **FAIL** | Labels: **85** "Assumptions", **116** "What we found", **80** "Five values side by side…". Too long for two lines at headline size (18–22 words, 104–113 characters): **23, 30, 105, 121, 126**. Factually wrong: **4, 8, 17** (see H8). |
| H7 Finance correct | **FAIL** | **(a) After-tax treatment (96–98).** The accrued interest JLR pays at settlement (US$11.3m) is interest, so it is tax-deductible. The plan gives the old May-2015 coupon its full tax shield in the "avoided" flows, but treats the accrued paid as not deductible. The missing shield is 11.29 × 21% = US$2.4m. Corrected realistic after-tax NPV ≈ **−US$4.9m** (not −7.3); naive ≈ **+US$45.4m** (not +43.0). I verified this by recomputing 454.00 − (461.30 − 2.37). **(b) Two "baselines" are one (99, 112).** 111.28 is the 4 Feb price at a 2.28% yield to call. On 17 Mar, at the same 2.28%, the notes are worth 110.61 (I recomputed: 111.28 on 4 Feb and 110.61 on 17 Mar; the premium shrinks as the call nears). So "vs market −US$4.4m / +1.08" and "vs call at 2.28% −US$7.1m / +1.74" are the same benchmark on two dates, presented as two different comparisons. **(c) Test 1 (56)** compares a 10-year yield at issue (8.125%) with a 14-month yield to call (2.28%). That fall mixes Treasury level, tenor and credit, so it cannot test credit. It must be done in spreads. **(d) Slide 105**: "at the cost of paying about 8 points early" is wrong as a cost. The 8.29 points (112.35 − 104.0625) buy 14 months of avoided 8.125% coupons; the net cost of tendering vs waiting is 1.74 per 100 (US$7.1m), or about 0 at 0.895%. "Locking in 3.5% before the Fed" is a rate view with no expected value in an efficient market, and the deck's own Q4 theory slide (103) says so. **(e) 66** says "certainly". Correct: near-certain (the call is optional; it is exercised only if refinancing is cheaper, which it is here by a wide margin). |
| H8 Numbers | **FAIL** (narrow) | 30 of the 31 plan numbers I checked match calcs.py, exhibits.csv or sources (table below). Wrong: **17**'s "US$472m spent" (that is the all-tendered hypothetical; the actual cost was US$375.7m, slide 117). Inconsistent without explanation: JLR's March 2015 spread is **189bp** on 30/57 (3 Mar Treasury 1.61%) but **193bp** on 14/53/54 (16 Mar Treasury 1.57%). So the fall is 308bp on 57 but 304bp on 54/58. Formats: 462.5bp on 19 vs 462bp on 54 (bp whole); "1% to 27%" on 42 (rates to 2 dp in the body: 1.28% → 27.48%). |
| H9 User decisions | PASS | Call-aware first (64–74, before 76–78). US$ maths with one conversion at 1.50, and why (29, 32). Case date 15 May 2021 used, with exactly one note slide (79: 127.26). One slide per repeat: mostly honoured (70, 73, 77, 90–95 each have their own slide), but see H3 for 109.11, 95 and the after-tax PVs. |
| H10 Known traps | PASS (Test 1 caveat) | Semi-annual and the May-2016 call (18, 64–66); US$ vs £ at 1.50 (29, 32); clean/full price, accrued paid separately, 30/360 (24, 67, 70, 73); gap between the 25% naive view, the 11% market and the 12.35% tender (76–80); "credit, not Treasuries (26bp)" tested (55–58), though Test 1 is flawed (H7c); "fair-price refinancing creates no value" tested (89–99). |
| **H11 Lucidity** | **FAIL** | More than a handful of slides would lose a part-way CFA L1 reader: **14** (bp, spread, high-yield before definition), **37** (yield curve never defined), **70** (where 0.3222 half-years and y/2 come from), **70/80/99/112** (why the same 2.28% gives 110.61 and 111.28), **12** ("outlook"), **110** (signalling undefined), **109** (refinancing risk), **2** (efficient market used in the opening question with no plain line), **48** (D/E). And about 26 calculation slides have no "so what" (blocking item 7). |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 4 | Q2 reproduces the tender to the cent. Q1 tests the claim three ways. Q3 has three baselines with pre- and after-tax versions. Held back by the flawed Test 1 and the after-tax and "two baselines" errors. |
| Q2 Logic and flow | 4 | Concepts now mostly come before use and Q2 runs call-first. But 14 comes before the toolkit, and 99/112 present one comparison as two. |
| Q3 Evidence | 4 | Primary releases and annual reports throughout, secondary sources labelled, Treasury data rebuilt. A few claims rest on headlines or have no source (8, 42, 112, 123). |
| Q4 Lucidity | **3** | Big improvement (toolkit, plain lines). But the part-period discounting, the yield curve, the 110.61/111.28 puzzle and about 26 missing "so whats" would still lose the target reader on paper. |
| Q5 Calculations | **3** | Pre-tax work is complete and traceable. The after-tax PVs have no tables and carry a tax error. 109.11 and the 0.895% PV table are not worked on their own slides. |
| Q6 Overview and epilogue | 4 | Sourced to Q1 FY27 (Aug 2026). The arc closes the loop (tender result → 2016 call → 2020 repayment at higher rates → today). Minor wording errors (4, 8, 121, 123). |

## 4. Number spot-check (31 numbers)

| Number | Slide | Source | Match |
|---|---|---|---|
| £2,448m drawn; notes 92%; £1,485m RCF undrawn | 26–27 | exhibits.csv Ex1 | yes |
| £12.6m + £21.9m = £34.5m at 1.50 | 29 | calcs (consistent rates block) | yes |
| 497 / 362 / 260 / 272 / 189bp | 30, 57 | calcs Q1 Test 2; R3-7 CSV rows | yes |
| 410/263 = 1.559; £273.3m | 32 | calcs | yes |
| 111.276 (4 Feb 2015); 2nd line 111.583 (Aug 2014) | 33 | exhibits.csv Ex2 | yes |
| YTM 5.94%, YTC 2.28% | 34 | calcs Q1 | yes |
| 8.25% sterling at 110.94 | 35 | exhibits.csv row 71 | yes |
| 10Y −105bp, 5Y −26bp; 0.395% | 38 | sources.md #1; PR Newswire 16 Mar | yes |
| Revenue +43%, PBT +69% | 39 | calcs | yes |
| EBITDA margin 14.8% → 18.0% | 40 | calcs | yes |
| Capitalised development 38–51% of PBT | 41 | calcs | yes |
| FCF 1,090/580/1,066/540; after interest and dividends 962/251/647/293 | 44 | calcs | yes |
| EBITDA/cash interest 12–30× | 45 | calcs 15.6/13.3/12.2/29.7 | yes |
| Net cash 456 → 1,604; D/E 0.68 → 0.36 | 47–48 | calcs | yes |
| 3.15% + 497; 1.57% + 193; 304bp (66%) / 158bp (34%) | 52–54 | calcs | yes |
| 1.83% → 1.57% = 26bp | 55 | sources.md #1 | yes |
| Accrued 122 days US$27.53; 136 days US$30.69 | 67 | calcs; PR Newswire | yes |
| Value to call at 2.28% = 110.61 | 70 | calcs; my recompute 110.612 | yes |
| Sensitivity 112.85 (0.5%) to 109.11 (3.5%) | 71 | calcs | yes |
| 0.895% → clean 112.35; full 115.10 | 73 | calcs (112.3514 + 2.7535) | yes |
| US$1,123.52 / 1,093.52 | 74 | pricing release | yes |
| Naive 128.18 − 2.75 = 125.43; Nov-2021 127.26 | 77, 79 | calcs | yes |
| US$456–461m (111.28 / 112.35 × 4.10) | 81 | arithmetic | yes |
| 471.9 needed; 28.1 surplus | 86 | calcs | yes |
| 33.3 vs 16.5 → 16.8/yr; premium 50.6 incl. 12.3 | 87–88 | calcs | yes |
| New debt PV 472.0 | 89 | calcs | yes |
| PV 525.5 → +53.6; PV 464.8 → −7.1; 0.895% → 0.0 | 91–95 | calcs | yes |
| Tax 10.6; after-tax 461.3; 1.82% / 2.80%; −7.3 / +43.0 | 96–98 | calcs | numbers yes; **method wrong** (accrued not deductible; H7a) |
| 1.08 (US$4.4m); 1.74 (US$7.1m) | 112 | calcs | yes; same benchmark on two dates (H7b) |
| 79.61%; US$375.7m; US$83.6m | 117–118 | final-results release; 20-F; calcs | yes |
| US$472m "spent" | 17 | 117 (actual US$375.7m) | **no**: hypothetical stated as fact |

External facts checked (exact quote present and supporting): 7 China 115,969 (AR15 p.71) ✓; 9 BMW 1,811,719 (secondary reprint, labelled) ✓; 14 HY 330→460bp (Fortune, secondary) ✓; 60 "callable after five" (Business Standard/Bloomberg) ✓; 72 0.395% ✓; 85 21% FY2014 (Finance Act 2013 s.4) ✓; 119 retail series ✓; 121 €5.875%/6.875%, US$7.75%, B+/B1 (AR20, Q2FY21) ✓; 125 Q1 FY27 £6.0bn, £109m, 2.8% ✓. **Fail:** 8 (SUV/China growth not found); 4 ("century old" contradicted by 1948); 65 (source says 104.663%); 112 (call price not found); 123 S&P May 2026 (headline only, and it is an affirmation).

## 5. Blocking items (slide → problem → exact fix)

1. **96–100: after-tax treatment leaves out the accrued-interest deduction (H7).**
   - Fix 96: "JLR also deducts the US$11.3m accrued interest it pays holders. It is interest owed up to 17 March: 11.3 × 21% = US$2.4m. After-tax cash paid: 471.9 − 10.6 − 2.4 = US$458.9m."
   - Re-run calcs.py. Realistic after-tax NPV ≈ −US$4.9m; naive ≈ +US$45.4m.
   - Update 98, 99 and 100. The conclusion (no economic saving) holds.

2. **70, 80, 99, 112: the 111.28 vs 110.61 puzzle; one comparison shown as two (H7/H11).**
   - On 70 add: "Same 2.28% yield as the 4 Feb market price. The value falls from 111.28 to 110.61 by 17 March because a premium bond's price drifts toward the call price as the call date nears."
   - On 99, relabel the −US$4.4m row "vs the stale 4 Feb price (same yield as the 2.28% row)", or drop it.
   - Retitle 112: "Holders who tendered got about 1.7 per 100 (US$7.1m) more than their notes were worth at the market's own yield". Show 1.08 only as the stale-price figure.

3. **56: Test 1 is not like for like (H7/H10).**
   - Express it in spreads: 2011 spread 497bp vs 2015 yield to call 2.28% minus the 14-month Treasury on 4 Feb 2015. Fetch that row from the same Treasury CSV and interpolate 1Y/2Y.
   - Title: "Test 1: the same bond's spread over Treasuries fell from 497bp at issue to about X bp in Feb 2015".

4. **105: the wrong cost and an untested benefit (H7).**
   - Retitle: "Tendering now instead of waiting for the 2016 call cost about 1.7 per 100 (US$7.1m)".
   - Body: 8.29 points over the call price buy 14 months of avoided 8.125% coupons. "Locking in 3.5% before the Fed's December 2015 rise" is a rate bet with no expected value in an efficient market. Add the 5-year Treasury on 16 May 2016 from the same CSV, to show what waiting would actually have cost.

5. **97–98, 95, 71/80: steps missing for repeated calculations (H3/H9/Q5).**
   - Add "after-tax realistic" table: date, after-tax flow (coupon × 0.8 = 13.33; May 2016 = 410 + coupon and call premium after tax), discount factor at 1.824%/2, PV; total 454.0.
   - Add "after-tax naive" table at 2.80% over 2 slides, as on 90–91; total 504.3. Say the call premium and coupons are deductible and the principal is not.
   - Give 95 its own three-row DF table.
   - Add one slide working 109.11 (to call at 3.5%), since it is one of the five values on 80.

6. **68–70 and toolkit 20/21: semi-annual mechanics never explained (H11/H3).**
   - Add in words: rate per half-year = annual yield ÷ 2.
   - Payments are counted in half-years from 17 March. The first is a part-period: 58 of 180 days = 0.3222.
   - Discount factor = 1 ÷ (1 + y/2)^n.
   - Add an "n (half-years)" column (0.3222, 1.3222, 2.3222) to the tables on 70, 73, 90–95 and 98.

7. **Lucidity gaps (H11).**
   - Plain lines to add:
     - 14: bp and spread, or move it after the toolkit.
     - 37: "yield curve = Treasury yields plotted against time to maturity".
     - 12: "outlook = where the agency expects the rating to move next".
     - 110: "signalling = management knows more than investors, so a costly action can reveal confidence", plus its limit.
     - 109: refinancing risk.
     - 2: efficient market in one line.
     - 48: D/E = debt ÷ equity.
   - Add a one-line "So what" to each calculation slide that lacks one: 40, 44, 45, 47, 48, 52, 53, 55, 57, 67, 70, 73, 74, 77, 79, 86, 87, 88, 90, 91, 93, 96, 97, 98, 106, 112. Examples:
     - 47: "So what: JLR could repay all its debt from cash; lenders face little default risk."
     - 70: "So what: holders should accept about 110.6 if they need the market's 2.28%."
     - 87: "So what: the saving looks large only if the old notes would have run to 2021."
   - Also make the header claim ("two tags on each line") true.

8. **Factual and sourcing fixes (H4/H8).**
   - 4: "Two British brands, born in 1922 and 1948, owned by Ford and then Tata".
   - 8: "Premium rivals grew 9–17% in 2014, while the EU set a 95g CO2/km limit for 2020" (BMW +9.5%, Audi +10.5%, Mercedes +12.9%, Porsche +17%, R3-3). Drop "on SUVs and China".
   - 17: "US$500m raised; buying back every old note would cost US$472m, leaving US$28m before fees".
   - 42: "FY2012's tax charge was unusually low (1.28%), so its profit after tax overstates normal earnings". Or source the cause.
   - 65: add "The 2015 offering memorandum prints 104.663%. We use 104.0625% (par + half a coupon) because only it reproduces the tender price to the cent [src: OM p.105; PR Newswire 16 Mar]".
   - 112/118: "repaid in May 2016 (price not published; at the call price this is 104.0625, our assumption)".
   - 123: "S&P: BBB- affirmed with a negative outlook, 28 May 2026 (secondary, Cbonds headline)". Or drop it until a page is read.
   - 53/57: explain 189 vs 193bp in one line. "On the 3 Mar pricing day the 5-year Treasury was 1.61%, so 189bp. The waterfall uses Exhibit 3's 16 Mar (193bp). The 4bp gap changes nothing." State 57's fall as "308bp (304bp on Exhibit 3's date)".

9. **Titles (H6).**
   - 85: "We assume JLR buys all US$410m at 112.35 on 17 March, funded at 3.5%".
   - 116: "Better credit, not lower rates, cut JLR's coupon; the buyback itself created no value".
   - 80: "Every call-aware value lands at 109–113; only the naive 2021 view reaches 125".
   - 23: "A call lets JLR repay early, so investors price to the call date".
   - 30: "JLR's spread over Treasuries fell from 497bp (2011) to 189bp (2015)".
   - 121: "Hindsight: by 2019–20 JLR paid 5.875–7.75% on new debt, not 3.5%".
   - 126: "Better credit cut JLR's borrowing cost; buying back fairly priced debt created no value".
   - 66: "certainly" → "almost certainly".

## 6. Non-blocking improvements (most valuable first)
1. 87/106: say the US$16.8m a year saving runs only to May 2016 against the realistic baseline (round-2 H7d, still open).
2. 54: say the 304bp also holds the 2011 call premium and the 10-year vs 5-year credit-curve slope. Either size the call part or say it cannot be split without the 2011 issue price.
3. 78 so-what: "paying 125 would give holders ~US$54m more than the actual offer (13.07 × 4.10)".
4. 9: JLR's figure is fiscal (to Mar 2015); rivals' figures are calendar 2014. Say so.
5. 19: 462.5bp vs 462bp elsewhere. Pick one and keep bp whole.
6. Exhibit slides 33, 37, 39, 43, 46: write "source line" explicitly.
7. 45: FY2015's 29.7× reflects 9 months of coupon timing. Also source or soften the "capitalised interest" explanation.
8. 100: give £ equivalents once at 1.50 (premium £33.8m; NPV in £), tying the answer back to a £-reporting firm.
9. 121: the 7.75% notes priced in Oct 2020, after March 2020, and € coupons aren't like-for-like with US$. Add the US$650m 5.875% (Dec 2020).
10. Depth: 127 slides against a 150–200 guide. The blocking fixes (tables, worked slides) add real content; don't pad beyond that.

## Strongest parts
- Q2 reproduces JLR's tender price to US$0.01 (0.395% + 50bp to the May 2016 call at 104.0625) and reconciles it with the market, the call value and the naive 125.
- Q3 now proves that new debt at market rates has zero NPV (89) and values the call baseline at a consistent 14-month rate.
- Q1's "26bp like for like" plus the spread series across five issues and the market high-yield comparison is a real test, not an assertion.
- The epilogue is sourced from primary JLR filings up to Q1 FY27, and the 2020 hindsight slide ties back to the decision.
