# Jaguar deck: independent gate-4 grader report

Reviewer: independent grader (strict rubric `review/shared/review-rubric.md`), 2026-10-30.
Deliverable judged: `review/jaguar/04-qc/deck_text.md` (145 pages), the current HTML of j109 and j121 (edited after the dump), 47 full-size renders in `04-qc/png/`, and all 8 greyscale contact sheets.
Checked against: `calcs.py` (run; output matches), `exhibits.csv`, the case text (`case-layout.txt`), `sources.md` and `sources_research.md`, the approved storyline, CLAUDE.md, DESIGN.md and PROGRESS.md.
Full-size renders opened (47): j01, j14, j27, j31, j34, j38, j39, j40, j40b, j41, j44, j44b, j44c, j45, j47, j47b, j47c, j55, j58, j59, j62, j65, j71, j73, j80, j82, j84, j85, j86, j89, j90, j95, j99, j100, j102, j107, j108, j110, j112, j122, j125, j130, j132, j134, j136, j140. Every other slide was read on the greyscale contact sheets and in the text dump.

---

## (a) Verdict

**NOT READY. Grade estimate: B+ as it stands, A−/A once the 7 blocking items are fixed.**

The analysis is strong. It reproduces the tender price to the cent, runs three independent tests of the credit-spread story, gives a ten-rate sensitivity, and works after-tax NPVs. The epilogue is current to August 2026. What holds it back is a set of narrow, fixable failures:
- an incomplete Exhibit 2 rebuild
- Q3's incremental cash-flow schedule is never shown, and the new-debt PV is asserted without its working
- unlabelled secondary sources, plus one unsupported external claim
- sub-18pt body text on 10 slides
- two displayed numbers that do not reproduce
- one chart drawn off-scale without a break

---

## (b) Hard requirements

| # | Requirement | Result | Evidence |
|---|---|---|---|
| H1 | Structure | **PASS** | Opening j01–j02. Overview j03–j17 plus toolkit j18–j25. Exhibits j26–j50. Q1 j51–j62, Q2 j63–j90, Q3 j91–j113, Q4 j114–j127. Epilogue j128–j139. Team j140 (placeholder, allowed). |
| H2 | Every exhibit rebuilt, labelled, analysed | **FAIL** | Exhibits 1, 3, 4, 5 and 6 are rebuilt in full, labelled and analysed (Ex1 j27–j33, Ex3 j38–j39, Ex4 j40–j43, Ex5 j44–j46, Ex6 j47–j49). **Exhibit 2 (j34) shows only 5 of the case's 8 rows.** It drops the second 8.25% £ 2020 line (XS0765386973, **111.182**, 30/01/2015) and the second ISIN lines of the 3.5% 2020 and 3.875% 2023 notes. It also drops the ISIN and start/end-date columns. The slide's own note says "Two lines = one note sold to US and non-US buyers", but it shows two lines for only one note. See finding 1. |
| H3 | Every question stated, split, theory, assumptions, alternatives, every step shown | **FAIL** | Q1, Q2 and Q4 pass. Q3 asks for "the incremental cash flows of this bond issue vis-à-vis the original issue". No slide shows the date-by-date incremental schedule (old flows avoided vs new-issue flows vs net). calcs.py prints it, but it never reaches a slide. j98 asserts "PV at 3.5% of what JLR repays = 472.0" with no table of the 10 new-debt payments and their discount factors. That is a calculation result with its steps missing. See finding 2. |
| H4 | External, current, sourced facts; secondary labelled; sources support | **FAIL** | Currency is good: Q1 FY27 to Aug 2026 (j138), cyber-attack (j137), ratings to 2025 (j136). Two failures: (1) Business Standard, a secondary source, is cited without a "secondary" label on **j59, j60, j61, j136** (findings 3). (2) **j15 and j36 say the £500m 8.25% notes were "bought back" in "February 2015".** sources_research.md says the result of the sterling tender was "not found" (the OM only estimates 60% tendered), and the tender only *commenced* on 19 Feb 2015 (finding 4). |
| H5 | No teaching note | **PASS** | No slide cites, quotes or uses the Questions.docx. Grep found no "teaching note", "Questions.docx" or "25–29%". Facts in the "what happened" section are independently sourced to PR Newswire, the 20-F and JLR releases. |
| H6 | Titles state the point, ≤2 lines | **PASS** (minor mismatches listed) | Every render checked fits within 2 lines, and the titles are findings, not labels. A few title/body mismatches are listed as non-blocking (finding 14). |
| H7 | Finance correct at CFA L1 | **PASS** | All correct: clean/full prices; 30/360 (122 and 136 days); YTM as IRR with its reinvestment assumption; yield to call and yield to worst; fractional-period discounting; callable = straight − call; negative convexity; after-tax rate = r(1−t); accrued interest deductible; zero-NPV fairly priced debt; MM and market efficiency. Two approximations are caveated but could be tightened (finding 12): j87 mixes discount rates for the option value, and j84 prices the callable as min(to-call, to-maturity), which ignores the option's time value. |
| H8 | Numbers right; formats | **FAIL** | 52 displayed calculations were recomputed (part e) and almost all reproduce. Two clear mismatches: **j95** "410 × 1.1511 = 471.9" (410 × 1.1511 = 471.95, which rounds to 472.0; the factor should be 1.1510). **j08** Porsche "+17.0%" (the source table says 17.1; 189,849 ÷ 162,145 − 1 = 17.09%). Finding 6. Other rounding and display issues are non-blocking (findings 8–10). |
| H9 | User decisions honoured | **PASS** | Call-aware Q2 comes first (j69–j82 before the naive j85–j86). Bond maths is in US$, converted once at 1.50 (j33, j113, j121). The case maturity is used, with one note slide (j88). Each repeated calculation gets its own slide (j71–j79). |
| H10 | Known traps handled | **PASS** | All handled: the tender is the US$410m 8.125% notes (j15, j27); semi-annual coupons and the May 2016 call (j18, j24, j66); FX at 1.50 with its reason (j11, j33); clean vs dirty (j25, j68); the gap between naive 125.43 and the actual 112.35 is explained (j87, j89); the efficient-market lesson is *tested*, not just asserted (j55–j59, j116); Treasuries fell only 26bp (j56). |
| H11 | Lucidity | **PASS (borderline)** | Almost every slide carries "Plain:" and "So what:", and concepts come before use (toolkit j18–j25, NPV j93, MM j116). Five slides would make a part-way Level 1 reader stop: j87, j98, j105, j118 and j124 (finding 19). That is a handful, not more. |

**Project restrictions.** Two are breached:
- **18pt rule (36 px) breached** on j71–j79 and j82: the caption "where this value sits among all ten (109–113)" is set at 24 px and is not a footer (confirmed in the HTML). Exhibit 6's subtotal rows also sit in the 24 px footers of j47b and j47c. See finding 5.
- **Secondary-source labelling** is breached (finding 3).

Not breached: the cover and team placeholders (allowed), and the teaching-note rule.

---

## (c) Quality scores (1–5; READY needs every score ≥ 4)

| | Score | Reason |
|---|---|---|
| Q1 Depth | **5** | The analysis tests its claims rather than asserting them: three spread tests, the tender reproduced to US$0.01, a ten-rate grid, naive vs realistic baselines, after-tax versions, and who gains vs who pays. |
| Q2 Logic and flow | **4** | Chronological, and every section ends in an answer slide. Some repetition: the "better credit, not cheaper money" line appears on j50, j62, j129 and j139, and j129 restates the four answer slides. |
| Q3 Use of evidence | **4** | Primary-heavy (PR Newswire releases, the OM, the 20-F, Treasury CSVs, JLR annual reports) and used as evidence. Docked for the unlabelled secondaries and the unsupported sterling-buyback claim. |
| Q4 Lucidity | **4** | Consistent Plain/So-what scaffolding. A handful of slides need a bridging line (finding 19). |
| Q5 Calculations | **3** | Q2 is exemplary. Q3 skips the literal ask (the incremental cash-flow schedule) and leaves the 472.0 new-debt PV unworked. Two displayed steps do not reproduce (j95, j87), and four PV tables do not sum as displayed and lack a "rows rounded" note. |
| Q6 Overview and epilogue | **5** | Informative, current to Q1 FY27 (Aug 2026), and tied back to the 2015 decision (j122 → j134). |

Q5 < 4, so the deck is NOT READY on the scores as well as on H2, H3, H4 and H8.

---

## (d) Findings

### Blocking

**1. j34 · Exhibit 2 rebuild is incomplete (H2). BLOCKING**
- Evidence: the case's Exhibit 2 has 8 rows; j34 shows 5. Missing:
  - 8.25% £ 2020, XS0765386973, **111.182** (30/01/2015)
  - 3.5% US$ 2020, US47010BAE48, 100 i (12/03/2015)
  - 3.875% £ 2023, XS1195503351, 100 i (06/03/2015)
- The Security (ISIN) and Start/End-date columns are also omitted, although the end dates carry the maturities the deck relies on: 15/05/2021 and 15/03/2020.
- Fix: rebuild all 8 rows with the columns Coupon; ISIN; Start–End; Last traded date; Price (2 dp, with "i"). Keep the lime highlight on the 4 Feb 111.28 row. If 8 rows do not fit at 36 px, split over j34/j34b as was done for Exhibits 4–6. Add one line saying the two 8.25% lines (110.94 / 111.18) agree within 0.24, so the market view is consistent.

**2. Q3 (j96–j104) · incremental cash flows not shown; new-debt PV not worked (H3 and the every-step rule). BLOCKING**
- Evidence: the case question asks for "the incremental cash flows of this bond issue vis-à-vis the original issue". calcs.py prints the 23-row schedule (old avoided / new paid / incremental, e.g. 2015-05-15 +16.66; 2015-09-15 −8.26; … 2020-03-15 −480.19; 2021-05-15 +426.66). No slide shows it.
- j98 states "PV at 3.5% of what JLR repays … = 472.0" with no table. My recomputation from 17 Mar 2015 (first coupon 178/180 of a half-year away) gives 472.02, so the number is right but its steps are not on a slide.
- Fix:
  - (a) Add one or two slides with the new-debt PV table: 10 payments of 8.26, the last 480.19; n = 0.9889, 1.9889, …; DF at 1.75%; PV; total 472.02.
  - (b) Add one or two slides with the incremental cash-flow timeline under the naive baseline, as a table or a ± bar chart. Columns: date, old avoided, new paid, net, labelled "+ = JLR better off". Do the same for the realistic baseline (three old flows vs the new-debt flows).
  - (c) Add one line reconciling it: "NPV of net flows = PV avoided − cash paid, because the new debt is zero-NPV (slide 98)".

**3. j59, j60, j61, j136 · secondary sources not labelled (project restriction; H4). BLOCKING**
- Evidence: "Bloomberg via Business Standard, 10 May 2011" (j59, j61) and "Business Standard, 18 Sep 2013" (j60, j136) are press reports, so secondary. j14 and j136 correctly label Fortune and Forbes as "(secondary)". j59 also cites Fortune without the label.
- Fix: add "(secondary)" after each Business Standard citation on j59, j60, j61 and j136, and after Fortune on j59. On j60 and j136 you can also cite the primary Moody's release that the case itself footnotes (case fn. 10: Moody's, 17 Sep 2013).

**4. j15, j36 · sterling buyback stated as completed without a source (H4). BLOCKING**
- Evidence: j15's column header says "Old notes bought back: £500m 8.25% due 2020"; j36 says "JLR bought them back in February 2015". sources_research.md, section D and "Not found", says: "Results of the sterling tender (amount … tendered, price): not found (the OM only estimates 60% tendered)". The tender *commenced* on 19 Feb 2015. The same header on j15 also implies all US$410m was bought back, when only US$326.4m was (j130).
- Fix: rename j15's column to "Old notes targeted by the tender". On j36 write "JLR launched a tender for them on 19 Feb 2015, funded by £400m of new 3.875% notes due 2023 … (result not published in our sources)".

**5. j71–j79, j82 (and j47b, j47c) · body text below 18pt (project restriction). BLOCKING**
- Evidence: the caption "where this value sits among all ten (109–113)" is `font-size:24px` on all 10 slides (HTML check), and it is not a footer. On j47b and j47c, Exhibit 6's subtotal rows (non-current 4,982 / 6,628 / 8,359 / 9,723, etc.) appear only inside the 24 px source footer.
- Fix: set the ladder caption to 36 px. Shortening it to "Among the ten values (109–113)" keeps it on one line. Move Exhibit 6's subtotals into the tables as bold rows ("Total non-current assets", "Total current assets", "Total current liabilities", "Total non-current liabilities"), as the case prints them.

**6. j95, j08 · displayed numbers that do not reproduce or do not match the source (H8). BLOCKING**
- j95: "410 × (112.35 + 2.75)% = 410 × 1.1511 = 471.9". But 112.35 + 2.75 = 115.10, and 410 × 1.1511 = 471.95, which is 472.0 at 1 dp. Fix: "410 × (112.3514 + 2.7535)% = 410 × 1.151049 = 471.93", or "410 × 1.1510 = 471.9".
- j08: "Porsche +17.0%". Porsche's own table gives 17.1, and 189,849 ÷ 162,145 − 1 = 17.09%. Fix: "+17.1%".

**7. j65 · chart not to scale, with no break shown. BLOCKING (chart scale criterion)**
- Evidence: the coupon bars (40.625) are about 35 px tall and the final bar (1,040.625) about 220 px. To scale, the final bar would be about 25.6 × 35 ≈ 900 px. The picture understates the repayment about fourfold.
- Fix: draw a visible axis break (two short diagonal strokes) on the 2021 bar and add "(final bar not to scale)" to the subtitle. Alternatively, plot to scale with the coupons labelled.

### Non-blocking

**8. Cross-slide inconsistency: JLR's 2015 spread, 189bp vs 193bp.**
- 189bp on j14, j31, j58 (3 Mar pricing day, 5-year 1.61%). 193bp on j19, j23, j54, j55, and inside the 304bp on j55, j59, j62, j129, j139 (16 Mar, 1.57%).
- The total fall is 304bp on j55/j59/j62/j129/j139, 308bp on j58, and 298bp on j57 (a different measure).
- j54 and j58 reconcile this, but j14 (189) and j19/j23 (193) appear five slides apart with no note.
- Fix: add "(193bp on Exhibit 3's 16 Mar date, slide 54)" to j14, or make j19's example the 189bp.

**9. Cross-slide inconsistency: JLR borrowings at 31 Dec 2014, £2,448m vs £2,423m.**
- j27/j28 (Exhibit 1, drawn) show £2,448m. j47c, j48 and j49 (Exhibit 6, 193 + 2,230) show £2,423m. The £25m gap is never explained.
- Fix: one line on j47c or j48: "Exhibit 6 shows £2,423m vs Exhibit 1's £2,448m drawn; the £25m gap is likely notes carried net of issue costs in the balance sheet (our inference)".

**10. Cross-slide inconsistency: the annual interest saving, US$19.0m vs US$16.8m.**
- j67: "roughly US$19m a year" ((8.125 − 3.5)% × 410).
- j96, j113, j119, j124, j129: US$16.8m (33.3 − 3.5% × 471.9).
- Fix: on j67 write "about US$19m a year on US$410m (before funding the premium; slide 96 nets it to US$16.8m)".

**11. j100, j102, j107, j109 · rows do not sum as displayed.**
- j100 rows 7–13 sum to 430.35, but the so-what says "95.20 + 430.33 = 525.53".
- j102 rows sum to 464.81 (total shown 464.80). j107 rows sum to 454.00 (shown 453.99). j109 rows sum to 76.89 (shown 76.90).
- Fix: add "(rows rounded)" to each total, as j73–j79 already do, and on j100 write "95.20 + 430.33 (unrounded rows)".

**12. j87 (and j84) · option value mixes definitions and rates.**
- The title says "about 15 points" (125.43 − 110.61 = 14.82, at different rates). The so-what says "about US$54m", which is 13.07 points (125.43 − 112.35).
- The working prints 125.4257 − 112.3514 = **13.0742**; the correct difference is 13.0743.
- Fix: show the same-rate option value as the clean CFA measure: straight − callable at 3.5% = 125.43 − 109.11 = 16.32. Keep 14.82 as the mixed-rate figure. Separate "option value" from "overpayment vs offer (13.07, US$53.6m)". Correct 13.0742 to 13.0743.
- On j84, add one line: "callable ≈ the lower of the two values (yield-to-worst rule); this ignores the option's time value, so the true callable price sits slightly below the line".

**13. j95 · colour alone identifies three segments; the subtitle is untrue.**
- The subtitle says "premium, accrued and left over are labelled below the bar", but only 410.0 and 50.6 are labelled.
- Accrued (black) and premium (dark green) look the same in greyscale (grey-5 sheet).
- Fix: put direct labels "11.3 accrued" and "28.1 left over" under their segments with leader ticks, or replace the chart with a 4-row table.

**14. Title or so-what not supported by the slide's own numbers.**
- j127 title says "nothing for Tata Motors", but the card shows −US$7.1m. Fix: "… a small loss for Tata Motors".
- j112 so-what says "only the naive baseline shows a saving", but the offer's rate after tax shows +0.7. Fix: "only the naive baseline shows a material saving".
- j44c title says "£150m of dividends a year", but FY2012 shows none ("–"). Fix: "£150m of dividends a year from FY2013".
- j134 so-what says new debt cost "twice as much", but the coupons are 1.7–2.2 × 3.5%. Fix: "1.7–2.2 times as much".

**15. j136 · rating chart is incomplete, so the so-what is not fully supported.**
- Missing points:
  - Moody's B1 by Mar 2020 (AR20, sourced, and stated on j134)
  - S&P BB in late 2014 (case p.2, on j12)
  - S&P BB− in Apr 2023 (JLR notice, in sources)
- The Moody's Ba3 dot has no date, and with no line per agency the reader cannot follow "swung down and back up" for Moody's.
- Fix: add those three points, join each agency's points with a thin line (solid for S&P, dashed for Moody's), and date the Ba3 dot ("to Sep 2013").

**16. Chart details.**
- j84: the label "Plain bond to 2021 (dashed)" sits on top of the dashed line; move it above the line. It also needs a y-axis title ("clean price per 100") at the axis, not only in the subtitle.
- j122: "to May 2016" runs past the end of its bar ("6" overhangs); place the label to the right of the bar.
- j59: falls of −42 and −304 are drawn as rightward bars, while j58 and j112 draw negatives down or left. Either draw them leftward, or label them "fall: 42bp / 304bp" without minus signs.

**17. j44b/j44c · Exhibit 5 row order changed.**
- "Net change in cash" and the cash balances appear on j44b, before the financing rows on j44c. A reader checks 2,500 − 1,542 = 958 ≠ 1,402 and is lost.
- Fix: move those three rows to the end of j44c, after "Net cash from financing", as in the case.

**18. Terminology and jargon.**
- One concept, three words: "length" (j55, j61), "tenor" (j58) and "term" (j62 title). Pick one.
- "Premium" has three meanings: price over par (US$50.6m), the early-tender premium (US$30 / US$12.3m), and the call premium (4.0625 / US$16.7m). Always qualify it.
- j105 "UK tax rate, FY2014" clashes with the deck's FY2015 = year to 31 Mar 2015. Write "UK rate for the year to 31 Mar 2015".
- Exhibit 6 headers (j47–j47c) say "years to 31 March" and "FY2015 (9m)" for a balance sheet. Write "at 31 March" and "at 31 Dec 2014".
- Undefined terms: "adjusted EBIT margin" (j138), "exceptional items" (j133, j137, j138), "dealer manager / tender agent" (j126), "PP&E" (j45), "liquidity backstop facilities" (j137), "demerger" (j138). Add one Plain line each.

**19. Lucidity stumbles (H11 list).**
- j98: "zero-NPV" and "the gap is the 2-day part-period" are opaque. Fix: "the first coupon on 15 Sep pays a full half-year although only 178 of 180 days have passed, so PV is 0.09 above the 471.93 borrowed". This is fixed together with finding 2.
- j118: "8.29 points over the call price buy 14 months of avoided coupons, so the net cost is only 1.74" does not add up on the page. Fix: add the bridge "value of waiting 110.61 = PV of 3 coupons + PV of call price − accrued (slide 71); 112.35 − 110.61 = 1.74".
- j124: "−3.4 US$m a year less tax relief" sits next to the NPVs and reads like an extra loss. Add "already inside the after-tax NPV (slide 111); not an extra cost".
- j105: the FY2014 label (see 18).
- j87: see 12.

**20. Calculation slides whose "So what" is not a so-what.**
- j85 says "continued overleaf". j109 says "the same table as slide 99, after tax". j100 restates arithmetic.
- Fix: give each a one-line meaning. For example, j109: "tax relief cuts each coupon's cost by a fifth, to US$13.3m".

**21. AI-sounding patterns.**
- The "X, not Y" construction repeats at least 9 times: j28, j50, j55, j62, j89, j116, j125, j129, j139.
- Stock closers: j137 "a reminder that credit can weaken fast, which is why lenders price risk"; j138 "the 2015 lesson stands"; j136 "swung down and back up".
- Fix: vary the wording and keep the "not cheaper money" line only on j62 and j139.

**22. Bland tables where a visual would help (optional).**
- j45: show FCF as a per-year waterfall (CFO → −PP&E → −intangibles → FCF → −interest −dividends) to make "heavy investment ate most of the cash" visible.
- j48: paired bars of cash+deposits vs borrowings per year.
- Keep the step tables as well.

**23. Unsourced or over-reaching phrases.**
- j11: "the rest mainly China and Europe" is not in the case. Retail volumes (j7) are not revenue. Fix: "(retail volumes, slide 7: China 25%, Europe 19%)".
- j131: "repaid in May 2016, the first call date". The 20-F says only "prepaid in May 2016". Fix: "repaid in May 2016 (from the first call date, 15 May)".

**24. Render pack is stale for j121.**
- `04-qc/png/j121.png` and the j121 text dump still show the old version (£3,147m only). The HTML now has a £3,600m bar and "0.5%".
- Fix: re-render j121 (and confirm j109) before the final QC record. The new j121 content was checked from the HTML and is correct: 28.07 ÷ 1.5 = 18.7; 18.7 ÷ 3,600 = 0.52%.

---

## (e) Calculations recomputed (52)

Method: independent Python. Settlement 17 Mar 2015, 30/360, n = 0.3222 + k, call 104.0625. ✓ = reproduces from the numbers shown on the slide; ✗ = does not.

| # | Slide | Calculation | My result | |
|---|---|---|---|---|
| 1 | j17 | 410 × 112.35% / × 2.7535% / total / left over | 460.64 / 11.29 / 471.93 / 28.07 | ✓ |
| 2 | j20 | 100 ÷ 1.035² | 93.35 | ✓ |
| 3 | j21 | 1 ÷ 1.0114^0.3222 | 0.99635 | ✓ |
| 4 | j25 | 112.3514 + 2.7535 | 115.1049 | ✓ |
| 5 | j27/j28 | note sum; 2,255 ÷ 2,448 | 2,255; 92.1% | ✓ |
| 6 | j30 | 273.33 × 4.625%; 500 × 4.375%; total | 12.64; 21.88; 34.52 | ✓ |
| 7 | j33 | 410/263; 500/321; 700/450 | 1.559; 1.558; 1.556 | ✓ |
| 8 | j35 | accrued 79/180 × 4.0625; YTC; YTM at 111.276 | 1.7830; 2.280%; 5.945% | ✓ |
| 9 | j39 | 11 curve changes vs Treasury CSV | 0, +1, +8, +8, +12, +13, −26, −60, −105, −154, −161 | ✓ |
| 10 | j40 | growth FY12→FY14 | 43.5%; 69.1% | ✓ |
| 11 | j41 | EBITDA ×4; margins | 1,999 / 2,389 / 3,287 / 2,880; 14.79 / 15.14 / 16.96 / 17.96% | ✓ |
| 12 | j42 | capitalised dev ÷ PBT | 50.8 / 51.4 / 41.2 / 38.3% | ✓ |
| 13 | j43 | effective tax | 1.28 / 27.48 / 24.87 / 21.73% | ✓ |
| 14 | j44–j44c | CFO, investing, financing sums; cash roll-forward | all rows add | ✓ |
| 15 | j45 | FCF; after interest and dividends | 1,090 / 580 / 1,066 / 540; 962 / 251 / 647 / 293 | ✓ |
| 16 | j46 | EBITDA ÷ cash interest | 15.62 / 13.35 / 12.22 / 29.69× | ✓ |
| 17 | j47–j47c | balance-sheet totals and subtotals; +132%; +72% | all add | ✓ |
| 18 | j48 | net cash | 456 / 680 / 1,449 / 1,604 | ✓ |
| 19 | j49 | debt/equity | 0.675 / 0.612 / 0.343 / 0.356 | ✓ |
| 20 | j53–j55 | 497; 193; 462; 304 ÷ 462; 158 | 66%; 34% | ✓ |
| 21 | j56 | 26 ÷ 462 | 5.6% | ✓ |
| 22 | j57 | 466/365; interpolation; spread; change | 1.2767; 0.288%; 199; −298 | ✓ |
| 23 | j58 | −135 − 102 + 12 − 83 | −308 | ✓ |
| 24 | j59 | 502 − 460; 304 − 42 | −42; 262 ≈ 260 | ✓ |
| 25 | j67 | 4.625% × 410; 4.0625% × 410 | 18.96; 16.66 | ✓ |
| 26 | j68 | 30/360 days; per US$1,000 | 122 → 27.53; 136 → 30.69 | ✓ |
| 27 | j71 | DFs, PVs, full, clean at 2.28% | 0.996354 / 0.985124 / 0.974020; 113.3657; 110.61 | ✓ |
| 28 | j72 | at 3.5% | full 111.8657; 109.11 (DF 6th dp uses unrounded n) | ✓ |
| 29 | j73–j79 | full price at 0.5, 0.75, 1, 1.5, 2, 2.5, 3% | 115.6082, 115.2893, 114.9717, 114.3403, 113.7141, 113.0930, 112.4769 | ✓ |
| 30 | j81 | 0.395 + 0.50 | 0.895% | ✓ |
| 31 | j82 | at 0.895% | full 115.1049; clean 112.3514 (US$1,123.51) | ✓ |
| 32 | j85 | PV payments 1–7 | 26.8611 (26.8610 shown, rounding) | ✓ |
| 33 | j86 | full / clean to May 2021 at 3.5% | 128.1792 / 125.4257 | ✓ |
| 34 | j87 | 125.4257 − 112.3514; × 4.10; 125.43 − 110.61 | **13.0743** (slide 13.0742); 53.60; 14.82 | ✗ (4th dp) |
| 35 | j88 | naive to 15 Nov 2021 | 127.26 | ✓ |
| 36 | j90 | 110.61 × 4.10; 112.3514 × 4.10 | 453.50; 460.64 | ✓ |
| 37 | j95 | 410 × 1.1511 as printed | **471.95 → 472.0** (true 471.93) | ✗ |
| 38 | j96/j97 | 3.5% × 471.9; 33.31 − 16.52; 50.64 ÷ 16.8 | 16.52; 16.80; 3.0 | ✓ |
| 39 | j98 | coupon; PV of new debt at 3.5% | 8.259; 472.02 (not worked on the slide) | ✓ value |
| 40 | j99 | six PVs; subtotal | 95.20 | ✓ |
| 41 | j100 | rows 7–13; total | rows sum 430.35 (slide 430.33); exact total 525.53 | ✓ total / ✗ rows as printed |
| 42 | j101–j103 | 525.5 − 471.9; 464.8 − 471.9; 1.74 × 4.10 | +53.6; −7.1; 7.13 | ✓ |
| 43 | j102 | 443.313 × 0.974020; total | 431.80; 464.80 (rows 464.81) | ✓ |
| 44 | j104 | 3 PVs at 0.4475% | 471.93 | ✓ |
| 45 | j105 | (50.64 + 11.29) × 21%; cash after tax | 13.01; 458.92 | ✓ |
| 46 | j107/j108 | after-tax PV at 0.912% / 0.358% | 453.99 / 459.61; NPV −4.93 / +0.69 | ✓ |
| 47 | j109/j110 | after-tax naive PV | 76.895 / 504.31; NPV +45.39 | ✓ |
| 48 | j113 | 16.8/1.5; 50.64/1.5; 7.13/1.5; 4.93/1.5; 53.6/1.5 | 11.2; 33.8; 4.8; 3.3; 35.7 | ✓ |
| 49 | j118 | 112.3514 − 104.0625; 1.26 − 1.57 | 8.29; −31bp | ✓ |
| 50 | j121 (HTML) | 28.07 ÷ 1.5; 18.7 ÷ 3,600 | 18.7; 0.52% | ✓ |
| 51 | j124/j125 | 20% × 16.8; (112.3514 − 111.276) × 4.10 | 3.36; 4.41 | ✓ |
| 52 | j130/j131 | early cash; late; accrued; total; 79.61%; 99.9%; 83.583 × 1.040625 | 366.40; 0.33; 8.99; 375.72; 79.61%; 99.91%; 86.98 | ✓ |
| — | j08 | Porsche 189,849 ÷ 162,145 − 1 | **17.09%** (slide 17.0%) | ✗ |

Every chart's bar heights were also measured against its stated base on these slides: j14, j31, j55, j80 (base 108), j89 (scale 106–128), j125 (base 109), j132 and j134. All are proportional except **j65** (finding 7).
