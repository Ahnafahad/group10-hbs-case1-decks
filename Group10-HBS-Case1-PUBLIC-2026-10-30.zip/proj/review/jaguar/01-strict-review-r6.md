NOT READY. Grade estimate A− (the plan itself is A−/A). One narrow blocking item: `answers.md` still has two stale lines from earlier rounds, and one of them is now false. The plan has no hard-requirement failure. The fix takes two lines.

# Jaguar storyline: strict independent review, round 6 (gate 1)

**Deliverable:** `review/jaguar/01-storyline.md` (140 slides, round 6), with `work/jaguar/answers.md` as the supporting answers file.

**What I read, in full:**
- `review/shared/review-rubric.md`
- the grading brief
- `case-layout.txt` (all six exhibits)
- CLAUDE.md and DESIGN.md
- PROGRESS.md (user feedback and decisions, including the 2026-10-30 "Mix (Recommended)" choice)
- the output of `python3 work/jaguar/calcs.py`
- `answers.md`, `sources.md` and `sources_research.md` (all 383 lines)
- the r5 review
- `work/jaguar/check/check_answers.md` (only the line behind B1)
- the G1 NESA benchmark (skimmed: 268 slides, with full discount tables on single slides)

I read the teaching note only to confirm the four questions.

**What I recomputed myself** (my own scratch script, not calcs.py):
- YTC 2.2801% and YTM 5.9446% at 111.276 (4 Feb 2015, 79 days accrued)
- all ten values to the call, with every discount factor and PV row (0.5%, 0.75%, 1%, 1.5%, 2%, 2.28%, 2.5%, 3%, 3.5%, 0.895%)
- naive 128.18 / 125.43
- the after-tax table at 0.716%, row by row (459.61)
- cash paid 471.93; tax saved 13.01
- the 0.2885% interpolation
- the checker's 110.44

**Re-fetched live today (30 Oct 2026):**
- PR Newswire pricing release: 0.395%, 50bp, US$30, 1,123.52 / 1,093.52, 27.53 / 30.69
- PR Newswire final results: US$326.417m = 79.61%; US$83.583m left outstanding
- JLR investor-relations page: Q1 FY27 £6.0bn (£5,973m), PBT before exceptional items £109m, 2.8%. Q2 FY27 has only a 3 Oct sales update, so Q1 FY27 is still the latest result.
- Fortune, 9 Mar 2015: about 4.6 points vs 3.3 points in summer 2014

## 0. Were the round-5 blocking items fixed?

| r5 item | Status | Evidence |
|---|---|---|
| **B1:** the after-tax value at the offer's 0.716% rate had no working | **FIXED** | **New slide 108** has a point title ("After tax at the offer's own 0.716% rate, the old notes cost US$459.6m"). It uses slide 107's columns at 0.358% per half-year and shows three rows: 13.32 × 0.998849 = 13.31; 13.32 × 0.995286 = 13.26; 436.65 × 0.991736 = 433.04. The total is 459.61 ("rows rounded"), NPV 459.6 − 458.9 = +0.7, and it ends with a so-what. I recomputed it: the DFs are 0.998849 / 0.995286 / 0.991736, the PVs 13.310 / 13.262 / 433.041, and the total 459.613. calcs.py now prints the three rows (r3 block, "after-tax at 0.895% x 0.8"). Slide 111 cites "(0.716%, slide 108)" and slide 112's table carries 0.0 / +0.7. The renumbering map (r5 108–139 → 109–140) checks out: r5's 109 title fix now sits on 110, and r5's 110 and 111 are now 111 and 112. |
| **B2:** `answers.md` not aligned with the plan | **FIXED for all six named lines; two stale lines remain elsewhere (new B1)** | All six named lines now match the plan: <br>• Q2 answer "110.6–112.4 clean … (US$453.5–460.6m) … plus accrued", floor 110.61 and ceiling 112.35 described as on slide 90 (line 38) <br>• option value "about 15 points (125.43 − 110.61 = 14.82; approximate …)" (line 39) <br>• after-tax 0.895% row "+US$0.7m (at 0.716%)" (line 52) <br>• tax 21% at the 17 Mar settlement and 20% from 1 Apr 2015 (line 11) <br>• maturity decision recorded (line 10) <br>• Q4 refinancing risk stated both ways, in r5's wording (line 67) <br>Also aligned: timing cost 1.74 (US$7.1m) (line 68), Test 1 in spreads, 497 → 199bp (line 20), holders +1.74 / +1.08 (line 70). <br>**Still stale:** the independent-check table (line 78) and Q1 (line 26). See B1. |

**New errors introduced by the fixes:** none in the plan. Slide 108's numbers, its cross-references (111, 112) and the renumbered references I traced are all correct:
- 17 → 130; 39 → 81; 54 → 31; 61 → 58; 80 → 71–79 and 82; 90 → 71 and 82; 104 → 103; 109 → 99; 111 → 108; 122 → epilogue 134

## 1. Verdict
**NOT READY. Grade estimate A−.**
- Plan: zero hard-requirement failures.
- Quality scores: all ≥ 4.
- One blocking item is left: `answers.md` must agree with the plan everywhere (brief, and r5 B2). Line 78 keeps the old "111–112" and says the checker's 110.44 "is inside our band". Against the plan's band (floor 110.61) that is now false. Line 26 says the market-wide spread data is "still being sourced", but plan slide 59 uses sourced data.
- It becomes READY once B1 is fixed. The plan itself needs no change.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover details are a placeholder). Overview 3–17, with the toolkit 18–25 placed before first use. Exhibits 26–50. Q1 51–62, Q2 63–90, Q3 91–113, Q4 114–127. Epilogue 128–139. Team placeholder 140. |
| H2 Every exhibit | PASS | Each exhibit is native, labelled "Exhibit N" with a source line, and has shows / numbers / meaning / implication: <br>• **Ex1** 27–33: all six notes, the revolver, factoring, and the FX rate (1.559 vs 1.50) <br>• **Ex2** 34–37: all four bond pairs; the stale Aug-2014 line; "i" and ISIN explained <br>• **Ex3** 38–39: rebuilt from the Treasury CSV; the rows match `sources.md` #1 <br>• **Ex4** 40–43: inputs shown <br>• **Ex5** 44–46 <br>• **Ex6** 47–49 <br>• synthesis on 50 |
| H3 Every question, all seven elements | PASS | **Q1:** question and parts 52; theory 23 and 55; evidence 53–61 (case and Treasury CSV, HY index); assumptions 52; alternatives 55–59 (four tests). <br>**Q2:** 64; parts 65–69; theory 22, 24, 84; evidence 66, 81–83; assumptions 67, 69; alternatives 71–89. <br>**Q3:** 92; 93, 98, 106; 94; 95–113. <br>**Q4:** 115; 116, 123; 118, 120; 115; 117–118, 122. <br>Every calculation is worked on a slide, including 0.716% (now 108). |
| H4 External, sourced, current | PASS | Every [src] I traced has a URL, access date and exact quote. Secondary sources are labelled (4, 8, 9, 14, 59, 94, 136, 138). Current to Q1 FY27; I confirmed live today that no Q2 FY27 result exists yet. |
| H5 No teaching note | PASS | A grep finds only the plan's own header line ("never refers to a teaching note"), which is plan metadata, not slide text. The ~25% appears only as "the naive view" (85–89). `answers.md` keeps its comparison in the marked "for checking only" section. |
| H6 Titles | PASS | Every content title states a point; none is longer than about 17 words (138). |
| H7 Finance correct | PASS | Checked correct: <br>• part-period semi-annual discounting (21) <br>• 30/360 accrued interest; clean vs full price (25, 68) <br>• YTM as IRR with the reinvestment assumption; YTC / YTW (22, 24) <br>• callable = straight − call (84), with 14.82 flagged as approximate (87) <br>• new debt at market rate has NPV ≈ 0 (98) <br>• NPV = PV of old debt avoided − cash paid <br>• after tax: premium and accrued deductible at 21% at settlement; coupons and call premium at 20%; principal not deductible (105–110) <br>• MM and market efficiency (116) <br>• tender-vs-wait (118) <br>• refinancing risk against both baselines (122) <br>One loose phrase, "capped near its call price" (24, 84), is non-blocking #1. |
| H8 Numbers | PASS (plan) | 47 numbers checked (section 4). All match within last-digit rounding. Formats: money 1 dp, prices 2 dp, yields 2 dp, bp whole. The one false claim is in `answers.md` (B1). |
| H9 User decisions | PASS | • Call-aware Q2 first (64–83 before 85–88). <br>• US$ maths, converted once at 1.50 (33, 113, 121). <br>• 15 May 2021 used throughout, with exactly one 15 Nov 2021 slide (88; the grep finds no other). <br>• One slide per repeated calculation: the ten values to call (71–79, 82), each baseline before and after tax (99–110), and now 108. <br>• The 2026-10-30 "Mix" choice is a Gilts decision. Jaguar matches its spirit: repeated bond valuations get their own slides, and simple ratio tables (41–49) show every year's numbers plugged in. |
| H10 Known traps | PASS | • Semi-annual coupons and the May 2016 call: 18, 21, 24, 66–67. <br>• US$ vs £: 33. <br>• Clean/dirty and 30/360, with accrued paid separately: 25, 68, 83, 90. <br>• ~25% naive vs ~11% market vs our answer, reconciled without the teaching note: 85–90. <br>• Credit, not Treasuries, tested four ways: 26bp like for like (56), the same bond 497 → 199bp (57), five issues (58), the market index (59). <br>• Fair-price refinancing ≈ no value, tested with three baselines before and after tax: 98–113, 124. |
| H11 Lucidity | PASS | The toolkit comes before use; terms are defined where first used (tenor now on 58, 0.395% pointed to 81, why a grid of rates on 73). Every PV table has n and DF, and every calculation slide ends with a so-what. Soft spots (fewer than a handful): 24/84 ("capped near its call price", when the values shown are 109–113); 27 ("factoring" not defined); 119 ("carrying amount" not defined). Fixes are in section 6. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Reproduces the tender price to US$0.01; ten worked values to the call; "credit, not rates" tested four ways; three baselines before and after tax, each worked; a three-party split of who gains. |
| Q2 Logic and flow | 4 | Clean concept → exhibit → question → epilogue flow. Small seams: 57 says "15-month" and 69–70 say "14-month" with no bridging line; 133 mixes FY2019 with COVID. |
| Q3 Evidence | 4 | Primary releases, legislation and Treasury CSVs, with secondary sources labelled. The epilogue figures check out live. |
| Q4 Lucidity | 4 | A part-way CFA Level 1 reader follows almost every slide on paper. Three small soft spots (above) keep it from a 5. |
| Q5 Calculations | 5 | Every value is worked on a slide and reproduces on a calculator within the last shown digit. Inputs are shown for 31, 40–49 and 58. |
| Q6 Overview and epilogue | 4 | Sourced history, industry and credit context. The epilogue runs from the tender result to Q1 FY27 and ties back on 129/139. |

## 4. Number spot-check (47 numbers)

| Number | Slide | Source | Match |
|---|---|---|---|
| 0.3222 half-years; 1 ÷ 1.0114^0.3222 = 0.9964 | 21 | my recompute 0.996354 | yes |
| £273.3m × 4.625% = £12.6m; £500m × 4.375% = £21.9m; £34.5m | 30 | calcs; 12.64 / 21.875 | yes |
| 8.125 − 3.15 = 497; 5.625 − 2.00 = 362; 4.125 − 1.52 = 260; 4.250 − 1.53 = 272; 3.500 − 1.61 = 189 | 31, 58 | calcs Test 2; Treasury rows R3-7 (10Y 2.00 on 28 Jan 2013; 5Y 1.52, 1.53, 1.61) | yes (half-bp rounded down; non-blocking #3) |
| 410/263 = 1.559 | 33 | calcs | yes |
| YTM 5.94%, YTC 2.28% at 111.276 | 35, 70 | my recompute 5.9446 / 2.2801 | yes |
| 19,386 ÷ 13,512 − 1 = 43.5%; 2,501 ÷ 1,479 − 1 = 69.1% | 40 | case Ex4; calcs | yes |
| EBITDA FY12 1,999 (14.8%), FY15 2,880 (18.0%) | 41 | calcs; 1999/13512, 2880/16040 | yes |
| 751/1,479 = 51%; 860/1,674 = 51%; 1,030/2,501 = 41%; 850/2,218 = 38% | 42 | case Ex4 | yes |
| 19/1,479 = 1.28%; 460/1,674 = 27.48%; 622/2,501 = 24.87%; 482/2,218 = 21.73% | 43 | case Ex4 | yes |
| FCF 1,090 / 580 / 1,066 / 540; after interest and dividends 962 / 251 / 647 / 293 | 45 | case Ex5; calcs | yes |
| Cover 15.6× / 13.3× / 12.2× / 29.7× | 46 | calcs; Ex5 | yes |
| Net cash 456 / 680 / 1,449 / 1,604 | 48 | case Ex6; my sums | yes |
| D/E 0.68 / 0.61 / 0.34 / 0.36 | 49 | case Ex6 | yes |
| 497 / 193 / 462 = 304 + 158; 66% | 53–55 | calcs | yes |
| 1.83% → 1.57% = 26bp | 56 | `sources.md` #1 | yes |
| 466 days = 1.276 yr; 0.20 + 0.276 × 0.32 = 0.29%; 199bp | 57 | `sources.md` 4 Feb row; my recompute 0.2885 | yes |
| 502 → ~460bp, ~40bp; ~260bp JLR-specific | 59 | R2-2 quotes (BofA 502; Fortune 4.6 pts, re-fetched) | yes |
| 122 days → US$27.53; 136 days → US$30.69 | 68 | PR Newswire (re-fetched) | yes |
| 2.28%: 0.996354 / 0.985123 / 0.974019 → 113.37 → **110.61** | 71 | my recompute | yes |
| 3.5% → 111.87 → **109.11** | 72 | my recompute | yes |
| 0.50%: 0.9992 / 0.9967 / 0.9942 → 115.61 → 112.85 | 73 | my recompute 115.608 / 112.855 | yes |
| 0.75% → 115.29 → 112.54; 1.00% → 114.97 → 112.22 | 74–75 | my recompute | yes |
| 1.50% → 114.34 → 111.59; 2.00% → 113.71 → 110.96 | 76–77 | my recompute | yes |
| 2.50% → 113.09 → 110.34; 3.00% → 112.48 → 109.72 | 78–79 | my recompute | yes |
| 0.395% + 0.50% = 0.895%; 0.998562 / 0.994114 / 0.989685 → 115.10 → **112.35** | 81–82 | PR Newswire (re-fetched); my recompute 112.3514 | yes |
| US$1,123.52 / 1,093.52 | 83 | PR Newswire (re-fetched) | yes |
| Naive 128.18 → 125.43; 12.6–16.3 | 85–86 | my recompute 128.179 / 125.426 | yes |
| 14.82; 13.07 × 4.10 ≈ US$54m | 87 | calcs | yes |
| 127.26 (15 Nov 2021) | 88 | calcs | yes |
| 110.6–112.4; US$453.5–460.6m | 90 | 453.50 / 460.64 | yes |
| 471.9; 28.1 | 95 | my recompute 471.930 | yes |
| 33.3 vs 16.5 → 16.8 a year; premium 50.6 incl. 12.3 | 96–97 | calcs | yes |
| New-debt PV 472.0 | 98 | calcs 472.02 | yes |
| 95.2; 430.3; 525.5; +53.6 | 99–101 | calcs | yes |
| 464.8; −7.1 | 102–103 | calcs | yes |
| 16.63 + 16.56 + 438.74 = 471.9 | 104 | calcs | yes |
| (50.6 + 11.3) × 21% = 13.0; 458.9 | 105 | my recompute 13.005 | yes |
| 1.82% / 2.80% | 106 | calcs | yes |
| 13.29 + 13.17 + 427.54 = 454.0 | 107 | calcs | yes |
| **0.716% table: 13.31 / 13.26 / 433.04 = 459.61; +0.7** | 108 | my recompute 459.613; calcs rows | yes |
| 504.3; last payment 423.32 | 110 | calcs | yes |
| −4.9 / +45.4 / +0.7 | 111–112 | calcs | yes |
| £33.8m; −£4.8m; −£3.3m; +£35.7m | 113 | calcs | yes |
| 112.35 − 110.61 = 1.74 → US$7.1m; 8.29 over the call; 1.26% (16 May 2016) | 118, 125 | calcs; `sources.md` row | yes |
| £18.7m | 121 | calcs | yes |
| 79.61%; US$375.7m | 130 | PR Newswire (re-fetched); calcs 375.72 | yes |
| US$83.6m; US$87.0m | 131 | final results (re-fetched); calcs 86.98; 20-F quote | yes |
| answers.md Q2: 110.6–112.4, US$453.5–460.6m, 14.82; Q3: +53.6 / −7.1 / 0.0 / −4.4 and +45.4 / −4.9 / +0.7; Q4: 1.74 (US$7.1m), 1.08 (US$4.4m) | answers.md | calcs | yes |
| answers.md checker row: "111–112 … 110.44 … inside our band" | answers.md line 78 | plan 90 (floor 110.61); my recompute | **no** (B1) |

**External facts checked (11):**

Re-fetched live today:
1. PR Newswire pricing
2. PR Newswire final results
3. JLR IR Q1 FY27
4. Fortune 460bp

Checked against the exact quotes in `sources_research.md`:

5. FY2011 £9,871m / £1,115m (R2-4)
6. FY2015 regions summing to 462,209, and Changshu 130,000 (R3-2)
7. BMW +9.5%, Audi +10.5%, Mercedes-Benz +12.9%, Porsche +17%; Land Rover 385,279 (+8.9%) (R3-3)
8. Retail series FY15–FY21 (R3-4)
9. 2019–20 coupons 5.875 / 6.875 / 7.75 / 5.875%; B+ / B1 (R3-5)
10. S&P BBB- (20 Aug 2024) and Moody's Ba1 (13 Jun 2025) (R3-6)
11. 21% (Finance Act 2013 s.4) and 20% (Pinsent Masons) (R2-7)

All support the plan.

## 5. Blocking items (slide → problem → exact fix)

**B1. `work/jaguar/answers.md`, lines 78 and 26: two stale lines contradict the plan (the brief requires answers.md to agree with the plan everywhere; r5 B2).**
- **Problem, line 78 (independent-check table, Q2 headline):**
  - It still says "Ours: 111–112 (to call; market and tender anchors)".
  - It explains the checker's 110.44 as "it is inside our band".
  - The plan's band is 110.61–112.35 (slide 90), so 110.44 is 0.17 below our floor. The stated reason for the difference is false.
  - I recomputed why. The checker settles on 31 Mar. At its own 2.24% on our 17 Mar date it gives 110.66, which is inside the band. At 31 Mar it gives 110.44, because a premium bond's clean value drifts toward the call price as the call date nears.
- **Problem, line 26 (Q1 drivers):** "market demand for high-yield bonds (market-wide spread data still being sourced)". Plan slide 59 uses the sourced data (BofA ~502bp in May 2011, Fortune ~460bp in Mar 2015, so market-wide spreads fell about 40bp vs JLR's 304bp).
- **Exact fix:**
  - Line 78 → "| Q2 headline | 110.6–112.4 (to call, 17 Mar: floor at the market's 2.28%, ceiling at the offer's 0.895%) | 110.44 (to call at 2.24%, settle 31 Mar) | 0.17 below our floor only because it settles on 31 Mar (the clean value drifts toward the call price); at its 2.24% on our 17 Mar date it gives 110.66, inside our band |".
  - Line 26 → "market-wide high-yield spreads fell only about 40bp (BofA ~502bp, May 2011 → Fortune ~460bp, Mar 2015; different indices, indicative), vs 304bp for JLR, so about 260bp is JLR-specific (plan 59)".
  - Optional, same pass: line 85, "our answer (11–12%)" → "(10.6–12.4%)". Line 80, "+53.5": add "(+53.6 in the PV form used on the slides; the 0.1 difference is the new debt's PV 472.0 vs 471.9 borrowed)".

## 6. Non-blocking improvements (most valuable first)
1. **24 and 84:** "a callable bond's price is capped near its call price" will puzzle a reader who sees values of 109–113 against a call price of 104.06. Say "capped near the value of being repaid on the call date: the call price plus the coupons until then (at most about 113 here, slide 73)".
2. **Accrued shown as 2.75 on 71–82 and 86:** several subtractions are 0.01 off on a calculator (e.g. 73: 115.61 − 2.75 = 112.86, shown 112.85). Show accrued as 2.7535 in the subtraction line so every step reproduces exactly.
3. **31, 53, 58:** 8.125 − 3.15 = 4.975 = 497.5bp, 5.625 − 2.00 = 362.5bp, and 4.125 − 1.52 = 260.5bp are shown as 497 / 362 / 260. A reader rounding half up gets 498 / 363 / 261. Add one footnote: "half basis points rounded down; this changes no conclusion".
4. **107, 108, 109, 110:** "16.66 − 3.33 = 13.32" (a calculator gives 13.33). Add a footnote: "coupon US$16.656m; after tax 13.325".
5. **calcs.py:** the Q3 and Q4 blocks still print superseded figures without a "[superseded]" tag: "saving 19.0 a year; 2.7 years", "total 34.0" at 1.559, "B to call @3.50% −13.3", "bondholders vs being called … +13.3". Gate-3 builders pull numbers from calcs, so tag or remove them.
6. **27:** define "receivable factoring (selling invoices to a bank for cash now)". **119:** define "carrying amount (the value of the notes in JLR's books)".
7. **57 vs 69–70:** add one line: "15 months from the 4 Feb price date; 14 months from the 17 Mar deal date".
8. **133:** the COVID shutdown and the chip shortage belong to FY2021. Move them to 135, or retitle 133 to cover FY2019–21.
9. **answers.md line 11:** "Finance Act 2013 … s.6" has no quote in the sources files. Drop "s.6", or add its quote to `sources_research.md`.
10. **Checklist:** add 118 to the "every calculation shown" row.

## Strongest parts
- Q2 reproduces JLR's real tender price to the cent. It works all ten discount rates on their own slides and reconciles them with the market price and the naive 125.
- Q3 proves that new debt at market rates has zero NPV. It then values every baseline, before and after tax, with dated tables, now including the offer-rate after-tax case (108). The tax treatment is right.
- Q1 tests "credit, not Treasuries" four ways instead of asserting it.
