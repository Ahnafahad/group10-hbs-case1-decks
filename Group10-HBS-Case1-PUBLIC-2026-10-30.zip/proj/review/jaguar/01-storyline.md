# Jaguar Land Rover: storyline (gate 1, round 7: after strict review round 6)

One line per slide: **section · the point (becomes the title, ≤ 2 lines, about 15 words or fewer) · what it shows**. Two tags help lucidity:
- **Plain:** a term defined in plain words where it first appears
- **So what:** the one-line takeaway. Every calculation slide ends with one; concept and fact slides carry one where the point is not already the title.

The reader is a student part-way through CFA Level 1, reading on paper with no presenter (user rule). The full analysis stays; it is explained, not simplified.

`[src]` points to `work/jaguar/sources*.md`; numbers come from `work/jaguar/calcs.py`. All bond maths in US$, converted once at 1.50 (user rule). The case's maturity date, 15 May 2021, is used, plus one note slide (user rule). Every repeated calculation gets its own slide (user rule). The deck never refers to a teaching note. Every table that discounts bond payments has the columns: date · n (half-years from 17 Mar 2015) · cash flow · discount factor · PV.

## 0 · Opening
1. **Cover**: "Jaguar Land Rover: did refinancing at half the rate create value?" · Group 10, course [PLACEHOLDER: user to supply]
2. **JLR halved its interest rate in 2015; can that be a free lunch in an efficient market?** · the case's question; the four questions, one line each; the sections. Plain: efficient market = prices already reflect all public information, so nobody can buy or sell at a "wrong" price for free

## 1 · Case overview
3. Divider · 01 Case overview
4. **Two British brands, born in 1922 and 1948, owned by Ford and then Tata** · timeline: Jaguar 1922 (Swallow Sidecar), Land Rover 1948 [src: JLR]; Ford bought Jaguar in 1989 and Land Rover from BMW in 2000 (€3bn) [src, secondary]; Tata 2008 [src: JLR]; earlier British Leyland/BMW years only as background (not sourced to primary)
5. **Tata bought JLR from Ford in June 2008 for US$2.3bn, as the crisis hit** · deal facts [src]; volumes −32% in 10 months, FY2009 loss £402.4m (case p.2)
6. **Three years later JLR made £1,115m before tax on £9.9bn of revenue** · FY2011: wholesales 243,621 (+26%), revenue £9,871m (+51%), PBT £1,115m vs £51m [src]; profit after tax £1,035.9m (case p.2)
7. **JLR sold 462,209 vehicles in FY2015; China was its biggest market** · by region: China 115,969, Europe 87,863, UK 86,750, North America 78,372, Asia Pacific 26,619, other 66,636; Changshu plant with Chery opened Oct 2014 (130,000 capacity) [src: JLR FY2015 report, release]
8. **Premium rivals grew 9–17% in 2014, while the EU set a 95g CO2/km limit for 2020** · BMW +9.5%, Audi +10.5%, Mercedes-Benz +12.9%, Porsche +17% (calendar 2014) [src; BMW and Audi secondary]; Land Rover brand +8.9% in FY2015 to 385,279 [src: JLR]; EU Regulation 333/2014 [src]. Plain: CO2 g/km target = the average emissions limit per car sold. So what: JLR had to grow and spend heavily on cleaner cars at the same time
9. **JLR sold about a quarter as many cars as BMW, Audi or Mercedes-Benz** · 2014: BMW 1,811,719 (secondary), Audi 1,741,129 (secondary), Mercedes-Benz 1,650,010, Porsche 189,849; JLR 462,209 [src]. Note on slide: JLR's figure is its fiscal year to March 2015; rivals' are calendar 2014
10. **JLR is Tata Motors' cash engine: over 80% of its automotive revenue** · and the only source of consolidated operating profit in FY2014 (case p.2)
11. **JLR borrows in pounds and dollars to match where it earns** · Plain: natural hedge = borrowing in the currency you earn in, so currency moves hit both sides; ~17% of revenue each from the UK and North America (case p.3)
12. **JLR's credit improved: Moody's upgraded it to Ba2 in 2013 and outlooks turned positive in 2014** · Plain: credit rating = an agency's grade of default risk; Ba/BB = "high yield" (below investment grade); outlook = where the agency expects the rating to move next (case p.2) [src]
13. **But heavy spending lay ahead: £3.6–3.8bn of capex planned for FY2016** · Moody's expected free cash flow to turn negative (case p.2). Plain: capex = spending on plants and equipment
14. **In early 2015 the Fed was at zero, but high-yield spreads had widened to about 460bp** · Plain (on this slide, before the toolkit): spread = the extra yield a company pays over a government bond; bp (basis point) = 0.01 percentage point, so 460bp = 4.60 points. Fed funds 0–0.25% until Dec 2015 [src]; high-yield spreads 330bp (2014) → ~460bp (Mar 2015) [src, secondary]. So what: the market was not getting easier; JLR still borrowed at only about 190bp over Treasuries
15. **JLR refinanced twice in two months: sterling in February, dollars in March 2015** · Feb: £400m 3.875% 2023 replaces £500m 8.25% 2020; Mar: US$500m 3.5% 2020 replaces US$410m 8.125% 2021 [src; case p.1]
16. **Holders could sell their notes back, swap into the new issue, or keep them without covenant protection** · Plain: tender offer = the issuer offers to buy its own bonds; consent solicitation = asking holders to vote away the covenants (the promises that protect them); early premium = an extra US$30 per US$1,000 for answering by 16 March [src]
17. **US$500m raised; buying back every old note would cost US$472m, leaving US$28m before fees** · flow diagram, every arrow labelled with the money and what it is; note: the all-tendered case is used in Q3; the actual cost (79.61% tendered) was US$375.7m (slide 130)

## 1b · Bond toolkit (concepts used in the rest of the deck)
18. **A bond's price is quoted per 100 of face value; JLR's notes pay coupons twice a year** · Plain: face value = the amount repaid at maturity; coupon = the fixed interest (8.125% a year = US$40.625 per US$1,000 every six months). So what: every price in this deck is "per 100 of face value"
19. **A basis point (bp) is one hundredth of a percentage point** · 1bp = 0.01%; example from this deck: 3.50% − 1.57% = 1.93 points = 193bp (bp always shown as whole numbers). So what: spreads and rate changes are quoted in bp
20. **Money paid later is worth less today: present value and discounting** · Plain: PV = future cash ÷ (1 + rate)^time; one-bond example. So what: every valuation in this deck is this one idea
21. **Bonds that pay twice a year are discounted in half-years, starting with a part-period** · in words first: (1) rate per half-year = annual yield ÷ 2; (2) count time in half-years from the deal date, 17 March 2015; the first coupon (15 May) is only 58 of 180 days away = 0.3222 half-years, then 1.3222, 2.3222…; (3) discount factor = 1 ÷ (1 + yield/2)^n. Worked: at 2.28%, the 15 May 2015 factor = 1 ÷ 1.0114^0.3222 = 0.9964. So what: this is the rule behind every PV table that follows
22. **Yield to maturity: the single rate that makes the PV of a bond's cash equal its price** · Plain: YTM = the bond's internal rate of return if held to maturity, assuming coupons are reinvested at the same rate; higher yield → lower price. So what: a price and a yield are two ways of saying the same thing
23. **A company's yield = a Treasury yield + a credit spread** · Plain: credit spread = the extra yield investors want for the company's default risk (CFA FI LM07); two-layer picture. Plain: yield curve = Treasury yields plotted against time to maturity (used on Exhibit 3). So what: a lower company yield can come from either layer, and Q1 separates them
24. **A call lets JLR repay early, so investors price to the call date** · Plain: call option = the issuer's right to repay early at a set price; yield to call = the yield if repaid on the call date; yield to worst = the lower of yield to call and YTM. So what: a callable bond's price is capped near the value of being repaid on the call date: the call price plus the coupons until then (at most about 113 here)
25. **Between coupon dates a buyer pays the price plus the interest earned so far** · Plain: clean price = quoted price; accrued interest = coupon earned since the last payment, counted 30/360; full price = clean + accrued (CFA FI LM06). So what: tender prices are clean; accrued is paid on top

## 2 · Exhibit analysis
26. Divider · 02 Exhibit analysis
27. **Exhibit 1: JLR owed £2.4bn at end-2014, almost all in six fixed-rate notes** · native table, rebuilt; source line "Exhibit 1, case (JLR FY2015 Q3 interim accounts, p.6)". Plain: receivable factoring = selling customer invoices to a bank for cash now. So what: debt is notes, not bank loans
28. **Notes are 92% of borrowing; the £1,485m credit line is completely unused** · composition chart. Plain: revolving facility = a pre-agreed credit line. So what: JLR had spare liquidity; it refinanced by choice, not need
29. **The two oldest notes cost most, 8.125% and 8.25%, and both become callable in 2016** · notes ranked by coupon, with call dates. So what: these are the obvious refinancing targets
30. **Those two notes cost £34.5m a year more than JLR's 2015 rates** · at 1.50: US$410m = £273.3m × (8.125 − 3.5)% = £12.6m; £500m × (8.25 − 3.875)% = £21.9m. So what: a clear target for refinancing
31. **JLR's spread over Treasuries fell from 497bp (2011) to 189bp (2015)** · spread at each US$ issue (assumes each note was issued at par, so its coupon = its yield): 497 (May 2011) → 362 (Jan 2013) → 260 (Dec 2013) → 272 (Oct 2014) → 189 (Mar 2015, pricing day 3 Mar); each = coupon − Treasury of the same length: 8.125 − 3.15 = 497; 5.625 − 2.00 = 362; 4.125 − 1.52 = 260; 4.250 − 1.53 = 272; 3.500 − 1.61 = 189 [src: Treasury CSVs; issue dates partly approximate]. So what: lenders demanded much less for JLR's risk, with one small rise in 2014
32. **Repayments are spread from 2018 to 2023, so there is no single wall of debt** · maturity ladder (£m per year). So what: low refinancing pressure in any one year
33. **Exhibit 1 converts dollars at about 1.56; the case tells us to use 1.50 for March 2015** · 410/263 = 1.559; £263m vs £273.3m. So what: we keep the bond maths in dollars and convert once at 1.50
34. **Exhibit 2: the market valued the 8.125% notes at 111.28, an 11% premium** · native table; source line "Exhibit 2, case (market data)"; plain notes on its jargon (two ISIN lines = the same bond sold to US and non-US investors; "i" = indicative price, no trade that day); price dated 4 Feb 2015, before the offer; second line stale (Aug 2014). So what: holders already valued the notes well above 100
35. **At 111.28 the notes yielded 5.94% to 2021 but only 2.28% to the 2016 call** · calc both. So what: the market already priced the bond as if JLR would repay it in 2016
36. **The sterling 8.25% notes told the same story at 110.94** · the second old bond, refinanced in February [src]. So what: the pattern is not unique to the dollar notes
37. **The new 2015 notes trade at 100, so their coupons equal JLR's market yield** · 3.5% 2020 and 3.875% 2023 rows. So what: 3.5% is JLR's 5-year borrowing cost in March 2015
38. **Exhibit 3: from 2011 to 2015, long Treasury yields fell a lot; short ones barely moved** · rebuilt yield-curve chart from Treasury data (axis titles, units); source line "Exhibit 3, rebuilt from US Treasury daily par yields". So what: the curve flattened at the long end
39. **The 10-year Treasury fell 105bp, the 5-year only 26bp** · change-by-maturity bars; the 14-month Treasury that priced the tender (0.395%, used on slide 81) marked. So what: lower Treasury yields explain little of JLR's lower 5-year rate
40. **Exhibit 4: revenue grew 43% and profit before tax 69% in two years** · native table; source line "Exhibit 4, case"; growth bars FY2012–FY2014 (FY2015 shown as 9 months); inputs: revenue 19,386 ÷ 13,512 − 1 = 43.5%; PBT 2,501 ÷ 1,479 − 1 = 69.1%. So what: a much bigger, more profitable company than in 2011
41. **EBITDA margin rose from 14.8% to 18.0%** · Plain: EBITDA = profit before interest, tax, depreciation and amortisation (a cash-earnings proxy). Step by step each year: PBT + D&A + finance expense − finance income − FX gain. So what: each £ of sales produced more cash to service debt
42. **Capitalised development costs equal 38–51% of profit before tax** · Plain: capitalising = recording R&D as an asset instead of an expense, which lifts this year's profit. Inputs: 751 ÷ 1,479 = 51%; 860 ÷ 1,674 = 51%; 1,030 ÷ 2,501 = 41%; 850 ÷ 2,218 = 38%. So what: profit quality needs care
43. **FY2012's tax charge was unusually low (1.28%), so its profit after tax overstates normal earnings** · effective tax rate = tax ÷ PBT: 19 ÷ 1,479 = 1.28%; 460 ÷ 1,674 = 27.48%; 622 ÷ 2,501 = 24.87%; 482 ÷ 2,218 = 21.73%. So what: compare years on profit before tax
44. **Exhibit 5: operations brought in £2.4–3.4bn of cash a year** · native table; source line "Exhibit 5, case"; CFO bars. Plain: CFO = cash from operations. So what: JLR's cash generation was large and steady
45. **Free cash flow stayed positive but thin, and Moody's expected it to turn negative** · Plain: FCF = CFO − capex (capex here includes spending on intangibles such as development). Each year's inputs: 2,500 − 596 − 814 = 1,090; 2,429 − 891 − 958 = 580; 3,422 − 1,201 − 1,155 = 1,066; 2,572 − 1,147 − 885 = 540 (9 months); after cash interest and dividends £962m, £251m, £647m, £293m. So what: heavy investment ate most of the cash, so cheap long-term funding mattered
46. **Cash interest is small next to earnings: EBITDA covers it 12 to 30 times** · EBITDA ÷ cash finance paid (Exhibit 5), each year's inputs shown (e.g. FY2012: 1,999 ÷ 128 = 15.6×): 15.6×, 13.3×, 12.2×, 29.7×; FY2015 covers 9 months, and coupon payment timing makes it look high. Plain: interest cover = how many times earnings pay the interest. So what: default risk from interest costs is low
47. **Exhibit 6: equity more than doubled, from £2.9bn to £6.8bn** · native table; source line "Exhibit 6, case"; equity bars. So what: a thicker cushion for lenders
48. **JLR held more cash than debt: net cash rose from £456m to £1,604m** · cash + deposits − debt, by year, inputs shown: 2,430 + 0 − 490 − 1,484 = 456; 2,072 + 775 − 328 − 1,839 = 680; 2,260 + 1,199 − 167 − 1,843 = 1,449; 2,884 + 1,143 − 193 − 2,230 = 1,604. So what: JLR could repay all its debt from cash; lenders face little default risk
49. **Debt/equity halved, from 0.68 to 0.36** · Plain: debt/equity = debt ÷ shareholders' equity, a measure of leverage. Ratio table by year, inputs shown: (490 + 1,484) ÷ 2,924 = 0.68; (328 + 1,839) ÷ 3,539 = 0.61; (167 + 1,843) ÷ 5,864 = 0.34; (193 + 2,230) ÷ 6,797 = 0.36. So what: much lower leverage supports a better rating and a lower spread
50. **The exhibits together: a stronger borrower, expensive callable notes, and a market already pricing the call** · synthesis linking each exhibit to Q1–Q4

## 3 · Q1: why could JLR borrow at less than half the 2011 rate?
51. Divider · 03 Q1
52. **Q1: what let JLR's coupon fall from 8.125% to 3.5%?** · three candidate causes: Treasury rates, the bond's length and features, JLR's credit. Assumptions: issued at par; Treasuries matched to each note's length
53. **2011: 8.125% = 3.15% Treasury + 497bp spread** · 10-year Treasury, 16 May 2011. So what: in 2011 most of the coupon was credit spread
54. **2015: 3.50% = 1.57% Treasury + 193bp spread** · 5-year Treasury, 16 Mar 2015 (Exhibit 3's date). One line: on the 3 Mar pricing day the 5-year Treasury was 1.61%, so 189bp (slide 31); the 4bp gap changes nothing. So what: the spread, not the Treasury, shrank most
55. **Two thirds of the 462bp fall came from a narrower credit spread** · footnote: half basis points are rounded down throughout (e.g. 497.5 → 497; 462.5 → 462); waterfall: spread 304bp (66%); Treasury level and shorter length 158bp (34%). Plain: the 304bp also includes the value of the 2011 notes' call feature and the extra spread a 10-year loan carries over a 5-year one; these cannot be split out without the 2011 issue terms in more detail. So what: JLR's own credit, not the market, did most of the work
56. **At the same 5-year length, Treasuries fell only 26bp** · 1.83% → 1.57%. So what: lower government rates explain little of the fall
57. **Test 1: the same bond's spread over Treasuries fell from 497bp at issue to 199bp in Feb 2015** · the 2015 yield to call 2.28% minus the Treasury for the same 15-month horizon on 4 Feb 2015: interpolate 1-year 0.20% and 2-year 0.52% at 1.276 years → 0.29%; 2.28% − 0.29% = 199bp [src: Treasury CSV]. Note: 15 months from the 4 Feb price date (the 14-month horizon on slides 69–70 counts from the 17 Mar deal date). Caveat: 497bp is a 10-year spread and 199bp a 15-month spread, so part of the fall is the extra spread long loans carry; the 0.29% is a straight line between the 1-year and 2-year Treasury yields. So what: the market itself cut the spread on this very bond by about 300bp
58. **Test 2: across five dollar issues, JLR's spread fell by 308bp** · 497 → 362 → 260 → 272 → 189bp (slide 31's data), tenor-matched (Plain: tenor = the length of a loan; each coupon is compared with the Treasury of the same length): 5.625 − 2.00 = 362; 4.125 − 1.52 = 260; 4.250 − 1.53 = 272; 3.500 − 1.61 = 189; 308bp on the 3 Mar pricing day = 304bp on Exhibit 3's 16 Mar date. So what: a steady fall, issue after issue
59. **Test 3: market-wide high-yield spreads fell about 40bp; JLR's fell 304bp** · Plain: high-yield index spread = the average spread of all below-investment-grade bonds; ~502bp (May 2011) vs ~460bp (Mar 2015), different indices and dates, indicative only [src, secondary]. So what: about 260bp is JLR-specific
60. **The reason: JLR became a far safer borrower** · dashboard from Exhibits 4–6 (EBITDA margin, net cash, debt/equity, cover) + ratings. So what: the falling spread matches the improving numbers
61. **The 2015 notes are also shorter, and the 2011 notes' call had to be paid for** · shorter loans usually cost less (tenor, defined on 58); 2011 notes sold as "callable after five years" [src]; the 2020 notes' early-repayment terms were not found, so no claim is made
62. **Q1 answer: mostly JLR's better credit; lower rates and a shorter term explain the rest** · summary with the waterfall

## 4 · Q2: what price would bondholders accept?
63. Divider · 04 Q2
64. **Q2: what price makes holders give up their 8.125% notes?** · holders' choices: sell in the market, keep (and be repaid in 2016), tender early or late, swap into the new notes
65. **The cash still due: US$40.625 every May and November, then US$1,000** · timeline to 2021. So what: these are the cash flows any valuation discounts
66. **JLR can repay these notes from 15 May 2016 at 104.0625%** · call terms; the 2015 offering memorandum prints 104.663%; we use 104.0625% (par + half a coupon) because only it reproduces the tender price to the cent, and JLR's 8.25% notes follow the same par-plus-half-coupon pattern. Plain: offering memorandum = the legal document that describes a new bond to investors [src: OM p.105; PR Newswire 16 Mar; sources_research A–B]
67. **With 8.125% to pay and 3.5% available, JLR will almost certainly repay in 2016** · the call is JLR's choice, used only if refinancing is cheaper, and here it is by a wide margin; so the notes behave like a 14-month bond. So what: value them to May 2016, not 2021
68. **Accrued interest at 17 March 2015: 122 days → US$27.53 per US$1,000** · 30/360 in words (every month counts as 30 days, a year as 360); 122/180 × 40.625; 31 March: 136 days → US$30.69 [src: matches JLR's payments]. So what: a buyer pays this on top of the clean price
69. **To value the notes, discount their three remaining payments at a 14-month rate** · discount rate choice in words: a holder's required yield for 14 months of JLR risk; recap of slide 21's half-year rule
70. **The market's 14-month rate for JLR was about 2.28%** · from Exhibit 2's price (yield to call; the price is from 4 Feb, the latest before the offer). So what: this is the rate holders were actually accepting
71. **At 2.28%, the notes are worth 110.61** · step table (n = 0.3222, 1.3222, 2.3222): 4.0625, 4.0625, 108.125 × DF 0.996354, 0.985123, 0.974019 → PV 4.05, 4.00, 105.32 → full 113.3656 − accrued 2.7535 = clean 110.61. Note: same 2.28% yield as the 4 Feb market price; the value falls from 111.28 to 110.61 by 17 March because a premium bond's price drifts toward its call price as the call date nears. So what: holders should accept about 110.6 if they need the market's 2.28%
72. **At JLR's own 3.5% borrowing rate, the value to call is lower: 109.11** · step table (same n): DF 0.994425, 0.977322, 0.960513 → PV 4.04, 3.97, 103.86 → full 111.8657 − 2.7535 = clean 109.11. So what: a higher discount rate means holders can ask less
73. **At 0.50%, the value to call is 112.85** · why a grid of rates: a holder's required 14-month rate could sit anywhere from near risk-free (0.5%) to JLR's own 3.5%, so we work each step; same n and layout as 71: rate per half-year 0.250%; DF 0.9992, 0.9967, 0.9942 → PV 4.06, 4.05, 107.50 → full 115.6082 − accrued 2.7535 = clean 112.85 (rows rounded). So what: near a risk-free rate, holders could ask almost 113
74. **At 0.75%, the value to call is 112.54** · same n and layout as 71: rate per half-year 0.375%; DF 0.9988, 0.9951, 0.9913 → PV 4.06, 4.04, 107.19 → full 115.2893 − accrued 2.7535 = clean 112.54 (rows rounded). So what: each 0.25% higher rate takes about 0.3 off the value
75. **At 1.00%, the value to call is 112.22** · same n and layout as 71: rate per half-year 0.500%; DF 0.9984, 0.9934, 0.9885 → PV 4.06, 4.04, 106.88 → full 114.9717 − accrued 2.7535 = clean 112.22 (rows rounded). So what: still above the market's 111.28
76. **At 1.50%, the value to call is 111.59** · same n and layout as 71: rate per half-year 0.750%; DF 0.9976, 0.9902, 0.9828 → PV 4.05, 4.02, 106.27 → full 114.3403 − accrued 2.7535 = clean 111.59 (rows rounded). So what: close to the 4 Feb market price
77. **At 2.00%, the value to call is 110.96** · same n and layout as 71: rate per half-year 1.000%; DF 0.9968, 0.9869, 0.9772 → PV 4.05, 4.01, 105.66 → full 113.7141 − accrued 2.7535 = clean 110.96 (rows rounded). So what: near the market's own 2.28% value (110.61)
78. **At 2.50%, the value to call is 110.34** · same n and layout as 71: rate per half-year 1.250%; DF 0.9960, 0.9837, 0.9716 → PV 4.05, 4.00, 105.05 → full 113.0930 − accrued 2.7535 = clean 110.34 (rows rounded). So what: below the market value: holders would refuse this
79. **At 3.00%, the value to call is 109.72** · same n and layout as 71: rate per half-year 1.500%; DF 0.9952, 0.9805, 0.9660 → PV 4.04, 3.98, 104.45 → full 112.4769 − accrued 2.7535 = clean 109.72 (rows rounded). So what: only 0.6 above the 3.5% value: the range is narrow
80. **The value to call ranges from 112.85 at 0.5% to 109.11 at 3.5%** · summary table and line of the ten worked values (slides 71–79, 82). So what: the lower the 14-month rate, the more holders can ask
81. **JLR priced its offer the same way: to the 2016 call, at a Treasury yield + 0.50%** · Plain: reference Treasury = the government bond whose yield sets the price; fixed spread = a set margin added to it. The 0.25% coupon note yielded 0.395% on 16 March [src]. So what: the offer rate is 0.895%
82. **At 0.895% the price is 112.35, JLR's offer to within US$0.01 per US$1,000** · step table (same n): DF 0.998562, 0.994114, 0.989685 → PV 4.06, 4.04, 107.01 → full 115.1049 − accrued 2.7535 = 112.35 (rows rounded; unrounded they sum to 115.1049). So what: our method reproduces the real offer, so it is the right method
83. **Early tenders got US$1,123.52 per US$1,000, late ones US$1,093.52, both plus accrued interest** · early premium US$30 [src]. So what: the US$30 early premium pushed holders to answer by 16 March
84. **A callable bond is worth the plain bond minus JLR's option to repay** · Plain: CFA rule callable = straight − call option; picture of the price capped near the value of being repaid at the call (call price plus coupons until then, at most about 113 here), called "negative convexity"
85. **The naive view ignores the call: discounting to 2021 at 3.5% gives 125.43** · why 3.5% (JLR's new borrowing cost), cash-flow table with n and DF, 1 of 2
86. **The naive view, continued: full 128.1792 − accrued 2.7535 = clean 125.43** · result; full price to 4 dp so the subtraction reproduces. So what: 12.6–16.3 points more than the call-aware values (112.85 to 109.11), because it pretends JLR will pay 8.125% until 2021
87. **So JLR's option to repay was worth about 15 points** · same date (17 Mar): 125.43 − 110.61 = 14.82 points; approximate, because each horizon uses its own market rate (3.5% to 2021, 2.28% to the call). So what: paying 125 would give holders about US$54m more than the actual offer ((125.43 − 112.35) × 4.10 = 13.07 × 4.10)
88. **JLR's filings date the maturity 15 November 2021; that moves only the naive value, to 127.26** · case date used throughout (user rule); filing quoted [src]. So what: the call-aware answer does not change
89. **Every call-aware value lands at 109–113; only the naive 2021 view reaches 125** · reconciliation chart of five values (109.11, 110.61, 111.28, 112.35, 125.43), each labelled with its method, rate and date. So what: the call, not the rate, explains most of the gap
90. **Q2 answer: about 110.6–112.4 per 100 plus accrued interest, US$453.5–460.6m for the issue** · floor = value at the market's 2.28% on 17 March (110.61, slide 71); ceiling = value at the offer's 0.895% (112.35, slide 82); the 4 Feb market price 111.28 sits inside; × 4.10 = US$453.5m to US$460.6m, plus accrued interest; the ceiling is what JLR had to pay to win early tenders, not a limit on value; consent solicitation as an extra push to tender

## 5 · Q3: incremental cash flows and savings
91. Divider · 05 Q3
92. **Q3: does buying back all the notes at 112.35 save JLR money?** · split: accounting saving vs economic value; before and after tax
93. **How we judge it: net present value of the change in cash flows** · Plain: incremental cash flow = cash with the deal minus cash without it; NPV = PV of those differences; positive = JLR better off
94. **We assume JLR buys all US$410m at 112.35 on 17 March, funded at 3.5%** · all US$410m bought at 112.35 (the actual early price; our Q2 range's top) on 17 Mar 2015; funded with new 3.5% debt; tax 21% at settlement (deal year), 20% after [src, secondary: Pinsent Masons, plus Finance Act 2013]; fees ignored, then noted
95. **JLR needs US$471.9m to buy the notes, leaving US$28.1m from the US$500m before fees** · 410 × (112.35 + 2.75)%. So what: almost all the new money goes to the buyback
96. **The accounting view: interest falls by US$16.8m a year after borrowing US$471.9m at 3.5%** · US$33.3m (8.125% × 410) vs US$16.5m (3.5% × 471.9). So what: the saving looks large only if the old notes would have run to 2021; against the realistic view it lasts only until May 2016
97. **But JLR pays US$50.6m above face value up front, three years of savings** · premium, including the US$12.3m early premium. So what: the premium must be weighed against the savings in PV terms
98. **New debt borrowed at the market rate adds no value by itself** · PV at 3.5% of the new-debt payments = US$472.0m ≈ the US$471.9m borrowed. So what: the NPV is simply the value of old debt avoided minus cash paid
99. **The first six payments JLR avoids are worth US$95.2m today, at 3.5%** · naive baseline table, May 2015 – Nov 2017: date, n, cash flow, discount factor, PV; subtotal 95.2. So what: the first three years of coupons alone are worth US$95.2m
100. **Holding the notes to 2021 would cost JLR US$525.5m in today's money** · naive baseline table continued, May 2018 – May 2021, same columns; 95.2 + 430.3 = 525.5. So what: holding to 2021 would cost US$525.5m in today's money
101. **Against keeping the notes to 2021, the NPV looks like +US$53.6m** · 525.5 − 471.9. So what: this is the illusion, because JLR would never keep 8.125% debt it can repay
102. **Realistic baseline: JLR repays in May 2016, valued at the market's 2.28%** · table: 3 payments, n, discount factors, PV US$464.8m. So what: the realistic cost of keeping the notes is US$464.8m
103. **Against the realistic baseline, the NPV is −US$7.1m** · 464.8 − 471.9. So what: JLR paid a little more than the debt was worth
104. **At the offer's own 0.895% rate, the NPV is zero** · its own three-row table: 16.66, 16.66, 443.31 × DF 0.998562, 0.994114, 0.989685 → PV 16.63, 16.56, 438.74 = 471.9. Note: zero by construction, because the same rate set the price; the real test is 0.895% against the market's 2.28% (slide 103). So what: JLR paid a near-risk-free price for a claim the market valued at 2.28%
105. **After tax, step 1: the premium and the accrued interest are tax-deductible, saving US$13.0m** · premium US$50.6m + accrued US$11.3m (interest owed up to 17 March) = US$61.9m × 21% = US$13.0m; after-tax cash paid 471.9 − 13.0 = US$458.9m. So what: tax relief cuts the up-front cost by about 3%
106. **After tax, both the coupons and the discount rate shrink by the 20% tax rate** · Plain: after-tax rate = rate × (1 − tax rate), because interest cuts tax; coupons and the call premium are deductible, the principal is not; 2.28% × 0.8 = 1.82% (realistic); 3.5% × 0.8 = 2.80% (naive). So what: both the cash flows and the rate shrink after tax
107. **After tax, realistic baseline: the old notes cost US$454.0m** · table: date, n, pre-tax flow, tax saved, after-tax flow (13.32, 13.32, 436.65; footnote: coupon 16.656 × 0.8 = 13.325, shown as 13.32), DF at 0.912% per half-year, PV (13.29, 13.17, 427.54). So what: compare with the US$458.9m paid
108. **After tax at the offer's own 0.716% rate, the old notes cost US$459.6m** · same columns as 107, at 0.716% a year (0.895% × 0.8) = 0.358% per half-year: n 0.3222: 13.32 × DF 0.998849 = 13.31; n 1.3222: 13.32 × DF 0.995286 = 13.26; n 2.3222: 436.65 × DF 0.991736 = 433.04; total 459.61 (rows rounded); NPV 459.6 − 458.9 = +0.7. So what: near zero again; tax adds only US$0.7m
109. **After tax, each avoided coupon costs JLR only US$13.32m, discounted at 2.80%** · naive baseline, May 2015 – Nov 2017, same columns. So what: the same table as slide 99, after tax
110. **After tax, holding the notes to 2021 would cost JLR US$504.3m in today's money** · naive baseline 2018–2021, same columns; last payment 423.32. So what: compare with the US$458.9m paid
111. **After tax, the answer holds: −US$4.9m realistic, +US$45.4m naive** · 454.0 − 458.9; 504.3 − 458.9; at the offer's rate after tax (0.716%, slide 108): 459.6 − 458.9 = +0.7. So what: taxes change the size, not the conclusion
112. **The answer depends on the baseline, and the realistic one shows no saving** · comparison table, pre- and after-tax: naive +53.6 / +45.4; realistic at 2.28% −7.1 / −4.9; at 0.895% 0.0 / +0.7; extra row "vs the stale 4 Feb market price −4.4 (same 2.28% yield as the realistic row, measured six weeks earlier)". So what: only the naive baseline shows a saving
113. **Q3 answer: a real cash-interest saving, but no economic saving; JLR paid the gain away up front** · summary; £ at 1.50 once: premium £33.8m; realistic NPV −£4.8m (after tax −£3.3m); naive +£35.7m

## 6 · Q4: other benefits, and who gains?
114. Divider · 06 Q4
115. **Q4: what else does JLR gain, and who wins: JLR, the bondholders or Tata Motors?** · question split; assumptions: all notes tendered at 112.35; holders' alternative = keep the notes and be repaid at the May 2016 call, valued at the market's 2.28%; Tata Motors owns 100% of JLR; fees ignored
116. **In an efficient market, swapping debt at fair prices creates no value** · Plain: market efficiency = prices already reflect public information; Modigliani–Miller = financing choices don't change a firm's value (before taxes and costs) (CFA CI LM06, EQ LM03)
117. **JLR's choices: do nothing, wait and repay in 2016, buy notes in the market, or tender now** · each with its cost (market 111.28; call 104.0625 + coupons; tender 112.35)
118. **Tendering now instead of waiting for the 2016 call cost about 1.7 per 100 (US$7.1m)** · 112.35 − 110.61 = 1.74 × 4.10 = US$7.1m; the 8.29 points over the call price (112.35 − 104.0625) buy 14 months of avoided 8.125% coupons, so the net cost is 1.74 per 100; "locking in 3.5% before the Fed's December 2015 rise" is a bet on rates, with no expected value in an efficient market; in fact the 5-year Treasury was 1.26% on 16 May 2016, below 1.57% in March 2015 [src: Treasury CSV]; JLR's own 2016 spread is unknown. So what: the timing benefit was not a sure thing
119. **Reported profit rises: interest falls US$16.8m a year after a one-off charge of about US$50.6m** · P&L effect; the exact accounting loss also depends on the notes' carrying amount (Plain: carrying amount = the value of the notes in JLR's own books). So what: the accounts look better, but only until May 2016 on the realistic view
120. **Holders who stayed lost their covenant protection** · what covenants restrict, and why removing them helps JLR [src]
121. **US$28m of extra cash (about £18.7m at 1.50) is small next to £3.6–3.8bn of capex** · liquidity. So what: the deal was not about raising money
122. **The deal fixed 3.5% to 2020: longer than the 2016 call, a year shorter than 2021** · Plain: refinancing risk = the risk that when debt falls due, new money costs more or is hard to get. Both views: against the realistic baseline (call in May 2016) the deal lengthened funding to 2020 and cut refinancing risk; against the naive baseline (2021) it brought repayment forward a year. Foreshadows 2020 (epilogue)
123. **The deal signals confidence to investors and rating agencies** · Plain: signalling = managers know more than investors, so a costly action can reveal confidence; limit: a deal priced at fair value is a weak signal (CFA)
124. **JLR as a firm: roughly no value created, as theory predicts** · tie to Q3; a lower coupon also means a slightly smaller tax saving on interest
125. **Tendering holders got about 1.7 per 100 (US$7.1m) more than the market's own yield implied** · 112.35 − 110.61 = 1.74 × 4.10; against the stale 4 Feb price it shows as 1.08 (US$4.4m); those who stayed were repaid in May 2016 (price not published; at the call price, 104.0625, our assumption). So what: the holders, not JLR, captured the small gain
126. **Tata Motors, the only shareholder, ends up slightly worse off** · who pays the holders' gain, plus fees
127. **Q4 answer: soft benefits for JLR, a small gain for bondholders, nothing for Tata Motors** · who-gains table

## 7 · Epilogue
128. Divider · 07 Epilogue
129. **Better credit, not lower rates, cut JLR's coupon; the buyback itself created no value** · four findings, one per question
130. **79.61% of the notes were tendered, almost all early, for US$375.7m including interest** · results [src]
131. **The remaining US$83.6m was repaid in May 2016, the first call date** · [src: Tata Motors 20-F FY2016]; price not published; at the call price (104.0625, our assumption) about US$87.0m. So what: every holder was out by May 2016
132. **Sales rose for three years to a record 614,309 in FY2018, then fell for three** · retail: 462,209 (FY15), 521,571, 604,009, 614,309, 578,915, 508,659, 439,588 (FY21) [src: JLR]
133. **FY2019–21: a £3.6bn loss, then COVID and the chip shortage** · FY2019: £3.6bn loss including a £3.1bn write-down, and the Project Charge savings plan (£2.5bn target, later £5bn); FY2021: COVID shut all plants for two months; the chip shortage followed [src: JLR]
134. **Hindsight: by 2019–20 JLR paid 5.875–7.75% on new debt, not 3.5%** · the 3.5% notes were repaid in March 2020; €500m 5.875% 2024 and €500m 6.875% 2026 (Nov/Dec 2019, euro, so not like-for-like with dollar coupons); after March 2020: US$700m 7.75% 2025 (Oct 2020) and US$650m 5.875% 2028 (Dec 2020); ratings fell to S&P B+, Moody's B1 [src: JLR]. So what: the 2015 deal fixed cheap money to 2020; that maturity then fell in the 2019–20 crisis, when new debt cost 5.875–7.75%
135. **2021: "Reimagine" turns Jaguar into an all-electric brand from 2025** · £1.5bn of exceptional charges; FY2021 loss before tax £861m [src: JLR]
136. **S&P rated JLR investment grade in August 2024; Moody's sits one notch below** · S&P BBB- (20 Aug 2024), Moody's Ba1 (13 Jun 2025) [src: JLR]; after the cyber-attack Moody's outlook turned negative (Sep 2025) [src, secondary]; S&P BBB- affirmed with a negative outlook, 28 May 2026 (secondary, Cbonds headline)
137. **2025: a cyber-attack stopped production for five weeks** · announced 2 Sep 2025, phased restart 8 Oct, normal by mid-November; Q2 FY26 cyber costs £196m, loss before tax and exceptional items £485m; £3.5bn of extra liquidity facilities [src: JLR]. So what: a reminder that credit can weaken fast
138. **Today JLR is barely profitable: Q1 FY2027 revenue £6.0bn, profit before tax and exceptional items £109m** · adjusted EBIT margin 2.8%; FY2026 revenue £22.9bn; owned by Tata Motors Passenger Vehicles after the Oct 2025 demerger (secondary) [src]
139. **Better credit cut JLR's borrowing cost; buying back fairly priced debt created no value** · closing

## 8 · Team
140. **Group 10** · [PLACEHOLDER] members' photos, full names, student IDs (until supplied)

---

## Instructions checklist
| Requirement | Slides |
|---|---|
| Overview: history, business model, industry and competition, financials, main problem | 4–17 |
| External, current information | 4–9, 12, 14–16, 130–138 |
| All 6 exhibits rebuilt, explained, key numbers, meaning, implications | 27–50 |
| Each question stated and broken into parts | 52, 64, 92, 115 |
| Theories and frameworks | 18–25, 55, 84, 93, 98, 106, 116, 123 |
| Evidence (case + external) | 57–61, 66, 81–83, 118, 120 |
| Assumptions explained | 52, 67, 69, 94, 115 |
| Alternatives compared | 71–82 and 85–89 (call-aware values at ten rates, the naive value, reconciliation), 101–112 (baselines, pre- and after-tax), 117–118, 122 |
| Every calculation shown step by step, one slide per repeat | 21, 30, 33, 35, 40–49, 53–59, 65–90, 95–113, 118, 125 |
| Chronological sequence | 4–17, 130–138 |
| Epilogue: findings, turning points, outcome, after the case, today | 129–139 |
| Final slide | 140 |

## Old → new slide numbers (round 5 → round 6)
1–107 → 1–107 · new 108 (after-tax table at the offer's 0.716%) · 108–139 → 109–140
(Round 4 → round 5: 1–72 same · new 73–79 sensitivity slides · 73–132 → 80–139.)

## Response to the strict review (round 6: plan passes every hard requirement; A−; blocked only by answers.md)
- **B1:** `answers.md` independent-check row now states our 110.6–112.4 band and why the checker's 110.44 is 0.17 below the floor (31 Mar settlement; 110.66 on 17 Mar, verified in calcs); the Q1 driver line now uses the sourced market-wide spreads (plan 59); optional lines taken (10.6–12.4%; +53.5 vs +53.6 explained); tax line cites s.4 (quoted) and labels the 20% source secondary.
- **Non-blocking taken:** 1 (24 and 84 "capped near the value of being repaid at the call"), 2 (accrued 2.7535 and full prices to 4 dp on 71–82 and 86, so subtractions reproduce), 3 (half-bp rounding footnote on 55), 4 (13.325 footnote on 107), 5 (old prints in calcs.py tagged superseded), 6 (carrying amount defined on 119; receivable factoring defined on 27, where Exhibit 1 shows that row; 27's source line now names the JLR FY2015 Q3 interim accounts, p.6), 7 (15 vs 14 months on 57), 8 (133 now FY2019–21), 9 (s.6 dropped), 10 (118 in the checklist).

## Earlier: response to the strict review (round 5: NOT READY on two narrow items; A− on content)
- **B1:** new slide 108 works the after-tax value at the offer's rate (0.716%, 0.358% per half-year): 13.31 + 13.26 + 433.04 = 459.61, NPV +0.7; rows printed by calcs.py; cited on 111 and 112.
- **B2:** `work/jaguar/answers.md` aligned with the plan: Q2 110.6–112.4 (US$453.5–460.6m), option ~15 points (14.82, approximate), after-tax 0.895% = +0.7, tax 21%/20% with sources, maturity decision recorded, Q4 refinancing risk stated both ways, timing cost 1.74 (US$7.1m), Test 1 in spreads.
- **Non-blocking taken:** 1 (31/58 subtractions; 40, 42, 43 inputs), 2 (73 why a grid; 80 "ten"), 3 (138 "and exceptional items"), 4 (110 title a point), 5 (87 approximate), 6 (106 "coupons"), 7 (tenor on 58; 39 points to 81), 8 (90 plus accrued; ceiling described), 9 (96 wording; 119 "about US$50.6m"), 10 (81 and 122 titles trimmed).

## Earlier: response to the strict review (round 4, numbers refer to the round-5 plan): NOT READY on five narrow items; A− on content)
Numbers added to `calcs.py` (`r3_fixes`, end of block): the seven sensitivity tables, the naive six-payment subtotal (95.20), after-tax at 0.895% (+0.69), the Q2 range in US$ (453.5–460.6), 14.82, £18.7m.
- **B1:** slide 99 shows US$95.2m (calcs subtotal printed).
- **B2:** Q2 answer (90) now 110.6–112.4 per 100, US$453.5–460.6m: floor = value at 2.28% on 17 Mar, ceiling = value at 0.895%; 111.28 sits inside.
- **B3:** 121 retitled and states both views (realistic: funding lengthened to 2020; naive: repayment a year earlier); 133's so-what reworded.
- **B4:** each sensitivity rate has its own worked slide (73–79), in the slide-71 layout; 80 is the summary. Same pattern as the user's "Mix" choice for Gilts (2026-10-30): repeated calculations get their own slides.
- **B5:** label titles replaced: 69, 99, 100, 106, 108.
- **Non-blocking taken:** 1 (104: zero by construction), 2 (after-tax at 0.895% = +0.7 on 110 and 111; "conclusion" not "sign"), 3 (117 shows 1.74 × 4.10 and says JLR's 2016 spread is unknown), 4 (57 caveat and the interpolation in words), 5 (87: same-date 14.82), 6 (answers.md updated), 7 (so-whats on 55, 89, 111, 130), 8 (45, 46, 48, 49 show each year's inputs; capex includes intangibles), 9 (120 £18.7m; 133 "from cash" dropped; 94 tax source labelled; 136 impact figures named; 11 p.3; 31 issued at par; 66 offering memorandum defined), 10 (82 rows-rounded note; 124 title trimmed).

## Earlier: response to the strict review (round 3, numbers refer to the round-4 plan): NOT READY, B+)
All nine blocking items accepted; numbers re-run in `calcs.py` (`q3_consistent` after-tax block and new `r3_fixes`).
1. **After tax:** accrued interest now deductible at settlement (21%): tax saved US$13.0m, after-tax cash US$458.9m; realistic −US$4.9m, naive +US$45.4m (98, 103–105). Conclusion unchanged.
2. **111.28 vs 110.61:** drift explained on 71; 104 relabels the −4.4 row as the stale-price view; 117 retitled to the 1.74 / US$7.1m figure.
3. **Test 1 (57):** redone in spreads: 497bp → 199bp (2.28% − 0.29% interpolated 14-month Treasury on 4 Feb 2015, Treasury CSV logged in `sources.md`).
4. **Tender vs wait (110):** retitled to the net 1.74 (US$7.1m) cost; the Fed point framed as a rate bet; 16 May 2016 5-year Treasury (1.26%) added from the Treasury CSV.
5. **Missing steps:** after-tax tables 100–102; 97 has its own table; 72 works 109.11.
6. **Half-year discounting:** new toolkit slide 21; every PV table carries an n column.
7. **Lucidity:** plain lines added on 2, 12, 14, 23 (yield curve), 46, 49, 114, 115; "So what" added to every slide the review listed (now 41, 45, 46, 48, 49, 53, 54, 56, 58, 68, 71, 75, 76, 79, 81, 88, 89, 90, 92, 93, 95, 98, 99, 101, 111, 117) and to the toolkit and exhibit slides. Header claim reworded so it is true.
8. **Facts:** 4 (1922 and 1948), 8 (rival growth 9–17%, sourced), 17 ("would cost"), 43 (no cause claimed), 66 (OM's 104.663% stated and why 104.0625), 117/123 (redemption price = our assumption), 128 (S&P affirmation, secondary), 54/58 (189 vs 193bp explained).
9. **Titles:** 87, 121, 82, 24, 31, 126, 131 replaced with the reviewer's wording; 67 "almost certainly".
- **Non-blocking taken:** 1 (89, 111), 2 (55), 3 (80), 4 (9), 5 (19 uses 193bp, a whole number), 6 (source lines on 27, 34, 38, 40, 44, 47), 7 (46), 8 (105), 9 (126). 10: the slide count rises to 132 only from real content; no padding.

## Earlier rounds (numbers refer to the round-3 plan)
### Sources round 3 applied (2026-10-30)
- Slides 4, 7–9, 30, 57 and 119–125 now carry sourced figures. Secondary sources are labelled.
- Unverified history (BMW and British Leyland dates) stays as background only.
- Industry-wide premium SUV growth was not found; Land Rover's own growth is used instead.

### Response to the strict review (round 2: NOT READY, B+)
- **B1 (lucidity):** a bond toolkit (18–24) before the exhibits; an NPV concept slide (84); MM and market efficiency (103); a "Plain:" definition and a "So what" on each slide the review listed.
- **B2:** the realistic baseline is now valued at 2.28% (the market's 14-month yield) and at 0.895% (the offer's rate); 3.5% is kept only for the naive 2021 view.
- **B3:** PV tables with discount factors (90–95); a proof that NPV = PV avoided − cash paid (89); after-tax split into 96–98, with the 21%/20% timing stated.
- **B4:** slide 30 retitled; 123 corrected (S&P investment grade, Moody's not); the 2011 B1 rating removed (12); 1.08 (112).
- **B5:** sources for 4, 7–9 and 119–125 fetched by a strict helper. Slide 14 reframed (spreads widened).
- **B6:** Q2 now leads with the call-aware value (64–74); the naive value follows (76–78). Slide 29 uses 1.50.
- **B7:** titles shortened to about 15 words or fewer; labels turned into points.
