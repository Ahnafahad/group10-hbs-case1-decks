# Jaguar Land Rover: storyline (gate 1, round 4: after strict review round 3)

One line per slide: **section · the point (becomes the title, ≤ 2 lines, about 15 words or fewer) · what it shows**. Two tags help lucidity:
- **Plain:** a term defined in plain words where it first appears
- **So what:** the one-line takeaway. Every calculation slide ends with one; concept and fact slides carry one where the point is not already the title.

The reader is a student part-way through CFA Level 1, reading on paper with no presenter (user rule). The full analysis stays; it is explained, not simplified.

`[src]` points to `work/jaguar/sources*.md`; numbers come from `work/jaguar/calcs.py`. All bond maths in US$, converted once at 1.50 (user rule). The case's maturity date, 15 May 2021, is used, plus one note slide (user rule). Every repeated calculation gets its own slide (user rule). The deck never refers to a teaching note. Every table that discounts bond payments has the columns: date · n (half-years from 17 Mar 2015) · cash flow · discount factor · PV.

## 0 · Opening
1. **Cover**: "Jaguar Land Rover: did refinancing at half the rate create value?" · Group 10, course [PLACEHOLDER: user to supply]
2. **JLR halved its interest rate in 2015; can that be a free lunch in an efficient market?** · the case's question; the four questions, one line each; the sections. Plain: efficient market = prices already reflect all public information, so nobody can buy or sell at a "wrong" price for free

## 1 · Case overview
3. Divider · 01 Case overview
4. **Two British brands, born in 1922 and 1948, owned by Ford and then Tata** · timeline: Jaguar 1922 (Swallow Sidecar), Land Rover 1948 [src: JLR]; Ford bought Jaguar in 1989 and Land Rover from BMW in 2000 (€3bn) [src, secondary]; Tata 2008 [src: JLR]; earlier British Leyland/BMW years only as background (not sourced to primary)
5. **Tata bought JLR from Ford in June 2008 for US$2.3bn, as the crisis hit** · deal facts [src]; volumes −32% in 10 months, FY2009 loss £402.4m (case p.2)
6. **Three years later JLR made £1,115m before tax on £9.9bn of revenue** · FY2011: wholesales 243,621 (+26%), revenue £9,871m (+51%), PBT £1,115m vs £51m [src]; profit after tax £1,035.9m (case p.2)
7. **JLR sold 462,209 vehicles in FY2015; China was its biggest market** · by region: China 115,969, Europe 87,863, UK 86,750, North America 78,372, Asia Pacific 26,619, other 66,636; Changshu plant with Chery opened Oct 2014 (130,000 capacity) [src: JLR FY2015 report, release]
8. **Premium rivals grew 9–17% in 2014, while the EU set a 95g CO2/km limit for 2020** · BMW +9.5%, Audi +10.5%, Mercedes-Benz +12.9%, Porsche +17% (calendar 2014) [src; BMW and Audi secondary]; Land Rover brand +8.9% in FY2015 to 385,279 [src: JLR]; EU Regulation 333/2014 [src]. Plain: CO2 g/km target = the average emissions limit per car sold. So what: JLR had to grow and spend heavily on cleaner cars at the same time
9. **JLR sold about a quarter as many cars as BMW, Audi or Mercedes-Benz** · 2014: BMW 1,811,719 (secondary), Audi 1,741,129 (secondary), Mercedes-Benz 1,650,010, Porsche 189,849; JLR 462,209 [src]. Note on slide: JLR's figure is its fiscal year to March 2015; rivals' are calendar 2014
10. **JLR is Tata Motors' cash engine: over 80% of its automotive revenue** · and the only source of consolidated operating profit in FY2014 (case p.2)
11. **JLR borrows in pounds and dollars to match where it earns** · Plain: natural hedge = borrowing in the currency you earn in, so currency moves hit both sides; ~17% of revenue each from the UK and North America (case p.2)
12. **JLR's credit improved: Moody's upgraded it to Ba2 in 2013 and outlooks turned positive in 2014** · Plain: credit rating = an agency's grade of default risk; Ba/BB = "high yield" (below investment grade); outlook = where the agency expects the rating to move next (case p.2) [src]
13. **But heavy spending lay ahead: £3.6–3.8bn of capex planned for FY2016** · Moody's expected free cash flow to turn negative (case p.2). Plain: capex = spending on plants and equipment
14. **In early 2015 the Fed was at zero, but high-yield spreads had widened to about 460bp** · Plain (on this slide, before the toolkit): spread = the extra yield a company pays over a government bond; bp (basis point) = 0.01 percentage point, so 460bp = 4.60 points. Fed funds 0–0.25% until Dec 2015 [src]; high-yield spreads 330bp (2014) → ~460bp (Mar 2015) [src, secondary]. So what: the market was not getting easier; JLR still borrowed at only about 190bp over Treasuries
15. **JLR refinanced twice in two months: sterling in February, dollars in March 2015** · Feb: £400m 3.875% 2023 replaces £500m 8.25% 2020; Mar: US$500m 3.5% 2020 replaces US$410m 8.125% 2021 [src; case p.1]
16. **Holders could sell their notes back, swap into the new issue, or keep them without covenant protection** · Plain: tender offer = the issuer offers to buy its own bonds; consent solicitation = asking holders to vote away the covenants (the promises that protect them); early premium = an extra US$30 per US$1,000 for answering by 16 March [src]
17. **US$500m raised; buying back every old note would cost US$472m, leaving US$28m before fees** · flow diagram, every arrow labelled with the money and what it is; note: the all-tendered case is used in Q3; the actual cost (79.61% tendered) was US$375.7m (slide 122)

## 1b · Bond toolkit (concepts used in the rest of the deck)
18. **A bond's price is quoted per 100 of face value; JLR's notes pay coupons twice a year** · Plain: face value = the amount repaid at maturity; coupon = the fixed interest (8.125% a year = US$40.625 per US$1,000 every six months). So what: every price in this deck is "per 100 of face value"
19. **A basis point (bp) is one hundredth of a percentage point** · 1bp = 0.01%; example from this deck: 3.50% − 1.57% = 1.93 points = 193bp (bp always shown as whole numbers). So what: spreads and rate changes are quoted in bp
20. **Money paid later is worth less today: present value and discounting** · Plain: PV = future cash ÷ (1 + rate)^time; one-bond example. So what: every valuation in this deck is this one idea
21. **Bonds that pay twice a year are discounted in half-years, starting with a part-period** · in words first: (1) rate per half-year = annual yield ÷ 2; (2) count time in half-years from the deal date, 17 March 2015; the first coupon (15 May) is only 58 of 180 days away = 0.3222 half-years, then 1.3222, 2.3222…; (3) discount factor = 1 ÷ (1 + yield/2)^n. Worked: at 2.28%, the 15 May 2015 factor = 1 ÷ 1.0114^0.3222 = 0.9964. So what: this is the rule behind every PV table that follows
22. **Yield to maturity: the single rate that makes the PV of a bond's cash equal its price** · Plain: YTM = the bond's internal rate of return if held to maturity, assuming coupons are reinvested at the same rate; higher yield → lower price. So what: a price and a yield are two ways of saying the same thing
23. **A company's yield = a Treasury yield + a credit spread** · Plain: credit spread = the extra yield investors want for the company's default risk (CFA FI LM07); two-layer picture. Plain: yield curve = Treasury yields plotted against time to maturity (used on Exhibit 3). So what: a lower company yield can come from either layer, and Q1 separates them
24. **A call lets JLR repay early, so investors price to the call date** · Plain: call option = the issuer's right to repay early at a set price; yield to call = the yield if repaid on the call date; yield to worst = the lower of yield to call and YTM. So what: a callable bond's price is capped near its call price
25. **Between coupon dates a buyer pays the price plus the interest earned so far** · Plain: clean price = quoted price; accrued interest = coupon earned since the last payment, counted 30/360; full price = clean + accrued (CFA FI LM06). So what: tender prices are clean; accrued is paid on top

## 2 · Exhibit analysis
26. Divider · 02 Exhibit analysis
27. **Exhibit 1: JLR owed £2.4bn at end-2014, almost all in six fixed-rate notes** · native table, rebuilt; source line "Exhibit 1, case p.X (company data)". So what: debt is notes, not bank loans
28. **Notes are 92% of borrowing; the £1,485m credit line is completely unused** · composition chart. Plain: revolving facility = a pre-agreed credit line. So what: JLR had spare liquidity; it refinanced by choice, not need
29. **The two oldest notes cost most, 8.125% and 8.25%, and both become callable in 2016** · notes ranked by coupon, with call dates. So what: these are the obvious refinancing targets
30. **Those two notes cost £34.5m a year more than JLR's 2015 rates** · at 1.50: US$410m = £273.3m × (8.125 − 3.5)% = £12.6m; £500m × (8.25 − 3.875)% = £21.9m. So what: a clear target for refinancing
31. **JLR's spread over Treasuries fell from 497bp (2011) to 189bp (2015)** · spread at each US$ issue: 497 (May 2011) → 362 (Jan 2013) → 260 (Dec 2013) → 272 (Oct 2014) → 189 (Mar 2015, pricing day 3 Mar) [src: Treasury CSVs; issue dates partly approximate]. So what: lenders demanded much less for JLR's risk, with one small rise in 2014
32. **Repayments are spread from 2018 to 2023, so there is no single wall of debt** · maturity ladder (£m per year). So what: low refinancing pressure in any one year
33. **Exhibit 1 converts dollars at about 1.56; the case tells us to use 1.50 for March 2015** · 410/263 = 1.559; £263m vs £273.3m. So what: we keep the bond maths in dollars and convert once at 1.50
34. **Exhibit 2: the market valued the 8.125% notes at 111.28, an 11% premium** · native table; source line "Exhibit 2, case (market data)"; plain notes on its jargon (two ISIN lines = the same bond sold to US and non-US investors; "i" = indicative price, no trade that day); price dated 4 Feb 2015, before the offer; second line stale (Aug 2014). So what: holders already valued the notes well above 100
35. **At 111.28 the notes yielded 5.94% to 2021 but only 2.28% to the 2016 call** · calc both. So what: the market already priced the bond as if JLR would repay it in 2016
36. **The sterling 8.25% notes told the same story at 110.94** · the second old bond, refinanced in February [src]. So what: the pattern is not unique to the dollar notes
37. **The new 2015 notes trade at 100, so their coupons equal JLR's market yield** · 3.5% 2020 and 3.875% 2023 rows. So what: 3.5% is JLR's 5-year borrowing cost in March 2015
38. **Exhibit 3: from 2011 to 2015, long Treasury yields fell a lot; short ones barely moved** · rebuilt yield-curve chart from Treasury data (axis titles, units); source line "Exhibit 3, rebuilt from US Treasury daily par yields". So what: the curve flattened at the long end
39. **The 10-year Treasury fell 105bp, the 5-year only 26bp** · change-by-maturity bars; the 14-month Treasury that priced the tender (0.395%) marked. So what: lower Treasury yields explain little of JLR's lower 5-year rate
40. **Exhibit 4: revenue grew 43% and profit before tax 69% in two years** · native table; source line "Exhibit 4, case"; growth bars FY2012–FY2014 (FY2015 shown as 9 months). So what: a much bigger, more profitable company than in 2011
41. **EBITDA margin rose from 14.8% to 18.0%** · Plain: EBITDA = profit before interest, tax, depreciation and amortisation (a cash-earnings proxy). Step by step each year: PBT + D&A + finance expense − finance income − FX gain. So what: each £ of sales produced more cash to service debt
42. **Capitalised development costs equal 38–51% of profit before tax** · Plain: capitalising = recording R&D as an asset instead of an expense, which lifts this year's profit. So what: profit quality needs care
43. **FY2012's tax charge was unusually low (1.28%), so its profit after tax overstates normal earnings** · effective tax rate by year: 1.28% → 27.48% → 24.87% → 21.73%. So what: compare years on profit before tax
44. **Exhibit 5: operations brought in £2.4–3.4bn of cash a year** · native table; source line "Exhibit 5, case"; CFO bars. Plain: CFO = cash from operations. So what: JLR's cash generation was large and steady
45. **Free cash flow stayed positive but thin, and Moody's expected it to turn negative** · Plain: FCF = CFO − capex. £1,090m, £580m, £1,066m, £540m (9 months); after cash interest and dividends £962m, £251m, £647m, £293m. So what: heavy investment ate most of the cash, so cheap long-term funding mattered
46. **Cash interest is small next to earnings: EBITDA covers it 12 to 30 times** · EBITDA ÷ cash finance paid (Exhibit 5): 15.6×, 13.3×, 12.2×, 29.7×; FY2015 covers 9 months, and coupon payment timing makes it look high. Plain: interest cover = how many times earnings pay the interest. So what: default risk from interest costs is low
47. **Exhibit 6: equity more than doubled, from £2.9bn to £6.8bn** · native table; source line "Exhibit 6, case"; equity bars. So what: a thicker cushion for lenders
48. **JLR held more cash than debt: net cash rose from £456m to £1,604m** · cash + deposits − debt, by year. So what: JLR could repay all its debt from cash; lenders face little default risk
49. **Debt/equity halved, from 0.68 to 0.36** · Plain: debt/equity = debt ÷ shareholders' equity, a measure of leverage. Ratio table by year. So what: much lower leverage supports a better rating and a lower spread
50. **The exhibits together: a stronger borrower, expensive callable notes, and a market already pricing the call** · synthesis linking each exhibit to Q1–Q4

## 3 · Q1: why could JLR borrow at less than half the 2011 rate?
51. Divider · 03 Q1
52. **Q1: what let JLR's coupon fall from 8.125% to 3.5%?** · three candidate causes: Treasury rates, the bond's length and features, JLR's credit. Assumptions: issued at par; Treasuries matched to each note's length
53. **2011: 8.125% = 3.15% Treasury + 497bp spread** · 10-year Treasury, 16 May 2011. So what: in 2011 most of the coupon was credit spread
54. **2015: 3.50% = 1.57% Treasury + 193bp spread** · 5-year Treasury, 16 Mar 2015 (Exhibit 3's date). One line: on the 3 Mar pricing day the 5-year Treasury was 1.61%, so 189bp (slide 31); the 4bp gap changes nothing. So what: the spread, not the Treasury, shrank most
55. **Two thirds of the 462bp fall came from a narrower credit spread** · waterfall: spread 304bp (66%); Treasury level and shorter length 158bp (34%). Plain: the 304bp also includes the value of the 2011 notes' call feature and the extra spread a 10-year loan carries over a 5-year one; these cannot be split out without the 2011 issue terms in more detail
56. **At the same 5-year length, Treasuries fell only 26bp** · 1.83% → 1.57%. So what: lower government rates explain little of the fall
57. **Test 1: the same bond's spread over Treasuries fell from 497bp at issue to 199bp in Feb 2015** · the 2015 yield to call 2.28% minus the Treasury for the same 15-month horizon on 4 Feb 2015: interpolate 1-year 0.20% and 2-year 0.52% at 1.276 years → 0.29%; 2.28% − 0.29% = 199bp [src: Treasury CSV]. So what: the market itself cut the spread on this very bond by about 300bp
58. **Test 2: across five dollar issues, JLR's spread fell by 308bp** · 497 → 362 → 260 → 272 → 189bp (slide 31's data), tenor-matched; 308bp on the 3 Mar pricing day = 304bp on Exhibit 3's 16 Mar date. So what: a steady fall, issue after issue
59. **Test 3: market-wide high-yield spreads fell about 40bp; JLR's fell 304bp** · Plain: high-yield index spread = the average spread of all below-investment-grade bonds; ~502bp (May 2011) vs ~460bp (Mar 2015), different indices and dates, indicative only [src, secondary]. So what: about 260bp is JLR-specific
60. **The reason: JLR became a far safer borrower** · dashboard from Exhibits 4–6 (EBITDA margin, net cash, debt/equity, cover) + ratings. So what: the falling spread matches the improving numbers
61. **The 2015 notes are also shorter, and the 2011 notes' call had to be paid for** · Plain: tenor effect = shorter loans usually cost less; 2011 notes sold as "callable after five years" [src]; the 2020 notes' early-repayment terms were not found, so no claim is made
62. **Q1 answer: mostly JLR's better credit; lower rates and a shorter term explain the rest** · summary with the waterfall

## 4 · Q2: what price would bondholders accept?
63. Divider · 04 Q2
64. **Q2: what price makes holders give up their 8.125% notes?** · holders' choices: sell in the market, keep (and be repaid in 2016), tender early or late, swap into the new notes
65. **The cash still due: US$40.625 every May and November, then US$1,000** · timeline to 2021. So what: these are the cash flows any valuation discounts
66. **JLR can repay these notes from 15 May 2016 at 104.0625%** · call terms; the 2015 offering memorandum prints 104.663%; we use 104.0625% (par + half a coupon) because only it reproduces the tender price to the cent, and JLR's 8.25% notes follow the same par-plus-half-coupon pattern [src: OM p.105; PR Newswire 16 Mar; sources_research A–B]
67. **With 8.125% to pay and 3.5% available, JLR will almost certainly repay in 2016** · the call is JLR's choice, used only if refinancing is cheaper, and here it is by a wide margin; so the notes behave like a 14-month bond. So what: value them to May 2016, not 2021
68. **Accrued interest at 17 March 2015: 122 days → US$27.53 per US$1,000** · 30/360 in words (every month counts as 30 days, a year as 360); 122/180 × 40.625; 31 March: 136 days → US$30.69 [src: matches JLR's payments]. So what: a buyer pays this on top of the clean price
69. **Step 1: discount the three payments to May 2016 at the 14-month rate** · discount rate choice in words: a holder's required yield for 14 months of JLR risk; recap of slide 21's half-year rule
70. **The market's 14-month rate for JLR was about 2.28%** · from Exhibit 2's price (yield to call). So what: this is the rate holders were actually accepting
71. **At 2.28%, the notes are worth 110.61** · step table (n = 0.3222, 1.3222, 2.3222): 4.0625, 4.0625, 108.125 × DF 0.996354, 0.985123, 0.974019 → PV 4.05, 4.00, 105.32 → full 113.37 − accrued 2.75 = clean 110.61. Note: same 2.28% yield as the 4 Feb market price; the value falls from 111.28 to 110.61 by 17 March because a premium bond's price drifts toward its call price as the call date nears. So what: holders should accept about 110.6 if they need the market's 2.28%
72. **At JLR's own 3.5% borrowing rate, the value to call is lower: 109.11** · step table (same n): DF 0.994425, 0.977322, 0.960513 → PV 4.04, 3.97, 103.86 → full 111.87 − 2.75 = clean 109.11. So what: a higher discount rate means holders can ask less
73. **The value to call ranges from 112.85 at 0.5% to 109.11 at 3.5%** · sensitivity table. So what: the lower the 14-month rate, the more holders can ask
74. **JLR priced its offer the same way: to the 2016 call, at the May 2016 Treasury yield + 0.50%** · Plain: reference Treasury = the government bond whose yield sets the price; fixed spread = a set margin added to it. The 0.25% coupon note yielded 0.395% on 16 March [src]. So what: the offer rate is 0.895%
75. **At 0.895% the price is 112.35, JLR's offer to within US$0.01 per US$1,000** · step table (same n): DF 0.998562, 0.994114, 0.989685 → PV 4.06, 4.04, 107.01 → full 115.10 − accrued 2.75 = 112.35. So what: our method reproduces the real offer, so it is the right method
76. **Early tenders got US$1,123.52 per US$1,000, late ones US$1,093.52, both plus accrued interest** · early premium US$30 [src]. So what: the US$30 early premium pushed holders to answer by 16 March
77. **A callable bond is worth the plain bond minus JLR's option to repay** · Plain: CFA rule callable = straight − call option; picture of the price capped near the call price (called "negative convexity")
78. **The naive view ignores the call: discounting to 2021 at 3.5% gives 125.43** · why 3.5% (JLR's new borrowing cost), cash-flow table with n and DF, 1 of 2
79. **The naive view, continued: full 128.18 − accrued 2.75 = clean 125.43** · result. So what: 14 points more than any call-aware value, because it pretends JLR will pay 8.125% until 2021
80. **So JLR's option to repay was worth about 14 points** · 125.43 − 111.28 (approximate: different dates and yields). So what: paying 125 would give holders about US$54m more than the actual offer ((125.43 − 112.35) × 4.10 = 13.07 × 4.10)
81. **JLR's filings date the maturity 15 November 2021; that moves only the naive value, to 127.26** · case date used throughout (user rule); filing quoted [src]. So what: the call-aware answer does not change
82. **Every call-aware value lands at 109–113; only the naive 2021 view reaches 125** · reconciliation chart of five values (109.11, 110.61, 111.28, 112.35, 125.43), each labelled with its method, rate and date
83. **Q2 answer: about 111–112 per 100 plus accrued interest, US$456–461m for the whole issue** · summary; consent solicitation as an extra push to tender

## 5 · Q3: incremental cash flows and savings
84. Divider · 05 Q3
85. **Q3: does buying back all the notes at 112.35 save JLR money?** · split: accounting saving vs economic value; before and after tax
86. **How we judge it: net present value of the change in cash flows** · Plain: incremental cash flow = cash with the deal minus cash without it; NPV = PV of those differences; positive = JLR better off
87. **We assume JLR buys all US$410m at 112.35 on 17 March, funded at 3.5%** · all US$410m bought at 112.35 (the actual early price; our Q2 range's top) on 17 Mar 2015; funded with new 3.5% debt; tax 21% at settlement (deal year), 20% after; fees ignored, then noted
88. **JLR needs US$471.9m to buy the notes, leaving US$28.1m from the US$500m before fees** · 410 × (112.35 + 2.75)%. So what: almost all the new money goes to the buyback
89. **The accounting view: interest falls by US$16.8m a year on the same funding** · US$33.3m (8.125% × 410) vs US$16.5m (3.5% × 471.9). So what: the saving looks large only if the old notes would have run to 2021; against the realistic view it lasts only until May 2016
90. **But JLR pays US$50.6m above face value up front, three years of savings** · premium, including the US$12.3m early premium. So what: the premium must be weighed against the savings in PV terms
91. **New debt borrowed at the market rate adds no value by itself** · PV at 3.5% of the new-debt payments = US$472.0m ≈ the US$471.9m borrowed. So what: the NPV is simply the value of old debt avoided minus cash paid
92. **Naive baseline, 2015–2017: old payments avoided, discounted at 3.5%** · table: date, n, cash flow, discount factor, PV. So what: the first six payments are worth US$95.0m today
93. **Naive baseline, 2018–2021, continued** · same columns; total PV US$525.5m. So what: holding to 2021 would cost US$525.5m in today's money
94. **Against keeping the notes to 2021, the NPV looks like +US$53.6m** · 525.5 − 471.9. So what: this is the illusion, because JLR would never keep 8.125% debt it can repay
95. **Realistic baseline: JLR repays in May 2016, valued at the market's 2.28%** · table: 3 payments, n, discount factors, PV US$464.8m. So what: the realistic cost of keeping the notes is US$464.8m
96. **Against the realistic baseline, the NPV is −US$7.1m** · 464.8 − 471.9. So what: JLR paid a little more than the debt was worth
97. **At the offer's own 0.895% rate, the NPV is zero** · its own three-row table: 16.66, 16.66, 443.31 × DF 0.998562, 0.994114, 0.989685 → PV 16.63, 16.56, 438.74 = 471.9. So what: the offer was priced at fair value for a near-risk-free 14-month claim
98. **After tax, step 1: the premium and the accrued interest are tax-deductible, saving US$13.0m** · premium US$50.6m + accrued US$11.3m (interest owed up to 17 March) = US$61.9m × 21% = US$13.0m; after-tax cash paid 471.9 − 13.0 = US$458.9m. So what: tax relief cuts the up-front cost by about 3%
99. **After tax, step 2: old payments after tax, discounted at the after-tax rate** · Plain: after-tax rate = rate × (1 − tax rate), because interest cuts tax; coupons and the call premium are deductible, the principal is not; 2.28% × 0.8 = 1.82% (realistic); 3.5% × 0.8 = 2.80% (naive). So what: both the cash flows and the rate shrink after tax
100. **After tax, realistic baseline: the old notes cost US$454.0m** · table: date, n, pre-tax flow, tax saved, after-tax flow (13.32, 13.32, 436.65), DF at 0.912% per half-year, PV (13.29, 13.17, 427.54). So what: compare with the US$458.9m paid
101. **After tax, naive baseline 2015–2017: coupons of US$13.32m after tax, at 2.80%** · same columns, first six payments. So what: the same table as slide 92, after tax
102. **After tax, naive baseline 2018–2021: total US$504.3m** · same columns; last payment 423.32. So what: compare with the US$458.9m paid
103. **After tax, the answer holds: −US$4.9m realistic, +US$45.4m naive** · 454.0 − 458.9; 504.3 − 458.9. So what: taxes change the size, not the sign
104. **The answer depends on the baseline, and the realistic one shows no saving** · comparison table, pre- and after-tax: naive +53.6 / +45.4; realistic at 2.28% −7.1 / −4.9; at 0.895% 0.0; extra row "vs the stale 4 Feb market price −4.4 (same 2.28% yield as the realistic row, measured six weeks earlier)"
105. **Q3 answer: a real cash-interest saving, but no economic saving; JLR paid the gain away up front** · summary; £ at 1.50 once: premium £33.8m; realistic NPV −£4.8m (after tax −£3.3m); naive +£35.7m

## 6 · Q4: other benefits, and who gains?
106. Divider · 06 Q4
107. **Q4: what else does JLR gain, and who wins: JLR, the bondholders or Tata Motors?** · question split; assumptions: all notes tendered at 112.35; holders' alternative = keep the notes and be repaid at the May 2016 call, valued at the market's 2.28%; Tata Motors owns 100% of JLR; fees ignored
108. **In an efficient market, swapping debt at fair prices creates no value** · Plain: market efficiency = prices already reflect public information; Modigliani–Miller = financing choices don't change a firm's value (before taxes and costs) (CFA CI LM06, EQ LM03)
109. **JLR's choices: do nothing, wait and repay in 2016, buy notes in the market, or tender now** · each with its cost (market 111.28; call 104.0625 + coupons; tender 112.35)
110. **Tendering now instead of waiting for the 2016 call cost about 1.7 per 100 (US$7.1m)** · the 8.29 points over the call price (112.35 − 104.0625) buy 14 months of avoided 8.125% coupons, so the net cost is 1.74 per 100; "locking in 3.5% before the Fed's December 2015 rise" is a bet on rates, with no expected value in an efficient market; in fact the 5-year Treasury was 1.26% on 16 May 2016, below 1.57% in March 2015 [src: Treasury CSV]. So what: the timing benefit was not a sure thing
111. **Reported profit rises: interest falls US$16.8m a year after a one-off US$50.6m charge** · P&L effect. So what: the accounts look better, but only until May 2016 on the realistic view
112. **Holders who stayed lost their covenant protection** · what covenants restrict, and why removing them helps JLR [src]
113. **US$28m of extra cash is small next to £3.6–3.8bn of capex** · liquidity
114. **Moving repayment from 2021 to 2020 adds refinancing risk** · Plain: refinancing risk = the risk that when debt falls due, new money costs more or is hard to get; trade-off; foreshadows 2020 (epilogue)
115. **The deal signals confidence to investors and rating agencies** · Plain: signalling = managers know more than investors, so a costly action can reveal confidence; limit: a deal priced at fair value is a weak signal (CFA)
116. **JLR as a firm: roughly no value created, as theory predicts** · tie to Q3; a lower coupon also means a slightly smaller tax saving on interest
117. **Holders who tendered got about 1.7 per 100 (US$7.1m) more than their notes were worth at the market's own yield** · 112.35 − 110.61 = 1.74 × 4.10; against the stale 4 Feb price it shows as 1.08 (US$4.4m); those who stayed were repaid in May 2016 (price not published; at the call price, 104.0625, our assumption). So what: the holders, not JLR, captured the small gain
118. **Tata Motors, the only shareholder, ends up slightly worse off** · who pays the holders' gain, plus fees
119. **Q4 answer: soft benefits for JLR, a small gain for bondholders, nothing for Tata Motors** · who-gains table

## 7 · Epilogue
120. Divider · 07 Epilogue
121. **Better credit, not lower rates, cut JLR's coupon; the buyback itself created no value** · four findings, one per question
122. **79.61% of the notes were tendered, almost all early, for US$375.7m including interest** · results [src]
123. **The remaining US$83.6m was repaid in May 2016, the first call date** · [src: Tata Motors 20-F FY2016]; price not published; at the call price (104.0625, our assumption) about US$87.0m
124. **Sales rose for three years to a record 614,309 in FY2018, then fell for three** · retail: 462,209 (FY15), 521,571, 604,009, 614,309, 578,915, 508,659, 439,588 (FY21) [src: JLR]
125. **FY2019: a £3.6bn loss, including a £3.1bn write-down, and the Project Charge savings plan** · Project Charge £2.5bn target, later £5bn; COVID shut all plants for two months; the chip shortage [src: JLR]
126. **Hindsight: by 2019–20 JLR paid 5.875–7.75% on new debt, not 3.5%** · the 3.5% notes were repaid from cash in March 2020; €500m 5.875% 2024 and €500m 6.875% 2026 (Nov/Dec 2019, euro, so not like-for-like with dollar coupons); after March 2020: US$700m 7.75% 2025 (Oct 2020) and US$650m 5.875% 2028 (Dec 2020); ratings fell to S&P B+, Moody's B1 [src: JLR]. So what: the 2015 deal locked in cheap money, but brought repayment forward into a crisis
127. **2021: "Reimagine" turns Jaguar into an all-electric brand from 2025** · £1.5bn of exceptional charges; FY2021 loss before tax £861m [src: JLR]
128. **S&P rated JLR investment grade in August 2024; Moody's sits one notch below** · S&P BBB- (20 Aug 2024), Moody's Ba1 (13 Jun 2025) [src: JLR]; after the cyber-attack Moody's outlook turned negative (Sep 2025) [src, secondary]; S&P BBB- affirmed with a negative outlook, 28 May 2026 (secondary, Cbonds headline)
129. **2025: a cyber-attack stopped production for five weeks** · impact [src]
130. **Today JLR is barely profitable: Q1 FY2027 revenue £6.0bn, profit before tax £109m** · adjusted EBIT margin 2.8%; FY2026 revenue £22.9bn; owned by Tata Motors Passenger Vehicles after the Oct 2025 demerger (secondary) [src]
131. **Better credit cut JLR's borrowing cost; buying back fairly priced debt created no value** · closing

## 8 · Team
132. **Group 10** · [PLACEHOLDER] members' photos, full names, student IDs (until supplied)

---

## Instructions checklist
| Requirement | Slides |
|---|---|
| Overview: history, business model, industry and competition, financials, main problem | 4–17 |
| External, current information | 4–9, 12, 14–16, 122–130 |
| All 6 exhibits rebuilt, explained, key numbers, meaning, implications | 27–50 |
| Each question stated and broken into parts | 52, 64, 85, 107 |
| Theories and frameworks | 18–25, 55, 77, 86, 91, 99, 108, 115 |
| Evidence (case + external) | 57–61, 66, 74–76, 110, 112 |
| Assumptions explained | 52, 67, 69, 87, 107 |
| Alternatives compared | 71/72/75/78/82 (five valuations), 94–104 (baselines, pre- and after-tax), 109–110 |
| Every calculation shown step by step, one slide per repeat | 21, 30, 33, 35, 41–49, 53–59, 65–82, 88–105, 117 |
| Chronological sequence | 4–17, 122–130 |
| Epilogue: findings, turning points, outcome, after the case, today | 121–131 |
| Final slide | 132 |

## Old → new slide numbers (round 3 → round 4)
1–20 → 1–20 · new 21 (half-year discounting) · 21–24 → 22–25 · 25–49 → 26–50 · 50–55 → 51–56 · 56 → 57 (Test 1 redone in spreads) · 57–70 → 58–71 · new 72 (109.11 worked) · 71–81 → 73–83 · 82–96 → 84–98 · 97 → 99 · new 100–102 (after-tax tables) · 98–100 → 103–105 · 101–114 → 106–119 · 115–126 → 120–131 · 127 → 132

## Response to the strict review (round 3: NOT READY, B+)
All nine blocking items accepted; numbers re-run in `calcs.py` (`q3_consistent` after-tax block and new `r3_fixes`).
1. **After tax:** accrued interest now deductible at settlement (21%): tax saved US$13.0m, after-tax cash US$458.9m; realistic −US$4.9m, naive +US$45.4m (98, 103–105). Conclusion unchanged.
2. **111.28 vs 110.61:** drift explained on 71; 104 relabels the −4.4 row as the stale-price view; 117 retitled to the 1.74 / US$7.1m figure.
3. **Test 1 (57):** redone in spreads: 497bp → 199bp (2.28% − 0.29% interpolated 14-month Treasury on 4 Feb 2015, Treasury CSV logged in `sources.md`).
4. **Tender vs wait (110):** retitled to the net 1.74 (US$7.1m) cost; the Fed point framed as a rate bet; 16 May 2016 5-year Treasury (1.26%) added from the Treasury CSV.
5. **Missing steps:** after-tax tables 100–102; 97 has its own table; 72 works 109.11.
6. **Half-year discounting:** new toolkit slide 21; every PV table carries an n column.
7. **Lucidity:** plain lines added on 2, 12, 14, 23 (yield curve), 46, 49, 114, 115; "So what" added to every slide the review listed (now 41, 45, 46, 48, 49, 53, 54, 56, 58, 68, 71, 75, 76, 79, 81, 88, 89, 90, 92, 93, 95, 98, 99, 101, 111, 117) and to the toolkit and exhibit slides. Header claim reworded so it is true.
8. **Facts:** 4 (1922 and 1948), 8 (rival growth 9–17%, sourced), 17 ("would cost"), 43 (no cause claimed), 66 (OM's 104.663% stated and why 104.0625), 117/123 (redemption price = our assumption), 128 (S&P affirmation, secondary), 54/58 (189 vs 193bp explained).
9. **Titles:** 87, 121, 82, 24, 31, 126, 131 replaced with the reviewer's wording; 67 "almost certainly".
- **Non-blocking taken:** 1 (89, 111), 2 (55), 3 (80), 4 (9), 5 (19 uses 193bp, a whole number), 6 (source lines on 27, 34, 38, 40, 44, 47), 7 (46), 8 (105), 9 (126). 10: the slide count rises to 132 only from real content; no padding.

## Earlier rounds (numbers refer to the round-3 plan)
### Sources round 3 applied (2026-10-30)
- Slides 4, 7–9, 30, 57 and 119–125 now carry sourced figures. Secondary sources are labelled.
- Unverified history (BMW and British Leyland dates) stays as background only.
- Industry-wide premium SUV growth was not found; Land Rover's own growth is used instead.

### Response to the strict review (round 2: NOT READY, B+)
- **B1 (lucidity):** a bond toolkit (18–24) before the exhibits; an NPV concept slide (84); MM and market efficiency (103); a "Plain:" definition and a "So what" on each slide the review listed.
- **B2:** the realistic baseline is now valued at 2.28% (the market's 14-month yield) and at 0.895% (the offer's rate); 3.5% is kept only for the naive 2021 view.
- **B3:** PV tables with discount factors (90–95); a proof that NPV = PV avoided − cash paid (89); after-tax split into 96–98, with the 21%/20% timing stated.
- **B4:** slide 30 retitled; 123 corrected (S&P investment grade, Moody's not); the 2011 B1 rating removed (12); 1.08 (112).
- **B5:** sources for 4, 7–9 and 119–125 fetched by a strict helper. Slide 14 reframed (spreads widened).
- **B6:** Q2 now leads with the call-aware value (64–74); the naive value follows (76–78). Slide 29 uses 1.50.
- **B7:** titles shortened to about 15 words or fewer; labels turned into points.
