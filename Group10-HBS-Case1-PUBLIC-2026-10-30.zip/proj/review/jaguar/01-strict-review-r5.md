NOT READY. Grade estimate A− on content. Two narrow blocking items remain: one unworked after-tax value (H3/H9), and the r4 B2/B3 fixes not carried into `answers.md`. Both are small fixes and neither changes a conclusion.

# Jaguar storyline: strict independent review, round 5 (gate 1)

**Deliverable:** `review/jaguar/01-storyline.md` (139 slides, round 5).

**What I read, in full:**
- `review/shared/review-rubric.md`
- the grading brief
- `case-layout.txt` (the text and all six exhibits)
- CLAUDE.md and DESIGN.md
- PROGRESS.md (user feedback and decisions)
- the output of `python3 work/jaguar/calcs.py`
- `exhibits.csv`, `answers.md`, `sources.md` and the relevant parts of `sources_research.md`
- the r4 review
- the G1 NESA benchmark (skimmed: 268 slides, with full discount tables on each slide, e.g. slides 106–108)

**What I recomputed myself** (scratch script, not calcs.py):
- YTC 2.2801%, YTM 5.9446% at 111.276
- all ten values to the call (0.5–3.5%, 2.28%, 0.895%), including every discount factor and PV row on slides 71–79 and 82
- naive 128.18 / 125.43
- the naive subtotals 95.20 and 430.33
- cash paid 471.93; tax saved 13.01
- the 0.29% interpolation
- the after-tax value at 0.716%: 459.61

**Facts re-fetched live today:**
- JLR Q2 FY26 release (cyber-attack figures)
- JLR investor-relations page (Q1 FY27 figures)

The PR Newswire page would not load this time. I checked it against its exact quote in `sources_research.md`, and r4 re-fetched it.

I read the teaching note only to see what the four questions ask. I did not take the plan's "Response to the strict review" on trust.

## 0. Were the round-4 blocking items fixed?

| r4 item | Status | Evidence (round-5 slide numbers) |
|---|---|---|
| **B1:** 95.0 should be 95.2 | **FIXED** | Slide 99 title and so-what give US$95.2m. calcs prints "first six payments … = 95.20". My own sum is 95.204. Slide 100 gives 95.2 + 430.3 = 525.5; I get 430.33 and calcs gives 525.53. |
| **B2:** Q2 range used the stale 111.28 as its floor | **FIXED in the plan; NOT FIXED in `answers.md`** | Slide 90 now reads 110.6–112.4 and US$453.5–460.6m: floor 110.61 (slide 71), ceiling 112.35 (slide 82), with 111.28 inside. 110.61 × 4.10 = 453.50 and 112.35 × 4.10 = 460.64, and calcs prints the same. The r4 item named "its echo in `answers.md`", and the plan's response says "answers.md updated". But `answers.md` (Q2, "Answer:") still says "about **111–112 clean** per 100 (US$456–461m for the issue)", and still gives the option as "about **14 points** (125.43 − 111.28)". See blocking item B2. |
| **B3:** refinancing risk judged against the naive baseline | **FIXED in the plan; NOT FIXED in `answers.md`** | Slide 121 has the new title and both views. Slide 133's so-what now uses r4's wording. But `answers.md` Q4 "Costs" still lists "refinancing risk from the maturity moving to 2020" with no realistic-baseline view. That is the H7 slip r4 blocked, still in the file builders read. See B2. |
| **B4:** seven sensitivity values had no working | **FIXED** | Slides 73–79 each work one rate in slide 71's layout: rate ÷ 2, three discount factors, three PVs, full − 2.75 = clean, and a so-what. I recomputed every row and all 21 discount factors and PVs match to 4 dp and 2 dp. "Rows rounded" is noted where the PVs sum to 0.01 off (77, 79). Slide 80 is the summary. This honours the user's 2026-10-29 choice, "One slide each". |
| **B5:** label titles on old 69, 92, 93, 99, 101 | **FIXED** | New slides 69, 99, 100, 106 and 108 carry r4's wording exactly. |

**New problem introduced by the fixes:**
- r4's non-blocking #2 added the after-tax value at the offer's rate (0.716%: 459.6 − 458.9 = +0.7) to slides 110 and 111.
- It appears only as a result. No slide works it, and calcs prints only the total.
- Every other baseline, before and after tax, has its own table (104, 107, 108–109). See B1.

## 1. Verdict
**NOT READY. Grade A− on content.**
- Hard failures:
  - H3/H9 on slide 110 (0.716% value not worked)
  - B2 (the stale `answers.md` contradicts the plan on the Q2 answer and repeats r4's H7 slip)
- All quality scores are ≥ 4.
- It becomes READY once B1 and B2 are fixed. Both are small.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover details are a placeholder). Overview 3–17, with the toolkit 18–25. Exhibits 26–50. Q1 51–62, Q2 63–90, Q3 91–112, Q4 113–126. Epilogue 127–138. Team placeholder 139. |
| H2 Every exhibit | PASS | Ex1 27–33 (all six notes, the revolving facility, factoring, FX 1.559 vs 1.50). Ex2 34–37 (all four bond pairs; stale Aug-2014 line; "i" explained). Ex3 38–39 (rebuilt from the Treasury CSV, rows checked in `sources.md` #1). Ex4 40–43. Ex5 44–46. Ex6 47–49. Synthesis 50. Each is native, labelled "Exhibit N" with a source line, and has shows / numbers / meaning / implication. |
| H3 Every question, all seven elements | **FAIL (narrow)** | Q1: question 52, parts 52, theory 23/55, evidence 53–61, assumptions 52, alternatives 55–59. Q2: 64; 65–69; 84; 66, 81–83; 67, 69; 71–89. Q3: 92; 93, 98; 94; 95–111. Q4: 114; 115, 122; 117, 119; 114; 116–117, 121. Steps are complete except **110**: the after-tax value at 0.716% (459.6) and its NPV (+0.7) are shown only as results (B1). |
| H4 External, sourced, current | PASS | Every [src] I traced has an exact quote. Secondary sources are labelled (4, 8, 9, 14, 59, 94, 135, 137). Current to Q1 FY27 (released 13 Aug 2026). I confirmed live today that Q2 FY27 has only a sales update (3 Oct 2026), so Q1 FY27 is the latest result. |
| H5 No teaching note | PASS | No citation, quote or reference. The ~25% appears only as "the naive view" (85–89). The header line "never refers to a teaching note" is plan metadata, not slide text. |
| H6 Titles | PASS | Every title states a point. The longest are 19 words (81, 121), which fit two lines at headline size but could be trimmed (non-blocking). Slide 109 is close to a label; non-blocking #4. |
| H7 Finance correct | PASS (in the plan) | Checked correct: <br>• semi-annual part-period discounting (21) <br>• 30/360 accrued interest; clean vs full price <br>• YTM as IRR with the reinvestment assumption; YTC / YTW <br>• callable = straight − call <br>• NPV = PV of old debt avoided − cash paid, with the new debt shown to be NPV ≈ 0 (98) <br>• after tax: premium and accrued deductible at 21% at settlement; coupons and call premium at 20%; principal not (105–107; 6.66 = 20% × (16.66 coupon + 16.66 call premium)) <br>• MM and market efficiency <br>• tender-vs-wait logic (117) <br>• refinancing risk against both baselines (121) <br>The 14.82 "option value" (87) uses each horizon's own market rate (3.5% for 2021, 2.28% to the call). That is defensible, but say so (non-blocking #5). The H7 slip r4 found survives only in `answers.md` (B2). |
| H8 Numbers | PASS | 48 numbers spot-checked; all match within rounding (section 4). Formats: money 1 dp, prices 2 dp, yields 2 dp, bp whole. |
| H9 User decisions | **FAIL (narrow)** | Honoured: call-aware Q2 first (64–83 before 85–88); US$ maths with one 1.50 conversion (33, 112, 120); 15 May 2021 used throughout, with exactly one 15 Nov 2021 slide (88; a grep finds no other); one slide per repeat for the sensitivities (73–79). The Gilts "Mix" choice (2026-10-30) is a Gilts decision; slides 73–79 also satisfy its "one slide per repeat" spirit. **Breach:** the 0.716% after-tax baseline is a repeat of slide 107's calculation with no slide of its own (B1). |
| H10 Known traps | PASS | Semi-annual coupons and the May 2016 call: 18, 21, 24, 66–67. <br>US$ vs £: 1.50 vs 1.559 (33). <br>Clean/dirty and 30/360, with accrued paid separately: 25, 68, 83. <br>~25% naive vs ~11% market vs our answer, reconciled without the teaching note: 85–90. <br>Credit, not Treasuries, tested: 26bp like for like (56), the same bond 497 → 199bp (57), five issues (58), the market index (59). <br>Fair-price refinancing ≈ no value, tested: 98–111 and 123. |
| H11 Lucidity | PASS | The toolkit (18–25) comes before use; terms are defined where first used; every PV table has n and DF; every calculation slide has a so-what. Fewer than a handful of soft spots: 73 (why a grid of rates?), 58 ("tenor-matched" comes before tenor is defined on 61), 39 (0.395% is mentioned before 81 explains it), 106 (the title says "payments" shrink, but principal does not). Fixes are in section 6. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Reproduces the tender price to US$0.01; ten worked values to the call; tests "credit, not rates" four ways; three baselines before and after tax; a three-party split of who gains. |
| Q2 Logic and flow | 4 | Clean concept → exhibit → question → epilogue flow. Slides 73–79 arrive without a line saying why the grid is there. |
| Q3 Evidence | 4 | Primary releases, legislation and Treasury CSVs; secondary sources labelled. 137 should say "before exceptional items". |
| Q4 Lucidity | 4 | A part-way CFA Level 1 reader follows nearly every slide on paper; the four soft spots above keep it from a 5. |
| Q5 Calculations | 4 | Every value is worked except 0.716% (B1). The input rows for 31/58 (the three middle issues) and 40/42/43 are not shown (non-blocking #1). |
| Q6 Overview and epilogue | 4 | Sourced history, industry and credit context; the epilogue runs tender result → 2016 call → sales cycle → 2019–20 hindsight → Reimagine → IG rating → cyber-attack → Q1 FY27, tied back on 128/138. |

## 4. Number spot-check (48 numbers; every number changed this round is included)

| Number | Slide | Source | Match |
|---|---|---|---|
| 0.3222 half-years; DF 0.9964 at 2.28% | 21 | calcs 0.996354; my recompute | yes |
| £273.3m × 4.625% = £12.6m; £500m × 4.375% = £21.9m; £34.5m | 30 | calcs; my recompute 12.64 / 21.875 | yes |
| 410/263 = 1.559 | 33 | calcs | yes |
| YTM 5.94%, YTC 2.28% at 111.276 | 35, 70 | my recompute 5.9446 / 2.2801 | yes |
| EBITDA FY12 1,999 (14.8%), FY15 2,880 (18.0%) | 41 | calcs; case Ex4 | yes |
| Tax rates 1.28 / 27.48 / 24.87 / 21.73% | 43 | 19/1,479 etc. | yes |
| FCF 2,500 − 596 − 814 = 1,090; 580; 1,066; 540; 962 / 251 / 647 / 293 | 45 | case Ex5; calcs | yes |
| Cover 1,999 ÷ 128 = 15.6×; 13.3×; 12.2×; 29.7× | 46 | calcs; Ex5 cash finance paid 128 / 179 / 269 / 97 | yes |
| Net cash 2,430 + 0 − 490 − 1,484 = 456; 680; 1,449; 1,604 | 48 | case Ex6; my recompute | yes |
| D/E (490 + 1,484) ÷ 2,924 = 0.68; 0.61; 0.34; 0.36 | 49 | case Ex6; my recompute | yes |
| 497 / 193 / 462 = 304 + 158 | 53–55 | calcs | yes |
| 1Y 0.20, 2Y 0.52 → 0.29%; 199bp | 57 | `sources.md` 4 Feb row; my recompute 0.2885 | yes |
| 497 → 362 → 260 → 272 → 189; 308bp | 31, 58 | calcs Test 2; Treasury rows | yes |
| Accrued 122 days → US$27.53; 136 days → US$30.69 | 68 | calcs; PR Newswire quote | yes |
| 2.28% table: DF 0.996354 / 0.985123 / 0.974019 → 4.05 / 4.00 / 105.32 → 113.37 → **110.61** | 71 | calcs; my recompute | yes |
| 3.5% table → 111.87 → **109.11** | 72 | calcs; my recompute | yes |
| 0.50%: DF 0.9992 / 0.9967 / 0.9942 → 115.61 → **112.85** | 73 | calcs; my recompute | yes |
| 0.75%: 0.9988 / 0.9951 / 0.9913 → 115.29 → **112.54** | 74 | same | yes |
| 1.00%: 0.9984 / 0.9934 / 0.9885 → 114.97 → **112.22** | 75 | same | yes |
| 1.50%: 0.9976 / 0.9902 / 0.9828 → 114.34 → **111.59** | 76 | same | yes |
| 2.00%: 0.9968 / 0.9869 / 0.9772 → 113.71 → **110.96** | 77 | same | yes |
| 2.50%: 0.9960 / 0.9837 / 0.9716 → 113.09 → **110.34** | 78 | same | yes |
| 3.00%: 0.9952 / 0.9805 / 0.9660 → 112.48 → **109.72** | 79 | same | yes |
| So-whats: −0.31 per 0.25% (74); 0.61 over the 3.5% value (79) | 74, 79 | my recompute | yes |
| 0.395% + 0.50% = 0.895%; DF 0.998562 / 0.994114 / 0.989685 → 115.10 → **112.35** | 81–82 | calcs; PR Newswire quote | yes |
| US$1,123.52 / 1,093.52 | 83 | PR Newswire quote | yes |
| Naive full 128.18 → 125.43 | 85–86 | calcs; my recompute 128.179 | yes |
| **12.6–16.3** points (125.43 − 112.85; 125.43 − 109.11) | 86 | my recompute 12.58 / 16.32 | yes |
| **14.82**; 13.07 × 4.10 ≈ US$54m | 87 | calcs r3 block; 53.59 | yes |
| 127.26 (15 Nov 2021) | 88 | calcs | yes |
| **110.6–112.4; US$453.5–460.6m** | 90 | calcs; 453.50 / 460.64 | yes |
| 410 × 115.10% = **471.9**; 28.1 surplus | 95, 17 | calcs 471.93 | yes |
| 33.3 vs 16.5 → 16.8 a year; premium 50.6 incl. 12.3 ≈ 3 years | 96–97 | calcs | yes |
| New-debt PV 472.0 | 98 | calcs 472.02 | yes |
| **95.2** (six PVs 16.56 … 15.19) | 99 | calcs 95.20; my recompute 95.204 | yes |
| **430.3**; 525.5; +53.6 | 100–101 | my recompute 430.33; calcs 525.53 | yes |
| 464.8; −7.1 | 102–103 | calcs | yes |
| 0.895% table 16.63 / 16.56 / 438.74 = 471.9 | 104 | calcs | yes |
| (50.6 + 11.3) × 21% = 13.0; 458.9 | 105 | calcs 13.01 / 458.93 | yes |
| 1.82% / 2.80% | 106 | calcs | yes |
| 13.32 / 13.32 / 436.65; DF at 0.912%; 13.29 / 13.17 / 427.54 = 454.0 | 107 | calcs | yes |
| 504.3; last flow 423.32 | 109 | calcs | yes |
| **459.6 − 458.9 = +0.7** | 110–111 | calcs "+0.69"; my recompute 459.61 | yes (but not worked: B1) |
| £33.8m; −£4.8m; −£3.3m; +£35.7m | 112 | calcs GBP line | yes |
| 1.74 × 4.10 = US$7.1m; 8.29 over call; 1.26% (16 May 2016) | 117, 124 | calcs; `sources.md` row | yes |
| **£18.7m** (28.1 / 1.5) | 120 | calcs | yes |
| 79.61%; US$375.7m | 129 | final-results quote; calcs 375.72 | yes |
| US$83.6m; US$87.0m at 104.0625 | 130 | calcs 83.583 / 86.98; 20-F quote | yes |
| **Cyber: £196m costs; £(485)m loss before tax and exceptional items; £3.5bn; 2 Sep / 8 Oct** | 136 | JLR Q2 FY26 release (re-fetched today) | yes |

**External facts checked (more than 6):**

Re-fetched live today:
1. Cyber-attack figures (JLR release).
2. Q1 FY27: £6.0bn (£5,973m), 2.8%, £109m. This is labelled "before tax & exc. items", so slide 137 must say so (non-blocking #3).

Checked against the exact quotes in `sources_research.md`:

3. PR Newswire pricing: 0.395%, 50bp, US$30, 1,123.52 / 1,093.52.
4. 79.61% tendered (final-results release).
5. 21% for FY2014 (Finance Act 2013 s.4) and 20% from April 2015 (Pinsent Masons, labelled secondary on 94).
6. S&P BBB- (20 Aug 2024) and Moody's Ba1 (13 Jun 2025), both JLR notices.
7. €500m 5.875% 2024 and €500m 6.875% 2026 (AR20; the second includes the Dec 2019 €200m tap); US$700m 7.75% and US$650m 5.875% (2020).
8. FY2021 pre-tax loss £861m and £1.5bn charges.
9. FY2019 £3.6bn loss including the £3.1bn impairment; Project Charge £2.5bn, then £5bn.
10. Retail series FY15–FY21.

All are supported.

## 5. Blocking items (slide → problem → exact fix)

**B1. Slide 110 (and 111's after-tax 0.895% cell): one value is shown without its working (H3; breaches the user's "one slide per repeated calculation").**
- **Problem:** "at the offer's rate after tax (0.716%): 459.6 − 458.9 = +0.7" is given as a result only. Every other baseline has its own table (104 pre-tax at 0.895%, 107 after tax at 1.82%, 108–109 after tax at 2.80%). `calcs.py` prints only the total (459.61), so a builder could not draw the table from it.
- **Fix:**
  - Insert a new slide between 107 and 108 (renumber after it).
  - Title: "After tax at the offer's own 0.716% rate, the old notes cost US$459.6m".
  - Use slide 107's columns: date · n · pre-tax flow · tax saved · after-tax flow · DF · PV.
  - Three rows, with 0.358% per half-year:
    - 15 May 2015: n 0.3222; 16.66, 3.33, 13.32; DF 0.998849; PV 13.31
    - 15 Nov 2015: n 1.3222; 16.66, 3.33, 13.32; DF 0.995286; PV 13.26
    - 15 May 2016: n 2.3222; 443.31, 6.66, 436.65; DF 0.991736; PV 433.04
  - Total 459.61 (I recomputed it). NPV 459.6 − 458.9 = +0.7.
  - So-what: "near zero again: the tax effect adds only US$0.7m".
  - Print these rows in `calcs.py` (in the r3_fixes block) so the builder pulls them, and cite the new slide on 110 and 111.

**B2. `answers.md`: the r4 B2 and B3 fixes are not carried over, although the plan says "answers.md updated" (r4 B2 named this file explicitly).**
- **Problem:** `answers.md` still says:
  - Q2 answer "about 111–112 clean … (US$456–461m)" (plan 90: 110.6–112.4, US$453.5–460.6m)
  - "the issuer's option is worth about 14 points (125.43 − 111.28)" (plan 87: 14.82, same date)
  - Q4 "refinancing risk from the maturity moving to 2020", the naive-baseline view r4 ruled an H7 error (plan 121 gives both views)
  - after-tax 0.895% "—" (plan: +0.7)
  - the tax line "20% … (Finance Act 2013 s.6)" (plan 94/105: 21% at settlement, Finance Act 2013 s.4; 20% after, Pinsent Masons)
  - "Maturity … Waiting for the user's decision" (decided 2026-10-29)

  CLAUDE.md makes `answers.md` the method/results record that gate 3 builders and reviewers use, so it must agree with the plan.
- **Fix:** update those six lines to match plan slides 87, 88, 90, 94/105, 110–111 and 121. In Q4, write: "Against the realistic 2016-call baseline the deal lengthened funding to 2020 and cut refinancing risk; only against the naive 2021 baseline did it bring repayment forward a year."

## 6. Non-blocking improvements (most valuable first)
1. **31 / 58:** show each issue's subtraction (coupon − matched Treasury): 5.625 − 2.00 = 362; 4.125 − 1.52 = 260; 4.250 − 1.53 = 272; 3.500 − 1.61 = 189. At present only the spreads are listed. Do the same for 40 (19,386 ÷ 13,512 = +43%; 2,501 ÷ 1,479 = +69%), 42 (751 ÷ 1,479 = 51% …) and 43 (19 ÷ 1,479 …).
2. **73:** before the first sensitivity slide, add one line saying why: "the right 14-month rate is uncertain, so we value the notes from a near-risk-free 0.5% up to JLR's 3.5%". Fix 80's "nine worked values": there are ten (71, 72, 73–79, 82).
3. **137:** say "profit before tax and exceptional items £109m". JLR's page labels it that way (re-fetched).
4. **109:** turn it into a point: "After tax, holding the notes to 2021 would cost JLR US$504.3m in today's money".
5. **87:** add one line saying 14.82 compares values at each horizon's own market rate (3.5% for 2021, 2.28% to the call). That makes it an approximate option value, not a single-curve one.
6. **106:** title "both the coupons and the discount rate shrink by the 20% tax rate" ("coupons", not "payments": principal does not shrink).
7. **58:** define tenor ("tenor = time until repayment") here, not on 61. On 39, add "(explained on slide 81)" after 0.395%.
8. **90:** add "plus accrued interest" after the US$ range, and call the ceiling "what JLR had to pay to win early tenders" rather than a value limit. Holders would accept anything at or above about 110.6.
9. **96 / 118:** "on the same funding" is unclear (410 vs 471.9 borrowed). Say "after borrowing US$471.9m at 3.5%". On 118, say "about US$50.6m", since the accounting loss also depends on the notes' carrying amount.
10. **81 / 121:** trim the titles to about 15 words. For example, 81: "JLR priced its offer to the 2016 call: May 2016 Treasury + 0.50%".

## Strongest parts
- Q2 rebuilds JLR's real tender formula to the cent. It now works every one of ten discount rates on its own slide and reconciles them with the market price and the naive 125.
- Q3 proves that new debt at market rates has zero NPV. It then values each baseline before and after tax with dated tables, and gets the tax treatment right (premium and accrued at 21%, coupons and call premium at 20%, principal not deductible).
- Q1 tests "credit, not Treasuries" four ways instead of asserting it.
