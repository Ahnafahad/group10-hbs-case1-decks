# Jaguar deck: independent gate-4 grader report, ROUND 2

Reviewer: independent grader (strict rubric `review/shared/review-rubric.md`), 2026-10-30.

**What I judged**
- `review/jaguar/04-qc/deck_text.md` (149 pages)
- 42 full-size renders in `04-qc/png/`
- the live slide HTML in `decks/jaguar/project/slides/`, scanned for font sizes

**Checked against**
- `calcs.py` (run; its output matches the slides)
- `exhibits.csv`, `sources.md` and `sources_research.md`
- CLAUDE.md hard rules and standing rules
- DESIGN.md
- GILTS_BUILD_BRIEF.md, section "Mistakes found in the Jaguar deck"

**Renders opened at full size (42):** j14, j15, j28, j34, j44d, j47b, j47c, j48, j55, j59, j62, j65, j71, j80, j84, j87, j89, j95, j98, j98b, j98c, j98d, j100, j106, j107, j109, j110, j112, j113, j118, j121, j122, j125, j129, j130, j134, j136, j138. I also measured every bar or dot against its stated scale on j14, j28, j55, j59, j62, j65, j71, j80, j87, j89, j95, j98c, j98d, j112, j121, j122, j125, j130 and j134.

---

## (a) Verdict

**NOT READY: 4 blocking items. Grade estimate: A− once they are fixed (B+/A− as it stands).**

All 24 round-1 findings are fixed or substantially fixed. What remains are four narrow defects, each fixable in minutes:
1. Body content (workings, a reconciliation, method notes) sits in the 24 px source footer on 11 slides.
2. j106 prints two products that do not reproduce (2.28% × 0.8 = 0.912%; 3.5% × 0.8 = 1.40%).
3. j121's new £3,600m bar is off-scale and starts from a different baseline.
4. j138's so-what claims something the slide's numbers and sources do not support, and it contradicts j136.

---

## (b) Round-1 findings: status

| # | Round-1 finding | Status | Evidence |
|---|---|---|---|
| 1 | j34 Exhibit 2 incomplete | **FIXED** | j34 render: all 8 rows; ISIN, Start, End, Last traded and Price columns; lime highlight on 111.28; the "agree within 0.24" line (111.18 − 110.94 = 0.24 ✓). |
| 2 | Q3 incremental flows / 472.0 not worked | **FIXED** | j98b: full 10-row new-debt PV table (DF at 1.75%, rows sum to 472.03, labelled "rows rounded" 472.02). j98c and j98d: date-by-date incremental bars for both baselines, with "+ = JLR better off", break marks, and the reconciliation 525.53 − 472.02 = +53.5 and 458.65 − 472.02 = −13.4 (both reproduce). |
| 3 | Secondary sources unlabelled | **FIXED** | j59, j60, j61 and j136 now carry "(secondary)" for Business Standard, Fortune and Forbes. |
| 4 | Sterling buyback overstated | **FIXED** | j15 header now reads "Old notes targeted by the tender". j36 now reads "launched a tender … Its result is not in our sources", quoting the OM p.9. |
| 5 | Body text < 36 px | **FIXED as written** | The ladder caption is now 36 px (j71 render; HTML scan finds no non-footer text below 36 px). Exhibit 6 subtotals are now bold table rows (j47b, j47c). **However, workings have since been moved into the 24 px footers instead (new finding N1).** |
| 6 | j95 / j08 numbers | **FIXED** | j95: 410 × 1.151049 = 471.93 ✓. j08: Porsche +17.1% ✓. |
| 7 | j65 off-scale | **FIXED** | Break mark on the 2021 bar, and "final bar not to scale" in the subtitle. |
| 8 | 189 vs 193bp | **FIXED** | j14 so-what reconciles the two (193bp on 16 Mar, slide 54). |
| 9 | £2,448m vs £2,423m | **FIXED, but in the footer** | The j47c reconciliation is in the 24 px footer (see N1). |
| 10 | US$19m vs US$16.8m | **FIXED** | j67 now says "slide 96 nets it to US$16.8m". |
| 11 | Rows not summing | **FIXED** | j100, j102, j107 and j109 are labelled "(rows rounded)". j100 says "unrounded rows". (j110 is still unlabelled: N6.) |
| 12 | j87 / j84 option value | **FIXED** | j87 shows the same-rate 16.32, the mixed-rate 14.82 and the overpayment 13.0743 separately. j84 now notes the yield-to-worst approximation. |
| 13 | j95 colour-only segments | **FIXED** | Each segment has a direct label with a leader line; widths measured to scale (3.2 px per US$m). |
| 14 | Unsupported titles / so-whats | **FIXED** | j127 "a small loss"; j112 "material"; j44c "from FY2013"; j134 "1.7–2.2 times". |
| 15 | j136 rating chart | **FIXED** | S&P BB late '14, B+ Mar '19, B Apr '20, BB− Apr '23 and BBB− Aug '24 are plotted. Moody's Ba3 is dated, and B1 by Mar '20 is shown. One line per agency (solid / dashed). |
| 16 | Chart details | **FIXED** | j84 label sits above the line and the y-axis title is at the axis. j122 label is right of the bar. j59 reads "42bp fall / 304bp fall". |
| 17 | Exhibit 5 order | **FIXED** | New j44d carries the full roll-forward after financing; all rows add. |
| 18 | Terminology / jargon | **FIXED (minor residue)** | j105 now says "year to 31 Mar 2015". j47 headers say "at 31 March / Dec 2014". Exceptional items, dealer manager, tender agent, backstop facilities, adjusted EBIT margin and demerger are all defined. Residue: "same-length" (j31, j129) alongside "tenor" (j52–j62). |
| 19 | Lucidity stumbles | **FIXED** | j98 (178/180 explanation), j118 (bridge), j124 ("already inside the after-tax NPV"), j105. |
| 20 | Non-so-whats | **FIXED** | j85, j100 and j109 now state a meaning. |
| 21 | "X, not Y" / stock closers | **PARTIAL** | Cleared on j55 and j116; j137 and j138 closers rewritten. Still present: j27, j28, j50, j61, j62, j126, j129 (title and so-what), j134 title. See (e) N8 for which are worth fixing. |
| 22 | Optional visuals (j45, j48) | **NOT DONE (optional)** | See N9. |
| 23 | Over-reaching phrases | **FIXED** | j11 now cites retail volumes from slide 7. j131 now says "from the first call date (15 May)". |
| 24 | Stale j121 render | **FIXED** | Re-rendered. The new bar has a scale defect (N3). |

---

## (c) Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | **PASS** | Opening j01–j02. Overview and toolkit j03–j25. Exhibits j26–j50. Q1 j51–j62, Q2 j63–j90, Q3 j91–j113, Q4 j114–j127. Epilogue j128–j139. Team j140 (placeholder, allowed). |
| H2 Every exhibit rebuilt in full | **PASS** | Ex1 j27: 8 facilities + total; sums 3,965 / 2,448 / 1,517 ✓. Ex2 j34: 8 rows, all columns. Ex3 j38–j39 (rebuilt from Treasury CSV). Ex4 j40–j40b: every line; PBT reproduces for all 4 years. Ex5 j44–j44d: every row in `exhibits.csv`; all subtotals add. Ex6 j47–j47c: every line; all subtotals add; balance sheet balances. Each exhibit has analysis slides after it. |
| H3 Every question, every step | **PASS** | Q3's literal ask is now on j98b–j98d. Every stated PV has a table, e.g. j71–j79, j82, j85–j86, j98b, j99–j100, j102, j104, j107–j110. |
| H4 External, current, sourced | **PASS (one over-reach, N4)** | Current to the Q1 FY27 release (13 Aug 2026). Secondaries are labelled. j15's "record-low coupons" is supported by AR15 p.73 (sources_research l.381), but AR15 is not cited on the slide (N7). |
| H5 No teaching note | **PASS** | No citation, wording or "25–29%" anywhere. |
| H6 Titles | **PASS** | All fit in 2 lines and state findings. The j87 title "about 15 points" vs the body's 14.8–16.3 is acceptable. |
| H7 Finance correct | **PASS** | Covered correctly: 30/360 accrual; fractional-period discounting; callable = straight − call, with the yield-to-worst caveat; after-tax rate r(1−t); call premium deductible, principal not; zero-NPV fair debt (j98, j98b); MM and efficiency. |
| H8 Numbers right | **FAIL** | (1) j106 prints "2.28% × 0.8 = 0.912% per half-year" and "3.5% × 0.8 = 1.40% per half-year": the products shown are 1.824% and 2.80%; the half-year step is missing (N2). (2) j121: the 3,600 bar is drawn at about 876 px from x=756, while the 3,147 bar is 786 px from x=772. To scale, 3,600 should be 899 px from x=772 (N3). Everything else recomputed reproduces (part f). |
| H9 User decisions | **PASS** | Call-aware first (j69–j82 before j85–j86); US$ maths with one conversion at 1.50; case maturity plus the j88 note; one slide per repeated calculation (j71–j79). |
| H10 Known traps | **PASS** | Covered: tender on the US$410m 8.125% notes; semi-annual coupons; the May 2016 call; FX at 1.50; clean vs dirty; the 125.43 vs 112.35 gap explained; the efficiency lesson tested (j55–j59); the 26bp Treasury move (j56). |
| H11 Lucidity | **PASS** | Plain/So-what scaffolding throughout; concepts come before use. Remaining minor stumbles (not more than a handful): j44 (the CFO jump from 2,091 to 2,500 is unexplained, N5) and j98d (−13.4 at 3.5% next to the headline −7.1, explained in the so-what). |
| 18 pt / 36 px rule | **FAIL** | Analysis content sits in the 24 px footer on 11 slides (N1). |

---

## (d) Quality scores (1–5)

| | Score | Reason |
|---|---|---|
| Q1 Depth | **5** | Three spread tests, the tender reproduced to the cent, a ten-rate grid, two baselines before and after tax, incremental-flow timelines, and who gains vs who pays. |
| Q2 Logic and flow | **4** | Clean chronology with an answer slide per section. The "better credit, not cheaper money" line still repeats (j50, j62, j129). |
| Q3 Evidence | **4** | Primary-heavy and labelled. Docked for the j138 inference and the missing AR15 citation on j15. |
| Q4 Lucidity | **4** | A part-way Level 1 reader follows almost everything. j44's CFO gap is the main stumble. |
| Q5 Calculations | **4** | Complete and traceable, including the new j98b–d. Docked for the j106 products and the j113 divisions that do not reproduce from the 1 dp figures shown. |
| Q6 Overview and epilogue | **4** | Current to Aug 2026 and tied back to the 2015 decision. j138's closing inference is unsupported. |

---

## (e) NEW findings

### Blocking

**N1. Analysis and workings in the 24 px footer (36 px rule; build brief mistake #4). BLOCKING**
- Slides and footer text:
  - **j47c**: "Loans here, 193 + 2,230 = £2,423m, vs £2,448m drawn in Exhibit 1: likely issue costs netted in the books (our inference)". This is the round-1 #9 fix, placed in the footer.
  - **j67**: "(8.125 − 3.5)% × 410 = US$19.0m a year; 4.0625% × 410 = US$16.7m"
  - **j95**: "Accrued: 410 × 122 ÷ 180 × 4.0625%"
  - **j100**: "The last payment = 410 + 16.656 = 426.656"
  - **j112**: "Stale price: (111.28 − 112.35) × 4.10"
  - **j119**: "premium 410 × 12.35% = 50.6; interest 33.3 − 16.5 = 16.8"
  - **j87**: "Gaps use the rounded prices shown; US$ = points × US$4.10m per point"
  - **j98c and j98d**: "Discounted at 3.5%" (the method behind the so-what)
  - **j55**: "The 158bp is one block: how it splits depends on the order chosen"
  - **j57**: "15 months from the 4 Feb price date; slides 69–70 count 14 from the 17 Mar deal"
- Evidence: HTML footers set at `font-size:24px; bottom:64px`. Each of these is a calculation step or an analytical caveat, not a source.
- Fix: move each into the body at 36 px (a "Working:" line or appended to the so-what). Leave only "Source(s): …" in the footer. Where there is no room, split the slide.
- Owners:
  - jlr_s2: j47c
  - jlr_s3: j55, j57
  - jlr_s4: j67, j87
  - jlr_s5: j95, j98c, j98d, j100, j112
  - jlr_s6: j119

**N2. j106: displayed products do not reproduce (H8). BLOCKING**
- Evidence: the captions read "realistic rate: 2.28% × 0.8 = 0.912% per half-year" and "naive rate: 3.5% × 0.8 = 1.40% per half-year". The products are 1.824% and 2.80%, which are the big numbers above the captions. The ÷ 2 step is missing.
- Fix: "2.28% × 0.8 = 1.824% a year; ÷ 2 = 0.912% per half-year" and "3.5% × 0.8 = 2.80% a year; ÷ 2 = 1.40% per half-year".
- Owner: jlr_s5.

**N3. j121: the £3,600m bar is not to scale and starts at a different baseline. BLOCKING (chart scale)**
- Evidence: scale from the other bars is 0.25 px per £m (18.7 → 4.7 px; 3,147 → 786 px from x=772). The 3,600 bar starts at x=756 and is 876 px long. It should start at x=772 and be 899 px long. The left edges visibly misalign.
- Fix: draw it from the same x origin with the same scale as the 3,147 bar, and move its value label right accordingly.
- Owner: jlr_s6.

**N4. j138: so-what not supported by the slide or its sources. BLOCKING**
- Evidence: "a 2.8% margin leaves little cushion, so new debt would cost far more than 2015's 3.5%". No current JLR borrowing cost or yield is on the slide or in the sources. It also sits awkwardly with j136, where S&P rates JLR investment grade (Aug 2024), the opposite signal on credit cost.
- Fix: either
  - cite a current JLR bond yield or coupon (primary source) and state it, or
  - reword to what the numbers show: "a 2.8% margin (0.7% for FY2026) leaves little cushion: the credit strength that won 3.5% in 2015 has to be rebuilt; Moody's outlook has been negative since the cyber-attack (slide 136)".
- Owner: jlr_s7.

### Non-blocking

**N5. j44: the CFO jump is not explained (lucidity).**
- "Cash from operations before working capital" is 2,091 / 2,295 / 3,431 / 3,066, then CFO is 2,500 / 2,429 / 3,422 / 2,572.
- The reader looks for the missing rows. The case does not print the working-capital and tax lines; they are not missing from the rebuild.
- Fix: add one line: "The case does not print the working-capital and tax rows; they net to +409 / +134 / −9 / −494 (CFO − pre-WC cash)."
- Check: 2,500 − 2,091 = 409; 2,429 − 2,295 = 134; 3,422 − 3,431 = −9; 2,572 − 3,066 = −494.
- Owner: jlr_s2.

**N6. j110: total not labelled as rounded.**
- Rows as shown sum to 504.32; the total shows 504.31.
- Fix: add "(rows rounded)", as on j107 and j109. Owner: jlr_s5.

**N7. j113 divisions and the j15 citation.**
- j113: "US$50.6m ÷ 1.50" gives 33.7, but the slide shows £33.8m. "−US$7.1m" ÷ 1.5 gives −4.7, but the slide shows −£4.8m. (Both come from the unrounded 50.64 and 7.13.) Fix: show the 2 dp inputs ("US$50.64m ÷ 1.50", "−US$7.13m"). Owner: jlr_s5.
- j15: "record-low coupons for JLR" is supported only by AR15 p.73, which is not cited on the slide. Fix: add "JLR Annual Report 2014/15, p.73" to the source line. Owner: jlr_s1.

**N8. "X, not Y" wording (open item). Which instances are worth fixing:**
- **j50 (fix):** "better credit, not cheaper money" asserts Q1's answer before Q1 tests it. Rewrite as "Q1 tests whether the lower coupon came from better credit or lower rates". Owner: jlr_s2.
- **j129 (fix):** the title "Better credit, not lower rates…" plus the so-what "moves value…; it does not create it" duplicates j139 almost word for word. Make j129 a plain recap title, e.g. "The four answers in one page", and keep the thesis for j139. Owner: jlr_s7.
- **j28 (optional):** one "X, not Y" here plus a second on j27; drop the j27 one ("fixed-rate bonds, not bank loans" → "almost all fixed-rate bonds"). Owner: jlr_s2.
- **j55, j116:** already cleared.
- **j62, j139:** keep. These are the answer and the closing thesis; one instance each is fine.
- **j61, j126:** low priority.

**N9. Finding 22 (optional visuals).**
- j48 paired bars (cash + deposits vs borrowings per year) would make "more cash than debt" visible at a glance, and the table must stay because it is the working. Worth doing only if a small paired-bar strip fits beside or under the table without crowding. It is not needed for A−.
- The j45 FCF waterfall would add more value than j48, because "investment ate most of the cash" is the point and a waterfall shows it.
- Owner: jlr_s2.

**N10. Minor chart and wording.**
- j84: the dashed plain-bond line is clipped above 140 at low rates (it starts at about 0.8%) with no note. Add "(plain-bond line runs off the top below 1%)" or extend the axis to 160.
- j118: "Locking in 3.5% before the Fed's Dec 2015 rise" sits in quotation marks but is nobody's quote. Remove the quotes or attribute them.
- j31, j129: "same-length" → "same-tenor", for one term per concept.
- j98c: the so-what says "PV avoided − cash paid" but subtracts 472.02, the PV of the new debt. Say "− PV of new-debt payments (472.02 ≈ cash borrowed)".
- Owners: jlr_s4 (j84), jlr_s6 (j118), jlr_s2 (j31), jlr_s7 (j129), jlr_s5 (j98c).

---

## (f) Calculations recomputed (independent; settlement 17 Mar 2015, 30/360)

| # | Slide | Calculation | My result | |
|---|---|---|---|---|
| 1 | j07 | regional sum; China and Europe shares | 462,209; 25.1%; 19.0% | ✓ |
| 2 | j17 / j95 | 410 × 1.151049; 500 − 471.93; segment sum | 471.93; 28.07; 410 + 50.6 + 11.3 + 28.1 = 500.0 | ✓ |
| 3 | j20 | 100 ÷ 1.035² | 93.35 | ✓ |
| 4 | j21 | 1 ÷ 1.0114^0.3222 | 0.99635 | ✓ |
| 5 | j27 / j28 | Ex1 totals; 2,255 ÷ 2,448 | 3,965 / 2,448 / 1,517; 92.1% | ✓ |
| 6 | j30 | 273.33 × 4.625% + 500 × 4.375% | 12.64 + 21.88 = 34.52 | ✓ |
| 7 | j31 / j58 | five spreads; −135 − 102 + 12 − 83 | 497 / 362 / 260 / 272 / 189; −308 | ✓ |
| 8 | j34 | 111.18 − 110.94 | 0.24 | ✓ |
| 9 | j35 | 79 ÷ 180 × 4.0625; full price | 1.7830; 113.063 | ✓ |
| 10 | j40 / j40b | PBT rebuilt from every line, 4 years | 1,479 / 1,674 / 2,501 / 2,218 | ✓ |
| 11 | j41 | EBITDA ×4 and margins | 1,999 / 2,389 / 3,287 / 2,880; 14.8 / 15.1 / 17.0 / 18.0% | ✓ |
| 12 | j43 | effective tax rates | 1.28 / 27.48 / 24.87 / 21.73% | ✓ |
| 13 | j44–j44d | pre-WC cash, investing, financing, roll-forward | 2,091 / 2,295 / 3,431 / 3,066; −1,542 / −2,609 / −2,736 / −2,025; 444 / −178 / −498 / 77; 1,402 / −358 / 188 / 624 | ✓ |
| 14 | j45 | FCF; after interest and dividends | 1,090 / 580 / 1,066 / 540; 962 / 251 / 647 / 293 | ✓ |
| 15 | j46 | EBITDA ÷ interest | 15.6 / 13.3 / 12.2 / 29.7× | ✓ |
| 16 | j47–j47c | all subtotals; 132%; 72%; loan share | balance; 132.5%; 71.6%; 27.1 / 23.3 / 20.7 / 22.6% | ✓ |
| 17 | j48 / j49 | net cash; debt/equity | 456 / 680 / 1,449 / 1,604; 0.68 / 0.61 / 0.34 / 0.36 | ✓ |
| 18 | j55 / j56 | 462; 304 ÷ 462; 158; 26 ÷ 462 | 66%; 34%; 6% | ✓ |
| 19 | j57 | 466 days; interpolation; 2.28 − 0.29 | 1.2767; 0.288%; 199; −298 | ✓ |
| 20 | j59 | 502 − 460; 304 − 42 | 42; 262 ≈ 260 | ✓ |
| 21 | j67 | (8.125 − 3.5)% × 410; 4.0625% × 410 | 18.96; 16.66 | ✓ |
| 22 | j68 | 122 ÷ 180 × 40.625; 136 ÷ 180 × 40.625 | 27.53; 30.69 | ✓ |
| 23 | j71 | DFs at 1.14%; full; clean | 0.996354 / 0.985124 / 0.974020; 113.3657; 110.61 | ✓ |
| 24 | j72 | DFs at 1.75%; full; clean | 0.994425 / 0.960513; 111.8658; 109.11 | ✓ |
| 25 | j73 / j79 | DF 1.0025^−2.3222; DF 1.015^−2.3222; PVs | 0.9942 → 107.50; 0.9660 → 104.45 | ✓ |
| 26 | j80 | range | 112.85 − 109.11 = 3.74 ("about 4") | ✓ |
| 27 | j81 / j82 | 0.395 + 0.50; DFs; full | 0.895; 0.998562 / 0.989685; 115.1049 → 112.35 | ✓ |
| 28 | j83 / j130 | 326.117 ÷ 410; residual; cash | 79.54%; 83.6; 366.40 + 0.33 + 8.99 = 375.72; 79.61%; 99.91% | ✓ |
| 29 | j85 / j86 | sum 1–7; full; clean; 128.18 − 26.86 | 26.8611 (26.8610 shown); 128.1792; 125.4257; 101.32 | ✓ |
| 30 | j87 | 125.43 − 109.11; 125.43 − 110.61; 125.4257 − 112.3514; × 4.10 | 16.32; 14.82; 13.0743; 53.60 | ✓ |
| 31 | j90 | 110.61 × 4.10; 112.35 × 4.10 | 453.50; 460.64 | ✓ |
| 32 | j96 / j97 | 3.5% × 471.9; 33.3 − 16.5; 50.6 ÷ 16.8 | 16.52; 16.8; 3.0 | ✓ |
| 33 | j98 / j98b | 471.93 × 1.75%; DFs at n = 0.9889…; PVs; total | 8.259; 0.982990 / 0.840891; 480.19 × 0.840891 = 403.79; 472.03 (472.02 shown, rows rounded) | ✓ |
| 34 | j98c | 525.53 − 472.02 | 53.51 | ✓ |
| 35 | j98d | PV realistic at 3.5%: 16.656 × 1.971747 + 443.313 × 0.960513; − 472.02 | 458.65; −13.37 | ✓ |
| 36 | j99 | six PVs | 95.20 | ✓ |
| 37 | j100 | rows 7–13; total | 430.35 (rounded rows); 525.53 | ✓ (labelled) |
| 38 | j102 / j103 | 443.313 × 0.974020; total; 1.74 × 4.10 | 431.80; 464.81 (464.80 shown, labelled); 7.13 | ✓ |
| 39 | j104 | 443.313 × 0.989685; total | 438.74; 471.93 | ✓ |
| 40 | j105 | (50.64 + 11.29) × 21%; 471.93 − 13.01 | 13.01; 458.92 | ✓ |
| 41 | j106 | 2.28% × 0.8; 3.5% × 0.8 | **1.824% (slide: "= 0.912%"); 2.80% (slide: "= 1.40%")** | ✗ |
| 42 | j107 | DFs at 0.912%; (16.656 + 16.656) × 20%; total | 0.997079 / 0.979138; 6.662; 454.00 (453.99 shown, labelled) | ✓ |
| 43 | j108 | DFs at 0.358%; total; NPV | 0.998849 / 0.991736; 459.61; +0.69 | ✓ |
| 44 | j109 / j110 | DF 1.014^−0.3222; rows; total; NPV | 0.995531; 76.89 (labelled); rows as shown 504.32 vs 504.31 (unlabelled); +45.39 | ✓ / note N6 |
| 45 | j111 / j112 | 453.99 − 458.92; (111.28 − 112.35) × 4.10 | −4.93; −4.39 | ✓ |
| 46 | j113 | 16.8 ÷ 1.5; 50.6 ÷ 1.5; 7.1 ÷ 1.5; 53.6 ÷ 1.5 | 11.2; **33.7 (slide 33.8)**; **4.7 (slide 4.8)**; 35.7 | ✗ as displayed (✓ from unrounded) |
| 47 | j118 | 112.3514 − 104.0625; 1.26 − 1.57 | 8.29; −31bp | ✓ |
| 48 | j121 | 28.07 ÷ 1.5; 18.7 ÷ 3,600; bar scale | 18.7; 0.52%; **3,600 bar 876 px vs 899 px expected** | ✗ (chart) |
| 49 | j122 | bar ends vs axis (187 px per year) | May 2016, Mar 2020, May 2021 all within 2 px | ✓ |
| 50 | j125 | 112.35 − 110.61; 112.3514 − 111.276; × 4.10 | 1.74 → 7.13; 1.0754 → 4.41 | ✓ |
| 51 | j131 | 83.583 × 1.040625 | 86.98 | ✓ |
| 52 | j134 | 5.875 ÷ 3.5; 7.75 ÷ 3.5; bar ratios | 1.68; 2.21; bars proportional | ✓ |
| 53 | j135 | 952 + 534 | 1,486 ≈ £1.5bn | ✓ |

Charts measured to scale: j14, j28, j55, j59, j62, j65 (break shown), j71 ladder, j80 (base 108), j87, j89 (106–128), j95, j98c/j98d (breaks shown), j112, j122, j125 (base 109), j130 and j134 are all proportional. **j121 is not** (N3).
