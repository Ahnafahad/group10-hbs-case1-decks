NOT READY. Grade estimate A− on content. Five narrow hard-requirement failures (H3/H9, H6, H7, H8) block it. Each is a small fix, and none changes a conclusion.

# Jaguar storyline: strict independent review, round 4 (gate 1)

Deliverable: `review/jaguar/01-storyline.md` (132 slides).

What I checked it against:
- the rubric, the grading brief and `case-layout.txt` (narrative and all six exhibits)
- CLAUDE.md, DESIGN.md and PROGRESS.md
- the output of `python3 work/jaguar/calcs.py`, plus `exhibits.csv`, `answers.md`, `sources.md` (including the 2026-10-30 rows) and all 383 lines of `sources_research.md`
- the G1 NESA benchmark (skimmed)

How I checked it:
- I recomputed the key bond numbers myself in a separate script: YTC 2.2801%, YTM 5.9446%, 110.612, the first six naive PVs, and the after-tax value at 0.716%.
- I re-fetched five external facts from their sources: the Treasury CSV rows for 4 Feb, 3 Mar and 16 Mar 2015 and 16 May 2016; the PR Newswire pricing release; JLR's S&P (Aug 2024) and Moody's (Jun 2025) notices.
- I read the questions file only to check what the four questions ask.
- I did not take the plan's "Response to the strict review" on trust.

## 0. Were the round-3 blocking items fixed?

| r3 item | Status | Evidence (new slide numbers) |
|---|---|---|
| 1 After tax: accrued interest is deductible | **FIXED** | 98: (50.6 + 11.3) × 21% = 13.0, so cash paid after tax = 458.9. 103: −4.9 / +45.4. 104 table. All match `calcs.py` (`q3_consistent`: 13.01, 458.93, 453.99, 504.31, −4.93, +45.39). |
| 2 111.28 vs 110.61 | **FIXED** | 71 explains the drift. 104 relabels −4.4 as the stale 4 Feb view. 117 is retitled to 1.74 / US$7.1m. **New knock-on error:** 83's dollar range still uses the stale 111.28 as its lower bound (blocking item B2). |
| 3 Test 1 in spreads | **FIXED** | 57: 2.28% − 0.29% = 199bp. I verified the interpolation (0.20 + 0.2767 × 0.32 = 0.2885) and the 4 Feb row on the Treasury CSV (re-fetched). Small leftover caveat: non-blocking #4. |
| 4 Tender vs wait | **FIXED** | 110 has the new title, the net cost 1.74, the rate bet framed as having no expected value, and 1.26% on 16 May 2016 (re-fetched: `05/16/2016,…,1.26,…`). |
| 5 Missing steps | **FIXED** | After-tax tables 100–102 (13.32 / 436.65, DF at 0.912%, PVs 13.29/13.17/427.54; 423.32). 97 has its own table. 72 works 109.11. All match `calcs.py`. **Still open:** the other sensitivity values on 73 (blocking item B4; r3 did not flag them). |
| 6 Half-year discounting | **FIXED** | New toolkit slide 21 (58/180 = 0.3222; 1 ÷ 1.0114^0.3222 = 0.9964). Every PV table (71, 72, 75, 78, 92, 93, 95, 97, 100–102) lists n. |
| 7 Lucidity | **FIXED** | Plain lines on 2, 12, 14, 23, 49, 114, 115. I checked every slide in r3's "so what" list against its new number and each now has one. Remaining gaps are minor (non-blocking #7). |
| 8 Facts | **FIXED** | 4: 1922/1948. 8: 9–17% (R3-3). 17: "would cost". 43: no cause claimed. 66: the OM's 104.663% stated, with the reason we use 104.0625. 117/123: the redemption price is labelled our assumption. 128: the S&P affirmation is labelled secondary/headline. 54/58: the 189 vs 193 gap is explained. |
| 9 Titles | **FIXED** | 87, 121, 82, 24, 31, 126, 131 carry the r3 wording. 67 says "almost certainly". **New label titles** found on 69, 92, 93, 99, 101 (blocking item B5). |

All nine r3 items are genuinely fixed. The fixes introduced or exposed four new problems: B1 (95.0), B2 (the Q2 range), B4 (unworked sensitivity values) and B5 (label titles). B3 is an older logic slip that r3 did not catch.

## 1. Verdict
**NOT READY. Grade A− on content.**
- Hard failures: H3/H9 (73), H6 (69, 92, 93, 99, 101), H7 (114/126), H8 (92, 83).
- All quality scores are ≥ 4.
- It becomes READY once B1–B5 are fixed.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2. Overview 3–17, with the toolkit 18–25 inside section 1. Exhibits 26–50. Q1 51–62, Q2 63–83, Q3 84–105, Q4 106–119. Epilogue 120–131. Team placeholder 132. Cover details are a placeholder on 1. |
| H2 Every exhibit | PASS | Ex1 27–33. Ex2 34–37 (all four bond pairs: 3.5%, 3.875%, 8.125% incl. the stale Aug-2014 line, 8.25% at 110.94). Ex3 38–39 (rebuilt from the Treasury CSV, `exhibits.csv` rows 325–344). Ex4 40–43. Ex5 44–46. Ex6 47–49. Synthesis 50. Each is native, labelled "Exhibit N" with a source line, and has shows / numbers / meaning / implication. |
| H3 Every question, all seven elements | **FAIL (narrow)** | Q1–Q4 each have the question, its parts, theory, evidence, assumptions and alternatives (52; 64; 85–87; 107–109). Steps: complete except **73**. Its title value 112.85 (0.5%) and six other rates (0.75–3.0%) are never worked on any slide. |
| H4 External, sourced, current | PASS | Every [src] I traced has an exact quote (table in section 4). Secondary sources are labelled (4, 8, 9, 14, 59, 128, 130). Current to Q1 FY27 (released 13 Aug 2026; Q2 FY27 results not out by 30 Oct). Minor wording issues: non-blocking #9. |
| H5 No teaching note | PASS | No citation, quote or reference. The 25% figure appears only as "the naive view" (78–82). The header's "never refers to a teaching note" is plan metadata, not slide text. |
| H6 Titles | **FAIL (narrow)** | Five labels rather than points: **93** "Naive baseline, 2018–2021, continued" (pure label), **92** "Naive baseline, 2015–2017: old payments avoided, discounted at 3.5%", **99** "After tax, step 2: old payments after tax, discounted at the after-tax rate", **101** "After tax, naive baseline 2015–2017: coupons of US$13.32m after tax, at 2.80%", **69** "Step 1: discount the three payments…". Lengths are fine; the longest is 117 (≈20 words, fits two lines, could be trimmed). |
| H7 Finance correct | **FAIL (narrow)** | Correct: semi-annual part-period discounting; 30/360 accrued; clean vs full; YTM as IRR with the reinvestment assumption; YTC/YTW; callable = straight − call; NPV = PV avoided − cash paid, with the new-debt NPV ≈ 0 proven (91); after-tax treatment (premium and accrued deductible at 21% at settlement; coupons and call premium at 20%; principal not); MM and efficiency; the tender-vs-wait logic. **Error: 114 (and 126's so-what)** says the deal "moves repayment from 2021 to 2020" and so adds refinancing risk. The deck's own realistic baseline (67, 95, 104) is a call in May 2016. Against that baseline the deal *lengthens* JLR's funding from 2016 to 2020. The plan judges risk against the baseline it calls an illusion on 94. |
| H8 Numbers | **FAIL (narrow)** | 44 of 45 spot-checked numbers match (section 4). **92**: "first six payments are worth US$95.0m". The correct sum is 16.66 × (0.994425 + 0.977322 + 0.960513 + 0.943993 + 0.927758 + 0.911801) = **US$95.2m** (rows from `calcs.py`; I recomputed 95.204). **83**: "US$456–461m" uses the stale 111.28 as its floor, but slide 71 says holders who need the market's 2.28% should accept 110.61 on the deal date (110.61 × 4.10 = US$453.5m). Formats: fine (money 1 dp, prices 2 dp, yields 2 dp, bp whole). |
| H9 User decisions | **FAIL (narrow)** | Honoured: call-aware Q2 first (66–77 before 78–80); US$ maths with one 1.50 rate, stated and justified (33, 105); 15 May 2021 with exactly one 15 Nov 2021 note (81; a grep finds no other slide); 104.0625; 158bp shown as one block (55); 21%/20% tax. **Breach:** "every repeated calculation gets its own slide" (PROGRESS, gate 1 choice). 73 presents seven repeats of the slide-71 calculation as a results-only table, which is the format the user turned down. |
| H10 Known traps | PASS | Semi-annual and callable from May 2016 (18, 21, 24, 66–67). US$ vs £ at 1.50 vs Exhibit 1's 1.559 (33). Clean/dirty and 30/360 with accrued paid separately (25, 68, 76). The 25% naive vs 11% market vs our answer, reconciled without the teaching note (78–83). Credit not Treasuries, tested three ways (56–59: 26bp; Test 1 199bp; Test 2 308bp; HY index −40bp). Fair-price refinancing ≈ no value, tested (91–97, 103–104, 108, 116). |
| H11 Lucidity | PASS | The toolkit (18–25) now comes before use. Terms are defined where first used. Every PV table has n and DF. "So what" lines are on almost all calculation slides. Slides that could still trip the target reader (fewer than a handful, none fatal): 110 (1.74 is stated before it is derived, on 117), 97 ("zero" not said to be by construction), 57 ("interpolate" not said in words), 66 ("offering memorandum" undefined). Fixes in section 6. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Reproduces the tender price to US$0.01; five reconciled valuations; three tests of "credit not rates"; naive / realistic / offer-rate baselines, pre- and after-tax, with full tables; who-gains split across three parties. |
| Q2 Logic and flow | 4 | Concept → exhibit → question flow is clean and chronological. Held back by the 114 vs baseline inconsistency and the Q2 range on 83 not tracking 71. |
| Q3 Evidence | 4 | Primary releases, filings, legislation and Treasury data; secondary sources labelled. A few soft spots: 129 "impact [src]" is unspecified; 126 "from cash" goes beyond its quote. |
| Q4 Lucidity | 4 | A part-way CFA L1 reader can follow nearly every slide on paper. The four small gaps in H11 keep it from a 5. |
| Q5 Calculations | 4 | Every main value has its own worked table, and the after-tax tables are complete. Held back by 73's unworked rows, the 95.0 error and the results-only ratio rows (45/46/48/49). |
| Q6 Overview and epilogue | 4 | Sourced history, industry and credit context; the epilogue runs tender result → 2016 call → 2019–20 hindsight → IG rating → cyber-attack → Q1 FY27, tied back to the decision on 126/131. |

## 4. Number spot-check (45 numbers; every number changed this round is included)

| Number | Slide | Source | Match |
|---|---|---|---|
| Premium 50.6 + accrued 11.3 = 61.9 × 21% = **13.0** | 98 | calcs `q3_consistent` (61.93, 13.01) | yes |
| After-tax cash paid **458.9** | 98, 102–103 | calcs 458.93 | yes |
| After-tax realistic PV **454.0** (13.29 + 13.17 + 427.54) | 100 | calcs 453.99 | yes |
| Flows 13.32 / 13.32 / 436.65; DF at 0.912% per half-year | 100 | calcs | yes |
| After-tax naive PV **504.3**; last flow 423.32 | 102 | calcs 504.31 | yes |
| **−4.9** / **+45.4** | 103–104 | calcs −4.93 / +45.39 | yes |
| 1.82% / 2.80% after-tax rates | 99 | calcs 1.824 / 2.800 | yes |
| Test 1: 1Y 0.20%, 2Y 0.52% on 4 Feb 2015; 466 days = 1.276 yrs; **0.29%**; **199bp** | 57 | sources.md 2026-10-30 row (re-fetched); calcs; my recompute 0.2885 | yes |
| **109.11** table: DF 0.994425 / 0.977322 / 0.960513 → PV 4.04 / 3.97 / 103.86 → full 111.87 − 2.75 | 72 | calcs r3 block; my recompute 111.866 | yes |
| **0.895%** table: 16.66 / 16.66 / 443.31 × DF 0.998562 / 0.994114 / 0.989685 → 16.63 / 16.56 / 438.74 = 471.9 | 97 | calcs | yes |
| 0.895% per-100 table: PV 4.06 / 4.04 / 107.01 → full 115.10 → 112.35 | 75 | calcs (115.105; 112.3514) | yes (rows sum to 115.11 after rounding; see non-blocking #10) |
| 2.28% table → 113.37 − 2.75 = **110.61** | 71 | calcs; my recompute 110.612 | yes |
| **1.74** per 100 / **US$7.1m** | 110, 117 | calcs (112.35 − 110.61 = 1.74 × 4.10) | yes |
| **1.26%** 5Y Treasury, 16 May 2016 | 110 | sources.md row (re-fetched) | yes |
| £ at 1.50: premium **£33.8m**; NPV **−£4.8m**; after tax **−£3.3m**; naive **+£35.7m** | 105 | calcs r3 GBP line | yes |
| 0.3222 half-years; DF 0.9964 at 2.28% | 21 | calcs (0.996354) | yes |
| YTM 5.94%, YTC 2.28% at 111.276 | 35, 70 | calcs; my recompute 5.9446 / 2.2801 | yes |
| Accrued US$27.53 (122 days) / US$30.69 (136 days) | 68 | calcs; PR Newswire (re-fetched) | yes |
| 0.395% + 50bp; US$1,123.52 / 1,093.52 | 74, 76 | PR Newswire 16 Mar (re-fetched) | yes |
| Naive full 128.18 → clean 125.43; Nov-2021 127.26 | 79, 81 | calcs | yes |
| (125.43 − 112.35) × 4.10 = 13.07 × 4.10 ≈ US$54m | 80 | calcs 53.6 | yes |
| Option ≈ 14 points (125.43 − 111.28) | 80 | calcs 14.15 | yes |
| **US$456–461m** | 83 | 111.28 / 112.35 × 4.10 | arithmetic yes; **basis inconsistent with 71 (B2)** |
| 471.9 needed; 28.1 surplus | 17, 88 | calcs | yes |
| 33.3 vs 16.5 → 16.8 a year; premium 50.6 incl. 12.3 | 89–90 | calcs | yes |
| "three years of savings" | 90 | 50.64 / 16.79 = 3.0 | yes |
| New-debt PV 472.0 | 91 | calcs 472.02 | yes |
| **First six naive payments US$95.0m** | 92 | calcs rows: 16.56 + 16.28 + 16.00 + 15.72 + 15.45 + 15.19 = 95.2 | **NO (95.2)** |
| Naive PV 525.5 → +53.6 | 93–94 | calcs | yes |
| Realistic PV 464.8 → −7.1 | 95–96 | calcs | yes |
| 497 / 362 / 260 / 272 / 189bp; 308bp | 31, 58 | calcs Test 2; R3-7 CSV rows | yes |
| 3.15% + 497; 1.57% + 193; 304bp (66%) / 158bp (34%); 26bp | 53–56 | calcs; sources.md #1 | yes |
| HY 502bp vs ~460bp → ~40bp; ~260bp JLR-specific | 59 | R2-2 (Business Standard/BofA; Fortune) | yes |
| 410 / 263 = 1.559; £273.3m; £12.6m + £21.9m = £34.5m | 30, 33 | calcs | yes |
| 111.276; 110.944 (8.25%) | 34, 36 | case Ex2; exhibits.csv | yes |
| 10Y −105bp, 5Y −26bp | 39 | exhibits.csv rows 332/342, 5Y rows | yes |
| Revenue +43%, PBT +69% | 40 | calcs 43.5 / 69.1 | yes |
| EBITDA margin 14.8% → 18.0% | 41 | calcs 1,999 / 13,512; 2,880 / 16,040 | yes |
| Tax rates 1.28 / 27.48 / 24.87 / 21.73% | 43 | 19/1,479; 460/1,674; 622/2,501; 482/2,218 | yes |
| FCF 1,090 / 580 / 1,066 / 540; after interest and dividends 962 / 251 / 647 / 293 | 45 | calcs; case Ex5 | yes |
| Cover 15.6 / 13.3 / 12.2 / 29.7× | 46 | calcs | yes |
| Net cash 456 → 1,604; D/E 0.68 → 0.36; equity £2.9bn → £6.8bn | 47–49 | calcs; case Ex6 | yes |
| Regions sum to 462,209 | 7 | R3-2 (my sum) | yes |
| 79.61%; US$375.7m; US$83.6m; US$87.0m at 104.0625 | 122–123 | final-results release; 20-F; calcs 375.72 / 86.98 | yes |
| Retail series 462,209 → 614,309 → 439,588 | 124 | R3-2, R3-4 | yes |

External facts checked (at least 6). Re-fetched by me:
- Treasury rows for 4 Feb, 3 Mar and 16 Mar 2015 and 16 May 2016
- PR Newswire pricing release (0.395%, 50bp, US$30, 1,123.52 / 1,093.52, 27.53 / 30.69)
- S&P BBB- from BB, 20 Aug 2024 (JLR notice)
- Moody's Ba1 from Ba2, outlook positive, 13 Jun 2025 (JLR notice)

Checked against the exact quotes in the sources files:
- 21% FY2014 (Finance Act 2013 s.4)
- FY2019 £3.6bn loss incl. £3.1bn impairment
- €5.875% / 6.875% (2019) and US$7.75% / 5.875% (2020)
- B+ / B1 at 31 Mar 2020
- Q1 FY27 £6.0bn, £109m, 2.8%; FY26 £22.9bn
- rivals' 2014 growth (BMW 9.5%, Audi 10.5%, Mercedes 12.9%, Porsche 17%)
- Changshu plant (Oct 2014, 130,000)
- cyber-attack 2 Sep → 8 Oct 2025 (≈5 weeks)

All supported. Two soft spots:
- 126 "repaid from cash": the quote says only "repaid … March 2020".
- 87 "20% from 1 Apr 2015": the source is Pinsent Masons (secondary) and is not labelled as such.

## 5. Blocking items (slide → problem → exact fix)

**B1. Slide 92: wrong subtotal (H8).**
- Problem: "the first six payments are worth US$95.0m". The six PVs in `calcs.py` sum to US$95.2m.
- Fix: change the so-what to "the first six payments are worth US$95.2m today". Print that subtotal in `calcs.py` so the builder pulls it rather than retyping it.

**B2. Slide 83 (and its echo in `answers.md`): the Q2 answer range uses the stale 4 Feb price as its floor (H7/H8; knock-on from r3 item 2).**
- Problem: slide 71 says holders who need the market's 2.28% should accept 110.61 on 17 March. Slide 83 still gives "US$456–461m", which is 111.28–112.35.
- Fix: retitle to "Q2 answer: about 110.6–112.4 per 100 plus accrued interest, US$453.5–460.6m for the issue".
- Body:
  - floor = the value at the market's own 2.28% on the deal date (71)
  - ceiling = the tender's near-risk-free 0.895% value (75)
  - the stale 111.28 sits inside the range
  - the consent solicitation is an extra push
- Check 87's "our Q2 range's top" still reads true (it does: 112.35).

**B3. Slide 114 (and 126's so-what): refinancing risk is judged against the naive baseline (H7).**
- Problem: "Moving repayment from 2021 to 2020 adds refinancing risk" assumes the old notes would have run to 2021. The deck's own realistic case is a call in May 2016 (67, 95), so the deal actually lengthened funding from 2016 to 2020.
- Fix 114: retitle to "Against the 2016 call, the deal fixed 3.5% for five years; against 2021 it brought repayment forward a year". The body states both views and the plain definition of refinancing risk.
- Fix 126 so-what: "the 2015 deal fixed cheap money to 2020; that maturity then fell in the 2019–20 crisis, when new debt cost 5.875–7.75%".

**B4. Slide 73: seven repeated calculations shown as results only (H3; breaches the user's "one slide per repeated calculation" choice).**
- Problem: 112.85 (in the title) and the values at 0.75, 1.0, 1.5, 2.0, 2.5 and 3.0% are never worked. Only 2.28% (71), 3.5% (72) and 0.895% (75) are.
- Fix: follow the user's rule. Give each of the seven rates its own slide in the slide-71 layout (rate ÷ 2 → n → three DFs → PVs → full − 2.75 = clean, plus a one-line so-what). Keep 73 as the summary chart, citing those slides.
- If that is felt to flood the deck, ask the user (multiple choice, plain words). Option: one table on 73 whose every row shows rate ÷ 2, the three DFs, full price, −2.75 and clean. Either way, no value may appear without its working.

**B5. Slides 69, 92, 93, 99, 101: label titles (H6).** Replace with points:
- 69: "To value the notes, discount their three remaining payments at a 14-month rate"
- 92: "The first six payments JLR avoids are worth US$95.2m today, at 3.5%"
- 93: "Holding the notes to 2021 would cost JLR US$525.5m in today's money"
- 99: "After tax, both the payments and the discount rate shrink by the 20% tax rate"
- 101: "After tax, each avoided coupon costs JLR only US$13.32m, discounted at 2.80%"

## 6. Non-blocking improvements (most valuable first)
1. **97:** add "zero by construction: discounting at the same rate that set the price always gives NPV = 0. The real test is whether 0.895% fits JLR's risk; the market (2.28%) says no, hence −US$7.1m."
2. **104:** the 0.895% row has no after-tax figure. At 0.716% it is about +US$0.7m (my recompute: 459.61 − 458.93). Add it to `calcs.py` and the table, and soften 103's "not the sign" to cover this row.
3. **110:** show the working on the slide itself (112.35 − 110.61 = 1.74; × 4.10 = US$7.1m; cite 71). Add that JLR's 2016 spread is unknown, so the 1.26% shows only the Treasury part.
4. **57:** add one caveat line: 497bp was a 10-year spread and 199bp is a 15-month spread, so part of the fall is the slope of JLR's credit curve. Say "straight-line between the 1-year and 2-year yields" in words.
5. **80:** use the same-date value: 125.43 − 110.61 = 14.82 points. That removes the "different dates" caveat; only the legitimately different yields remain.
6. **`answers.md`** is stale: the after-tax table still shows +43.0 / −7.3 and the tax line omits the accrued deduction. Update it before gate 3, because builders take numbers from it.
7. Add a "So what" to calculation slides 55 and 123, and to the tables on 82 and 104, so the header's "every calculation slide ends with one" is true.
8. **45, 46, 48, 49:** show each year's inputs, not just results (e.g. 2,500 − 596 − 814 = 1,090). Say on 45 that capex includes cash spent on intangibles (capitalised development).
9. Wording and sourcing:
   - 113: convert US$28m at 1.50 (≈£18.7m) before comparing it with £3.6–3.8bn.
   - 126: drop "from cash".
   - 87: label the 20% source as secondary.
   - 129: name the impact figures (£196m cyber costs, Q2 FY26 loss £(485)m, £3.5bn backstop).
   - 11: the 17% figure is in Exhibit 1's note (p.3), not p.2.
   - 31: add "assumes each note was issued at par".
   - 66: define "offering memorandum" (the bond's sale document).
10. **75:** the rounded PVs (4.06 + 4.04 + 107.01) sum to 115.11 while the full price shows 115.10. Add "rows rounded" or show 3 dp. Also trim 117's title (about 20 words).

## Strongest parts
- Q2 rebuilds JLR's actual tender formula (May 2016 Treasury 0.395% + 50bp to the call at 104.0625) to the cent, and reconciles it with the market, the value at the 2.28% market yield, the value at the 3.5% new-debt rate and the naive 125.
- Q3 proves that new debt at market rates has zero NPV. It then values every baseline with full, dated PV tables, before and after tax, with the 21%/20% timing and the accrued deduction now right.
- Q1 tests "credit, not Treasuries" four ways (26bp like for like, the same bond's spread, five issues, the market index) instead of asserting it.
