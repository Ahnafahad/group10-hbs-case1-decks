READY. Grade estimate A− (borderline A). The r6 blocking item is fixed, answers.md now agrees with the plan, and the 4-dp full prices and the 2.7535 accrued on slides 71–82 and 86 all reproduce exactly. No hard-requirement failures; every quality score is 4 or more.

# Jaguar storyline: strict independent review, round 7 (gate 1)

**Deliverable:** `review/jaguar/01-storyline.md` (140 slides, round 7), with `work/jaguar/answers.md` as the supporting answers file.

**What I read, in full:** `review/shared/review-rubric.md`; the grading brief; `case-layout.txt` (six exhibits); CLAUDE.md and DESIGN.md; PROGRESS.md (user feedback word for word and decisions, including the 2026-10-30 "Mix (Recommended)" choice); the full output of `python3 work/jaguar/calcs.py` (runs, exit 0); `answers.md` (88 lines); `sources.md`; `sources_research.md` (all 383 lines); `exhibits.csv` (Exhibits 1–3 rows and the totals); the r6 review. I skimmed the G1 NESA benchmark (268 slides; one calculation step or one full table per slide). I read the teaching note only to check two numbers in answers.md's "for checking only" section, and `work/jaguar/check/check_answers.md` only for the checker's numbers that answers.md quotes.

**What I recomputed myself** (my own script, not calcs.py): 30/360 accrued (122 and 136 days → 2.7535 and 3.0694); YTC 2.2801% and YTM 5.9446% at 111.276 on 4 Feb (79 days); all ten values to the call at 0.50 / 0.75 / 1.00 / 1.50 / 2.00 / 2.28 / 2.50 / 3.00 / 3.50 / 0.895%, every discount factor, PV row and full price to 4 dp; the naive 128.1792 / 125.4257; the checker's 2.24% at 17 Mar (110.6619) and at 31 Mar (110.4442); cash paid 471.93; every subtraction on 71–82 and 86; plus about 30 ratio and spread subtractions by hand.

**Live re-checks this round:** WebFetch hit its usage limit and the proxy refused curl to prnewswire.com, jlr.com, legislation.gov.uk and federalreserve.gov. So I could not re-open those pages (r6 re-fetched the PR Newswire and JLR IR pages earlier today, 30 Oct 2026). A web search today found **no Q2 FY27 results yet**: only the Q2 FY27 wholesale update (82,400 units, +24.5%) and Q1 FY27 coverage (profit after tax £248m → £66m, which matches R3-6). So Q1 FY27 is still the latest result, and slide 138 is current.

## 0. Were the round-6 items fixed?

| r6 item | Status | Evidence |
|---|---|---|
| **B1, line 78** (checker row said "111–112" and "110.44 is inside our band") | **FIXED** | Line 78 now reads: "110.6–112.4 (to call, 17 Mar: floor at the market's 2.28%, ceiling at the offer's 0.895%) \| 110.44 (to call at 2.24%, settle 31 Mar) \| 0.17 below our floor only because it settles on 31 Mar …; at its 2.24% on our 17 Mar date it gives 110.66, inside our band". I recomputed 110.6619 (17 Mar) and 110.4442 (31 Mar). The checker file confirms its 31 Mar basis: dirty 113.51 − clean 110.44 = 3.07 = 136 days of accrued. Correct. |
| **B1, line 26** (market-wide spreads "still being sourced") | **FIXED** | Line 26: "market-wide high-yield spreads fell only about 40bp (BofA ~502bp, May 2011 → Fortune ~460bp, Mar 2015; different indices, indicative), vs 304bp for JLR, so about 260bp is JLR-specific (plan 59)". This matches plan 59 and R2-2's quotes. |
| B1 optional, line 85 | **FIXED** | "(10.6–12.4%)" |
| B1 optional, line 80 | **FIXED** | "+53.5 (+53.6 in the PV form …; the 0.1 gap is the new debt's PV 472.0 vs 471.9)". calcs prints +53.5 (incremental) and 472.02 vs 471.93. Correct. |
| NB1: 24 and 84, "capped near its call price" | **FIXED** | Both now say "capped near the value of being repaid on the call date: the call price plus the coupons until then (at most about 113 here)". 112.85 at 0.5% confirms the "about 113". |
| NB2: accrued 2.7535 and 4-dp full prices on 71–82 and 86 | **FIXED, no new errors** | Each slide checked against my recompute: 71 113.3656 − 2.7535 = 110.6121 → 110.61 (I get 113.3657 at exactly 2.28%; calcs uses the implied 2.2801%, so this is a last-digit difference). 72 111.8657 → 109.1122 → 109.11. 73 115.6082 → 112.8547 → 112.85. 74 115.2893 → 112.5358 → 112.54. 75 114.9717 → 112.2182 → 112.22. 76 114.3403 → 111.5868 → 111.59. 77 113.7141 → 110.9606 → 110.96. 78 113.0930 → 110.3395 → 110.34. 79 112.4769 → 109.7234 → 109.72. 82 115.1049 → 112.3514 → 112.35. 86 128.1792 → 125.4257 → 125.43. All the 4-dp DFs on 73–79 match mine. One last-digit item on a calculator: 74's 108.125 × 0.9913 = 107.18 vs 107.19 shown (that row's unrounded DF is 0.991346). Rounding only; see NB3. |
| NB3: half-bp rounding footnote | **PARTLY FIXED** | The footnote is on 55 ("rounded down throughout"). The first half-bp figures (497.5, 362.5, 260.5) appear on 31 and 53, before the footnote. Non-blocking (NB4). |
| NB4: 13.325 footnote | **FIXED** | On 107 ("coupon 16.656 × 0.8 = 13.325, shown as 13.32"); 108–110 say "same columns". |
| NB5: superseded prints in calcs.py | **MOSTLY FIXED** | "saving 19.0", "total 34.0", "+13.3 bondholders" and the old after-tax lines are now tagged. Still untagged: "B to call @3.50% … −13.3", "tender ex early premium … −12.3" and "issuer call value implied … 14.15 / 13.07". Non-blocking (NB2). |
| NB6: factoring (27), carrying amount (119) | **FIXED** | Both defined in plain words; 27's source line names the Q3 interim accounts p.6. |
| NB7: 15 vs 14 months | **FIXED** | 57: "15 months from the 4 Feb price date (the 14-month horizon on slides 69–70 counts from the 17 Mar deal date)". 466 days checked. |
| NB8: 133 FY2019 vs COVID | **FIXED** | Retitled "FY2019–21: …". |
| NB9: "s.6" without a quote | **FIXED** | answers.md line 11 cites s.4 (quoted in R2-7) and labels the 20% secondary. |
| NB10: 118 in the checklist | **FIXED** | The checklist "every calculation" row now lists 118 and 125. |

**Does answers.md now agree with the plan everywhere?** Yes, on substance. I checked it line by line:
- Conventions (US$; 1.50; 30/360; 17/31 Mar; 104.0625; 15 May 2021 plus the note; 21%/20%)
- Q1 (497/193/462; 304 = 66%; 26bp; Test 1 at 199bp; drivers incl. 40bp market-wide)
- Q2 (125.43, 109.11, 111.28, 112.35, 109.35; 27.53/30.69; 110.6–112.4; US$453.5–460.6m; 14.82)
- Q3 (471.9, 28.1, 16.8, 50.6/12.3, +53.6/−7.1/0.0/−4.4 and +45.4/−4.9/+0.7; 472.0; tax on premium + accrued)
- Q4 (1.74 / US$7.1m; 1.08 / US$4.4m; 1.26%; both refinancing-risk views)
- the checker table

The only stale text is the file header, "aligned with storyline round 6" (the plan is round 7). That is a label, not a contradiction (NB6).

**New errors introduced by the fixes:** none found.

## 1. Verdict
**READY. Grade estimate A− (borderline A).**
- Zero hard-requirement failures.
- Q1–Q6 all ≥ 4.
- answers.md agrees with the plan.
- 52 numbers spot-checked, all within last-digit rounding.
- 12 external facts checked against their quotes; 2 confirmed by search today.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover details are a placeholder). Overview 3–17 (toolkit 18–25 before first use). Exhibits 26–50. Q1 51–62, Q2 63–90, Q3 91–113, Q4 114–127. Epilogue 128–139. Team placeholder 140. |
| H2 Every exhibit | PASS | Ex1 27–33 (all six notes, revolver, factoring, FX 1.559 vs 1.50; notes 2,255 of 2,448 = 92% checked). Ex2 34–37 (all four pairs, ISIN/"i" explained, stale line flagged, 110.944 sterling). Ex3 38–39 (rebuilt from the Treasury CSV; rows match sources #1). Ex4 40–43. Ex5 44–46. Ex6 47–49. Each has a native rebuild, an "Exhibit N" label with a source line (27, 34, 38, 40, 44, 47), and shows / numbers / meaning / implication, with the synthesis on 50. |
| H3 Every question | PASS | **Q1:** stated 52; parts 52; theory 23, 55; evidence 53–61 (case, Treasury CSV, HY index); assumptions 52; alternatives 55–59 (four tests). **Q2:** 64; 65–69; 21–25, 84; 66, 81–83; 67, 69; 71–89. **Q3:** 92; 93, 98, 106; 94; 99–112. **Q4:** 115; 116, 123; 117–118, 120; 115; 117–118, 122. Every calculation is worked on a slide (formula → numbers → result). |
| H4 External, sourced, current | PASS | Every [src] I traced has a URL, access date and exact quote. Secondary sources are labelled (4, 8, 9, 14, 59, 136, 138). Current to Q1 FY27 (no Q2 FY27 results exist as of today). One weak link: 136's "S&P affirmed BBB- negative, 28 May 2026" rests on a search headline that sources_research itself marks "NOT verified". It is labelled "secondary, Cbonds headline" on the slide, so this is non-blocking, but fix it at gate 3 (NB1). |
| H5 No teaching note | PASS | grep finds only the plan's header metadata line ("never refers to a teaching note"). The ~25% appears only as "the naive view" (85–89). answers.md keeps its comparison in the marked "for checking only" section. |
| H6 Titles | PASS | Every content title states a point. The longest is 57 at 18 words; most are ≤ 17. Trim 57 (NB5). |
| H7 Finance correct | PASS | Checked correct: <br>• part-period semi-annual discounting (21) <br>• 30/360 accrued; clean vs full (25, 68) <br>• YTM as IRR with its reinvestment assumption; YTC/YTW (22, 24) <br>• callable = straight − call, with 14.82 flagged approximate (84, 87) <br>• new debt at market rate NPV ≈ 0 (98) <br>• NPV = PV avoided − cash paid <br>• after tax: premium + accrued deductible at 21% at settlement; coupons and call premium at 20%; principal not; after-tax rate r(1 − t) (105–110). The accrued deduction is not a double count: the baseline tables deduct the full May coupon instead. <br>• MM and efficiency (116), tender vs wait (118), refinancing risk both ways (122), signalling (123) |
| H8 Numbers | PASS | 52 numbers checked (section 4); all match within the last shown digit. Formats: money 1 dp, prices 2 dp, yields 2 dp, bp whole; extra decimals only in intermediate steps. |
| H9 User decisions | PASS | • Call-aware Q2 first (64–83 before 85–88). <br>• US$ maths converted once at 1.50 (33, 113, 121). <br>• 15 May 2021 throughout, with exactly one 15 Nov 2021 slide (grep: only 88). <br>• One slide per repeated calculation (71–79, 82; 99–110 including 108). <br>• The "Mix" choice is a Gilts decision; Jaguar follows its spirit (ratio slides 40–49 show every year's numbers plugged in). |
| H10 Known traps | PASS | • Semi-annual coupons and the May 2016 call: 18, 21, 24, 66–67. <br>• US$ vs £: 33. <br>• Clean/dirty and 30/360: 25, 68, 83, 90. <br>• ~25% naive vs ~11% market vs our answer, reconciled without the teaching note: 85–90. <br>• Credit, not Treasuries (26bp), tested four ways: 56–59. <br>• Fair-price refinancing ≈ no value, tested with three baselines before and after tax: 98–113, 124. |
| H11 Lucidity | PASS | Toolkit before use, terms defined at first use, every PV table has n and DF, and every calculation slide ends with a so-what. Soft spots (a handful, none severe): <br>• 25 uses "30/360" before 68 explains it <br>• "par" is used on 31/37/66 but never defined <br>• 138 uses "adjusted EBIT margin" and "exceptional items" without a plain line <br>Fixes in NB3. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Reproduces the real tender price to US$0.01; ten worked values to the call; "credit, not rates" tested four ways; three baselines before and after tax; a three-party gain split. |
| Q2 Logic and flow | 4 | Clean concept → exhibit → question → epilogue order. The r6 seams are closed (57 vs 69–70; 133). It stays at 4 rather than 5 because Q2 runs to 28 slides with nine near-identical rate slides; that is the user's rule, but the flow is heavy. |
| Q3 Evidence | 4 | Primary releases, legislation and Treasury CSVs; secondary sources labelled. 136's headline-only S&P item keeps it from 5. |
| Q4 Lucidity | 4 | A part-way CFA Level 1 reader follows almost every slide on paper; three small soft spots (H11). |
| Q5 Calculations | 5 | Every value is worked on a slide and reproduces on a calculator within the last shown digit, now including the full-price subtractions. |
| Q6 Overview and epilogue | 4 | Sourced history, industry and credit context; the epilogue runs from the tender result to Q1 FY27 and ties back on 129/139. |

## 4. Number spot-check (52 numbers)

| Number | Slide | Source | Match |
|---|---|---|---|
| 0.3222; 1 ÷ 1.0114^0.3222 = 0.9964 | 21 | my recompute 0.996354 | yes |
| 3.50 − 1.57 = 193bp | 19, 54 | sources #1 | yes |
| £273.3m × 4.625% = 12.6; £500m × 4.375% = 21.9; 34.5 | 30 | calcs | yes |
| 497 / 362 / 260 / 272 / 189 | 31, 58 | R3-7 rows (2.00, 1.52, 1.53, 1.61), sources #1 (3.15) | yes (half-bp rounded down) |
| 410 / 263 = 1.559 | 33 | exhibits.csv; calcs | yes |
| notes 92% of £2,448m; £1,485m undrawn | 27–28 | exhibits.csv (2,255 / 2,448) | yes |
| 111.28; 110.94 | 34, 36 | exhibits.csv 111.276, 110.944 | yes |
| YTM 5.94%, YTC 2.28% | 35, 70 | my recompute 5.9446 / 2.2801 | yes |
| 10Y −105bp, 5Y −26bp | 39, 56 | sources #1 (3.15 → 2.10; 1.83 → 1.57) | yes |
| 43.5%; 69.1% | 40 | exhibits.csv; calcs | yes |
| EBITDA margin 14.8% → 18.0% | 41 | calcs 1,999 / 13,512; 2,880 / 16,040 | yes |
| 51 / 51 / 41 / 38% | 42 | calcs | yes |
| 1.28 / 27.48 / 24.87 / 21.73% | 43 | my division | yes |
| FCF 1,090 / 580 / 1,066 / 540; 962 / 251 / 647 / 293 | 45 | calcs | yes |
| 15.6× (1,999 ÷ 128) … 29.7× | 46 | calcs | yes |
| net cash 456 / 680 / 1,449 / 1,604 | 48 | my sums | yes |
| D/E 0.68 / 0.61 / 0.34 / 0.36 | 49 | my division | yes |
| 304bp = 66% of 462 | 55 | calcs | yes |
| 466 days, 1.276 yr; 0.29%; 199bp | 57 | sources.md 4 Feb row; calcs | yes |
| 308 vs 304bp | 58 | 497 − 189; 497 − 193 | yes |
| ~502 → ~460bp; ~260bp JLR-specific | 59 | R2-2 quotes | yes |
| 104.0625 (OM prints 104.663) | 66 | sources A–B | yes |
| 122 days → US$27.53; 136 → US$30.69 | 68 | my 30/360; PR Newswire quote | yes |
| 2.28%: DFs 0.996354 / 0.985123 / 0.974019; full 113.3656; clean 110.61 | 71 | my recompute | yes |
| 3.5%: 111.8657 → 109.11 | 72 | my recompute | yes |
| 0.50%: DFs 0.9992 / 0.9967 / 0.9942; 115.6082 → 112.85 | 73 | my recompute | yes |
| 0.75%: 115.2893 → 112.54 | 74 | my recompute (row 107.19 vs 107.18 from 4-dp DF) | yes |
| 1.00%: 114.9717 → 112.22 | 75 | my recompute | yes |
| 1.50%: 114.3403 → 111.59 | 76 | my recompute | yes |
| 2.00%: 113.7141 → 110.96 | 77 | my recompute | yes |
| 2.50%: 113.0930 → 110.34 | 78 | my recompute | yes |
| 3.00%: 112.4769 → 109.72 | 79 | my recompute | yes |
| 0.395% + 0.50%; DFs 0.998562 / 0.994114 / 0.989685; 115.1049 → 112.35 | 81–82 | R-A quote; my recompute | yes |
| US$1,123.52 / 1,093.52 | 83 | PR Newswire quote (A) | yes |
| naive 128.1792 → 125.43; 12.6–16.3 | 85–86 | my recompute 128.1792 / 125.4257 | yes |
| 14.82; 13.07 × 4.10 ≈ US$54m | 87 | calcs | yes |
| 127.26 | 88 | calcs | yes |
| US$453.5–460.6m | 90 | 110.61 / 112.35 × 4.10 | yes |
| 410 × (112.35 + 2.75)% = 471.9; 28.1 | 95 | my recompute 471.93 | yes |
| 33.3 vs 16.5 → 16.8; 50.6 incl. 12.3 | 96–97 | calcs | yes |
| 472.0 | 98 | calcs 472.02 | yes |
| 95.2; 430.3; 525.5; +53.6 | 99–101 | calcs | yes |
| 464.8; −7.1 | 102–103 | calcs | yes |
| 16.63 + 16.56 + 438.74 = 471.9 | 104 | calcs | yes |
| (50.6 + 11.3) × 21% = 13.0; 458.9 | 105 | calcs 13.01 | yes |
| 1.82% / 2.80% | 106 | calcs | yes |
| 13.29 + 13.17 + 427.54 = 454.0 | 107 | calcs | yes |
| 13.31 + 13.26 + 433.04 = 459.61; +0.7 | 108 | calcs | yes |
| 504.3; 423.32 | 110 | calcs | yes |
| £33.8m; −£4.8m; −£3.3m; +£35.7m | 113 | calcs | yes |
| 1.74 → US$7.1m; 8.29; 1.26% | 118 | calcs; sources.md 16 May 2016 row | yes |
| £18.7m | 121 | calcs | yes |
| 79.61%; US$375.7m; US$83.6m; US$87.0m | 130–131 | PR Newswire quotes; calcs | yes |
| answers.md 110.66 / 110.44 (checker) | answers 78 | my recompute 110.6619 / 110.4442 | yes |

**External facts checked (12):**

Against the exact quotes in the sources files:
1. Tata–Ford June 2008, US$2.3bn (F, R3-1) → 5
2. FY2011 £9,871m / £1,115m (R2-4) → 6
3. FY2015 regions summing to 462,209; Changshu 130,000 (R3-2) → 7
4. BMW +9.5%, Audi +10.5%, Mercedes-Benz +12.9%, Porsche +17%; Land Rover 385,279; Reg. 333/2014 (R3-3) → 8–9
5. Moody's Ba2 Sep 2013 (E) → 12
6. Fed 0–¼% Mar 2015, first rise Dec 2015 (G) → 14, 118
7. Pricing 0.395% / 50bp / US$30 / 1,123.52 / 1,093.52 and final 79.61% / US$83.583m (A) → 81–83, 130–131
8. Retail FY15–FY21 series and FY2019 £3.6bn / £3.1bn (R3-4) → 132–133
9. 2019–20 coupons 5.875 / 6.875 / 7.75 / 5.875%; B+ / B1 (R3-5) → 134
10. S&P BBB- 20 Aug 2024; Moody's Ba1 13 Jun 2025 (R3-6) → 136
11. Q1 FY27 £6.0bn / £109m / 2.8% (R3-6) → 138

By search today:

12. No Q2 FY27 results yet (only the Q2 wholesale update), and Q1 FY27 profit after tax £248m → £66m (Express & Star). Both are consistent with 138.

All support the plan. The one weak item is 136's Cbonds headline (NB1).

## 5. Blocking items
None.

## 6. Non-blocking improvements (most valuable first)
1. **136, S&P 28 May 2026 affirmation:** `sources_research.md` (lines 116, 360) marks this "search-snippet / headline only, NOT verified". Its own header says such rows must not go on a slide until re-checked. At gate 3, either open a page that carries the statement and log the exact quote, or drop that clause and keep "S&P BBB- (20 Aug 2024)" plus Moody's negative outlook (Forbes quoting Moody's).
2. **calcs.py traceability for gate 3:**
   - The r3 block still prints "full 115.61 − 2.75" (2 dp) for every rate, so the slides' 4-dp full prices (113.3656, 111.8657, 115.6082 … 115.1049, 128.1792) are not printed anywhere. Print them to 4 dp with the 2.7535 accrued, so builders pull numbers from calcs as CLAUDE.md requires.
   - Tag the remaining old lines "[superseded]": "B to call @3.50% −13.3", "tender ex early premium −12.3" and "issuer call value implied 14.15 / 13.07".
   - The plan's response says 110.66 is "verified in calcs", but calcs does not print it. Add one line.
3. **Lucidity soft spots:**
   - 25: add "30/360 = every month counts as 30 days, a year as 360".
   - 18 (or 31): add "par = 100% of face value".
   - 138: add "adjusted EBIT = profit before interest and tax, excluding one-off (exceptional) items".
4. **31 and 53:** put the half-bp footnote ("half basis points rounded down; 8.125 − 3.15 = 4.975 → 497") where these numbers first appear, not only on 55.
5. **57 title (18 words):** trim to "Test 1: the same bond's spread fell from 497bp at issue to 199bp in Feb 2015".
6. **answers.md header:** "aligned with storyline round 6" → "round 7".
7. **73–79:** show DFs to 6 dp as on 71, 72 and 82, so every PV row reproduces exactly (e.g. 74: 108.125 × 0.9913 = 107.18 vs 107.19 shown). Also add "(rows rounded)" to 71 and 72 for consistency.
8. **answers.md line 88 (checking-only):** "different date" does not explain the teaching note's US$25.92: 30/360 to 15 Mar gives US$27.08. Say "different date and day count".
9. **138 (optional):** add the Q2 FY27 wholesale update (82,400, +24.5%, against a cyber-hit base) once its primary release is logged, labelled "sales only; results due November".
10. **125:** "112.35 − 111.28" gives 1.07 on a calculator from the shown figures, while 1.08 comes from 112.3514 − 111.276. Show the unrounded pair once.

## Strongest parts
- Q2 reproduces JLR's real offer price to the cent, works all ten rates on their own slides, and now every subtraction reproduces exactly.
- Q3 shows that new debt at market rates has zero NPV, then values three baselines before and after tax with correct UK tax timing.
- Q1 tests "credit, not Treasuries" four ways instead of asserting it.
