NOT READY. Grade estimate A− on content. Both r8 blocking items are fixed. Slides 22 and 70 now agree, and calcs.py's new "FINAL SLIDE DISPLAYS" block prints slides 29, 30, 44–47, 85, 108 and 70 exactly as the plan shows them. But one r8 non-blocking fix added a new factual error. **Slide 7** now says "AA- is one notch below AA, which is one notch below the top grade AAA". AA is **two** notches below AAA (AAA → AA+ → AA), and the project's own source for slide 131 says so ("chopped an AAA-rated sovereign credit rating by two notches"). It is a one-line fix. With it made, I expect READY at A−.

# UK Gilts: strict review of the gate 1 storyline, round 9

Reviewed: `review/gilts/01-storyline.md` (139 slides, round 9). Checked against:
- the rubric
- the grading brief
- `case-layout.txt`
- `UK Gilts.xlsx.md`
- `exhibits.csv`
- CLAUDE.md
- DESIGN.md
- PROGRESS.md: user feedback word for word and the decisions, including "Mix (Recommended)" and the slide-56 split note

I ran `python3 work/gilts/calcs.py` live on 2026-10-30. It exits 0 and every assert passes. I read `answers.md`, `sources.md` and `sources_research.md`. I skimmed the G1 NESA benchmark (268 slides, one step per slide). I used `UK Gilts Questions.docx.md` only to check answers; the plan does not cite, quote or mention it.

I recomputed every number listed below in my own script (`/tmp/claude-0/-home-claude/535c8268-cdcd-5ed5-9093-f9b3d4b34d6b/scratchpad/v9.py`), from the numbers as printed in the plan. I did not count the "Response to the strict review" sections as evidence.

## 0. Round 8 items: fixed or not

| r8 item | Status | Evidence |
|---|---|---|
| **B1 · slide 70: "3bp" from 3.39 vs 3.37** | **FIXED** | It now reads "only about 3bp (4½% 2042 at 3.393% vs 4% 2060 at 3.365%, DMO: 2.8bp)". 3.393 − 3.365 = 2.8bp ✓. Both match sources.md (DMO 2014 reference prices: `Yield (%) 3.393`, `Yield (%) 3.365`). calcs.py prints `70: … 3.365% = 2.8bp` ✓. |
| B1 sub-point: slide 22 shows the 4% 2060 as 3.36% | **FIXED** | 22 now has "~50-year 4.24% vs 3.37%", the same as 70 and 136. "About a point above" still holds: 4.24 − 3.37 = 0.87. |
| **B2 · calcs.py does not print the displays on 29, 45, 47, 85 and 108** | **FIXED** | The new `final_displays()` block prints each one. I compared each against the plan digit for digit: **29** `4.75 x 30.9642 = 147.08 (+100 = 247.08)` and `4.75 x 24.2974 = 115.41 (+100 = 215.41)` ✓. **30** 3.66% and 3.15% ✓. **44** `2.75 x 4.579707 = 12.5942; + 100/1.0300^5 = 86.2609; = 98.8551` ✓. **45** `5.25 x 1.948985 = 10.2322; … 96.6088; = 106.8410 … (exact 106.8409)` ✓. **46** `3.75 x 8.094769 = 30.3554; … 67.2971; = 97.6525` ✓. **47** `4.5 x 16.560615 = 74.5228; + 100/1.0436^30 = 27.7957; = 102.3185` ✓. **85**: all nine rows, −1.0075 / −2.0199 / −2.9596 / −4.4199 / −6.2069 / −7.5943 / −12.4782 / −15.0132 / −16.8475 ✓. **108**: 8.094769 → 7.706757; 67.2971 → 61.1579; 30.3554 → 97.6525 → 28.9003 → 90.0582; 64.7582 → 132.0553 → 61.6541 → 122.8120; −9.12 / −7.78 / −7.00% ✓. Every line also reproduces in my script. Results are asserted (lines 470, 477, 485, 493). |
| B2 sub-point: remove `90.0583` and the superseded money line | **FIXED** | Neither is printed any more. |
| B2 sub-point: print `100/3.597677 = 27.7957` (slide 47) | **Partly** | calcs.py prints `100/1.0436^30 = 27.7957`, which is the same number by a different route. The value 3.597677 that 47 shows in brackets is printed nowhere (I get 1.0436³⁰ = 3.5976765 → 3.597677 ✓). Non-blocking 2. |
| B2 sub-point: remove the old conflicting lines | **Mostly** | The lines r8 named are gone. The author note says the "1.9490" and "100/3.5977" versions were removed, but they are still printed in the older 2-dp "Annuity form" block (output lines 100 and 106). Those two lines are internally consistent at 2 dp. Four older 2-dp lines are off by one in the last digit (5y `12.59 + 86.26 = 98.86`; 10y `30.36 + 67.30 = 97.65`; −1% 5y `12.96 + 90.57 = 103.54`; −1% 20y `68.28 + 51.49 = 119.76`). The `[SUPERSEDED]` 4% 2060 line (−52.8%, +237bp) is still printed too. None of these is a plan display, and the gaps are last-digit rounding, so this is non-blocking 1. Still, delete them before gate 3 so builders cannot pick them up. |
| r8 nb 1 (46 uses 8.094769) | Done ✓ | See B2. |
| r8 nb 2 (47 factor 16.560615) | Done ✓ | 4.50 × 16.560615 = 74.5228 ✓. |
| r8 nb 3 (111: 1.0824 = (1+y)²) | Done ✓ | 1.0404² = 1.082432 ✓. |
| r8 nb 4 (46: 67.2971 = 100/1.0404¹⁰) | Done ✓ | 67.29713 ✓. |
| r8 nb 5 (134: why a ~20% fall) | Done, wording repeats | The physics is right (ModD near 20 needs a low coupon and a low yield). But "coupon effect (slide 108)" now appears twice in one line (non-blocking 4). |
| r8 nb 6 (74: part (b) 96–108) | Done ✓ | |
| r8 nb 7 (56 at 18pt; split only if needed) | Done ✓ | Logged in PROGRESS "Decisions made" as still ONE comparison. |
| r8 nb 8 (7: AA- one notch below AA) | **Done, but it adds a new error (B1 below)** | "…which is one notch below the top grade AAA" is wrong: AA is two notches below AAA. |
| r8 nb 9 (137 re-check) | Done ✓ | "(provisional date) … (re-check before submission)". |

**Did the fixes add new errors?** One: slide 7 (B1). Slides 22, 29, 30, 44–47, 70, 85 and 108 all re-derive cleanly from their printed inputs, and they match calcs.py.

## 1. Verdict
**NOT READY. Grade estimate A− on content.** H7 fails on slide 7. A plain-words definition of the rating scale is wrong, and it contradicts the project's own source for slide 131. That is the only failure. Every other hard requirement passes, every quality score is ≥ 4, and all 56 numbers I checked reproduce.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover with placeholder); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37; Q2 38–56; Q3 57–72; Q4 73–127; Epilogue 128–138; team slide 139 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (nine gilts, "Source: IMD research"). It is rebuilt natively on 18, with "?" for the blanks; its values match `exhibits.csv` row by row. What it shows: 18–19. Key numbers and trends: 19–21. Meaning: 22 (against the DMO's 9 May 2014 data). Implication: 23–24. |
| H3 Every question | PASS | Stated and broken into parts: 26, 39, 58, 74. Theory: 28, 32, 34–35, 44, 49–50, 62, 68, 96, 98, 110–112. Evidence: Q1 36; Q2 22; Q3 67, 70; Q4 134, 136. Assumptions: 28, 40, 55–56, 66, 74. Alternatives: 31, 44, 55–56, 108, 109–124, 126. Every calculation is shown as formula → numbers → result on the slide; there is no "see Excel". |
| H4 External, sourced, current | PASS | All 10 facts I checked (section 4b) have a URL, an access date and an exact quote that supports them. They are current to 27–29 Oct 2026, and secondary sources are labelled (7, 108, 131, 134 LBC, 136, 137). |
| H5 No teaching note | PASS | I grepped the plan for "teaching", "Questions.docx" and "answer key": no hits. The question wording is the assigned questions. |
| H6 Titles | PASS | Every content title states a finding. The longest (22, 66, 70) are about 95–98 characters, which fits in two lines. |
| H7 Finance correct | **FAIL (slide 7 only)** | "AA- is one notch below AA, which is one notch below the top grade AAA." The S&P/Fitch scale is AAA, AA+, AA, AA-, so AA is two notches below AAA and AA- is three. sources.md 4a quotes Euronews: "reduced to AA … by two notches in one move", which slide 131 relies on. The reader would learn the scale wrong, and slides 7 and 131 contradict each other. All the bond maths is correct: YTM as IRR and its three conditions; reinvestment risk; current yield; price = PV; the premium/discount rule; pull to par; clean = full on a coupon date; bracketing, interpolation and the reprice check; the semi-annual convention; bootstrapping (spot above YTM on a rising curve); no-arbitrage forwards; the three curve theories; PVBP; Macaulay and modified duration, including the CFA closed form; analytic and price-based convexity; duration + convexity; up/down asymmetry; the coupon effect. |
| H8 Numbers right | PASS | 56 numbers checked (4a); all reproduce within the last shown digit. Formats follow the rules: money 1 dp, prices 2 dp, yields 2 dp, bp whole. Extra decimals appear only in intermediate steps and in DMO 3-dp quotes. PVBP in £ thousand is a logged decision. |
| H9 User decisions | PASS | Annual coupons plus exactly one semi-annual comparison: 55 is the worked example and 56 the table with every bond's numbers plugged in. The possible two-slide split is logged as still ONE comparison. No case bond gets a real name (23); real gilts appear only as context (4, 22, 70, 108, 136). "Mix": PVBP gets one slide per bond (86–94, summary 95), and so does −1% (115–123, summary 124). Every other repeat has its own slide (41–53, 75–83, 97–106). |
| H10 Known traps | PASS | Annual coupons are stated (24, 40) and tested (55–56). Prices are per £100 (5, 15, 40). Duration and convexity explain the +1% shift (96–114). |
| H11 Lucidity | PASS (one slide to fix) | Every term has a "Plain:" line where it first appears. Formulas come in words first (29, 32, 44, 66, 75, 86, 102, 111, 112). Numbers are labelled, every calculation slide has a so-what, concepts come before use, and titles are in everyday language. The only slide that would mislead (rather than lose) the reader is 7 (B1). |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Goes well past the four questions and tests its claims. Examples: reinvestment risk, three yield measures, bootstrap plus forwards with a hindsight test, PVBP per bond, duration two ways, convexity two ways, asymmetry, the coupon effect, the exhibit vs the real 2014 curve, and the 4% 2060 with the instant shock separated out. |
| Q2 Logic and flow | 4 | A clean arc with correct cross-references (27→52, 31→51, 53→86/106/112/114, 70→108–110, 134→108). Q4 is long (55 slides), but each slide earns its place under "one slide per repeat". |
| Q3 Evidence | 5 | Primary ONS, DMO, BoE, US Treasury and Bundesbank data for nearly every fact; secondary sources labelled. |
| Q4 Lucidity | 4 | Words before numbers, labels and a so-what throughout. Not 5: slide 7's scale error, and 56 is still very dense. |
| Q5 Calculations | 4 | Complete and traceable. Every plan display is printed by calcs.py and reproduces. Not 5: calcs.py still prints old 2-dp lines that disagree in the last digit, plus one superseded line. |
| Q6 Overview and epilogue | 5 | Current to 27–29 Oct 2026, and tied back to Q4 through 2022 (134), the real 4% 2060 (136) and today's curve (137). |

## 4a. Number spot-check (56 numbers, recomputed from the printed inputs)

| # | Number (plan) | Slide | My result / source | Match |
|---|---|---|---|---|
| 1 | 4.75 × 30.9642 = 147.08 (factor at 4.3751%) | 29 | factor 30.964174; 147.080 | yes |
| 2 | 4.75 × 24.2974 = 115.41 | 29 | 24.297370; 115.413 | yes |
| 3 | 3.66%; 0% case 3.15% | 30 | 3.6617%; 3.1470% | yes |
| 4 | 3.17%; 4.59% | 31 | 3.1707%; 4.5909% | yes |
| 5 | PVs 2.6699 / 2.5921 / 2.5166 / 2.4433 / 88.6331 → 98.8551 | 42–43 | identical; sum 98.8550 (exact 98.85507) | yes |
| 6 | 2.75 × 4.579707 = 12.5942; 86.2609; 98.8551 | 44 | 12.594194; 86.260878; 98.8551 | yes |
| 7 | 5.25 × 1.948985 = 10.2322; 96.6088; 106.8410 (106.8409) | 45 | 10.232171; 96.608766; 106.8410; 106.840938 | yes |
| 8 | 3.75 × 8.094769 = 30.3554; 67.2971; 97.6525 | 46 | 30.355384; 67.297133; 97.6525 | yes |
| 9 | 4.50 × 16.560615 = 74.5228; 3.597677; 27.7957; 102.3185 | 47 | 74.522767; 3.5976765; 27.795714; 102.3185 | yes |
| 10 | 1 + y = 1.007317 | 48 | 1.0073171 | yes |
| 11 | 107.21 / 104.24 → 2.064%; exact 2.063% | 49–50 | 2.0640%; 2.0628% | yes |
| 12 | 112.46 / 106.00 → 3.550%; 3.541% | 51 | 3.5495%; 3.5406% | yes |
| 13 | 110.19 / 96.88 → 4.395%; 4.375%; "2bp too high" | 52 | 4.3952%; 4.3751% | yes |
| 14 | 100.00 / 81.74 → 4.276%; 4.244519% | 53 | 4.2760%; 4.2445188% | yes |
| 15 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | 2.6024 / 2.5799 / 2.5577 / 99.1300; 106.8699 | yes |
| 16 | semi-annual yields 0.7362 / 2.0743 / 3.5512 / 4.3775 / 4.2437% | 56 | 0.73619 / 2.07433 / 3.55118 / 4.37752 / 4.24374 | yes |
| 17 | five "check" rows reprice to 102.50 / 107.02 / 108.91 / 104.93 / 94.96 | 56 | 102.4999 / 107.0201 / 108.9099 / 104.9303 / 94.9608 | yes |
| 18 | semi-annual 2y / 5y / 10y / 30y prices: 106.87 / 98.85 / 97.63 / 102.33 | 56 | 106.8699 / 98.8472 / 97.6336 / 102.3306 | yes |
| 19 | 106.84 − 5.21 = 101.63; 1.0356; 1.77% | 64 | 5.2119; 1.035619; 1.765% | yes |
| 20 | 4.4673 + 4.3452; 98.2075; 1.0641; 2.09% | 65 | 4.467313 / 4.345182; 1.064074; 2.0917% | yes |
| 21 | 1y1y 2.81%; 2y1y 2.75% | 66 | 2.8106%; 2.7466% | yes |
| 22 | +331 / +34 / −2 / −12bp | 61 | 331 / 33.5 / −1.5 / −11.5 (exact); −2 and −12 from the 2-dp yields | yes |
| 23 | 1y +1%: 0.982978, 1.017317 → 3.1947 + 98.2978 = 101.4925; −0.98% | 75 | identical; −0.983% | yes |
| 24 | 5y +1%: 4.451822, 1.216653 → 12.2425 + 82.1927 = 94.4352 | 78 | identical | yes |
| 25 | 7y +1%: 29.4198 + 73.2833 = 102.7031 | 79 | 29.41978 + 73.28332 | yes |
| 26 | 10y +1%: 28.9003 + 61.1579 = 90.0582 | 80 | 28.900339 + 61.157928 | yes |
| 27 | 20y +1%: 12.075203, 2.849443 → 92.4518; −11.89% | 81 | identical; −11.892% | yes |
| 28 | 30y +1%: 14.761224, 4.789309 → 87.3053 | 82 | identical | yes |
| 29 | 50y +1%: 17.587377, 12.881619 → 78.1125; −17.74% | 83 | identical; −17.742% | yes |
| 30 | "about twice / three / 4½ / 8 / 12 / 18 times" the 1-year | 76–83 | 1.93 / 2.83 / 4.56 / 7.9 / 12.1 / 18.1 | yes |
| 31 | 85 rows −1.0075 … −16.8475 | 85 | each subtraction reproduces | yes |
| 32 | 50y PVBP 95.1580 / 94.7626 → 0.1977 → £197.7k | 86 | 95.158036 / 94.762630 | yes |
| 33 | 1y PVBP (102.5102 − 102.4898)/2 = 0.0102 | 87 | 0.010176 | yes |
| 34 | 7y / 20y / 30y PVBP 0.0644 / 0.1358 / 0.1684 | 91, 93, 94 | 0.064375 / 0.135794 / 0.168358 | yes |
| 35 | "19 times", "13 times", "about 8 times" | 95, 93, 92 | 19.4; 13.3; 7.8 | yes |
| 36 | MacD 4.74; 90% in year 5; 4.74/1.03 = 4.60 | 97–98 | 4.7377; 0.8966; 4.6019 | yes |
| 37 | 5.1602 + 203.3615 = 208.52 → 1.95 → 1.92 | 100 | 5.160212 / 203.361452; 1.9517; 1.9167 | yes |
| 38 | 307.92 → 2.88 → 2.82 | 101 | 307.9219; 2.8772; 2.8219 | yes |
| 39 | 29.2437 − 1.137563/0.049195 = 29.2437 − 23.1235 = 6.12; 5.91 | 102 | 29.243726; 1.137563; 0.049195; 23.123549; 5.9108 | yes |
| 40 | 10 / 20 / 30 / 50y closed form 8.50 / 13.51 / 17.17 / 21.70 | 103–106 | 17.252614; 10.349056; 6.764074; 2.856567 → 8.4999 / 13.5076 / 17.1717 / 21.7032 | yes |
| 41 | ModD 8.17 / 12.94 / 16.45 / 20.82 | 103–106 | 8.1699 / 12.9431 / 16.4527 / 20.8173 | yes |
| 42 | weight 0.137 in the final £104 | 106 | 0.13703 | yes |
| 43 | 0% / 3.75% / 8% coupon: −9.12 / −7.78 / −7.00% | 108 | −9.1225 / −7.7769 / −6.9996% | yes |
| 44 | 8,620.9 ÷ (97.65 × 1.0824) = 81.56; 1.0824 = 1.0404² | 111 | 81.5629; 1.082432; analytic 81.558 | yes |
| 45 | P₋ 95.956890, P₊ 93.979753; 0.016643/0.00002374 = 701.05; 701.03; 8.6× | 112 | 95.956890 / 93.979753; 701.053; 701.026; 8.595 | yes |
| 46 | −8.17 + 0.41 = −7.76% | 113 | −7.762 | yes |
| 47 | −20.82 + 3.51 = −17.31; 21.30; 711.82; −17.74% | 114 | −17.315; 21.3037; 711.8155; −17.741 | yes |
| 48 | 4.0 × 24.576771 + 100/4.935672 = 118.5678; +24.86% | 115 | 98.307084 + 20.260666; 4.9356718; +24.861% | yes |
| 49 | 1y −1%: 3.2587 + 100.2690 = 103.5277; +1.00% | 116 | 3.258743 / 100.269022; +1.003% | yes |
| 50 | 20y −1%: 68.2783 + 51.4851 = 119.7634; +14.14% | 122 | 68.278276 / 1.9423114; +14.136% | yes |
| 51 | +3.5 points for 21× the risk | 125 | 3.51; 20.82/0.99 = 21.03 | yes |
| 52 | gilt − Bund 127bp then, 191bp now | 13 | 2.77 − 1.50; 5.30 − 3.39 | yes |
| 53 | real +240bp vs exhibit +331bp | 22 | 2.803 − 0.402 = 240.1; 4.04 − 0.73 | yes |
| 54 | 3.393% vs 3.365% = 2.8bp ("about 3bp") | 70 | 2.8 | yes |
| 55 | 4% 2060: +229bp; −51.0%; −34.4%; −36.4% instant | 136 | 5.658 − 3.365; 22.24 × 0.02293 = 51.0%; 75.28/114.76 − 1 = −34.4%; calcs 72.98 → −36.4% | yes |
| 56 | AA "one notch below the top grade AAA" | **7** | **The scale is AAA → AA+ → AA, two notches; sources 4a: "by two notches in one move"** | **no (B1)** |

## 4b. External fact spot-check (10 facts)

| Slide | Claim | Evidence in sources files | Supported? |
|---|---|---|---|
| 9 | £1,365bn (2014) → £2,817bn (2026), same basis | 7a `1,365.02` gross nominal; 7b `£2,144` + `£673`; 7c same-basis verdict | yes (DMO, primary) |
| 11 | 29% / 27% / 26%, "over 80%" | `29.2%`, `26.6%`, `26.4%` (DMO GAR 2013-14) = 82.2%; "end-2014" footnoted | yes |
| 12 | 35.6 / 78.6 / 93.2% of GDP; 2.9 / 5.6 / 4.4% | ONS HF6X and J5IJ rows 1a–1f | yes (primary) |
| 13 | 2.77 / 2.62 / 1.50% (May 2014); 5.30 / 4.98 / 3.39% now | BoE `09 May 2014,2.7654`, `27 Oct 2026,5.3046`; US Treasury CSV rows; Bundesbank `1,50`, `3,39` | yes (primary) |
| 36 | 4.75% → 5.75% → 0.50% | D2 `03 Aug 06 4.75`, `05 Jul 07 5.75`, `05 Mar 09 0.50` | yes |
| 108 | 0½% 2061 at £23.41, ModD 26.75; 4% 2060 at 15.73 | sources_research l.206 (giltsyield, secondary, labelled); sources.md 8a | yes |
| 130 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a `04 Aug 2020,0.1239`, series from `01 Nov 1993` | yes |
| 131 | S&P cut AAA → AA, June 2016 | 4a Euronews (secondary, labelled), "by two notches" | yes, but it contradicts slide 7 |
| 133 | BoE bought £19.3bn, 28 Sep – 14 Oct 2022 | E rows (BoE notices of Sep 2022, Oct 2022, Jan 2023) | yes |
| 135 | reinvestment stopped Feb 2022, sales from Nov 2022; £895bn → £488bn | 6a, 6b; Governor's letter of 17 Sep 2026 | yes |

## 5. Blocking items (exact fixes)

**B1 · H7 / H11 · slide 7: the rating-scale line is wrong.**
The plan says: "Plain: AA- is one notch below AA, which is one notch below the top grade AAA." On the S&P/Fitch scale the order is AAA, AA+, AA, AA-. So AA is two notches below AAA, and AA- is three. The project's own source for slide 131 (sources.md 4a, Euronews) says the 2016 cut from AAA to AA was "by two notches in one move". As written, slide 7 teaches the reader the scale wrongly and contradicts slide 131. This came in through r8 non-blocking 8.
**Fix (slide 7):** "Plain: the agencies' scale runs AAA (top), AA+, AA, AA-, …; so AA- is one notch below AA and three below AAA." Optionally, slide 131 can add "(two notches)", which its source supports.

## 6. Non-blocking improvements (most valuable first)
1. **calcs.py: delete the leftover lines before gate 3.** Remove the 2-dp "Annuity form" block (output lines 99–107), the 2-dp "-1% per bond" block (lines 241–250), the 2-dp semi-annual block (251–260) and the `[SUPERSEDED]` 4% 2060 line (194). The 4-dp blocks now cover every slide. Four of the old lines do not add up in the last digit (98.86, 97.65, 103.54, 119.76), and a builder working from calcs.py could pick them up. Correct the round-9 author note too: the "1.9490" and "100/3.5977" lines are still printed.
2. **calcs.py, slide 47:** add `(= 100/3.597677)` to the 47 line, so every number on that slide is printed.
3. **Plan line 9:** it says the `r5_displays` block prints every display. Slides 29, 30, 44–47, 70, 85 and 108 now come from `final_displays()`. Name both blocks.
4. **Slide 134:** "coupon effect (slide 108)" appears twice in one line. Merge the two clauses: "a 20% fall per 1% rise means a modified duration near 20; a low coupon and 2022's lower starting yield produce that (slide 108), which explains the gap with our −11.89%".
5. **Slide 56:** at build, test the nine-row table at 18pt first; use the logged two-slide split only if it does not fit.
6. **Slide 66:** "in words:" follows a "Plain:" sentence in lower case; capitalise it.
7. **Slide 137:** keep "re-check before submission" as a build task (the 5 Nov 2026 MPC date is provisional).
