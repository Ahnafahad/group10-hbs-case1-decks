NOT READY. Grade estimate A− on content. Both r6 blocking items are fixed. But two of the round-7 "non-blocking" edits added new display errors. **Slide 108**: the four 4-dp prices do not come out of the inputs printed beside them; they are off by 0.002–0.003. **Slide 85**: it now shows five gilts' +1% prices on a different 4-dp basis from slides 75–83 (e.g. 78.1122 vs 78.1125), with no note. This is the same contradiction r6 blocked on slide 114. Both are one-line fixes. With them made, I expect READY at A−.

# UK Gilts: strict review of the gate 1 storyline, round 7

Reviewed: `review/gilts/01-storyline.md` (139 slides, round 7). Checked against: the rubric; the grading brief; `case-layout.txt`; `UK Gilts.xlsx.md`; CLAUDE.md; DESIGN.md; and PROGRESS.md, including the 2026-10-30 "Mix (Recommended)" choice and the logged 4-dp/6-dp display decision. I ran `python3 work/gilts/calcs.py` live on 2026-10-30; it runs clean and every assert passes. I also checked `exhibits.csv`, `answers.md`, `sources.md` and `sources_research.md`, and skimmed the G1 NESA benchmark (268 slides). I used `UK Gilts Questions.docx.md` only to check answers, and all of them match (Q2 prices and yields, the semi-annual row, the Q4 % changes). I recomputed every display I list below in my own Python, **from the numbers as printed in the plan**. I did not count the "Response to the strict review" sections as evidence.

## 0. Round 6 blocking items: fixed or not

| r6 item | Status | Evidence (round 7 plan) |
|---|---|---|
| **B1 · slide 29: factor labelled "at 4.38%" but taken at 4.3751%** | **FIXED** | It now reads "at the exact YTM 4.3751% (slide 52; 4.38% rounded), 4.75 × 30.9641 = 147.08 (+100 = 247.08)". The factor at 4.3751% is 30.964174, so 30.9642 would be exact; 30.9641 is the factor at 4.375092%. That is a last-digit difference, and 4.75 × either = 147.08. It reproduces. (Polish: print 30.9642; non-blocking 4.) |
| **B2(a) · slide 53: state the 6-dp yield** | **FIXED** | "exact 4.2445% (4.244519% to 6 dp, used on slides 86, 106, 112 and 114)". My solve: 4.2445188%. ✓ |
| **B2(b) · slide 112** | **FIXED** | P₋ at 4.194519% = 95.956890 and P₊ at 4.294519% = 93.979753. I get 95.956890 / 93.979753. The sum is 0.016643, and ÷ 0.00002374 = 701.05. ✓ |
| **B2(c) · slide 86** | **FIXED** | At 4.234519%: 95.1580; at 4.254519%: 94.7626. I get 95.158036 / 94.762630. Half the gap is 0.1977 → £197.7 thousand. ✓ |
| **B2(d) · slide 114** | **FIXED** | The prices are labelled as at the exact yield ∓ 1% (3.244519% / 5.244519%). I get 118.567225 / 78.112241. 118.5672 + 78.1122 − 189.92 = 6.7594, and ÷ 0.009496 = 711.8155 → 711.82 ✓. The tie-note to slides 115 and 83 is present. −21.30% + 3.56% = −17.74% ✓. |
| B2 · add the lines to `r5_displays` | **FIXED** | calcs.py prints "50y exact yield 4.244519%", the three price pairs and "6.7594 / 0.009496 = 711.82". |
| r6 non-blocking 1 (85 rows to 4 dp) | **Done, but it adds a new error (B2 below)** | Every row now subtracts correctly. But five of the nine new-price figures differ from those on 75–83. |
| r6 non-blocking 2 (42–43 PVs to 4 dp) | Done ✓ | 2.6699 + 2.5921 + 2.5166 + 2.4433 + 88.6331 = 98.8550 → 98.86 ✓ |
| r6 non-blocking 3 (108 4-dp prices; 47 27.7957) | **108 done wrongly (B1 below)**; 47 ✓ | 108's 4-dp prices do not reproduce from the factors printed beside them. |
| r6 non-blocking 4–10 | Done ✓ | 102–106 print the exact yields (3.540609%, 4.375092%, 4.244519%); 76–83 and 116–123 carry the formula line; 56 has a layout note; 30 shows the 0% case (195 → 3.15% ✓); 137 says "(provisional date)"; 22 has the order fixed; 135 is shortened; 56 says "about 1bp". |

**Did the fixes add new errors?** Yes, two: slide 108 (B1) and slide 85 (B2). Both came from the non-blocking edits, not from the r6 blocking fixes.

## 1. Verdict
**NOT READY. Grade estimate A− on content.** H8 fails on slides 108 and 85. Every other hard requirement passes, and every quality score is ≥ 4.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover placeholder); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37; Q2 38–56; Q3 57–72; Q4 73–127; Epilogue 128–138; team slide 139 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (9 gilts, source IMD research). It is rebuilt natively on 18 with "?" for the blanks; the values match `exhibits.csv`. What it shows: 18–19. Key numbers: 19–21. Meaning: 22 (vs DMO 9 May 2014). Implication: 23–24. |
| H3 Every question | PASS | Stated and split into parts: 26, 39, 58, 74. Theory: 28, 32, 34–35, 44, 49–50, 62, 68, 96, 98, 110–112. Evidence: 36; 22; 67, 70; 134, 136. Assumptions: 28, 40, 55–56, 66, 74. Alternatives: 31, 44, 55–56, 108, 109–124, 126. Every calculation has its steps on the slide. |
| H4 External, sourced, current | PASS | All 10 facts I checked (section 4b) are backed by exact quotes with URL and access date. Current to 27–29 Oct 2026. Secondary sources are labelled (7, 108, 131, 134 LBC, 136, 137). |
| H5 No teaching note | PASS | No citation, quote or reference. 22 calls the data "a classroom data set". |
| H6 Titles | PASS | Every content title states a finding; the longest (22, 85, 66) are about 95–100 characters and fit in 2 lines at headline size. |
| H7 Finance correct | PASS | YTM as IRR and its three conditions (28); reinvestment risk (29–30); current yield (31); price = PV (32); the premium/discount rule (34); pull to par (35); clean = full on a coupon date (40); bracketing and interpolation with reprice (49–53); the semi-annual convention (55–56); bootstrapping, with spot above YTM on a rising curve (64–65, 71); no-arbitrage forwards (66); the three term-structure theories (68); PVBP as half the ±1bp gap (86); Macaulay/modified duration and the CFA closed form (96–106); analytic and price-based convexity (111–112); duration + convexity (113–114); asymmetry (115–124); coupon effect (108); the real 4% 2060 decomposition (136). No conceptual error. |
| H8 Numbers right | **FAIL** | 44 numbers checked (section 4a); 42 match within the last shown digit. **108**: the 4-dp prices do not reproduce from the inputs printed with them (B1). **85**: the +1% prices on five rows contradict 75, 79, 80, 81 and 83 in the 4th decimal (B2). Formats otherwise follow the rules. |
| H9 User decisions | PASS | Annual coupons plus exactly one semi-annual comparison (55 worked, 56 the comparison with every bond's numbers plugged in). A split of 56 over two facing slides "if it does not fit" is still one comparison, but log it as a decision (non-blocking 3). No case bond is given a real name (23). "Mix": PVBP one slide per bond (86–94 + 95); −1% one slide per bond (115–123 + 124); every other repeat has its own slide (41–53, 75–83, 97–106). |
| H10 Known traps | PASS | Annual coupons are stated (24, 40) and tested (55–56); prices per £100 (5, 15, 40); duration and convexity explain the +1% shift (96–114). |
| H11 Lucidity | PASS | Every term gets a "Plain:" line where it first appears; formulas come in words first (29, 32, 44, 66, 75, 86, 102, 111, 112); numbers are labelled; every calculation slide has a so-what; concepts come before use; titles are in everyday language. 76–83 and 116–123 now carry the formula line. No slide would lose this reader. 56 stays the densest slide; the layout note handles it. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Far beyond the four questions, and claims are tested: reinvestment risk, three yield measures, bootstrap and forwards with a hindsight test, PVBP per bond, duration two ways, convexity two ways, asymmetry, coupon effect, exhibit vs the real 2014 curve, and the real 4% 2060 test with the instant shock separated out. |
| Q2 Logic and flow | 4 | A clean arc, and cross-references are correct (31→51, 53→86/106/112/114, 74's part ranges, 134→108). Q4 is long (55 slides) but each slide earns its place under the "one slide per repeat" rule. |
| Q3 Evidence | 5 | Primary ONS, DMO, BoE, US Treasury and Bundesbank data for almost every fact; secondary sources labelled. |
| Q4 Lucidity | 4 | Words before numbers, labels and so-whats throughout. Not 5: slide 56's density, and the 4-dp displays need care to stay readable. |
| Q5 Calculations | 4 | Complete and traceable; about 70 per-bond displays reproduce. Docked for B1 and B2. |
| Q6 Overview and epilogue | 5 | Current to 27–29 Oct 2026; tied back to Q4 through 2022 (134), the real 4% 2060 (136) and today's curve (137). |

## 4a. Number spot-check (44 numbers; my recomputation from the printed inputs)

| # | Number | Slide | Source / my result | Match |
|---|---|---|---|---|
| 1 | 4.75 × 30.9641 = 147.08 at 4.3751% | 29 | factor 30.964174 (30.9642); product 147.08 | yes (last digit) |
| 2 | 4.75 × 24.2974 = 115.41 at 2% | 29 | 24.29737 | yes |
| 3 | 3.66%; 0% case 195 → 3.15% | 30 | 3.6617%; 3.1470% | yes |
| 4 | 3.25/102.50 = 3.17%; 5.00/108.91 = 4.59% | 31 | 3.1707; 4.5909 | yes |
| 5 | PVs 2.6699 … 88.6331 → 98.8551 | 42–43 | sum 98.8550; exact 98.85510 | yes |
| 6 | 2.75 × 4.5797 = 12.5942; + 86.2609 = 98.8551 | 44 | 12.594175; 98.8551 | yes |
| 7 | 5.25 × 1.9490 + 96.61 = 106.84 | 45 | 106.8423 | yes |
| 8 | 3.75 × 8.0948 = 30.3555; + 67.2971 = 97.6526 | 46 | exact | yes |
| 9 | 4.50 × 16.5606 = 74.5228; 100/3.5977 = 27.7957; 102.3185 | 47 | 74.5227(7); 100/3.5977 = 27.7955 (exact factor 3.597677 → 27.7957) | yes (last digit; non-blocking 2) |
| 10 | 103.25/102.50 = 1.007317 | 48 | 1.0073171 | yes |
| 11 | 107.21 / 104.24; 2.064% | 49–50 | 107.2097 / 104.2429; 2.0640% | yes |
| 12 | 112.46 / 106.00; 3.550% | 51 | 112.4606 / 106.0021; 3.5495% | yes |
| 13 | 110.19 / 96.88; 4.395%; "2bp too high" | 52 | 110.1927 / 96.8844; 4.3952 vs 4.3751 | yes |
| 14 | 100.00 / 81.74; 4.276%; exact 4.244519% | 53 | 100.0000 / 81.7441; 4.2760; 4.2445188% | yes |
| 15 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | 2.6024 / 2.5799 / 2.5577 / 99.1300 | yes |
| 16 | semi 1-year: 3.2321 + 99.2678 = 102.50 | 56 | 102.49994 | yes |
| 17 | semi 10-year: 30.5998 + 67.0337 = 97.63 | 56 | 97.6336 | yes |
| 18 | semi 50-year: 82.7109 + 12.2499 = 94.96 | 56 | 94.9608 | yes |
| 19 | 106.84 − 5.21 = 101.63; 1.0356; 1.77% | 64 | 101.628; 1.03562; 1.765% | yes |
| 20 | 107.02 − 4.4673 − 4.3452 = 98.2075; 1.0641; 2.09% | 65 | 4.467313 / 4.345182; 2.0917% | yes |
| 21 | 1.035629/1.007317 − 1 = 2.81%; 1.064074/1.035629 − 1 = 2.75% | 66 | 2.8106%; 2.7466% | yes |
| 22 | +331 / +34 / −2 / −12bp | 61 | calcs | yes |
| 23 | 1-year +1%: 3.1947 + 98.2978 = 101.4925 | 75 | 101.49246 | yes |
| 24 | 5-year +1%: 12.2425 + 82.1927 = 94.4352 | 78 | 94.43522 | yes |
| 25 | 10-year +1%: 28.9003 + 61.1579 = 90.0582 | 80 | 90.05828 | yes |
| 26 | 50-year +1%: 70.3495 + 7.7630 = 78.1125; −17.74% | 83 | 78.11251 | yes |
| 27 | 85 rows: −1.0076 / −2.0200 / … / −16.8478 | 85 | subtractions reproduce (2y 2.0199, 30y 15.0132, last digit); **but 101.4924, 102.7030, 90.0583, 92.4519, 78.1122 ≠ 75/79/80/81/83's 101.4925, 102.7031, 90.0582, 92.4518, 78.1125** | **no (B2)** |
| 28 | 50-year PVBP 95.1580 / 94.7626 → 0.1977 | 86 | 95.158036 / 94.762630 | yes |
| 29 | PVBP 1/2/3/5/10/30-year prices | 87–90, 92, 94 | all match to 4 dp | yes |
| 30 | PVBP 7/20-year prices | 91, 93 | 108.9745/108.8457; 105.0658/104.7942 (one off in the 4th dp; gap unchanged) | yes (last digit) |
| 31 | MacD 4.74; 4.74/1.03 = 4.60 | 97–98 | 4.6019 | yes |
| 32 | 5.1602 + 203.3615 = 208.52; 1.95; 1.92 | 100 | 5.160212; 203.36145; 1.9517; 1.9167 | yes |
| 33 | 307.92/107.02 = 2.88; 2.82 | 101 | 307.9219; 2.8772; 2.8219 | yes |
| 34 | closed form 7-year: 29.2437 − 1.137563/0.049195 = 6.12; 5.91 | 102 | 29.243729; 1.137563; 0.049195; 6.1202; 5.9108 | yes |
| 35 | closed form 10/20/30/50-year quotients and results | 103–106 | 17.2526 / 10.3491 / 6.7641 / 2.8566; 8.50 / 13.51 / 17.17 / 21.70; ModD 8.17 / 12.94 / 16.45 / 20.82 | yes |
| 36 | weight 0.137 on the final £104 | 106 | 0.13703 | yes |
| 37 | **108: 3.75 × 8.0948 + 67.30 = 97.6525 → 3.75 × 7.7068 + 61.16 = 90.0583; 8 × 8.0948 + 67.30 = 132.0553 → 8 × 7.7068 + 61.16 = 122.8120** | 108 | from the printed inputs: **97.6555 → 90.0605; 132.0584 → 122.8144** (exact 97.6525, 90.0583, 132.0553, 122.8120 need factors 8.094769 / 7.706757 and PVs 67.2971 / 61.1579) | **no (B1)** |
| 38 | % changes −9.12% / −7.78% / −7.00% | 108 | −9.123% / −7.777% / −7.000% | yes |
| 39 | 8,620.9 ÷ (97.65 × 1.0824) = 81.56 | 111 | 81.5629 | yes |
| 40 | 0.016643 ÷ 0.00002374 = 701.05; 8.6× | 112 | 701.053; 8.595 | yes |
| 41 | −8.17% + 0.41% = −7.76% | 113 | −7.762 | yes |
| 42 | −20.82 + 3.51 = −17.31; 21.30; 6.7594 → 711.82; −17.74% | 114 | −17.315; 21.3037; 6.7594; 711.8155; −17.741 | yes |
| 43 | 50-year −1%: 4 × 24.576771 + 100/4.935672 = 118.5678; +24.86% | 115 | 98.30708 + 20.2607; 24.861% | yes |
| 44 | +3.5 points for 21× risk; 127/191bp; +240 vs +331bp; −51.0% / −34.4% | 125, 13, 22, 136 | 3.51; 21.03; 1.27 / 1.91; 2.40 / 3.31; 22.24 × 0.02293 = 51.0%; 75.28/114.76 − 1 = −34.4% | yes |

## 4b. External fact spot-check (10 facts)

| Slide | Claim | Evidence in sources files | Supported? |
|---|---|---|---|
| 9 | £1,365bn (2014) → £2,817bn (2026), same basis | 7a `1,365.02` gross nominal; 7b `£2,144` + `£673`; 7c same-basis verdict | yes (DMO primary) |
| 11 | 29% / 27% / 26% | `29.2%`, `26.6%`, `26.4%` (DMO GAR 2013-14); "end-2014" footnoted | yes |
| 12 | 35.6 / 78.6 / 93.2% of GDP; 2.9 / 5.6 / 4.4% | ONS HF6X and J5IJ rows 1a–1f | yes (primary) |
| 13 | 2.77% / 2.62% / 1.50% (May 2014); 5.30 / 4.98 / 3.39% today | BoE IUDMNPY `09 May 2014,2.7654`, `27 Oct 2026,5.3046`; Treasury CSV rows; Bundesbank `1,50`, `3,39` | yes (primary) |
| 36 | 4.75% → 5.75% → 0.50% | D2 rows `03 Aug 06 4.75`, `05 Jul 07 5.75`, `05 Mar 09 0.50` | yes |
| 108 | 0½% 2061 at £23.41, ModD 26.75 | sources_research l.206 giltsyield row (secondary, labelled) | yes |
| 130 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a `04 Aug 2020,0.1239`, series from `01 Nov 1993` | yes |
| 133 | BoE bought £19.3bn, 28 Sep – 14 Oct 2022 | E rows (BoE notices) | yes |
| 134 | ">100bp in four days"; "20 year gilt … roughly a 20% price fall"; LBC 3.8% → 5% | Bank Underground exact quotes; LBC labelled secondary | yes |
| 135, 137 | £895bn → £488bn; Bank Rate 3.75%; next decision 5 Nov 2026 (provisional) | Governor's letter of 17 Sep 2026; D `Current official Bank Rate 3.75%`; D3 | yes |

## 5. Blocking items (exact fixes)

**B1 · H8 · slide 108: the 4-dp prices do not reproduce from the inputs printed beside them.**
The slide prints the factors at 4 dp and the PVs of £100 at 2 dp (8.0948 / 7.7068; 67.30 / 61.16), then states 4-dp results. From those inputs a calculator gives 3.75 × 8.0948 + 67.30 = **97.6555** (printed 97.6525), 3.75 × 7.7068 + 61.16 = **90.0605** (printed 90.0583), 8 × 8.0948 + 67.30 = **132.0584** (printed 132.0553) and 8 × 7.7068 + 61.16 = **122.8144** (printed 122.8120). The gaps of 0.002–0.003 are beyond last-digit rounding. 90.0583 also contradicts slide 80's 90.0582.
**Fix:** print the inputs at the precision that reproduces: "annuity factors 8.094769 → 7.706757; PV of £100 67.2971 → 61.1579". Then:
- 0%: 67.2971 → 61.1579 = −9.12%
- 3.75%: 3.75 × 8.094769 = 30.3554, + 67.2971 = 97.6525 → 3.75 × 7.706757 = 28.9003, + 61.1579 = 90.0582; change −7.78%
- 8%: 8 × 8.094769 = 64.7582, + 67.2971 = 132.0553 → 8 × 7.706757 = 61.6541, + 61.1579 = 122.8120; change −7.00%

Update the "coupon …" lines in `r5_displays` to match, and assert them.

**B2 · H8 · slide 85: the same +1% prices are shown differently from slides 75–83.**
Slide 85 uses prices at the exact yield + 1%. Slides 75–83 use the 4-dp yield. So the same price differs in the 4th decimal on five rows: 1-year 101.4924 (75: 101.4925); 7-year 102.7030 (79: 102.7031); 10-year 90.0583 (80: 90.0582); 20-year 92.4519 (81: 92.4518); 50-year 78.1122 (83: 78.1125). This is the same contradiction r6 blocked on slide 114. There it was fixed with a note; here it came in through r6 non-blocking 1, with no note.
**Fix:** use the 75–83 prices in 85: 1y 102.5000 → 101.4925 = −1.0075; 7y 108.9100 → 102.7031 = −6.2069; 10y 97.6525 → 90.0582 = −7.5943; 20y 104.9300 → 92.4518 = −12.4782; 50y 94.9600 → 78.1125 = −16.8475. The other four rows are unchanged. Every 1-dp figure and the title (£1.0m, £16.8m) stay the same. Update the "GBP m on 100m, 4 dp" line in calcs.py.

## 6. Non-blocking improvements (most valuable first)
1. **Slide 45:** slides 76 and 117 use 106.8409 as the 2-year base, but 45 shows only 5.25 × 1.9490 + 96.61 → 106.84, which gives 106.8423 at 4 dp. Show 5.25 × 1.948984 = 10.2322, + 96.6087 = 106.8409.
2. **Slide 47:** 100/3.5977 = 27.7955, not 27.7957. Print (1.0436)³⁰ as 3.597677 so the term reproduces exactly.
3. **Slide 56:** if it is split over two facing slides, log this under "Decisions made" in PROGRESS.md as still "ONE comparison", so a later reviewer does not read it as two.
4. **Slide 29:** print 30.9642 (the factor at the printed 4.3751%) instead of 30.9641.
5. **Slides 91 and 93:** printed at 4-dp yields, the prices come out one higher (lower) in the 4th dp (108.9745 / 108.8457; 105.0658 / 104.7942). Either print the 6-dp yields (3.530609% / 3.550609%; 4.365092% / 4.385092%) or say "yields rounded".
6. **Slide 85 title** is about 100 characters; trim it to about 90 (e.g. "On £100m of each gilt, a 1% rise costs £1.0m (1-year) to £16.8m (50-year)").
7. **Slide 70:** "the real 9 May 2014 dip was only 3bp": add which two gilts (4½% 2042 3.39% vs 4% 2060 3.37%), so the reader can trace it.
8. **Slide 137:** keep "re-check before submission" as a build-time task, so the date is checked before printing.
