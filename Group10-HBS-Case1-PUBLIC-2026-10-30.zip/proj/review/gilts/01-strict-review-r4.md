NOT READY. Grade estimate B+ as it stands, A− once the five blocking items below are fixed. The finance is sound and the Q4 depth is strong. What holds it back: Q3 is never stated as a question, four calculations cannot be reproduced from the numbers shown, three external claims are unsourced or unlabelled, three repeated calculations are tables (against the user's "one slide each"), and about 22 calculation slides have no "so what". Every fix is wording-level; none needs new analysis.

# UK Gilts: strict review of the gate 1 storyline, round 4

Reviewed: `review/gilts/01-storyline.md` (120 slides). Checked against: the rubric, the grading brief, `case-layout.txt`, `UK Gilts.xlsx.md`, CLAUDE.md, DESIGN.md, PROGRESS.md, the live output of `python3 work/gilts/calcs.py` (run 2026-10-30), `exhibits.csv`, `answers.md`, `sources.md` and `sources_research.md`. I also skimmed the G1 NESA benchmark. I used the teaching note only to check answers; it agrees with calcs.py (its 50-year price of 94.97 differs from the case's 94.96, and the plan correctly uses 94.96). I recomputed by hand: the 5bp convexity, the forward rates from the rounded inputs shown, the closed-form durations, the FV factors, the bootstrap rearrangement, and an instant +229bp shock on the 4% 2060.

The "Response to the strict review" sections were not taken as evidence. Each claim in them was checked against the slide lines.

## 0. Round 3 blocking items: fixed or not

| r3 item | Status | Evidence in the plan (round 4) |
|---|---|---|
| B1 · slide 96, the false "most of its value sits in the final £104" | **FIXED** | Now reads "only 14% of its value sits in the final £104 (weight 0.137); the other 86% is coupons". This matches calcs (t=50 weight 0.1370). |
| B2 · slide 117, the yield-convention mix | **FIXED** | Now 3.365% → 5.658% (both DMO semi-annual), +229bp, −22.24 × 2.29% = −51.0%, durations labelled "modified", today labelled secondary. Matches calcs ("like-for-like" line) and sources 8a/8b. Leftover: calcs.py still prints the old line "3.36% -> 5.74% (+237bp) … −52.8%" (non-blocking item 3). |
| B3 · slide 98, the unsourced 2061 claim | **FIXED** | It now uses "0½% 2061 … modified duration 26.75 … £23.41 [src, secondary]", which matches sources_research line 206. The comparison with the 4% 2060 (15.73) that gives the point is missing (B5). |
| B3 · slide 10, "buyers" | **FIXED** | It now says "by 2014 the Bank was one of the biggest holders"; £375bn is sourced (DMO GAR 2013-14). |
| B3 · slide 36, Bank Rate 2007–08 not logged | **FIXED for sourcing; evidence now thin** | The chart is limited to "path to 0.50% (March 2009)"; earlier levels are "added to sources.md at build or omitted". No unsourced fact is required, but the slide's point ("high-coupon gilts date from higher-rate years") now rests on the case text alone (non-blocking item 4). |
| B3 · slide 118, giltsyield unlabelled | **FIXED** | It is now "today's curve (secondary: giltsyield.com)". It still does not say which column (DMO yield, as on 117) (non-blocking item 9). |
| B3 · slide 7, ratings not pinned down | **PARTLY FIXED** | The ratings are now named (S&P AAA 2014; Fitch AA− Aug 2026, secondary). But S&P 2014 comes from PTI/Business Standard (sources.md line 76), a **secondary** source, and it is not labelled as one. This is now in B3. |
| B4 · slides 92–96, Σ(t × PV) not derived | **FIXED, one display slip** | The CFA closed form now has numbers on each slide. They reproduce 6.12 / 13.51 / 17.17 / 21.70. On slide 93 the numbers shown give 25.7525 − 1.0114/0.0586 = **8.49**, not 8.50 (B2). |
| B4 · slides 90–91, tables | **FIXED** | 5.1602 + 203.3615 = 208.52 → 1.95 → 1.92; 4.4090 + 8.6399 + 294.8730 = 307.92 → 2.88 → 2.82. All verified. |
| B4 · slide 101, Σ t(t+1)PV not derived | **FIXED** | The 10-row table is there; I summed the rows: 8,620.87; ÷ (97.65 × 1.0824) = 81.56. |
| B4 · slide 102, the 50-year convexity | **NOT FIXED in effect** | The plan follows r3's prescription (prices to 4 dp), but that prescription was wrong. With the numbers shown, (95.9569 + 93.9798 − 189.92)/(94.96 × 0.0005²) = **703.45**, not 701.05. At a 5bp step, rounding each price to 4 dp moves the answer by up to ±4. A reader with a calculator cannot reproduce "701.05, matching 701.03". This is now in B2. |
| B6.1 · Bank Rate defined (10) | **FIXED** | "Plain: Bank Rate = the Bank of England's main interest rate…" |
| B6.2 · clean/full price (40) | **FIXED** | Clean, full and accrued interest are all defined. |
| B6.3 · the FV formula in words (29) | **FIXED** | "each coupon is invested until maturity and grows with interest". |
| B6.4 · slide 69's forward references | **FIXED** | Plain-words versions plus "(explained fully in Q4, slides 98–100)". |
| B6.5 · 2y1y gloss and formula (65) | **FIXED in words; numbers do not reproduce** | Gloss and formula are present. From the 2-dp spot rates shown, the reader gets 1y1y = 2.82% (not 2.81%) and 2y1y = 2.73% (not 2.75%) (B2). |
| B6.6 · par yield (13) | **FIXED** | "Plain: par yield = the coupon a bond would need to be priced at exactly £100." |

r3 non-blocking items: taken: 2 (104's 21.30), 3 (115's Bank Underground credit); partly taken: 1 (27 only; 31 and 33 still use 3.54% without "derived on slide 51"), 4 (44 and 46 only; 29 and 65 not). Not taken: 5 (long titles), 6 (instantaneous shift), 7 (so-whats on 75–81), 8 (2.77 vs 2.80 footnote), 9 (113 "inflation returned" unsourced, now blocking because it is a factual claim in a title), 10 (slide 24 still says "tested on slide 58"; slide 58 is the yield-curve definition).

## 1. Verdict
**NOT READY. Grade estimate B+ as it stands; A− (low A) once B1–B5 are fixed.** Hard requirements failing: H3, H4, H9, H11 (H8 also, on traceability only). Quality: Q4 = 3; the rest are 4–5.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover with placeholders); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37, Q2 38–56, Q3 57–71, Q4 72–108; Epilogue 109–119; team slide 120 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (case p.3, "Source: IMD research"; `UK Gilts.xlsx` holds the same table). Slide 18 rebuilds it natively, labelled with its source, blanks shown as "?". What it shows (18–19); key numbers and trends (19–21: coupons 2¾–5¼%, 4 of 5 given prices above 100, given yields 1.74 → 4.36%, all checked); meaning (22, against the DMO's 9 May 2014 data); implication (23–24). |
| H3 Every question, all seven elements | **FAIL** | **Q3 is never stated.** Slide 57 is a divider ("Q3: the yield curve") and slide 58 is a definition ("A yield curve shows…"), yet the checklist cites 58 as "question stated and broken into parts". The question ("plot the yield curve that results from the given bonds") and its parts (plot, describe, explain) appear nowhere. **Q4 is stated (73) but not broken into parts**: the line covers only the parallel shift. Q1 (26: three parts) and Q2 (39: two tasks) pass. Theory, evidence, assumptions and alternatives pass for all four. Calculation steps: the bootstrap (63–64) jumps from the equation to "→ z2 = 1.77%" without the rearrangement step, and four slides show numbers that do not give the stated result (see H8 and B2). |
| H4 External sourced facts | **FAIL** | Verified and supported: 9, 10, 11, 12, 13, 66, 98, 111, 112 (secondary, labelled), 114, 116, 117, 118 (spot-check in section 4b). Failures: **113** "From December 2021 inflation returned": no inflation figure or quote is logged anywhere in the sources files. **115** "though not as a parallel shift: the long end moved most": no logged source compares the moves at different maturities (Bank Underground says only "the interest rate on UK gilts rose by over 100 basis points in four days"; LBC covers the 30-year alone). **7** S&P AAA (2014) rests on PTI/Business Standard (sources.md line 76), a secondary source, and is not labelled as such. |
| H5 No teaching note | PASS | No citation, quotation or reference. The word "teaching set" on 22 describes the exhibit; rewording is safer (non-blocking item 8). |
| H6 Titles | PASS (watch length) | Every content title states a finding. Seven run 101–119 characters (2: 101, 11: 116, 15: 110, 65: 109, 107: 119, 116: 107, 119: 110) and may run to 3 lines at headline size. 119's "duration is the price of extra yield" is unclear (non-blocking item 6). |
| H7 Finance correct | PASS | Checked: YTM as IRR and its three conditions (28); price = PV (32); the premium/discount rule (34); pull to par (35); clean/full/accrued (40); interpolation then exact solve (49–53); the semi-annual convention (55); bootstrap and forwards (61–65); expectations/liquidity/segmentation (67); annual ModD = MacD/(1+y) (88); the CFA closed-form MacD (92, verified on all five bonds); analytic annual convexity Σt(t+1)PV/[P(1+y)²] (101); price-based convexity (102); duration plus convexity (103–104); "matches by construction" (104) is correct algebra, since −AMD·Δy + ½·AC·Δy² = (P₊ − P₀)/P₀ exactly; PVBP as the average of the ±1bp moves (85); the coupon effect (98). Slide 117: my instant +229bp shock on the 2014 bond gives −36.4%, so the gap to the duration-only −51.0% is mostly convexity, with about 2 points from the 12 years that pass. The plan's explanation is right. Small imprecision: 67 defines preferred habitat as investors who "stick to" maturities, which describes segmentation (non-blocking item 10). |
| H8 Numbers right | **FAIL (traceability)** | All 40 numbers checked match calcs.py or the sources (section 4). But on four slides the numbers shown do not give the result shown: **102** gives 703.45, not 701.05; **65** gives 2.82% / 2.73%, not 2.81% / 2.75%; **93** gives 8.49, not 8.50; **29** gives 4.75 × 30.96 = 147.06 and 4.75 × 24.30 = 115.43, not 147.08 / 115.41. Each is caused by rounding intermediates, but a reader checking on paper gets a different number, and 102's whole point ("matching 701.03") cannot be checked. Formats: results follow the rule. Three-decimal yields (50–53, 117) are acceptable as intermediates; 85's "£0.20m" breaks the 1-dp money rule (non-blocking item 9). |
| H9 User decisions | **FAIL** | Honoured: annual coupons plus one semi-annual comparison (40, 55–56); no real gilt names for the case bonds (23); one slide per Q2 value (41–53), per +1% repricing (74–82) and per duration (87–96). Breach: the user chose "One slide each … every repeated calculation gets its own slide (formula → numbers → result)" (PROGRESS.md, 2026-10-29). **Slides 85 (PVBP), 105 (−1% repricing) and 56 (semi-annual)** each give one worked example, then a results-only table for the other eight bonds: 24 full repricings with no steps shown. 31 (current yield) and 84 (£m) do the same for one-operation sums. r3 flagged this and asked for it to be put to the user at the gate. It is not in PROGRESS.md's "Decisions made", so the user has not been told. A reviewer cannot waive a user decision. |
| H10 Known traps | PASS | Annual-coupon simplification stated (24, 40) and tested (55–56); per £100 (5, 15, 40); duration and convexity explain the +1% shift (86–105). |
| H11 Lucidity | **FAIL** | Definitions are now excellent: a "Plain:" line wherever a term first appears. But the user's rule says *every calculation ends with a one-line so what*, and **about 22 calculation slides have none in the plan**: 44, 50, 51, 52, 62, 63, 64, 75, 76, 77, 78, 79, 80, 81, 85, 87, 89, 90, 91, 92, 93, 94, 95, 101, 103. Built exactly from the plan, these slides end on a bare number. On six more slides this reader would get lost: **102** (which price is P₋ and which is P₊? the "price-based method" is never put in words), **104** ("ApproxModDur" is never defined or derived), **105** (24.5767 and 4.9357 have no labels), **98** (26.75 has no comparison, so "more risk" cannot be seen), **85** (95.1580 and 94.7626 are not said to be prices at 1bp lower and higher yields), and **63–64** (no step from the equation to the spot rate). That is far more than a handful. Analysis has not been cut anywhere; this is purely missing explanation. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Well beyond the four questions, and claims are tested: reinvestment FV, three yield measures, bootstrap and forwards with a hindsight test, coupon effect, convexity two ways, up/down asymmetry, the exhibit against the real 2014 curve, a real 4% 2060 test of Q4. |
| Q2 Logic and flow | 4 | Clean arc; concepts come before use. Docked for: Q3 has no question slide; wrong cross-reference on 24 ("slide 58"); 31 and 33 use 3.54% before slide 51 derives it, with no note. |
| Q3 Evidence | 4 | Strong primary sources (ONS, US Treasury, Bundesbank, BoE, DMO). Docked for the unsourced 113 and 115 claims and the thin Bank Rate evidence on 36. |
| Q4 Lucidity | **3** | Definitions are first-rate, but about 22 calculation slides lack a so-what and six slides would lose a part-way Level 1 reader (H11). |
| Q5 Calculations | 4 | Q2 is exemplary; the duration sums are now traceable. Docked for the four displays that do not reproduce (29, 65, 93, 102), the missing bootstrap rearrangement (63–64) and ApproxModDur never derived (104). |
| Q6 Overview and epilogue | 4 | Current to 29 Oct 2026, tied back to Q4 through 115 and 117. Docked for 113 and 115 (unsourced). |

## 4a. Number spot-check (40 numbers; calcs.py run 2026-10-30)

| # | Number | Slide | Source | Match |
|---|---|---|---|---|
| 1 | FV 147.08 / 247.08; 115.41 / 215.41 | 29 | calcs STRICT ADDITIONS | yes (but the factors shown give 147.06 / 115.43; use 30.9641 / 24.2974) |
| 2 | Realised 3.66%; 3.15% at 0% | 30 | calcs; my calc 3.662% / 3.147% | yes |
| 3 | 7-year 5.00 / 4.59 / 3.54% | 31 | calcs current yield | yes |
| 4 | PVs 2.67 / 2.59 / 2.52 / 2.44 / 88.63 → 98.86 | 42–43 | calcs example A | yes |
| 5 | 12.5942 + 86.2609 = 98.8551 | 44 | calcs 4dp | yes |
| 6 | 5.25 × 1.9490 + 96.61 = 106.84 | 45 | calcs annuity | yes |
| 7 | 30.3554 + 67.2971 = 97.6525 | 46 | calcs 4dp | yes |
| 8 | 4.50 × 16.5606 + 27.80 = 102.32 | 47 | calcs | yes |
| 9 | 1 + y = 1.007317 → 0.73% | 48 | calcs example B | yes |
| 10 | 107.21 / 104.24 → 2.064% → 2.063% | 49–50 | calcs | yes |
| 11 | 112.46 / 106.00 → 3.550 → 3.541% | 51 | calcs | yes |
| 12 | 110.19 / 96.88 → 4.395 → 4.375% | 52 | calcs | yes |
| 13 | 100.00 / 81.74 → 4.276 → 4.245% | 53 | calcs | yes |
| 14 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | calcs | yes |
| 15 | Max £0.03, 1bp | 56 | calcs semi-annual block | yes |
| 16 | +331 / +34 / −2 / −12bp | 60 | calcs Q3 | yes |
| 17 | z2 1.77%, z3 2.09% | 63–64 | calcs; mine 1.7659 / 2.0917% | yes |
| 18 | 1y1y 2.81%, 2y1y 2.75% | 65 | calcs; mine 2.8106 / 2.7466% | yes (but 2-dp inputs give 2.82 / 2.73) |
| 19 | +1% prices 101.49 … 78.11 and % changes −0.98 … −17.74 (all nine) | 74–82 | calcs Q4 | yes, 18 of 18 |
| 20 | "18 times" | 82 | 17.74 / 0.98 = 18.1 | yes |
| 21 | £1.0m / £16.8m on £100m | 84 | calcs £100m block | yes |
| 22 | PVBP (95.1580 − 94.7626)/2 = 0.1977 → £0.20m | 85 | calcs | yes (format: £0.2m) |
| 23 | MacD 4.74, ModD 4.60 | 87–88 | calcs | yes |
| 24 | 208.52 / 106.84 = 1.95 → 1.92; 307.92 / 107.02 = 2.88 → 2.82 | 90–91 | calcs; my sums | yes |
| 25 | Closed form 6.12 / 8.50 / 13.51 / 17.17 / 21.70 and ModD 5.91 / 8.17 / 12.94 / 16.45 / 20.82 | 92–96 | calcs closed-form block | yes (93's numbers shown give 8.49) |
| 26 | Weight 0.137 (14%) | 96 | calcs t=50 | yes |
| 27 | −9.12 / −7.78 / −7.00% | 98 | calcs coupon effect | yes |
| 28 | Convexity 10-year table rows; sum 8,620.9; 81.56 | 101 | calcs; my row sum 8,620.87 | yes |
| 29 | 50-year 701.05 from (95.9569 + 93.9798 − 2 × 94.96)/(94.96 × 0.0005²) | 102 | calcs; my exact P± 95.956890 / 93.979753 | **result yes; the numbers shown give 703.45** |
| 30 | 701.03 / 81.56 = 8.6 | 102 | calcs | yes |
| 31 | −8.17 + 0.41 = −7.76% | 103 | calcs example D | yes |
| 32 | −20.82 + 3.51 = −17.31%; −21.30 + 3.56 = −17.74% | 104 | calcs | yes |
| 33 | 4 × 24.5767 + 100/4.9357 = 118.57, +24.86% | 105 | calcs; mine 24.57669 / 4.93572 | yes |
| 34 | "+3.5 points for 21 times the risk" | 106 | 4.24 − 0.73; 20.82 / 0.99 | yes |
| 35 | 4% 2060: 114.76 → 75.28 = −34.4%; 3.365 → 5.658 = +229bp; −51.0%; ModD 22.24 / 15.73 | 117 | sources 8a, 8b; calcs like-for-like | yes |
| 36 | 10-year 2.80 / 4.04; 3.39 / 4.36; 3.36 / 4.24 | 22 | DMO 2.803 / 3.393 / 3.364984 | yes |
| 37 | Six premium, three discount; 0.73–4.38% | 54 | calcs Q2 | yes |
| 38 | 4 of 5 given prices above 100; 94.96 the only discount | 20 | exhibits.csv | yes |
| 39 | 0.73/1.74/2.06 vs 0.73/1.77/2.09 | 70 | calcs | yes |
| 40 | Bank Rate 0.10 → 5.25% (Dec 21 – Aug 23; 14 rises) | 113 | sources D | yes |

## 4b. External fact spot-check (14 facts)

| Slide | Claim | Sources file evidence | Supported? |
|---|---|---|---|
| 9 | £1,365bn (2014) → £2,817bn (2026), same basis | 7a–7c, DMO GAR tables | yes |
| 10 | QE from March 2009; £375bn by 2014 | 9a "We first began using QE in March 2009"; GAR "APF purchasing £375 billion" | yes |
| 11 | 29% / 27% / 26% | GAR 29.2% / 26.6% / 26.4% ("end-2014" footnote handled) | yes |
| 12 | 35.6 / 78.6 / 93.2%; 2.9 / 5.6 / 4.4% | ONS HF6X, J5IJ rows | yes |
| 13 | 2.77 / 2.62 / 1.50%; 5.30 / 4.98 / 3.39%; 127 / 191bp | 3b, 2a–2d | yes (UK figure is 27 Oct, US/DE 29 Oct; label the dates) |
| 7 | S&P AAA (2014); Fitch AA− (Aug 2026) | line 76 PTI (secondary); 5a (secondary) | yes, but **S&P not labelled secondary** |
| 98 | 0½% 2061 £23.41, ModD 26.75 | sources_research line 206 (giltsyield, secondary) | yes |
| 111 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a | yes |
| 112 | S&P AAA → AA, June 2016 | 4a Euronews (secondary, labelled) | yes |
| 113 | "inflation returned" | nothing logged | **no** |
| 114 | >100bp in four days; £19.3bn 28 Sep – 14 Oct | section E (Bank Underground; BoE notices) | yes |
| 115 | BU "100bp … 20-year gilt … roughly a 20% price fall" | section E, exact quote | yes |
| 115 | "the long end moved most" | nothing compares maturities | **no** |
| 116 | Reinvestment stopped Feb 2022, sales from Nov 2022; £895bn → £488bn | 6a, 6b, APF letter | yes |
| 117–118 | 4% 2060 figures; Bank Rate 3.75%; curve higher than 2014 at every point shown | 8a, 8b, D, F | yes |

## 5. Blocking items (exact fixes)

**B1 · H3 · Q3 not stated; Q4 not broken into parts (slides 57–58, 73).**
- Insert a slide after 57 (or retitle 58 and move the definition into its body): **"Q3: plot the yield curve the nine gilts make, then describe and explain its shape"** · three parts: (1) plot the nine YTMs against years to maturity (59); (2) describe the shape in numbers (60); (3) explain it: spot and forward rates (61–66), the three theories (67–69), caveats (70). Update the checklist row "Each question stated" to cite the new slide.
- Slide 73: add the parts: "(a) reprice all nine at the new yields (74–83); (b) say which falls most and why: duration (86–97); (c) test how good the duration estimate is: convexity (99–105); (d) what it means for investors (106–107)."

**B2 · H3/H8/Q5 · numbers shown that do not give the result shown, and a missing step.**
- **Slide 102:** show the prices to 6 dp: "price if the yield falls 0.05% (to 4.1945%): 95.956890; price if it rises 0.05% (to 4.2945%): 93.979753; (95.956890 + 93.979753 − 2 × 94.960000) = 0.016643; ÷ (94.96 × 0.0005²) = 0.016643 ÷ 0.00002374 = **701.05**". (As written now, it gives 703.45.)
- **Slide 65:** show the spot rates to 4 dp: "1y1y = 1.017659² ÷ 1.007317 − 1 = 1.035630 ÷ 1.007317 − 1 = 2.81%; 2y1y = 1.020917³ ÷ 1.017659² − 1 = 1.064058 ÷ 1.035630 − 1 = 2.75%".
- **Slide 93:** "25.7525 − 1.0114/**0.05862** = 25.7525 − 17.2526 = 8.50". On 92 show 0.04920, and on 94–96 show four significant figures in the denominator.
- **Slide 29:** "4.75 × **30.9641** = 147.08" and "4.75 × **24.2974** = 115.41"; label each factor "future-value annuity factor".
- **Slides 63–64:** add the rearrangement step. 63: "take away the year-1 coupon's PV: 106.84 − 5.25/1.007317 = 106.84 − 5.21 = 101.63; so (1 + z2)² = 105.25/101.63 = 1.0356; z2 = 1.77%". 64: "107.02 − 4.47 − 4.35 = 98.21; (1 + z3)³ = 104.5/98.21 = 1.0641; z3 = 2.09%".

**B3 · H4 · external claims (slides 7, 113, 115).**
- **Slide 7:** tag "S&P AAA (2014) [src, secondary: PTI]".
- **Slide 113:** either log an ONS CPI datum with an exact quote in sources.md (e.g. the ONS CPI annual-rate series for Dec 2021 and the 2022 peak) and cite it, or retitle to what is sourced: **"From December 2021 the Bank raised Bank Rate 14 times, from 0.10% to 5.25% by August 2023"** (sources D lists all 14 rises).
- **Slide 115:** retitle **"Our 1% scenario happened in 2022: gilt yields rose more than 100bp in four days"** [src: Bank Underground, a BoE staff blog], and add the 30-year "from around 3.8% to 5% in just three days" [src: LBC, secondary]. Keep "the long end moved most" only if a maturity comparison (e.g. BoE database 5-year vs 30-year yields, 22–27 Sep 2022) is logged with its rows.

**B4 · H9 · repeated calculations shown as results tables (slides 56, 85, 105; also 31, 84).**
The user chose "every repeated calculation gets its own slide". Do one of the following before gate 2:
- **(a) Comply:** after each worked example, add one slide per remaining bond (formula → numbers → result). PVBP: 8 slides (e.g. "10-year: [P at 4.03%] − [P at 4.05%] / 2 = (97.7323 − 97.5728)/2 = 0.0798 → £0.08m per £100m"; I computed these prices; add them to calcs.py). −1%: 8 slides (C × annuity factor + 100/(1+y)^N at y − 1%). Semi-annual: 8 slides. For 31 and 84, each row can carry its numbers ("3.25 ÷ 102.50 = 3.17%"; "£102.5m × −0.98% = −£1.0m").
- **(b) Ask:** put one multiple-choice question to the user in simple words (CLAUDE.md rule): "For the three side checks (PVBP, −1%, twice-a-year coupons), (A) one slide per bond (+24 slides), or (B) one worked example plus a table that shows the numbers plugged in for each bond". Record the answer word for word in PROGRESS.md. Note that "exactly one semi-annual comparison" may favour (B) for slide 56; say so in the question.

**B5 · H11 · missing so-whats and six slides that lose the reader.** Add these lines to the plan (wording can be tightened at build):
- 44: "Two methods, one answer; the shortcut saves work on the long gilts."
- 50: "The check reprices to 107.02, so 2.06% is right."
- 51: "3.54% is below the 5% coupon, so the gilt sells at a premium, as slide 34's rule says."
- 52: "Below the 4¾% coupon: a premium; the straight-line guess was 2bp too high."
- 62: "One payment, so nothing to average: the spot rate equals the YTM. This anchors the next step."
- 63: "The 2-year spot rate (1.77%) sits just above the 2-year YTM (1.74%), because the YTM also averages in the lower 1-year rate."
- 64: "Again just above the YTM (2.06%): on a rising curve, spot rates sit above coupon-bond yields."
- 75: "About twice the 1-year's fall: the money comes back later."
- 76: "About three times the 1-year's fall."
- 77: "The discount 5-year loses about 4½ times what the 1-year loses."
- 78: "−5.70%: less than 7 years suggests, because the high 5% coupon returns money early."
- 79: "The 10-year loses about 8 times what the 1-year loses."
- 80: "About 12 times the 1-year's loss."
- 81: "−14.67%: the loss keeps growing, but more slowly with each extra decade."
- 85: label the inputs ("price if the yield is 1bp lower: 95.1580; 1bp higher: 94.7626"), plus the so-what: "a desk knows each 1bp move costs about £0.2m on £100m of the 50-year, which is what it hedges."
- 87: "90% of the value arrives in year 5, so the duration (4.74) is close to the 5-year maturity."
- 89: "One payment: duration = maturity."
- 90–91: "Just under the maturity: early coupons pull the average wait down."
- 92: define the symbols (c = coupon rate, y = yield, N = years), say in words "a ready-made formula that gives the same answer as adding t × PV for every payment", and show the cross-check Σ(t × PV)/P = 666.55/108.91 = 6.12. So what: "a 1% rise should cost about 5.9%."
- 93–95: "A 1% rise should cost about 8.2% / 12.9% / 16.5% (actual −7.78 / −11.89 / −14.67%, slides 79–81)."
- 98: add the comparison: "vs 15.73 for the 4% 2060, which matures 21 months earlier [secondary]: lower coupon, far more risk."
- 101: "The 10-year bends only a little: convexity adds back just 0.41% on a 1% rise (slide 103)."
- 102: put the method in words first: "reprice the bond at a yield 0.05% lower and 0.05% higher; the amount by which the two prices together beat twice today's price measures the bend". Label P₋ and P₊.
- 103: "Adding convexity brings the estimate within 0.02% of the actual fall."
- 104: define and derive approximate modified duration: "(price at −1% − price at +1%) ÷ (2 × price × 1%) = (118.57 − 78.11)/(2 × 94.96 × 0.01) = 21.30".
- 105: label "24.5767 = annuity factor for 50 years at 3.24%; 4.9357 = 1.0324⁵⁰".

## 6. Non-blocking improvements (most valuable first)
1. **Slide 24:** "tested on slide 58" → "tested on slides 55–56".
2. **Slides 31 and 33:** add "(derived on slide 51)" after 3.54%.
3. **calcs.py:** delete or mark as superseded the old line "Real bond, 4% 2060: 3.36% -> 5.74% (+237bp) … −52.8%". The builders take numbers from calcs.py and could pick it up.
4. **Slide 36:** commit now. Either log 2–3 earlier Bank Rate rows from the same BoE database page (e.g. the 2007 peak) and chart them, or say "Bank Rate 1.00% (Feb 2009) → 0.50% (Mar 2009), unchanged to 2014" plus the case's p.2 sentence ("the coupon rate usually reflects the market interest rate at the time of the first issue").
5. **Slide 117:** add one line showing convexity does most of the work: "an instant 229bp rise on the 2014 bond already gives −36.4%; the other 2 points come from 12 years passing" (add this to calcs.py first). Show yields as 3.37% → 5.66% (2 dp), with the bp computed from the DMO's 3-dp figures.
6. **Titles 2, 11, 15, 65, 107, 116, 119:** trim to about 95 characters. For 119 try "Lessons: the coupon is not the return, the curve carries information, and extra yield brings much more rate risk".
7. **Slide 73:** add "the shift is instantaneous: no time passes, so no pull to par".
8. **Slide 22:** "teaching set" → "simplified classroom data set" (keeps clear of any teaching-note reading). Replace "similar rise at the short end" with numbers: real 1-year 0.40% → 10-year 2.80% (+240bp) vs Exhibit +331bp.
9. **Formats and labels:** 85 "£0.20m" → "£0.2m (£197.7 thousand)"; 118 name the DMO-yield column (as 117 does); 13 date the today figures (UK 27 Oct, US and Germany 29 Oct 2026); footnote 2.77% (BoE par yield) vs 2.80% (DMO, 2¾% 2024) on 13, 22 and 111.
10. **Slide 67:** preferred habitat = "investors who prefer certain maturities and need extra yield to move away from them" (segmentation = they never move). For Q3 depth, add one line on liquidity: the thinly traded 50-year (slide 8) would normally need *more* yield, so its lower yield is further evidence of strong long-end demand.
