READY. Grade estimate A−. The r9 blocking item (slide 7's rating scale) is fixed and correct, and no new error came in with the round-10 edits. One claim in the author's response is **not true**: calcs.py still prints the old 2-dp "−1% per bond" and semi-annual blocks, plus a few other leftover lines that do not add up in the last digit. No plan display depends on them, so under the rubric this is non-blocking. But it must be done before gate 3, and the false statements in the plan's response and in PROGRESS.md must be corrected.

# UK Gilts: strict review of the gate 1 storyline, round 10

Reviewed: `review/gilts/01-storyline.md` (139 slides, round 10). I checked it against:
- the rubric
- the grading brief (`Case Presentation Instructions.docx.md`)
- `case-layout.txt` and `UK Gilts.xlsx.md`
- `exhibits.csv`
- CLAUDE.md and DESIGN.md
- PROGRESS.md: user feedback word for word, and the decisions, including "Mix (Recommended)" and the slide-56 split note

I ran `python3 work/gilts/calcs.py` live on 2026-10-30. It exits 0 and every assert passes. I read `answers.md`, `sources.md` and `sources_research.md`, and skimmed the G1 NESA benchmark (268 slides). I used `UK Gilts Questions.docx.md` only to check answers: the plan's Q2 and Q4 numbers match its tables (except its 94.97 typo for the 50-year, where the plan correctly uses the case's 94.96). I recomputed every number below from the inputs as printed in the plan, in my own script (`/tmp/claude-0/-home-claude/535c8268-cdcd-5ed5-9093-f9b3d4b34d6b/scratchpad/v10.py`). The "Response to the strict review" sections were not counted as evidence.

## 0. Round 9 items: fixed or not

| r9 item | Status | Evidence |
|---|---|---|
| **B1 · slide 7 rating scale** | **FIXED** | It now reads "the agencies' scale runs AAA (top), AA+, AA, AA-, …; so AA- is one notch below AA and three below AAA". That is correct for S&P and Fitch. Slide 131 now says "two notches in one move", which matches sources.md 4a (Euronews: "by two notches in one move"). Slides 7 and 131 now agree. |
| nb 1 · delete the leftover 2-dp blocks and the `[SUPERSEDED]` line from calcs.py | **NOT FIXED (partly done)** | Removed: the "Annuity form" block (now `pass`), the `[SUPERSEDED]` 4% 2060 line, and the 1.9490 and 100/3.5977 lines (a grep finds none). **Still printed:** (a) the 2-dp "−1% per bond" block (calcs.py lines 321–326; output "5y at 2.00%: … 12.96 + 90.57 = 103.54" (true sum 103.53) and "20y at 3.38%: … 68.28 + 51.49 = 119.76" (true sum 119.77), the exact two lines r9 named). (b) The 2-dp semi-annual block (lines 328–337). Other leftovers that do not reproduce at their printed digits: line 209 "4.75 x 30.96 = 147.08" (= 147.06) and "4.75 x 24.30 = 115.41" (= 115.43), which are alternative versions of slide 29; line 297 "107.02 - 4.47 - 4.35 = 98.21" (= 98.20), an alternative to slide 65; line 253 "1.1376/0.0492 = 23.1236" (= 23.122) and "1.0114/0.0586 = 17.2526" (= 17.259), and line 306 "1.1376/0.04919 = 23.1236" (= 23.127), all alternatives to slides 102–103; and Worked example A's 2-dp PVs, which sum to 98.85 but print "running 98.86". The plan's response ("leftover 2-dp blocks … deleted"), its round-8 note ("the remaining 2-dp blocks (annuity form, −1% vs +1%, semi-annual comparison) … were removed in round 10") and PROGRESS.md's status line ("calcs.py leftovers removed") are all **untrue** for (a) and (b). |
| nb 2 · slide 47 prints "= 100/3.597677" | FIXED | The final_displays line 47 now reads `+ 100/1.0436^30 (= 100/3.597677) = 27.7957`. I get 1.0436³⁰ = 3.5976765 ✓. |
| nb 3 · plan line 9 names both blocks | FIXED | Line 9 names `r5_displays` (56, 75–83, 115–123) and `final_displays` (29, 30, 44–47, 70, 85, 108). Both blocks print exactly those lines. |
| nb 4 · slide 134 repeated phrase | FIXED | Now: "…which a low coupon and a low starting yield produce (the coupon effect, slide 108), and 2022 had both". There is no repeat. A precision point on the wording is under non-blocking 2. |
| nb 5 · slide 56 tested at 18pt at build | Kept as a build task ✓ | The split is logged in PROGRESS "Decisions made" as still ONE comparison. |
| nb 6 · slide 66 capital "In words" | FIXED | |
| nb 7 · slide 137 re-check | Kept ✓ | "(provisional date) … (re-check before submission)". |

**Does calcs.py still print a display that conflicts with the plan?** Yes, but only in the last digit, and only in leftover lines that the plan does not use. Every display the plan does use is printed exactly, in `r5_displays` or `final_displays`, and reproduces. The leftovers listed above are older versions of slides 29, 56, 65, 102–103, 119 and 122. Seven of them fail to add up in the last printed digit, so a builder could still copy one by mistake.

**New errors from the round-10 edits:** none. I diffed the plan against `01-storyline-r9-before-fixes.md`. Only lines 1, 9, 7, 66, 131 and 134 and the response section changed, and each change is correct.

## 1. Verdict
**READY. Grade estimate A−.** No hard requirement fails, every quality score is ≥ 4, all 62 numbers I checked reproduce, and all 16 external facts I checked are supported. The calcs.py clean-up is not done, despite the claim. It is non-blocking because no plan display depends on the leftover lines, but it must be done before gate 3 (non-blocking 1).

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover placeholder); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37; Q2 38–56; Q3 57–72; Q4 73–127; Epilogue 128–138; team slide 139 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (nine gilts, "Source: IMD research"). It is rebuilt natively on 18 with "?" for the blanks, and matches `exhibits.csv` row by row. What it shows: 18–19. Key numbers and trends: 19–21. Meaning: 22, set against the DMO's 9 May 2014 data. Implication: 23–24. |
| H3 Every question | PASS | **Q1:** stated and split 26; theory 27–35; evidence 36 (BoE); assumptions 28 (the three YTM conditions); alternatives 31 (three yield measures); calculations 29–30. **Q2:** 39; assumptions 40; steps 41–53; alternatives 44 (two methods) and 55–56 (semi-annual); evidence 22. **Q3:** 58 (three parts); theory 62–70; evidence 67 and 70; assumptions and caveats 66 and 71; alternatives 68 (three theories). **Q4:** 74 (parts a–d); 75–124; evidence 134 and 136. Every calculation goes formula → numbers → result on the slide. There is no "see Excel". |
| H4 External, sourced, current | PASS | All 16 facts I checked (section 4b) have a URL, an access date and an exact quote that supports them. They are current to 27–29 Oct 2026. Secondary sources are labelled (7, 108, 131, 134 LBC, 136, 137). |
| H5 No teaching note | PASS | I grepped for "teaching", "Questions.docx" and "answer key": no hits. The question wording is the assigned questions. |
| H6 Titles | PASS | Every content title states a finding. The longest is 99 characters (16), then 98 (127) and 96 (22, 66, 126), which fits two lines at title size. |
| H7 Finance correct | PASS | Slide 7's scale is now right. Also correct: YTM as IRR and its three conditions; realised return and reinvestment risk; current yield; price = PV; the premium/discount rule; pull to par; clean = full on a coupon date; bracketing, interpolation and the reprice check; semi-annual compounding; bootstrapping (spot above YTM on a rising curve); no-arbitrage forwards; the three curve theories and preferred habitat; parallel instantaneous shift; PVBP; Macaulay and modified duration, including the CFA closed form; analytic and price-based convexity; duration + convexity; up/down asymmetry; the coupon effect; QE and QT; LDI and margin calls. |
| H8 Numbers right | PASS | 62 numbers checked (4a); all reproduce within the last shown digit. Formats: money 1 dp, prices 2 dp, yields 2 dp, bp whole. Extra decimals appear only in intermediate steps and in DMO 3-dp quotes. PVBP in £ thousand is a logged decision. |
| H9 User decisions | PASS | Annual coupons plus exactly one semi-annual comparison (55 worked example plus the 56 table with every bond's numbers; the possible two-slide split is logged as ONE comparison). No case bond gets a real name (23); real gilts appear only as context (4, 22, 70, 108, 136). "Mix": PVBP gets one slide per bond (86–94, summary 95), and so does −1% (115–123, summary 124). Every other repeat has its own slide (41–53, 75–83, 97–106). |
| H10 Known traps | PASS | Annual coupons are stated (24, 40) and tested (55–56). Prices are per £100 (5, 15, 40). Duration and convexity explain the +1% shift (96–114). |
| H11 Lucidity | PASS | Every term has a "Plain:" line where it first appears: interest-rate risk, face value/coupon/maturity, risk-free rate, the rating scale, QE, Bank Rate, net debt, par yield, sovereign spread, YTM, premium/discount, bp, IRR, realised return, annuity factor, current yield, discount factor, clean/full/accrued, bracketing, interpolation, spot, forward, bootstrapping, 1y1y/2y1y, term premium, preferred habitat, parallel shift, PVBP, Macaulay/modified duration, convexity, approximate duration and convexity, coupon effect, LDI, margin calls, QT. Formulas come in words first (29, 30, 32, 44, 66, 75, 86, 102, 111, 112, 114). Numbers are labelled, every calculation has a so-what, concepts come before use, and titles are everyday language. No slide would leave the reader lost. The densest slides (13, 56, 108, 114) are a layout risk at build, not a lucidity failure in the plan. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Well past the four questions, and it tests its claims: reinvestment risk, three yield measures, bootstrap plus forwards with a hindsight test, PVBP per bond, duration two ways, convexity two ways, asymmetry, the coupon effect, the exhibit vs the real 2014 curve, and the real 4% 2060 with the instant shock separated out. |
| Q2 Logic and flow | 4 | A clean arc with correct cross-references (27→52, 31→51, 45→76/117, 53→86/106/112/114, 70→108–110, 134→108). Q4 is long (55 slides), but each slide earns its place under "one slide per repeat". |
| Q3 Evidence | 5 | Primary ONS, DMO, BoE, US Treasury and Bundesbank data for nearly every fact; secondary sources labelled. |
| Q4 Lucidity | 4 | Words before numbers, labels and a so-what throughout. Not 5 because 56, 108 and 114 are very dense for a paper reader. |
| Q5 Calculations | 4 | Complete and traceable from the plan, and every plan display is printed and reproduces. Not 5 because calcs.py still holds conflicting leftover lines (section 0). |
| Q6 Overview and epilogue | 5 | Current to 27–29 Oct 2026, and tied back to Q4 through 2022 (134), the real 4% 2060 (136) and today's curve (137). |

## 4a. Number spot-check (62 numbers, recomputed from the printed inputs)

| # | Number (plan) | Slide | My result / source | Match |
|---|---|---|---|---|
| 1 | 4.75 × 30.9642 = 147.08; factor at 4.3751% | 29 | 30.964174; 147.0800 | yes |
| 2 | 4.75 × 24.2974 = 115.41 | 29 | 24.297370; 115.4127 | yes |
| 3 | 3.66%; 0% case 3.15% | 30 | 3.6617%; 3.1470% | yes |
| 4 | 3.25 ÷ 102.50 = 3.17%; 5.00 ÷ 108.91 = 4.59% | 31 | 3.1707%; 4.5909% | yes |
| 5 | PVs 2.6699 / 2.5921 / 2.5166 / 2.4433 / 88.6331 → 98.8551 | 42–43 | identical; exact 98.85507 | yes |
| 6 | 2.75 × 4.579707 = 12.5942; 86.2609; 98.8551 | 44 | 4.5797072; 12.594194; 86.260878 | yes |
| 7 | 5.25 × 1.948985 = 10.2322; 96.6088; 106.8410 (exact 106.8409) | 45 | 1.9489852; 10.232171; 96.608766; 106.840938 | yes |
| 8 | 3.75 × 8.094769 = 30.3554; 67.2971; 97.6525 | 46 | 8.0947690; 30.355384; 67.297133 | yes |
| 9 | 4.50 × 16.560615 = 74.5228; 3.597677; 27.7957; 102.3185 | 47 | 16.560615; 3.5976765; 27.795714 | yes |
| 10 | 1 + y = 1.007317 → 0.73% | 48 | 1.0073171 | yes |
| 11 | 107.21 / 104.24 → 2.064%; exact 2.063% | 49–50 | 107.2097 / 104.2429; 2.0640%; 2.0628% | yes |
| 12 | 112.46 / 106.00 → 3.550%; 3.541% | 51 | 112.4606 / 106.0021; 3.5495%; 3.5406% | yes |
| 13 | 110.19 / 96.88 → 4.395%; 4.375%; "2bp too high" | 52 | 4.3952%; 4.3751% | yes |
| 14 | 100.00 / 81.74 → 4.276%; 4.244519% | 53 | 4.2760%; 4.2445188% | yes |
| 15 | six above £100, three below; 0.73%–4.38% | 54 | 1, 2, 3, 7, 20, 30y premium; 5, 10, 50y discount | yes |
| 16 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | 2.6024 / 2.5799 / 2.5577 / 99.1300; 106.8699 | yes |
| 17 | semi-annual yields 0.7362 / 2.0743 / 3.5512 / 4.3775 / 4.2437% | 56 | 0.73619 / 2.07433 / 3.55118 / 4.37752 / 4.24374 | yes |
| 18 | 2y 10.2755 + 96.5944 = 106.87; 10y 97.63; 50y 82.7109 + 12.2499 = 94.96 | 56 | 106.8699; 97.6336; 94.9608 | yes |
| 19 | 106.84 − 5.21 = 101.63; 1.0356; 1.77% | 64 | 5.2119; 1.035619; 1.765% | yes |
| 20 | 4.4673 + 4.3452; 98.2075; 1.0641; 2.09% | 65 | 4.467313 / 4.345182; 1.064074; 2.0917% | yes |
| 21 | 1y1y 2.81%; 2y1y 2.75% | 66 | 1.035630; 2.8106%; 1.064073; 2.7466% | yes |
| 22 | +331 / +34 / −2 / −12bp | 61 | 330.8 / 33.5 / −2 / −12 | yes |
| 23 | 1y +1%: 3.1947 + 98.2978 = 101.4925; −0.98% | 75 | 0.982978; −0.983% | yes |
| 24 | 5y +1%: 4.451822, 1.216653 → 94.4352; −4.47% | 78 | identical; −4.471% | yes |
| 25 | 7y +1%: 29.4198 + 73.2833 = 102.7031; −5.70% | 79 | identical; −5.699% | yes |
| 26 | 20y +1%: 12.075203, 2.849443 → 57.3572 + 35.0946 = 92.4518; −11.89% | 81 | identical; −11.892% | yes |
| 27 | 30y +1%: 87.3053; −14.67% | 82 | 87.30535; −14.673% | yes |
| 28 | 50y +1%: 17.587377, 12.881619 → 78.1125; −17.74% | 83 | identical; −17.742% | yes |
| 29 | "about twice / three / 4½ / 8 / 12 / 18 times" the 1-year | 76–83 | 1.93 / 2.83 / 4.56 / 7.94 / 12.1 / 18.1 | yes |
| 30 | 85 rows −1.0075 … −16.8475 | 85 | every subtraction reproduces; also printed by final_displays | yes |
| 31 | 50y PVBP 95.1580 / 94.7626 → 0.1977 → £197.7k | 86 | 95.158031 / 94.762625 | yes |
| 32 | 1y PVBP (102.5102 − 102.4898)/2 = 0.0102 | 87 | 102.510177; 0.0102 | yes |
| 33 | 7y / 20y / 30y PVBP 0.0644 / 0.1358 / 0.1684 | 91, 93, 94 | 0.0644 / 0.1358 / 0.16835 | yes |
| 34 | "19 times", "13 times", "about 8 times" | 95, 93, 92 | 19.4; 13.3; 7.8 | yes |
| 35 | MacD 4.74; 4.74/1.03 = 4.60; 90% in year 5 | 97–98 | 4.6019; weight 0.8966 | yes |
| 36 | 5.1602 + 203.3615 = 208.52 → 1.95 → 1.92 | 100 | 5.160212 / 203.361452; 1.9517; 1.9167 | yes |
| 37 | 4.4090 + 8.6399 + 294.8730 = 307.92 → 2.88 → 2.82 | 101 | 307.9219; 2.8772; 2.8219 | yes |
| 38 | 29.2437 − 1.137563/0.049195 = 29.2437 − 23.1235 = 6.12; 5.91 | 102 | 29.243729; 1.137563; 0.049195; 23.123549; 5.9108 | yes |
| 39 | closed form 10 / 20 / 30 / 50y 8.50 / 13.51 / 17.17 / 21.70 | 103–106 | 8.4999 / 13.5076 / 17.1717 / 21.7032 | yes |
| 40 | ModD 8.17 / 12.94 / 16.45 / 20.82 | 103–106 | 8.1699 / 12.9431 / 16.4527 / 20.8173 | yes |
| 41 | weight 0.137 in the final £104 | 106 | 0.13703 | yes |
| 42 | 0% / 3.75% / 8%: −9.12 / −7.78 / −7.00%; 64.7582, 132.0553, 122.8120 | 108 | −9.1225 / −7.7769 / −6.9996%; 64.758152; 122.811956 | yes |
| 43 | 8,620.9 ÷ (97.65 × 1.0824) = 81.56; 1.0824 = 1.0404² | 111 | 81.5629; 1.082432 | yes |
| 44 | P₋ 95.956890, P₊ 93.979753; 0.016643 / 0.00002374 = 701.05; 8.6× | 112 | 95.956885 / 93.979749; 701.053; 8.595 | yes |
| 45 | −8.17 + 0.41 = −7.76% | 113 | ½ × 81.56 × 0.0001 = 0.41% | yes |
| 46 | −20.82 + 3.51 = −17.31; 21.30; 6.7594/0.009496 = 711.82; −17.74% | 114 | −17.315; 21.3037; 118.567218 / 78.112237; 711.8155; −17.741 | yes |
| 47 | 4.0 × 24.576771 + 100/4.935672 = 118.5678; +24.86% | 115 | 24.576771; 4.9356718; +24.861% | yes |
| 48 | 1y −1%: 103.5277; +1.00% | 116 | 103.52776; +1.003% | yes |
| 49 | 5y −1%: 12.9620 + 90.5731 = 103.5351; +4.73% | 119 | 103.53508; +4.734% | yes |
| 50 | 20y −1%: 68.2783 + 51.4851 = 119.7634; +14.14% | 122 | 119.76334; +14.136% | yes |
| 51 | +3.5 points for 21× the risk | 125 | 3.51; 20.82/0.99 = 21.03 | yes |
| 52 | gilt − Bund 127bp then, 191bp now | 13 | 2.77 − 1.50; 5.30 − 3.39 (BoE 2.7654 / 5.3046; Bundesbank 1,50 / 3,39) | yes |
| 53 | real +240bp vs exhibit +331bp; 4.04/2.80, 4.36/3.39, 4.24/3.37 | 22 | 2.803 − 0.402 = 240.1; gaps 1.24 / 0.97 / 0.87 ("about a point") | yes |
| 54 | 3.393% vs 3.365% = 2.8bp ("about 3bp") | 70 | 2.8; DMO rows in sources.md | yes |
| 55 | 4% 2060: +229bp; −51.0%; −34.4%; −36.4% instant | 136 | 5.658 − 3.365 = 2.293; 22.24 × 0.02293 = 51.0%; 75.28/114.76 − 1 = −34.4%; calcs −36.4% | yes |
| 56 | £1,365bn → £2,817bn, "doubled" | 9 | 2,144 + 673 = 2,817; ×2.06 | yes |
| 57 | 29% / 27% / 26%, "over 80%" | 11 | 29.2 / 26.6 / 26.4 = 82.2% | yes |
| 58 | 35.6 → 78.6 → 93.2% of GDP, "more than doubled" | 12 | ONS HF6X; ×2.21 | yes |
| 59 | 14 rises, 0.10% → 5.25% | 132 | 14 rows, 16 Dec 21 to 03 Aug 23 (sources D) | yes |
| 60 | AA- one notch below AA, three below AAA | 7 | AAA, AA+, AA, AA- | yes |
| 61 | 0½% 2061 is 21 months after the 4% 2060 | 108 | 22 Jan 2060 → 22 Oct 2061 = 21 months | yes |
| 62 | 4 given prices above £100 | 20 | 102.50, 107.02, 108.91, 104.93 > 100; 94.96 < 100 | yes |

More than 20 of these displays were recomputed on a calculator from the plan's own printed inputs (rows 1–14, 16, 18–28, 31–33, 36–50, 55). Each one gives the stated result.

## 4b. External fact spot-check (16 facts)

| Slide | Claim | Evidence in the sources files | Supported? |
|---|---|---|---|
| 7 | S&P AAA (2014), Fitch AA- (Aug 2026), both labelled secondary | PTI row 76 "reaffirmed its top-notch 'AAA'"; 5a "maintained … at 'AA-'" | yes |
| 9 | £1,365bn (2014) → £2,817bn (2026), same basis | 7a `1,365.02`; 7b `£2,144` + `£673`; 7c basis verdict | yes (DMO) |
| 10 | QE from Mar 2009; £375bn bought | 9a "first began using QE in March 2009"; DMO "APF purchasing £375 billion" | yes |
| 11 | 29% / 27% / 26%; Bank figure footnoted "end-2014" | `29.2%`, `26.6%`, `26.4%` (DMO GAR 2013-14) | yes |
| 12 | 35.6 / 78.6 / 93.2% of GDP; 2.9 / 5.6 / 4.4% borrowing | ONS HF6X and J5IJ (1a–1f) | yes (primary) |
| 13 | 2.77 / 2.62 / 1.50% (9 May 2014); 5.30 / 4.98 / 3.39% now | 3b, 2a, 2b, 2c, 2d | yes (primary) |
| 36 | 4.75% (Aug 06) → 5.75% (Jul 07) → 0.50% (Mar 09) | D2 rows | yes |
| 67 | Bank Rate cut to 0.25% in Aug 2016 | D `04 Aug 16 \| 0.25` | yes |
| 108 | 0½% 2061 at £23.41, ModD 26.75; 4% 2060 at 15.73 | sources_research l.206 (giltsyield, secondary); 8a | yes (secondary, labelled) |
| 130 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a `04 Aug 2020,0.1239`, series from `01 Nov 1993` | yes |
| 131 | S&P AAA → AA, two notches, June 2016 | 4a Euronews | yes (secondary, labelled) |
| 133 | BoE bought £19.3bn, 28 Sep – 14 Oct 2022 | E rows (BoE Sep 2022, Oct 2022, Jan 2023) | yes |
| 134 | +100bp in four days; 30-year 3.8% → 5%; "roughly a 20% price fall" | E (Bank Underground; LBC secondary) | yes |
| 135 | reinvestment stopped Feb 2022, sales from Nov 2022; £895bn → £488bn | 6a, 6b; Governor's letter of 17 Sep 2026 | yes |
| 136 | 4% 2060 £114.76 → £75.28; 3.365% → 5.658%; ModD 22.24 | 8b (DMO 2014), 8a (giltsyield, secondary) | yes |
| 137 | Bank Rate 3.75%; next decision 5 Nov 2026 (provisional) | D "Current official Bank Rate 3.75%"; D3 | yes |

## 5. Blocking items
None.

## 6. Non-blocking improvements (most valuable first)
1. **calcs.py: finish the clean-up the round-10 response claims, before gate 3.** Delete the 2-dp "−1% per bond" loop (lines 321–326) and the 2-dp semi-annual loop (lines 328–337). Also delete, or move to the same rounded-input style, these lines: the 2-dp FV lines (209–210: "4.75 x 30.96 = 147.08"), the 2-dp bootstrap-3y line (297: "98.21"), both 4/5-dp closed-form loops (253 and 306: "23.1236", "17.2526"), and Worked example A's running total (2-dp PVs that sum to 98.85 but print 98.86). Then correct the plan's two response notes and PROGRESS.md's status line, which now say this was done.
2. **Slide 134, precision.** Bank Underground's "roughly 20%" is a straight-line (duration) rule of thumb. A true 20-year gilt has a modified duration of at most about 20/(1 + y). With convexity, even a zero-coupon 20-year gilt at 3.5% falls only about 17.5% for +1%. Add half a line, "(a duration rule of thumb; with convexity even a zero-coupon 20-year gilt falls about 17–18%)", so a sharp examiner cannot catch the deck overstating.
3. **Slide 7:** merge the two "Plain:" lines. The scale line now makes "AAA/AA = the agencies' top grades" redundant. Name the agencies once ("credit-rating agencies such as S&P and Fitch").
4. **Slide 56:** at build, test the nine-row table at 18pt first. Use the logged two-slide split only if it does not fit.
5. **Slides 108 and 114:** they are the densest after 56. At build, give each its own two-column layout (inputs | results) and do not shrink the text.
6. **Slide 35:** add "if yields stay the same" to the pull-to-par line. The path to £100 at repayment is certain; the smooth year-by-year path assumes an unchanged yield.
7. **sources.md:** rows 8a and 127 give the 4% 2060's modified duration as 15.73 and 15.74 (two reads of the same page). The plan uses 15.73 (8a). Note that 8a is the one used.
8. **Slide 137:** keep "re-check before submission" as a build task (the 5 Nov 2026 MPC date is provisional).
