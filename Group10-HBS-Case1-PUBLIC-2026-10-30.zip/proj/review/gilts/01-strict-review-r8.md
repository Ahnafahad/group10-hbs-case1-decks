NOT READY. Grade estimate A− on content. Both r7 slide fixes are right: slides 85 and 108 now reproduce and match slides 75–83. But two things are still wrong. **(1)** The r7 non-blocking fix on slide 70 added a new display error. It prints the 4% 2060 at 3.37% and the gap as "3bp", but 3.39 − 3.37 = 2bp. Slide 22 prints the same DMO yield (3.365%) as 3.36%. **(2)** The calcs.py parts of r7 B1 and B2 were not done. calcs.py still prints 90.0583 for slide 108 (the plan has 90.0582) and the old slide-85 values. It does not print the new displays on 29, 45 and 47 either. So the plan's own claim (line 9) that `r5_displays` prints every display is false. Both are small fixes. With them made, I expect READY at A−.

# UK Gilts: strict review of the gate 1 storyline, round 8

Reviewed: `review/gilts/01-storyline.md` (139 slides, round 8). Checked against:
- the rubric
- the grading brief
- `case-layout.txt`
- `UK Gilts.xlsx.md`
- `exhibits.csv`
- CLAUDE.md
- DESIGN.md
- PROGRESS.md: user feedback and decisions, including "Mix (Recommended)" and the logged slide-56 split note

I ran `python3 work/gilts/calcs.py` live on 2026-10-30; it exits 0 and every assert passes. I read `answers.md`, `sources.md` and `sources_research.md`. I skimmed the G1 NESA benchmark (268 slides). I used `UK Gilts Questions.docx.md` only to check answers. Its prices, yields, +1% prices and semi-annual row all match. Its 50-year 94.97 and 78.12 come from 94.96 being rounded differently; the plan uses the case's 94.96, which is correct.

Every number listed below I recomputed in my own Python (scratchpad scripts), **from the numbers as printed in the plan**. I did not count the "Response to the strict review" sections as evidence.

## 0. Round 7 items: fixed or not

| r7 item | Status | Evidence (round 8 plan) |
|---|---|---|
| **B1 · slide 108: the 4-dp prices do not reproduce** | **Slide: FIXED** | It now prints the factors 8.094769 → 7.706757 and the PVs 67.2971 → 61.1579. 3.75 × 8.094769 = 30.3554, + 67.2971 = 97.6525 → 3.75 × 7.706757 = 28.9003, + 61.1579 = 90.0582 (the same as slide 80) ✓. 8 × 8.094769 = 64.7582, + 67.2971 = 132.0553 → 61.6541 + 61.1579 = 122.8120 ✓. Changes −9.12 / −7.78 / −7.00% ✓. |
| B1 sub-point: "update the coupon lines in `r5_displays` to match, and assert them" | **NOT FIXED** | calcs.py still prints `coupon 3.75% 4dp: … 3.75 x 7.706757 + 61.1579 = 90.0583`, which contradicts the plan and slide 80. The old 2-dp lines (`8.0948 … 67.30`) are still printed too. |
| **B2 · slide 85: +1% prices differ from 75–83** | **Slide: FIXED** | Rows now use 101.4925, 104.8210, 104.0604, 94.4352, 102.7031, 90.0582, 92.4518, 87.3053 and 78.1125, which are exactly the 75–83 prices. Every subtraction reproduces: −1.0075 / −2.0199 / −2.9596 / −4.4199 / −6.2069 / −7.5943 / −12.4782 / −15.0132 / −16.8475 ✓. The title figures (£1.0m, £16.8m) are unchanged ✓. |
| B2 sub-point: "update the 'GBP m on 100m, 4 dp' line in calcs.py" | **NOT FIXED (partly)** | The old line has been marked "[superseded …]" but is still printed with the wrong values (101.4924, 78.1122, −16.8478). No line prints the new slide-85 rows. The +1% block does print the prices, so the right numbers can be found, but the money line is not printed or asserted anywhere. |
| r7 non-blocking 1 (slide 45) | Done ✓ | 5.25 × 1.948985 = 10.2322; 100/1.0174² = 96.6088; sum 106.8410; unrounded 106.8409 (my value: 106.840938) ✓. Not printed by calcs.py, which prints `5.25 x 1.9490 + 100/1.0351 = 10.23 + 96.61` (see B2). |
| r7 nb 2 (slide 47: 3.597677) | Done ✓ | 100/3.597677 = 27.7957 ✓. calcs.py still prints `100/3.5977 = 27.7957`, and 100/3.5977 is 27.7955. |
| r7 nb 3 (slide 56 split logged) | Done ✓ | PROGRESS.md "Decisions made", 2026-10-30: "it remains ONE comparison". |
| r7 nb 4 (slide 29: 30.9642) | Done ✓ | The factor at 4.3751% is 30.964174 → 30.9642 ✓. calcs.py still prints 30.9641 twice. |
| r7 nb 5 (slides 87–94 note) | Done ✓ | "(yields shown to 4 dp; prices worked at the exact yield ± 0.01%)" is on all eight. That explains the last-digit gap on 91 and 93. |
| r7 nb 6 (slide 85 title) | Done ✓ | About 85 characters. |
| r7 nb 7 (slide 70 names the two gilts) | **Done, but it adds a new error (B1 below)** | "4½% 2042 at 3.39% vs 4% 2060 at 3.37%" with "only 3bp": 3.39 − 3.37 = 2bp. Slide 22 shows the same 2060 yield as 3.36%. |
| r7 nb 7 (slide 70) + nb 8 (slide 137 re-check) | nb 8 done ✓ | "(provisional date) … (re-check before submission)". |

**Did the fixes add new errors?** Slides 29, 45, 47, 85 and 108 all re-derive cleanly from their printed inputs (section 4a, rows 1–9 and 27–29). The one new error is on slide 70 (B1).

## 1. Verdict
**NOT READY. Grade estimate A− on content.** H8 fails on slide 70 vs slide 22 (B1). The fixes to r7's blocking items are not finished in calcs.py, the plan's stated source of every display (B2). Every other hard requirement passes, and every quality score is ≥ 4.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover placeholder); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37; Q2 38–56; Q3 57–72; Q4 73–127; Epilogue 128–138; team slide 139 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (9 gilts, "Source: IMD research"). It is rebuilt natively on 18, with "?" for blanks; the values match `exhibits.csv` row by row. What it shows: 18–19. Key numbers and trends: 19–21. Meaning: 22 (vs DMO, 9 May 2014). Implication: 23–24. |
| H3 Every question | PASS | Stated and split into parts: 26, 39, 58, 74. Theory: 28, 32, 34–35, 44, 49–50, 62, 68, 96, 98, 110–112. Evidence: Q1 36; Q2 22; Q3 67, 70; Q4 134, 136. Assumptions: 28, 40, 55–56, 66, 74. Alternatives: 31, 44, 55–56, 108, 109–124, 126. Every calculation has its formula → numbers → result on the slide; no "see Excel". |
| H4 External, sourced, current | PASS | All 12 facts I checked (4b) have a URL, an access date and an exact quote that supports them. Current to 27–29 Oct 2026. Secondary sources are labelled (7, 108, 131, 134 LBC, 136, 137). |
| H5 No teaching note | PASS | No citation, quote or reference. The question wording is the assigned questions, not teaching-note text. 22 calls the data "a classroom data set". |
| H6 Titles | PASS | Every content title states a finding. The longest (66, 70, 22) are about 95–98 characters and fit in two lines. |
| H7 Finance correct | PASS | Covers: YTM as IRR and its three conditions (28); reinvestment risk (29–30); current yield (31); price = PV (32); the premium/discount rule (34); pull to par (35); clean = full on a coupon date (40); bracketing, interpolation and reprice (49–53); the semi-annual convention (55–56); bootstrapping, with spot above YTM on a rising curve (64–65, 71); no-arbitrage forwards (66); the three theories (68); PVBP (86); Macaulay and modified duration, with the CFA closed form (96–106); analytic and price-based convexity (111–112); duration + convexity (113–114); asymmetry (115–124); coupon effect (108). The module citations (LM06, LM09, LM10, LM11) match `materials/cfatxt`. No conceptual error. |
| H8 Numbers right | **FAIL** | I checked 52 numbers (4a); 51 reproduce within the last shown digit. **Slide 70** states "3bp" from 3.39% and 3.37%, which gives 2bp. Its 3.37% is the same DMO figure that slide 22 shows as 3.36% (B1). Formats otherwise follow the rules (money 1 dp, prices 2 dp, yields 2 dp, bp whole; extra decimals only in intermediate steps). |
| H9 User decisions | PASS | Annual coupons plus exactly one semi-annual comparison: 55 is the worked example, 56 the comparison table with every bond's numbers; the split is logged as still ONE comparison. No case bond is given a real name (23); real gilts appear only for context (4, 22, 70, 108, 136). "Mix": PVBP gets one slide per bond (86–94 + 95) and −1% one slide per bond (115–123 + 124). Every other repeat has its own slide (41–53, 75–83, 97–106). |
| H10 Known traps | PASS | Annual coupons are stated (24, 40) and tested (55–56); prices are per £100 (5, 15, 40); duration and convexity explain the +1% shift (96–114). |
| H11 Lucidity | PASS | Every term gets a "Plain:" line where it first appears. Formulas come in words first (29, 32, 44, 66, 75, 86, 102, 111, 112). Numbers are labelled; every calculation slide has a so-what; concepts come before use; titles are in everyday language. Two small gaps (non-blocking 3 and 4): 111's "1.0824" is not labelled as (1.0404)², and 46's "67.2971" is not labelled as 100/1.0404¹⁰. Neither would lose the reader, because 44 sets the pattern. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Far beyond the four questions, and claims are tested rather than asserted. The extra analysis covers: reinvestment risk; three yield measures; bootstrap and forwards with a hindsight test; PVBP per bond; duration two ways; convexity two ways; asymmetry; the coupon effect; the exhibit vs the real 2014 curve; and the real 4% 2060 with the instant shock separated out. |
| Q2 Logic and flow | 4 | A clean arc, and the cross-references are right (27→52, 31→51, 53→86/106/112/114, 70→108–110, 134→108). Q4 is long (55 slides) but each slide earns its place under "one slide per repeat". 74's part list leaves out 108 (non-blocking 6). |
| Q3 Evidence | 5 | Primary ONS, DMO, BoE, US Treasury and Bundesbank data for almost every fact; secondary sources labelled. |
| Q4 Lucidity | 4 | Words before numbers, labels and a so-what throughout. Not 5: 56 is still the densest slide, and some 4–6-dp displays need careful layout. |
| Q5 Calculations | 4 | Complete and traceable, with about 90 per-bond displays that reproduce. Docked for slide 70 and the calcs.py lag. |
| Q6 Overview and epilogue | 5 | Current to 27–29 Oct 2026, and tied back to Q4 through 2022 (134), the real 4% 2060 (136) and today's curve (137). |

## 4a. Number spot-check (52 numbers; recomputed from the printed inputs)

| # | Number (plan) | Slide | My result / source | Match |
|---|---|---|---|---|
| 1 | 4.75 × 30.9642 = 147.08 at 4.3751% | 29 | factor at 4.3751% = 30.964174; 147.08 | yes |
| 2 | 4.75 × 24.2974 = 115.41 at 2% | 29 | 24.297370; 115.41 | yes |
| 3 | (215.41/104.93)^(1/20) − 1 = 3.66%; 0% case 3.15% | 30 | 3.6617%; 3.1470% | yes |
| 4 | 3.25/102.50 = 3.17%; 5.00/108.91 = 4.59% | 31 | 3.1707%; 4.5909% | yes |
| 5 | PVs 2.6699 … 88.6331 → 98.8551 | 42–43 | each PV matches; sum 98.8550; exact 98.85507 | yes |
| 6 | 2.75 × 4.5797 = 12.5942; + 86.2609 = 98.8551 | 44 | 12.594175; 98.8551 | yes |
| 7 | 5.25 × 1.948985 = 10.2322; 96.6088; 106.8410; unrounded 106.8409 | 45 | 10.232171; 96.608766; 106.8410; 106.840938 | yes |
| 8 | 3.75 × 8.0948 = 30.3555; + 67.2971 = 97.6526 | 46 | 30.3555; 97.6526 (exact 97.6525) | yes |
| 9 | 4.50 × 16.5606 = 74.5228; 100/3.597677 = 27.7957; 102.3185 | 47 | 74.5227 (last digit; exact factor 16.560615 → 74.5228); 27.7957; 102.3185 | yes (last digit) |
| 10 | 103.25/102.50 = 1.007317 | 48 | 1.0073171 | yes |
| 11 | 107.21 / 104.24; 2.064%; exact 2.063% | 49–50 | 107.2097 / 104.2429; 2.0640%; 2.0628% | yes |
| 12 | 112.46 / 106.00; 3.550%; 3.541% | 51 | 112.4606 / 106.0021; 3.5495%; 3.5406% | yes |
| 13 | 110.19 / 96.88; 4.395%; 4.375%; "2bp too high" | 52 | 110.1927 / 96.8844; 4.3952%; 4.3751% | yes |
| 14 | 100.00 / 81.74; 4.276%; 4.244519% | 53 | 100.0000 / 81.7441; 4.2760%; 4.2445188% | yes |
| 15 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | 2.6024 / 2.5799 / 2.5577 / 99.1300; 106.8699 | yes |
| 16 | semi yields 0.7362 / 2.0743 / 3.5512 / 4.3775 / 4.2437% | 56 | 0.73619 / 2.07433 / 3.55118 / 4.37752 / 4.24374 | yes |
| 17 | semi 5-year: 12.6805 + 86.1667 = 98.85 | 56 | 98.8472 | yes |
| 18 | semi 30-year: 74.9119 + 27.4187 = 102.33 | 56 | 102.3306 | yes |
| 19 | all nine semi-annual factors (6 dp) | 56 | each matches to 6 dp | yes |
| 20 | 106.84 − 5.21 = 101.63; 1.0356; 1.77% | 64 | 5.2119; 1.035619; 1.765% | yes |
| 21 | 107.02 − 4.4673 − 4.3452 = 98.2075; 1.0641; 2.09% | 65 | 4.467313 / 4.345182; 1.064074; 2.0917% | yes |
| 22 | 1y1y 2.81%; 2y1y 2.75% | 66 | 2.8107%; 2.7464% | yes |
| 23 | +331 / +34 / −2 / −12bp | 61 | 330.8 / 33.5 / −1.5 / −11.6 (from exact; −2 and −12 from 2-dp yields) | yes |
| 24 | 1-year +1%: 3.1947 + 98.2978 = 101.4925; −0.98% | 75 | 101.4925; −0.983% | yes |
| 25 | 7-year +1%: 29.4198 + 73.2833 = 102.7031; −5.70% | 79 | 102.7031 | yes |
| 26 | 20-year +1%: 57.3572 + 35.0946 = 92.4518; −11.89% | 81 | 92.4518 | yes |
| 27 | 50-year +1%: 70.3495 + 7.7630 = 78.1125; −17.74% | 83 | 78.1125; factors 17.587377 and 12.881619 match | yes |
| 28 | all nine rows of 85 | 85 | every subtraction reproduces; the prices equal 75–83 | yes |
| 29 | 108: 30.3554 → 97.6525 → 28.9003 → 90.0582; 64.7582 → 132.0553 → 61.6541 → 122.8120; −9.12 / −7.78 / −7.00% | 108 | identical; −9.123 / −7.777 / −7.000% | yes |
| 30 | 50-year PVBP 95.1580 / 94.7626 → 0.1977 → £197.7k | 86 | 95.158036 / 94.762630 | yes |
| 31 | PVBP 1/2/3/5-year prices and halves | 87–90 | all match to 4 dp | yes |
| 32 | PVBP 10/30-year: 0.0798 / 0.1684 | 92, 94 | (97.7323 − 97.5728)/2 = 0.07975; (102.4870 − 102.1503)/2 = 0.16835 (half-up) | yes (last digit) |
| 33 | "19 times"; "13 times"; "about 8 times" | 95, 93, 92 | 19.4; 13.3; 7.8 | yes |
| 34 | MacD 4.74; 90% in year 5; 4.74/1.03 = 4.60 | 97–98 | 4.7377; 0.8966; 4.6019 | yes |
| 35 | 5.1602 + 203.3615 = 208.52; 1.95; 1.92 | 100 | 5.160212; 203.36145; 1.9517; 1.9167 | yes |
| 36 | 4.4090 + 8.6399 + 294.8730 = 307.92; 2.88; 2.82 | 101 | 307.9219; 2.8772; 2.8219 | yes |
| 37 | 7-year closed form: 29.2437 − 1.137563/0.049195 = 6.12; 666.55/108.91; 5.91 | 102 | 23.12355; 6.1202; 666.5464; 5.9108 | yes |
| 38 | 10/20/30/50-year closed form: 8.50 / 13.51 / 17.17 / 21.70; ModD 8.17 / 12.94 / 16.45 / 20.82 | 103–106 | 8.4999 / 13.5076 / 17.1717 / 21.7032; 8.1699 / 12.9431 / 16.4527 / 20.8173 | yes |
| 39 | weight 0.137 on the final £104 | 106 | 0.13703 | yes |
| 40 | 8,620.9 ÷ (97.65 × 1.0824) = 81.56 | 111 | sum 8,620.87; 81.5629 | yes |
| 41 | 0.016643 ÷ 0.00002374 = 701.05; 701.03; 8.6× | 112 | 701.053; analytic 701.026; 8.595 | yes |
| 42 | −8.17% + 0.41% = −7.76% | 113 | −7.762 | yes |
| 43 | −20.82 + 3.51 = −17.31; 21.30; 6.7594/0.009496 = 711.82; −17.74% | 114 | −17.315; 21.3011; 711.8155; −17.741 | yes |
| 44 | 4.0 × 24.576771 + 100/4.935672 = 118.5678; +24.86% | 115 | 98.3071 + 20.2607; 24.861% | yes |
| 45 | −1% rows (1y −0.2683% … 30y 3.3600%) | 116–123 | every factor, term, sum and % change matches | yes |
| 46 | +3.5 points for 21× the risk | 125 | 3.51; 20.82/0.99 = 21.03 | yes |
| 47 | gilt − Bund 127bp then, 191bp now | 13 | 2.77 − 1.50; 5.30 − 3.39 | yes |
| 48 | real curve +240bp vs Exhibit +331bp | 22 | 2.803 − 0.402 = 240.1; 4.04 − 0.73 | yes |
| 49 | 4% 2060 −51.0% / −34.4% / +229bp | 136 | 22.24 × 0.02293 = 51.0%; 75.28/114.76 − 1 = −34.4%; 5.658 − 3.365 | yes |
| 50 | 14 rises, 0.10% → 5.25% | 132 | BoE table: 14 rows from 16 Dec 21 to 03 Aug 23 | yes |
| 51 | 21 months (0½% 2061 vs 4% 2060) | 108 | 22 Jan 2060 → 22 Oct 2061 | yes |
| 52 | **"only 3bp (4½% 2042 at 3.39% vs 4% 2060 at 3.37%)"** | **70** | **3.39 − 3.37 = 2bp from the printed numbers (exact 3.393 − 3.365 = 2.8bp). Slide 22 prints the same DMO 3.365% as 3.36%** | **no (B1)** |

## 4b. External fact spot-check (12 facts)

| Slide | Claim | Evidence in sources files | Supported? |
|---|---|---|---|
| 9 | £1,365bn (2014) → £2,817bn (2026), same basis | sources.md 7a `1,365.02` gross nominal; 7b `£2,144` + `£673`; 7c same-basis verdict | yes (DMO primary) |
| 11 | 29% / 27% / 26% ("over 80%") | `29.2%`, `26.6%`, `26.4%` (DMO GAR 2013-14) = 82.2%; "end-2014" footnoted | yes |
| 12 | 35.6 / 78.6 / 93.2% of GDP; 2.9 / 5.6 / 4.4% | ONS HF6X and J5IJ rows 1a–1f | yes (primary) |
| 13 | 2.77 / 2.62 / 1.50% (May 2014); 5.30 / 4.98 / 3.39% today | BoE IUDMNPY `09 May 2014,2.7654`, `27 Oct 2026,5.3046`; Treasury CSV rows; Bundesbank `1,50`, `3,39` | yes (primary) |
| 36 | 4.75% → 5.75% → 0.50% | D2 rows `03 Aug 06 4.75`, `05 Jul 07 5.75`, `05 Mar 09 0.50` | yes |
| 67 | Bank Rate cut to 0.25%, Aug 2016 | D row `04 Aug 16 \| 0.25` | yes |
| 108 | 0½% 2061 at £23.41, ModD 26.75; 4% 2060 15.73 | sources_research l.206 (giltsyield, secondary, labelled); sources.md 8a | yes |
| 130 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a `04 Aug 2020,0.1239`, series from `01 Nov 1993` | yes |
| 133 | BoE bought £19.3bn, 28 Sep – 14 Oct 2022 | E rows (BoE notices of 28 Sep 2022, Oct 2022 and Jan 2023) | yes |
| 134 | ">100bp in four days"; "20 year gilt … roughly a 20% price fall"; LBC 3.8% → 5% | Bank Underground, exact quotes; LBC labelled secondary | yes |
| 135 | reinvesting stopped Feb 2022, sales from Nov 2022; £895bn → £488bn | 6a, 6b (BoE minutes and market notice); Governor's letter of 17 Sep 2026 | yes |
| 137 | Bank Rate 3.75%; next decision 5 Nov 2026 (provisional) | D `Current official Bank Rate 3.75%`; D3 BoE "MPC dates for 2026" | yes |

## 5. Blocking items (exact fixes)

**B1 · H8 · slide 70 (and 22): the dip does not reproduce, and the 4% 2060 yield is shown two ways.**
Slide 70 prints "the real 9 May 2014 dip was only 3bp (4½% 2042 at 3.39% vs 4% 2060 at 3.37%, DMO)". From the numbers shown, 3.39 − 3.37 = **2bp**. The 3bp comes from the DMO's 3-dp figures, 3.393 − 3.365 = 2.8bp. Slide 22 also shows the same DMO yield (3.365%) as **3.36%**, while 70 and 136 show **3.37%**. This is the same "one number, two values" problem that r6 and r7 blocked. It came in through r7 non-blocking 7.
**Fix:**
- slide 70: "… the real 9 May 2014 dip was only about 3bp (4½% 2042 at 3.393% vs 4% 2060 at 3.365%, DMO: 2.8bp)"
- slide 22: "~50-year 4.24% vs 3.37%" (standard rounding of 3.365, as on 136)

"About a point above" still holds (4.24 − 3.37 = 0.87).

**B2 · H8/Q5 traceability · calcs.py: the r7 calcs.py fixes were not made, so the plan's line-9 claim is false.**
The plan says the `r5_displays` block "prints every per-bond display below … and asserted against the exact answers". For five slides it does not:
- 108: it prints `90.0583` (the plan has 90.0582) and still prints the old 2-dp lines
- 85: only a "[superseded]" line with the old wrong values; no line prints the new rows
- 29: it prints `30.9641` (the plan has 30.9642)
- 45: it prints `1.9490 … 10.23 + 96.61` (the plan has 1.948985 / 10.2322 / 96.6088 / 106.8410)
- 47: it prints `100/3.5977 = 27.7957` (the plan has 3.597677; 100/3.5977 is really 27.7955)

At gate 3 the builders take numbers from calcs.py (CLAUDE.md: "never retyped"). Building from the current file would bring back the exact errors r7 blocked. r7's B1 and B2 both asked for this update.
**Fix (code only, no slide text changes):** in `r5_displays`:
1. Replace the "coupon … 4dp" lines with the slide 108 text, built from the 6-dp factors and 4-dp terms as printed: 3.75 × 8.094769 = 30.3554, + 67.2971 = 97.6525 → 28.9003 + 61.1579 = 90.0582; 8%: 64.7582 + 67.2971 = 132.0553 → 61.6541 + 61.1579 = 122.8120.
2. Delete the old 2-dp coupon lines and the superseded money line. Print the slide 85 rows from the +1% block's 4-dp prices (−1.0075 … −16.8475).
3. Print 30.9642 at 4.3751% (slide 29), the slide 45 line, and `100/3.597677 = 27.7957` (slide 47).
4. Assert each printed result equals the plan's shown value.

Then rerun and check that every display in 29, 45–47, 85 and 108 matches the plan character for character.

## 6. Non-blocking improvements (most valuable first)
1. **Slide 46:** for the same bond, 46 shows 3.75 × 8.0948 = 30.3555 → 97.6526, while 108 shows 30.3554 → 97.6525. Use 8.094769 on 46 as well (30.3554 + 67.2971 = 97.6525), so the 10-year base is printed one way everywhere (46, 80, 85, 108, 121).
2. **Slide 47:** print the annuity factor as 16.560615, so 4.50 × it = 74.5228 exactly; from 16.5606 a calculator gives 74.5227.
3. **Slide 111:** label "1.0824 = (1.0404)², i.e. (1 + y)²" so the reader sees where it comes from.
4. **Slide 46:** label 67.2971 as "100/1.0404¹⁰" (47 does this for the 30-year).
5. **Slide 134:** say in one plain line why a 20-year gilt in 2022 could lose about 20% (low coupon and low starting yield give a modified duration near 20). Right now, "the coupon effect plus lower starting yields" asks the reader to make that link themselves.
6. **Slide 74:** add 108 (the coupon effect) to part (b)'s range ("96–108"), so every Q4 slide sits inside a listed part.
7. **Slide 56:** at build, check the nine-row table at 18pt first; use the logged two-slide split only if it does not fit.
8. **Slide 7:** add "AA- = one notch below AA" to the Plain line.
9. **Slide 137:** keep "re-check before submission" as a build-time task (already noted).
