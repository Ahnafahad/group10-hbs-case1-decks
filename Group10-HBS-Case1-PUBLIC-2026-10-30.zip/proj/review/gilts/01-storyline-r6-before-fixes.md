# UK Gilts: storyline (gate 1, round 6: after strict review round 5)

One line per slide: **section · the point (becomes the title, ≤ 2 lines, about 95 characters or fewer) · what it shows**. Two tags help lucidity:
- **Plain:** a term defined in plain words where it first appears
- **So what:** the one-line takeaway. Every calculation slide ends with one; concept and fact slides carry one where the title alone does not give the point.

The reader is a student part-way through CFA Level 1, reading on paper with no presenter (user rule). The full analysis stays; it is explained, not simplified.

`[src]` points to `work/gilts/sources.md`; numbers come from `work/gilts/calcs.py` (the `r5_displays` block prints every per-bond display below, built from the rounded numbers shown and asserted against the exact answers). Every repeated calculation gets its own slide (user rule); the semi-annual check is ONE comparison with each bond's numbers shown (user choice, 2026-10-30, "Mix"). Money on holdings is shown in £m to 1 dp on £100m face; PVBP is shown in £ thousand to 1 dp, because it is below £0.1m for most gilts. Every displayed calculation can be reproduced on a calculator from the numbers shown.

## 0 · Opening
1. **Cover**: "UK Gilts: pricing, yields and interest-rate risk" · Group 10, course [PLACEHOLDER: user to supply]
2. **A trader must price nine UK government bonds and know what each could lose if rates rise** · the four questions, one line each; the five sections. Plain: "interest-rate risk" = how much a bond's price falls when market rates rise.

## 1 · Case overview (the market, not a company)
3. Divider · 01 Case overview
4. **A gilt is a loan to the UK government that pays fixed interest twice a year** · cash-flow diagram: £1,000 of 4% Treasury Gilt 2016 pays £20 every March and September, then £1,000 back (case p.2). Plain: face value, coupon, maturity.
5. **A gilt's name gives its coupon and repayment year; its price is quoted per £100 of face value** · "4% Treasury Gilt 2060" annotated. So what: a price of 102.50 means £102.50 per £100 [src]
6. **Conventional gilts pay fixed cash; index-linked gilts pay cash that rises with inflation** · side-by-side; this case covers conventional gilts only (case p.2)
7. **The UK has never missed a gilt payment, so gilts set the UK's risk-free rate** · DMO quote (case p.2); ratings shown: S&P AAA (2014) [src, secondary: PTI] and Fitch AA- (Aug 2026) [src, secondary] only; others not verified, so not shown. Plain: risk-free rate = the return on a loan with no real chance of default; AAA/AA = the agencies' top grades
8. **The Debt Management Office (DMO) sells gilts for the Treasury, mostly at 5, 10 and 30 years** · issuance; 50-year gilts since 2005, thinly traded (case p.2) [src]
9. **The gilt market has doubled: £1,365bn in 2014, £2,817bn in 2026** · bar chart, conventional vs index-linked, same DMO basis [src]
10. **QE: since 2009 the Bank of England has created money to buy gilts and push yields down** · Plain: QE (quantitative easing) in one line [src]; Bank Rate 0.50% from Mar 2009; £375bn of gilts bought by 2014 [src]. Plain: Bank Rate = the Bank of England's main interest rate, which sets the cost of short-term borrowing. So what: by 2014 the Bank was one of the biggest holders
11. **In 2014 three groups held over 80% of gilts: overseas, pension funds and insurers, and the Bank** · holdings chart 29% / 27% / 26% (Bank figure footnoted as "end-2014" per DMO) [src]
12. **UK government debt more than doubled as a share of GDP, from 35.6% in 2008 to 78.6% in 2014** · net debt % GDP: Mar 2008 35.6, Mar 2014 78.6, Mar 2026 93.2; borrowing % GDP: 2.9 / 5.6 / 4.4 (ONS, current vintage) [src]. Plain: net debt = what the government owes minus its liquid assets. So what: more gilts to sell, and investors to persuade
13. **In May 2014 a 10-year gilt paid 2.77%, against 2.62% in the US and 1.50% in Germany** · today 5.30% (UK, 27 Oct 2026) / 4.98% / 3.39% (US and Germany, 29 Oct 2026) (BoE, US Treasury, Bundesbank) [src]. Plain: par yield = the coupon a bond would need to be priced at exactly £100. Plain: Treasuries and Bunds = the US and German governments' bonds; sovereign spread = the extra yield one government pays over another (gilt − Bund: 127bp then, 191bp now; the "now" spread mixes the UK figure of 27 Oct with Germany's of 29 Oct). Footnote: 2.77% (BoE par yield) and 2.80% (DMO yield on the 2¾% 2024, slide 22) are two measures of the same 10-year yield
14. **The case: Petr Cech must price nine gilts and measure their risk for his trading desk** · setting (MU Securities); why a desk needs fair prices (to spot over- or under-priced bonds) and risk numbers (to set limits and hedge) (case p.1)
15. **Five ideas used throughout: price per £100, coupon, YTM, premium/discount, basis point** · primer, one plain line each. YTM = the single interest rate at which the bond's future cash, discounted, equals its price; premium = price above 100; discount = below 100; 1 basis point (bp) = 0.01 percentage point
16. **Each question needs one CFA tool: time value of money, YTM, the yield curve, duration and convexity** · Q1–Q4 mapped to tools

## 2 · Exhibit analysis
17. Divider · 02 Exhibit analysis
18. **Exhibit 1 gives nine gilts, each with either a price or a yield, never both** · native table, rebuilt (coupon, maturity, price, YTM; blanks shown as "?"); source: IMD research. So what: our job is to fill the gaps
19. **Coupons range from 2¾% to 5¼% because each gilt was issued when rates were different** · coupon vs maturity chart. So what: a coupon tells you about the past, not today's market
20. **Four of the five given prices are above £100: those gilts must yield less than their coupon** · given prices vs 100 bar; the 50-year at 94.96 is the only discount. So what: a first clue for Q1
21. **The four given yields rise with maturity, from 1.74% at 2 years to 4.36% at 30** · the given yields plotted with the gaps marked. So what: longer loans pay more, which sets up Q3
22. **Exhibit 1 is a simplified classroom data set: from 10 years out its yields sit about one point above the real market** · chart: Exhibit 1 vs real DMO yields on 9 May 2014 (10-year 2.80% vs 4.04%; ~30-year 3.39% vs 4.36%; ~50-year 3.36% vs 4.24%) [src]. Shape: the real curve rose 240bp from ~1 to 10 years (0.40% → 2.80%), Exhibit 1 rises 331bp (0.73% → 4.04%); the real long end is flatter. So what: we analyse the exhibit's numbers and use the real data only as context
23. **None of the nine is an exact real gilt, so we keep the case's labels** · no certain coupon-and-maturity match in the DMO list (user rule: name only if certain); nearest real gilts for context [src]
24. **The task: work out four prices and five yields, then test all nine against a rate rise** · roadmap; Exhibit 1 assumes annual coupons (stated here and tested on slides 55–56)

## 3 · Q1: coupon rate vs YTM
25. Divider · 03 Q1: coupon rate vs yield to maturity
26. **Q1: how do the coupon rate and the YTM differ, and what does that do to price?** · question in three parts: define, compare, effect on price
27. **The coupon rate fixes the cash; the YTM is the return the market demands today** · two definitions; example: 20-year 4¾% pays £4.75 a year whatever happens, but the market now wants 4.38% (derived on slide 52)
28. **YTM is the bond's internal rate of return, and it is only earned under three conditions** · Plain: internal rate of return (IRR) = the one discount rate that makes the PV of the cash flows equal the price. Conditions: held to maturity, no default, coupons reinvested at the YTM (CFA FI LM10)
29. **Reinvesting coupons at less than the YTM lowers the return actually earned** · Plain: realised return = what you actually earn, given the rate you reinvest coupons at. In words first: each coupon is invested until maturity and grows with interest; adding them up gives a standard formula. Coupons grow to FV = C × [(1+r)^N − 1]/r, the bracket being the "future-value annuity factor": at 4.38%, 4.75 × 30.9641 = 147.08 (+100 = 247.08); at 2%, 4.75 × 24.2974 = 115.41 (+100 = 215.41). So what: lower reinvestment rates leave much less cash at the end
30. **On the 20-year gilt, the return falls from 4.38% to 3.66% if coupons earn 2%** · in words: the yearly rate that grows the price paid into the cash at the end; realised return = (215.41/104.93)^(1/20) − 1 = 3.66%; at 0%, 3.15%. So what: if rates fall, a holder earns less than the YTM promised (reinvestment risk)
31. **Coupon rate, current yield and YTM give three different answers for the same bond** · Plain: current yield = annual coupon ÷ price (ignores the gain or loss at maturity). Table for all nine, each row with its numbers (e.g. 3.25 ÷ 102.50 = 3.17%; 7-year: 5.00% / 5.00 ÷ 108.91 = 4.59% / 3.54% (derived on slide 51)). So what: only the YTM counts the whole return
32. **A bond's price is the present value of its cash flows, discounted at the YTM** · formula in words first ("each payment is worth less the later it comes"), then P = Σ C/(1+y)^t + 100/(1+y)^N with each symbol explained (CFA FI LM06)
33. **When the yield rises, the price falls** · price–yield curve for the 7-year 5% gilt, its given price 108.91 at 3.54% (derived on slide 51) marked. So what: price and yield always move in opposite directions
34. **YTM below the coupon means a price above £100; above it, below £100** · rule with given yields only: 2-year (1.74% < 5.25%) and 30-year (4.36% < 4.50%) → premium; 5-year (3.00% > 2.75%) and 10-year (4.04% > 3.75%) → discount; par shown as a hypothetical
35. **A premium or discount shrinks to zero as the gilt nears repayment** · Plain: pull to par. Year-by-year price path of a premium and a discount gilt (chart). So what: on the repayment date every gilt is worth exactly £100
36. **Coupons and yields differ because Bank Rate fell from 5.75% in 2007 to 0.50% in 2009** · Bank Rate step chart: 4.75% (Aug 2006) → 5.75% (Jul 2007) → 0.50% (Mar 2009), unchanged to 2014 [src: BoE Bank Rate history, D2]; case p.2: "the coupon rate usually reflects the market interest rate at the time of the first issue". So what: high-coupon gilts date from higher-rate years
37. **Q1 answer: the coupon sets the cash; the yield sets the price** · three-line summary

## 4 · Q2: fill in the missing values
38. Divider · 04 Q2: the missing prices and yields
39. **Q2: four prices and five yields are missing** · question; gaps highlighted; two tasks (price from yield; yield from price)
40. **Assumptions: annual coupons, priced on a coupon date, per £100** · each with a reason; no accrued interest, so clean = full price. Plain: clean price = the quoted price; full price = clean + accrued interest; accrued interest = interest earned since the last coupon, paid on top when a bond is sold between coupon dates
41. **Price from yield, step 1: list the 5-year gilt's cash flows** · £2.75 a year for 4 years, then £102.75
42. **Step 2: discount each cash flow at 3.00%** · table: year, cash flow, discount factor 1/1.03^t, PV (2.67, 2.59, 2.52, 2.44, 88.63). Plain: discount factor = what £1 paid in year t is worth today
43. **Step 3: add them up: the 5-year gilt is worth £98.86** · sum. So what: below £100, because 3.00% > 2.75%
44. **A shortcut gives the same answer: the coupons as an annuity plus the PV of £100** · Plain: annuity = equal payments every year. P = C × [1 − (1+y)^−N]/y + 100/(1+y)^N → 2.75 × 4.5797 = 12.5942; + 86.2609 = £98.8551 ≈ £98.86. So what: two methods, one answer; the shortcut saves work on the long gilts
45. **The 2-year gilt at 1.74% is worth £106.84** · formula → 5.25 × 1.9490 + 96.61 → result. So what: a premium, because 1.74% < 5.25%
46. **The 10-year gilt at 4.04% is worth £97.65** · 3.75 × 8.0948 = 30.3555; + 67.2971 = 97.6526 ≈ 97.65 (unrounded 97.6525). So what: a discount
47. **The 30-year gilt at 4.36% is worth £102.32** · 4.50 × 16.5606 + 27.80. So what: a small premium
48. **Yield from price, the easy case: the 1-year gilt yields 0.73%** · 102.50 = 103.25/(1+y) → 1+y = 1.007317 → y = 0.73%. So what: buyers accept 0.73% because the gilt pays 3.25% on a price of 102.50 and loses £2.50 at repayment
49. **Longer gilts need a search: try two yields whose prices sit either side of the target** · Plain: "bracketing". 3-year at 107.02: at 2% the price is 107.21, at 3% it is 104.24, so the yield is between 2% and 3%
50. **Estimate in proportion, then check: the 3-year gilt yields 2.06%** · Plain: interpolation = assume the price falls in a straight line between the two tries. 2% + (107.21 − 107.02)/(107.21 − 104.24) × 1% = 2.064%; exact 2.063%; reprice at 2.063% = 107.02 ✓. So what: the check reprices to 107.02, so 2.06% is right
51. **The 7-year gilt at £108.91 yields 3.54%** · bracket (3%: 112.46; 4%: 106.00) → interpolate 3.550% → exact 3.541% → check ✓. So what: 3.54% is below the 5% coupon, so the gilt sells at a premium, as slide 34's rule says
52. **The 20-year gilt at £104.93 yields 4.38%** · bracket (4%: 110.19; 5%: 96.88) → 4.395% → exact 4.375% → check ✓. So what: below the 4¾% coupon, so a premium; the straight-line guess was 2bp too high
53. **The 50-year gilt at £94.96 yields 4.24%** · bracket (4%: 100.00; 5%: 81.74) → 4.276% → exact 4.245% → check ✓. So what: for long bonds the straight-line estimate is further off, so the check matters
54. **Exhibit 1 complete: six gilts trade above £100, three below; yields run from 0.73% to 4.38%** · full table; computed cells in bold and accent (readable in grey)
55. **Real gilts pay twice a year: a worked example** · 2-year at 1.74% a year = 0.87% per half-year; four payments of £2.625 → 2.602 + 2.580 + 2.558 + 99.130 = £106.87 (vs £106.84 annual). Plain: the yield is still quoted as an annual rate, compounded twice a year. So what: £0.03 more than the annual answer
56. **Paying twice a year changes prices by at most £0.03 and yields by at most 1bp** · the one semi-annual comparison (user choice): table for all nine with the numbers plugged in, P = C/2 × [1 − (1+y/2)^−2N]/(y/2) + 100/(1+y/2)^2N, yields to 4 dp; rows: 1-year: price 102.50 given: solved semi-annual yield 0.7362% (annual-pay 0.7317%); check 1.625 × 1.989011 + 100/1.007376 = 3.2321 + 99.2678 = 102.50 (annual-pay 102.50); 2-year: yield 1.7400% given: 2.625 × 3.914491 + 100/1.035257 = 10.2755 + 96.5944 = 106.87 (annual-pay 106.84); 3-year: price 107.02 given: solved semi-annual yield 2.0743% (annual-pay 2.0628%); check 2.25 × 5.788085 + 100/1.063865 = 13.0232 + 93.9969 = 107.02 (annual-pay 107.02); 5-year: yield 3.0000% given: 1.375 × 9.222185 + 100/1.160541 = 12.6805 + 86.1667 = 98.85 (annual-pay 98.86); 7-year: price 108.91 given: solved semi-annual yield 3.5512% (annual-pay 3.5406%); check 2.5 × 12.299657 + 100/1.279415 = 30.7491 + 78.1607 = 108.91 (annual-pay 108.91); 10-year: yield 4.0400% given: 1.875 × 16.319918 + 100/1.491786 = 30.5998 + 67.0337 = 97.63 (annual-pay 97.65); 20-year: price 104.93 given: solved semi-annual yield 4.3775% (annual-pay 4.3751%); check 2.375 × 26.471409 + 100/2.377516 = 62.8696 + 42.0607 = 104.93 (annual-pay 104.93); 30-year: yield 4.3600% given: 2.25 × 33.294196 + 100/3.647152 = 74.9119 + 27.4187 = 102.33 (annual-pay 102.32); 50-year: price 94.96 given: solved semi-annual yield 4.2437% (annual-pay 4.2445%); check 2.0 × 41.355467 + 100/8.163330 = 82.7109 + 12.2499 = 94.96 (annual-pay 94.96). So what: the case's annual simplification is safe

## 5 · Q3: the yield curve
57. Divider · 05 Q3: the yield curve
58. **Q3: plot the yield curve the nine gilts make, then describe and explain its shape** · question in three parts: (1) plot the nine YTMs against years to maturity (60); (2) describe the shape in numbers (61); (3) explain it: spot and forward rates (62–67), the three theories (68–70), caveats (71)
59. **A yield curve shows the yield on one borrower's bonds at each maturity** · definition; why it matters (it is the benchmark for all UK borrowing)
60. **Exhibit 1's curve rises steeply to 10 years, is flat to 30, and falls to 4.24% at 50** · line chart of the nine YTMs on a true-scale years axis
61. **In numbers: +331bp from 1 to 10 years, +34bp to 20, then −2bp and −12bp** · step bars. So what: almost all the rise happens in the first ten years
62. **A YTM mixes many payment dates; a spot rate is the yield for a single payment date** · Plain: spot rate = the yield on a single payment due at one date (like a zero-coupon bond). Plain: forward rate = the one-year rate for a future year that today's prices lock in (CFA FI LM09)
63. **Step 1: the 1-year spot rate is the 1-year yield, 0.73%** · one payment, so YTM = spot. So what: one payment, so nothing to average; this anchors the next step
64. **Step 2: the 2-year gilt reveals a 2-year spot rate of 1.77%** · 106.84 = 5.25/1.007317 + 105.25/(1+z2)²; take away the year-1 coupon's PV: 106.84 − 5.21 = 101.63; so (1+z2)² = 105.25/101.63 = 1.0356; z2 = 1.77%. Plain: "bootstrapping" = using shorter rates to unlock the next one. So what: the 2-year spot rate sits just above the 2-year YTM (1.74%), because the YTM also averages in the lower 1-year rate
65. **Step 3: the 3-year gilt reveals a 3-year spot rate of 2.09%** · 107.02 = 4.5/1.007317 + 4.5/1.017659² + 104.5/(1+z3)³; 107.02 − 4.4673 − 4.3452 = 98.2075; (1+z3)³ = 104.5/98.2075 = 1.0641; z3 = 2.09%. So what: again just above the YTM (2.06%); on a rising curve, spot rates sit above coupon-bond yields
66. **Step 4: the curve implies 1-year rates of 2.81% next year and 2.75% the year after, vs 0.73% now** · Plain: "1y1y" = the one-year rate starting in one year; "2y1y" = starting in two years. in words: two years at the 2-year spot rate must earn the same as one year at the 1-year rate and then one year at the forward rate, so the forward = (1+z2)² ÷ (1+z1) − 1. 1y1y = 1.017659² ÷ 1.007317 − 1 = 1.035629 ÷ 1.007317 − 1 = 2.81%; 2y1y = 1.020917³ ÷ 1.017659² − 1 = 1.064074 ÷ 1.035629 − 1 = 2.75%. So what: the exhibit's curve implies rates rising sharply. Caveat: this is the exhibit's curve, not the 2014 market's
67. **Hindsight test: rates did not rise; Bank Rate was cut to 0.25% in August 2016** · [src: BoE]. So what: a curve shows expectations plus a premium, not a forecast that comes true
68. **Three theories explain why curves rise, and each predicts a different shape** · expectations / liquidity preference / segmentation side by side. Plain: term premium = extra yield for lending longer; preferred habitat = investors who prefer certain maturities and need extra yield to move away from them (segmentation = they never move)
69. **The steep short end fits rising rate expectations plus a term premium** · links slides 66–68; Bank Rate 0.50% in 2014 [src]
70. **The long end flattens and dips, most likely because pension funds and insurers want long gilts** · preferred habitat; they held 27% of gilts in 2014 [src]; and the thinly traded 50-year (slide 8) would normally need more yield, so its lower yield is further sign of strong long-end demand. Competing explanations, in plain words (both explained fully in Q4, slides 108–110): investors pay up for long bonds' extra price gains when rates fall, and coupon differences shift yields. Evidence is suggestive, not proof: the real 9 May 2014 dip was only 3bp
71. **Caution: this is a curve of coupon-bond yields; the spot curve sits slightly differently** · YTM vs spot for 1–3 years (0.73/1.74/2.06 vs 0.73/1.77/2.09)
72. **Q3 answer: a curve that rises steeply, flattens, and dips slightly at the long end** · summary with the chart thumbnail

## 6 · Q4: what if all yields rise by 1%?
73. Divider · 06 Q4: a 1% rise in all yields
74. **Q4: every yield rises by one percentage point at the same moment** · Plain: parallel shift = the whole curve moves up by the same amount (3.00% → 4.00%); instantaneous = no time passes, so no pull to par. Parts: (a) reprice all nine at the new yields (75–85); (b) which falls most and why: duration (96–107); (c) how good the duration estimate is: convexity (109–114); (d) what it means for investors (125–126); plus the money at risk per 1bp (86–95) and a falling-rate check (115–124). One line: real curves can also twist (shaping risk), which Q4 does not ask about
75. **At 1.73%, the 1-year gilt falls from 102.50 to 101.49 (−0.98%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 1.7317% (old yield + 1%, to 4 dp): 3.25 × 0.982978 + 100/1.017317 = 3.1947 + 98.2978 = 101.4925 = 101.49; change 101.4925/102.5000 − 1 = −0.98%. So what: a tiny move for a short gilt
76. **At 2.74%, the 2-year gilt falls from 106.84 to 104.82 (−1.89%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 2.7400% (old yield + 1%, to 4 dp): 5.25 × 1.920703 + 100/1.055551 = 10.0837 + 94.7373 = 104.8210 = 104.82; change 104.8210/106.8409 − 1 = −1.89%. So what: about twice the 1-year's fall, because the money comes back later
77. **At 3.06%, the 3-year gilt falls from 107.02 to 104.06 (−2.77%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 3.0628% (old yield + 1%, to 4 dp): 4.5 × 2.825200 + 100/1.094727 = 12.7134 + 91.3470 = 104.0604 = 104.06; change 104.0604/107.0200 − 1 = −2.77%. So what: about three times the 1-year's fall
78. **At 4.00%, the 5-year gilt falls from 98.86 to 94.44 (−4.47%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 4.0000% (old yield + 1%, to 4 dp): 2.75 × 4.451822 + 100/1.216653 = 12.2425 + 82.1927 = 94.4352 = 94.44; change 94.4352/98.8551 − 1 = −4.47%. So what: the 5-year loses about 4½ times what the 1-year loses
79. **At 4.54%, the 7-year gilt falls from 108.91 to 102.70 (−5.70%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 4.5406% (old yield + 1%, to 4 dp): 5.0 × 5.883956 + 100/1.364567 = 29.4198 + 73.2833 = 102.7031 = 102.70; change 102.7031/108.9100 − 1 = −5.70%. So what: less than 7 years suggests, because the high 5% coupon returns money early
80. **At 5.04%, the 10-year gilt falls from 97.65 to 90.06 (−7.78%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 5.0400% (old yield + 1%, to 4 dp): 3.75 × 7.706757 + 100/1.635111 = 28.9003 + 61.1579 = 90.0582 = 90.06; change 90.0582/97.6525 − 1 = −7.78%. So what: the 10-year loses about 8 times what the 1-year loses
81. **At 5.38%, the 20-year gilt falls from 104.93 to 92.45 (−11.89%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 5.3751% (old yield + 1%, to 4 dp): 4.75 × 12.075203 + 100/2.849443 = 57.3572 + 35.0946 = 92.4518 = 92.45; change 92.4518/104.9300 − 1 = −11.89%. So what: about 12 times the 1-year's loss
82. **At 5.36%, the 30-year gilt falls from 102.32 to 87.31 (−14.67%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 5.3600% (old yield + 1%, to 4 dp): 4.5 × 14.761224 + 100/4.789309 = 66.4255 + 20.8798 = 87.3053 = 87.31; change 87.3053/102.3185 − 1 = −14.67%. So what: the loss keeps growing, but more slowly with each extra decade
83. **At 5.24%, the 50-year gilt falls from 94.96 to 78.11 (−17.74%)** · formula in words first on 75 (each coupon and the £100 discounted at the new yield; shortcut as on slide 44); new yield 5.2445% (old yield + 1%, to 4 dp): 4.0 × 17.587377 + 100/12.881619 = 70.3495 + 7.7630 = 78.1125 = 78.11; change 78.1125/94.9600 − 1 = −17.74%. So what: the longest gilt loses 18 times as much as the shortest
84. **All nine together: the longer the gilt, the bigger the fall** · table + bar chart of % change by maturity
85. **In money: on £100m of each gilt, a 1% rise costs £1.0m on the 1-year and £16.8m on the 50-year** · £m table, each row with its numbers (e.g. £102.5m → £101.5m = −£1.0m). So what: this is the number a trading desk watches
86. **PVBP: the 50-year gilt loses about £197.7 thousand per £100m for every 1bp rise** · Plain: PVBP (price value of a basis point) = money lost for a 0.01% rise. In words: reprice at a yield 1bp lower and 1bp higher, and take half the gap. Price if the yield is 1bp lower (4.2345%): 95.1580; 1bp higher (4.2545%): 94.7626; (95.1580 − 94.7626)/2 = 0.1977 per £100 of face; £100m is 1,000,000 × £100, so 0.1977 × 1,000,000 = £197,700 = £197.7 thousand per £100m. So what: a desk knows each 1bp move costs about £0.2m on £100m of the 50-year, which is what it hedges
87. **1-year PVBP: £10.2 thousand per £100m** · (102.5102 at 0.7217% − 102.4898 at 0.7417%)/2 = 0.0102. So what: almost no rate risk
88. **2-year PVBP: £20.5 thousand per £100m** · (106.8614 at 1.7300% − 106.8204 at 1.7500%)/2 = 0.0205. So what: twice the 1-year
89. **3-year PVBP: £30.2 thousand per £100m** · (107.0502 at 2.0528% − 106.9898 at 2.0728%)/2 = 0.0302. So what: rising in step with maturity
90. **5-year PVBP: £45.5 thousand per £100m** · (98.9006 at 2.9900% − 98.8096 at 3.0100%)/2 = 0.0455. So what: about 4½ times the 1-year
91. **7-year PVBP: £64.4 thousand per £100m** · (108.9744 at 3.5306% − 108.8456 at 3.5506%)/2 = 0.0644. So what: the high coupon keeps it below 7 times the 1-year
92. **10-year PVBP: £79.8 thousand per £100m** · (97.7323 at 4.0300% − 97.5728 at 4.0500%)/2 = 0.0798. So what: about 8 times the 1-year
93. **20-year PVBP: £135.8 thousand per £100m** · (105.0659 at 4.3651% − 104.7943 at 4.3851%)/2 = 0.1358. So what: 13 times the 1-year
94. **30-year PVBP: £168.4 thousand per £100m** · (102.4870 at 4.3500% − 102.1503 at 4.3700%)/2 = 0.1684. So what: still rising, but more slowly
95. **PVBP rises from £10.2 thousand to £197.7 thousand per £100m: 19 times from shortest to longest** · summary table of the nine (from 86–94). So what: hedging the long end needs far more cover per £ held
96. **Duration measures how long, on average, you wait for a bond's money** · Plain: Macaulay duration = the average time to each payment, weighted by its PV. See-saw picture
97. **The 5-year gilt: Macaulay duration 4.74 years** · step table: t, CF, PV, weight (PV ÷ price), t × weight → sum 4.74. So what: 90% of the value arrives in year 5, so the duration is close to the 5-year maturity
98. **Modified duration turns waiting time into price sensitivity: 4.60% per 1% of yield** · ModD = MacD/(1+y) = 4.74/1.03 = 4.60; %ΔP ≈ −ModD × Δy (CFA FI LM11). So what: predicts −4.60% vs the actual −4.47%
99. **The 1-year gilt: duration 1.00 year, modified 0.99** · sum(t × PV)/P = 102.50/102.50; one payment, so duration = maturity. So what: one payment, so duration equals maturity
100. **The 2-year gilt: duration 1.95, modified 1.92** · table: t1 PV 5.1602 (t × PV 5.1602); t2 PV 101.6807 (203.3615); sum 208.52 ÷ 106.84 = 1.95 → ÷1.0174 = 1.92. So what: just under the maturity, because the early coupon pulls the average wait down
101. **The 3-year gilt: duration 2.88, modified 2.82** · table: t × PV 4.4090 + 8.6399 + 294.8730 = 307.92 ÷ 107.02 = 2.88 → ÷1.0206 = 2.82. So what: again just under the maturity
102. **For longer gilts a CFA shortcut gives duration in one line: the 7-year's is 6.12** · in words first: "a ready-made formula that gives the same answer as adding t × PV for every payment"; symbols: c = coupon rate, y = yield, N = years. Macaulay = (1+y)/y − [(1+y) + N(c−y)]/[c((1+y)^N − 1) + y] = 29.2437 − 1.137563/0.049195 = 29.2437 − 23.1235 = 6.12; cross-check Σ(t × PV)/P = 666.55/108.91 = 6.12; modified 6.12/1.0354 = 5.91. So what: a 1% rise should cost about 5.9% (actual −5.70%, slide 79)
103. **The 10-year gilt: duration 8.50, modified 8.17** · shortcut: 25.7525 − 1.011400/0.058623 = 25.7525 − 17.2526 = 8.50 → ÷1.0404 = 8.17. So what: a 1% rise should cost about 8.2% (actual −7.78%, slide 80)
104. **The 20-year gilt: duration 13.51, modified 12.94** · shortcut: 23.8567 − 1.118733/0.108100 = 23.8567 − 10.3491 = 13.51 → ÷1.0438 = 12.94. So what: a 1% rise should cost about 12.9% (actual −11.89%, slide 81)
105. **The 30-year gilt: duration 17.17, modified 16.45** · shortcut: 23.9358 − 1.085600/0.160495 = 23.9358 − 6.7641 = 17.17 → ÷1.0436 = 16.45. So what: a 1% rise should cost about 16.5% (actual −14.67%, slide 82)
106. **The 50-year gilt: duration 21.70, modified 20.82** · shortcut: 24.5598 − 0.920186/0.322130 = 24.5598 − 2.8566 = 21.70 → ÷1.0424 = 20.82; only 14% of its value sits in the final £104 (weight 0.137); the other 86% is coupons spread over 50 years. So what: that is why a 50-year gilt behaves like a 22-year loan
107. **Modified duration ranks the risk from 0.99 (1-year) to 20.82 (50-year)** · table of Macaulay and modified duration, columns labelled
108. **Same maturity, lower coupon, more risk** · hypothetical 10-year gilts at 0%, 3.75% and 8%, yield 4.04% → 5.04% (annuity factors 8.0948 → 7.7068; PV of £100 67.30 → 61.16): 0%: 67.30 → 61.16 = −9.12%; 3.75%: 3.75 × 8.0948 + 67.30 = 97.65 → 3.75 × 7.7068 + 61.16 = 90.06 = −7.78%; 8%: 8 × 8.0948 + 67.30 = 132.06 → 8 × 7.7068 + 61.16 = 122.81 = −7.00%. Plain: the coupon effect: low coupons push the money later. Real example: today the 0½% 2061 gilt has a modified duration of 26.75 and trades at £23.41, against 15.73 for the 4% 2060, which matures 21 months earlier [src, secondary]. So what: lower coupon, far more risk
109. **For long gilts, duration overstates the fall: −20.82% predicted vs −17.74% actual** · estimate vs actual, all nine
110. **Convexity: the price–yield line curves, so prices fall less than the straight line predicts** · Plain: convexity = how much the line bends. Chart with the duration tangent line
111. **Convexity of the 10-year gilt: 81.56** · formula in words first; 10-row table of t, CF, PV, t(t+1) × PV (7.21 … 7,680.29), sum 8,620.9; ÷ (97.65 × 1.0824) = 81.56. So what: the 10-year bends only a little; convexity adds back just 0.41% on a 1% rise (slide 113)
112. **Convexity of the 50-year gilt: 701** · in words first: reprice the bond at a yield 0.05% lower and 0.05% higher; the amount by which the two prices together beat twice today's price measures the bend (CFA price-based method). P₋ (yield 4.1945%) = 95.956890; P₊ (yield 4.2945%) = 93.979753; (95.956890 + 93.979753 − 2 × 94.960000) = 0.016643; ÷ (94.96 × 0.0005² = 0.00002374) = 701.05, matching the cash-flow formula (701.03). So what: almost nine times the 10-year's bend (701.03 ÷ 81.56 = 8.6)
113. **Duration plus convexity: −7.76% for the 10-year (actual −7.78%)** · %ΔP ≈ −8.17 × 1% + ½ × 81.56 × (1%)² = −8.17% + 0.41%. So what: adding convexity brings the estimate within 0.02% of the actual fall
114. **For the 50-year a gap remains: −17.31% estimated vs −17.74% actual** · −20.82% + ½ × 701.03 × (1%)² = −20.82% + 3.51% = −17.31%. Why: two terms cannot capture all the bending over a move as big as 1%. Cross-check with price-based measures at ±1%: Plain: approximate modified duration = (price if yields fall 1% − price if they rise 1%) ÷ (2 × price × 1%) = (118.57 − 78.11)/(2 × 94.96 × 0.01) = 21.30; approximate convexity = (118.5672 + 78.1122 − 2 × 94.96)/(94.96 × 0.01²) = 6.7595/0.009496 = 711.82; −21.30% + ½ × 711.82 × (1%)² = −17.74%, which matches by construction because both are built from those same two prices
115. **Falling yields help more than rising yields hurt: +24.86% vs −17.74% on the 50-year** · new yield 3.2445% (old yield − 1%, to 4 dp): 4.0 × 24.576771 + 100/4.935672 = 98.3071 + 20.2607 = 118.5678 = 118.57 (24.576771 = annuity factor for 50 years at 3.2445%; 4.935672 = 1.032445⁵⁰); change 118.5678/94.9600 − 1 = +24.86%. So what: convexity is good for the holder
116. **If yields fell 1%, the 1-year would gain only 1.00%, to 103.53** · new yield −0.2683% (old yield − 1%, to 4 dp): 3.25 × 1.002690 + 100/0.997317 = 3.2587 + 100.2690 = 103.5277 = 103.53; change 103.5277/102.5000 − 1 = +1.00%. Plain: a negative yield means buyers pay more than they will get back; the formula still works. So what: gain (+1.00%) and loss (−0.98%) are almost equal for a short gilt
117. **If yields fell 1%, the 2-year would gain 1.95%, to 108.92** · new yield 0.7400% (old yield − 1%, to 4 dp): 5.25 × 1.978017 + 100/1.014855 = 10.3846 + 98.5362 = 108.9208 = 108.92; change 108.9208/106.8409 − 1 = +1.95%. So what: +1.95% vs −1.89%: a small gap appears
118. **If yields fell 1%, the 3-year would gain 2.87%, to 110.10** · new yield 1.0628% (old yield − 1%, to 4 dp): 4.5 × 2.937344 + 100/1.032224 = 13.2180 + 96.8782 = 110.0962 = 110.10; change 110.0962/107.0200 − 1 = +2.87%. So what: +2.87% vs −2.77%
119. **If yields fell 1%, the 5-year would gain 4.73%, to 103.54** · new yield 2.0000% (old yield − 1%, to 4 dp): 2.75 × 4.713460 + 100/1.104081 = 12.9620 + 90.5731 = 103.5351 = 103.54; change 103.5351/98.8551 − 1 = +4.73%. So what: +4.73% vs −4.47%
120. **If yields fell 1%, the 7-year would gain 6.13%, to 115.59** · new yield 2.5406% (old yield − 1%, to 4 dp): 5.0 × 6.339590 + 100/1.191986 = 31.6980 + 83.8936 = 115.5916 = 115.59; change 115.5916/108.9100 − 1 = +6.13%. So what: +6.13% vs −5.70%
121. **If yields fell 1%, the 10-year would gain 8.59%, to 106.04** · new yield 3.0400% (old yield − 1%, to 4 dp): 3.75 × 8.512816 + 100/1.349145 = 31.9231 + 74.1210 = 106.0441 = 106.04; change 106.0441/97.6525 − 1 = +8.59%. So what: +8.59% vs −7.78%: the gap widens with maturity
122. **If yields fell 1%, the 20-year would gain 14.14%, to 119.76** · new yield 3.3751% (old yield − 1%, to 4 dp): 4.75 × 14.374374 + 100/1.942311 = 68.2783 + 51.4851 = 119.7634 = 119.76; change 119.7634/104.9300 − 1 = +14.14%. So what: +14.14% vs −11.89%
123. **If yields fell 1%, the 30-year would gain 18.59%, to 121.34** · new yield 3.3600% (old yield − 1%, to 4 dp): 4.5 × 18.718940 + 100/2.695101 = 84.2352 + 37.1044 = 121.3396 = 121.34; change 121.3396/102.3185 − 1 = +18.59%. So what: +18.59% vs −14.67%
124. **Up vs down for all nine: the longer the gilt, the more a fall helps than a rise hurts** · table and paired bars (from 115–123). So what: convexity grows with maturity
125. **Long gilts paid little extra yield for much more risk** · scatter: YTM vs modified duration. So what: +3.5 points of yield for 21 times the risk
126. **Short gilts suit investors who may need cash soon; long gilts suit those with long-term promises** · who should hold which (pension funds vs a bank treasury)
127. **Q4 answer: all prices fall, long gilts by far the most; duration predicts it, convexity refines it** · summary

## 7 · Epilogue
128. Divider · 07 Epilogue
129. **What we found: coupon ≠ return, a rising curve, and risk that grows with maturity** · four findings, one per question
130. **After 2014 gilt yields kept falling, to a record low of 0.12% in August 2020** · BoE 10-year par yield: 2.77% (9 May 2014) → 0.12% (4 Aug 2020, lowest since the series began in 1993) [src]
131. **After the 2016 Brexit vote, S&P cut the UK from AAA to AA** · June 2016 [src, secondary: Euronews]
132. **From December 2021 the Bank raised Bank Rate 14 times, from 0.10% to 5.25% by August 2023** · Bank Rate chart [src: BoE, D]
133. **September 2022: pension funds' borrowed bets forced gilt sales, and the Bank had to step in** · Plain: LDI (liability-driven investment) = strategies pension schemes use to match their assets to their long-term promises (BoE FSR Dec 2022 [src]), often with borrowed money; falling gilt prices forced them to post cash (margin calls) and sell gilts. BoE bought £19.3bn, 28 Sep – 14 Oct 2022 [src]
134. **Our 1% scenario happened in 2022: gilt yields rose more than 100bp in four days** · [src: Bank Underground, a BoE staff blog]; the 30-year went "from around 3.8% to 5% in just three days" [src, secondary: LBC]; Bank Underground: "a 100 basis point increase in yields for a 20 year gilt maps to roughly a 20% price fall" vs our −11.89% (20-year); the gap is the coupon effect (slide 108) plus 2022's lower starting yields [src]. So what: the risk Q4 measures was real
135. **Meanwhile the Bank was reversing QE: it stopped reinvesting in February 2022 and began selling in November** · Plain: QT (quantitative tightening) = the reverse of QE [src: BoE]; holdings down from £895bn to £488bn [src]
136. **A real 50-year gilt shows Q4 in practice: the 4% 2060 fell from £114.76 to £75.28** · a real gilt, not the case's bond (it shares the 4% coupon); DMO yields (semi-annual basis): 3.37% → 5.66% (+229bp, from the DMO's 3-dp figures 3.365% and 5.658%); modified duration 22.24 alone predicts −51.0%; an instant 229bp rise on the 2014 bond already gives −36.4% (convexity), and the other ~2 points come from 12 years passing; actual −34.4% (modified duration today 15.73) [src: DMO 2014; today secondary, giltsyield.com]
137. **Today Bank Rate is 3.75% and gilt yields are higher than in 2014 at every maturity** · today's curve (secondary: giltsyield.com, DMO-yield column) vs Exhibit 1 vs real May 2014 (DMO) (chart) [src]; next Bank Rate decision Thursday 5 November 2026 [src: BoE MPC dates for 2026, D3] (re-check before submission)
138. **Lessons: coupon is not return, the curve carries information, long gilts carry far more risk** · closing

## 8 · Team
139. **Group 10** · [PLACEHOLDER] members' photos, full names, student IDs (until supplied)

---

## Instructions checklist
| Requirement (Case Presentation Instructions) | Slides |
|---|---|
| Overview: background, "business model", industry/competition, key financial information, main problem | 4–16 |
| External sources in the overview | 5, 7–13 |
| Every exhibit rebuilt, explained, key numbers, meaning, implications | 18–24 |
| Each question stated and broken into parts | 26, 39, 58, 74 |
| Theories and frameworks | 28–35, 44, 62–71, 96–115 |
| Evidence from the case and external sources, per question | Q1: 36 · Q2: 22 · Q3: 67, 70 · Q4: 134, 136 |
| Assumptions explained | 28, 40, 55–56, 66, 74 |
| Alternatives compared | 31 (three yield measures), 44 (two pricing methods), 55–56 (annual vs semi-annual), 108 (coupons), 109–124 (duration vs convexity; up vs down), 126 |
| Every calculation shown step by step, one slide per repeat | 29–30, 41–56, 63–66, 75–124 |
| Epilogue: findings, turning points, outcome, after the case, today | 129–138 |
| Final slide with photo, name, ID | 139 |

## Old → new slide numbers (round 4 → round 5)
1–57 → 1–57 · new 58 (Q3 stated) · 58–72 → 59–73 · 73 → 74 (Q4 parts) · 74–84 → 75–85 · 85 → 86 (PVBP worked) · new 87–95 (PVBP per bond + summary) · 86–104 → 96–114 · 105 → 115 (−1% worked) · new 116–124 (−1% per bond + summary) · 106–120 → 125–139

## Response to the strict review round 5 (NOT READY on reproducibility; A− once fixed)
- **B1:** every +1% (75–83), −1% (115–123) and semi-annual (56) display is now printed by `r5_displays()` in calcs.py from the numbers shown: yields to 4 dp, factors to 6 dp, terms to 4 dp, the 4-dp sum, then the 2-dp price; the % change is computed from the 4-dp prices. The script asserts each shown result equals the exact answer. 115's label is now 1.032445⁵⁰.
- **B2:** 65 (98.2075), 102–106 (6-dp inputs), 108 (0% and 8% steps), 114 (711.82 step, +3.51%), 46 (30.3555 + 67.2971 = 97.6526 ≈ 97.65).
- **B3:** 137's date sourced to the BoE "MPC dates for 2026" page (D3, exact row).
- **Non-blocking taken:** 1 (66 forward in words), 2 (86 £ conversion), 3 (30 in words), 4 (133 retitled to the mechanism), 5 (135 "Meanwhile"), 6 (136 "not the case's bond"), 7 (22 "from 10 years out"), 8 (114 +3.51%), 9 (13 dates footnoted), 10 partly (138 trimmed; 55 so-what; chart data for 33/35/110 left for the build, from calcs functions already used).

## Earlier: response to the strict review round 4 (NOT READY, B+; A− once fixed)
All five blocking items accepted; displays regenerated by `r4_extras()` in `calcs.py`.
- **B1:** Q3 stated with three parts (58); Q4 broken into parts (74).
- **B2:** 112 prices to 6 dp (701.05 reproduces); 66 spot rates to 6 dp (2.81% / 2.75% reproduce); 103 denominator 0.05862 (and 0.04919 / 0.10810 / 0.16050 / 0.32213 on 102–106); 29 factors 30.9641 / 24.2974; 64–65 rearrangement steps.
- **B3:** 7 S&P labelled secondary (PTI); 132 retitled to the sourced 14 rises; 134 retitled to the sourced "more than 100bp in four days" plus LBC's 30-year (secondary); "the long end moved most" dropped.
- **B4:** put to the user (2026-10-30). Answer "Mix (Recommended)": PVBP gets one slide per bond (86–95) and the −1% check one slide per bond (115–124); the semi-annual check stays ONE comparison (56) with every bond's numbers plugged in. Current yield (31) and money rows (85) carry their numbers in each row.
- **B5:** "So what" added to 44, 50–52, 63–65, 76–82, 86–94, 97, 99–106, 111, 113, 116–124; the six slides that lost the reader fixed: 112 (method in words, P₋/P₊ labelled), 114 (approximate modified duration defined and derived), 115 (24.5767 and 4.9357 labelled), 108 (26.75 vs 15.73), 86 (inputs labelled), 102 (symbols, words, Σ(t × PV) check).
- **Non-blocking taken:** 1 (24 → slides 55–56), 2 (31, 33), 3 (old 4% 2060 line marked SUPERSEDED in calcs.py), 4 (36: BoE Bank Rate history logged as D2, 5.75% → 0.50%), 5 (136: −36.4% instant shock computed in calcs.py; yields at 2 dp), 6 (titles 2, 11, 15, 66, 126, 135, 138 trimmed; 138 reworded), 7 (74 instantaneous), 8 (22 reworded with +240bp vs +331bp), 9 (PVBP in £ thousand; 137 column named; 13 dates; 2.77 vs 2.80 footnote), 10 (68 preferred habitat; 70 liquidity line).

## Earlier rounds (numbers refer to the round-3/round-4 plan)
### Response to the strict review round 3 (NOT READY, A− once fixed)
- **B1:** slide 96 corrected (14% of value in the final payment).
- **B2:** slide 117 now compares like with like (semi-annual yields): +229bp, duration estimate −51.0%; durations labelled modified.
- **B3:** slide 98 uses the sourced 0½% 2061 facts (secondary); slide 10 says "holders"; slide 36 limited to sourced Bank Rate; slide 118 labels giltsyield.com as secondary; slide 7 names exactly which ratings it shows.
- **B4:** duration tables for the 2- and 3-year gilts; the CFA closed form for 7–50 years; convexity 10-row table (10-year) and 5bp price-based method (50-year); slide 104's cross-check independent.
- **Lucidity (six slides):** Bank Rate (10), clean/full price (40), the FV formula in words (29), forward references on 69, "2y1y" (65) and par yield (13).

### Response to the strict review (round 2: NOT READY, B+)
- **B1 (repeats):** +1% repricing for all nine; duration for all nine; convexity split; worked −1% and PVBP before their tables.
- **B2:** one convexity measure throughout (analytic), the price-based measure as a labelled cross-check.
- **B3:** reinvestment FV formula; semi-annual worked example; bootstrap split into steps.
- **B4:** `work/gilts/sources.md` built; primary sources for 12, 13, 111, 116; secondary labelled.
- **B5:** slide 113 says December 2021.
- **B6 (lucidity):** primer (15); every term defined where first used; concepts before use; so-whats.
- **B7:** label titles turned into points; long titles shortened.
