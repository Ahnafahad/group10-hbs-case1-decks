NOT READY. Grade estimate B+ as it stands; A− once the three blocking items below are fixed. The analysis, structure, sourcing and lucidity now meet the A bar, and all five r4 blocking items were dealt with. What still fails is the user's own test that every displayed calculation reproduces on a calculator from the numbers shown. Most of the failures are on the new slides added to fix r4. On the slides that re-price a bond whose yield was solved from its price, the yield is shown to 2 dp but the price was computed from the exact yield. So the shown yield gives a different price: at "5.24%" the 50-year is worth 78.18, not 78.11. Slide 115's new label "4.9357 = 1.0324⁵⁰" is false (1.0324⁵⁰ = 4.9249). Two more cross-check results have no steps (slides 108 and 114). Every fix is display-level; no analysis changes.

# UK Gilts: strict review of the gate 1 storyline, round 5

Reviewed: `review/gilts/01-storyline.md` (139 slides). Checked against the rubric, the grading brief, `case-layout.txt`, `UK Gilts.xlsx.md`, CLAUDE.md, DESIGN.md, PROGRESS.md (including the 2026-10-30 "Mix (Recommended)" entry), a live run of `python3 work/gilts/calcs.py` (2026-10-30), `exhibits.csv`, `answers.md`, `sources.md` (including the rows added 2026-10-30) and `sources_research.md`. I skimmed the G1 NESA benchmark (268 slides). I recomputed every displayed calculation independently in Python from the numbers as printed in the plan, not from calcs.py, and also re-solved the semi-annual yields and the 4% 2060 instant shock. I did not take the "Response to the strict review" section as evidence. I checked each claim in it against the slide lines.

## 0. Round 4 blocking items: fixed or not (old → new slide numbers)

| r4 item | Status | Evidence in the plan (round 5) |
|---|---|---|
| B1 · Q3 never stated (old 57–58) | **FIXED** | New slide 58 states the Q3 question in three parts with slide pointers (60; 61; 62–67, 68–70, 71). The checklist cites 58. |
| B1 · Q4 not broken into parts (old 73) | **FIXED** | Slide 74 lists (a)–(d) plus PVBP and the falling-rate check, with slide ranges. All the ranges are correct in the new numbering. It also adds "instantaneous" and a one-line note on twisting. |
| B2 · old 102 (50-year convexity) does not reproduce | **FIXED** | Slide 112 shows P₋ 95.956890 and P₊ 93.979753 (I re-priced both exactly). 0.016643 ÷ 0.00002374 = 701.05. |
| B2 · old 65 forwards do not reproduce | **FIXED** | Slide 66: 1.035629/1.007317 − 1 = 2.81% and 1.064074/1.035629 − 1 = 2.75%. Both reproduce; the 6th-dp inputs are within rounding (my 1.035630 / 1.064073). |
| B2 · old 93 (8.49 vs 8.50) | **FIXED for the result; new slip in the intermediates** | Slide 103: 25.7525 − 1.0114/0.05862 → 8.499 → 8.50 ✓. But the quotient printed (17.2526) is not what the printed numbers give (17.2535). The same happens on 102 (1.1376/0.04919 = 23.1267, printed 23.1236), 104 (10.3488 vs 10.3491) and 105 (6.7639 vs 6.7641). The cause: the numerators and denominators were rounded but the quotient was not recomputed. See B2. |
| B2 · old 29 FV factors | **FIXED** | Slide 29: 4.75 × 30.9641 = 147.08 ✓; 4.75 × 24.2974 = 115.41 ✓; the factor is labelled. |
| B2 · old 63–64 bootstrap rearrangement | **PARTLY FIXED** | Slide 64 reproduces: 106.84 − 5.21 = 101.63 → 1.0356 → 1.77% ✓. Slide 65 does not: as printed, 107.02 − 4.47 − 4.35 = **98.20**, not 98.21 (exactly, 107.02 − 4.4673 − 4.3452 = 98.2075). See B2. |
| B3 · slide 7 S&P not labelled secondary | **FIXED** | "S&P AAA (2014) [src, secondary: PTI]". |
| B3 · old 113 "inflation returned" unsourced | **FIXED** | Slide 132 is retitled to the sourced 14 rises, 0.10% → 5.25%. I counted the 14 rows in sources D. |
| B3 · old 115 "long end moved most" unsourced | **FIXED** | Slide 134 is retitled "more than 100bp in four days" (Bank Underground, exact quote). The 30-year "3.8% to 5% in just three days" is labelled LBC, secondary. The unsourced claim is gone. |
| B4 · repeated calculations shown as tables | **FIXED (decision)** | Put to the user; the answer "Mix (Recommended)" is recorded word for word in PROGRESS.md. PVBP: worked 86 plus 87–94 = nine slides plus summary 95 ✓. −1%: worked 115 plus 116–123 = nine plus summary 124 ✓. Semi-annual: one comparison (56) with the numbers plugged in, after the worked example (55) ✓. 31 and 85 carry numbers in each row ✓. **But the new per-bond −1% slides carry display errors (B1).** |
| B5 · missing so-whats | **FIXED** | Present on every slide r4 listed: 44, 50–52, 63–65, 75–83, 86–94, 97, 99–106, 111, 113, 116–123. |
| B5 · six slides that lost the reader | **5 FIXED, 1 FIXED WITH A NEW ERROR** | 112 (method in words, P₋/P₊ labelled) ✓; 108 (26.75 vs 15.73; 21 months checked: Jan 2060 → Oct 2061) ✓; 86 (inputs labelled) ✓; 102 (symbols, words, Σ(t × PV) check 666.55/108.91 = 6.12) ✓; 114 (approximate modified duration defined and derived: 40.46/1.8992 = 21.30) ✓, though approximate convexity 711.82 is still stated without its step (B2). **115:** the labels were added, but "4.9357 = 1.0324⁵⁰" is false. 1.0324⁵⁰ = 4.9249, and the annuity factor at 3.24% is 24.5973, which gives 118.69, not 118.57. The numbers belong to 3.2445%. See B1. |
| r4 non-blocking 1–10 | **All taken** | 24 → 55–56 ✓; 31 and 33 "(derived on slide 51)" ✓; old 4% 2060 line marked SUPERSEDED in calcs.py ✓; 36 uses D2 ✓; 136 has −36.4% (I re-derived −36.41%) ✓; titles trimmed (138 still 105 characters) ✓; 74 instantaneous ✓; 22 +240bp vs +331bp ✓; PVBP in £ thousand, 137 column named, 13 dated, 2.77/2.80 footnote ✓; 68 preferred habitat, 70 liquidity line ✓. |

**Did the fixes introduce new errors?** Yes, three kinds, all display-level: (1) the new −1% slides (115–123) and the semi-annual price-given rows (56) print rounded yields next to factors computed at the exact yields, plus two sums that do not add up (119, 122); (2) the same problem on the +1% titles (75–83); (3) the closed-form quotients on 102–105 (above). The plan's claim (line 9) that "the round-4 block prints every display below" is also untrue for 75–83: calcs.py prints no formula-and-numbers lines for the +1% repricings.

## 1. Verdict
**NOT READY. B+ as it stands; A− once B1–B3 are fixed.** Hard requirements failing: H3 (two cross-check calculations with no steps), H4 (one unsourced fact), H8 (displayed calculations that do not reproduce). Quality: Q5 = 3; the rest are 4–5.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover placeholder); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37, Q2 38–56, Q3 57–72, Q4 73–127; Epilogue 128–138; team slide 139 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (case p.3, "Source: IMD research"). It is rebuilt natively on 18 with "?" for blanks. What it shows (18–19); key numbers (19–21, all checked against exhibits.csv); meaning (22, against the DMO's 9 May 2014 data; +240bp vs +331bp checked); implication (23–24). |
| H3 Every question, all seven elements | **FAIL (narrow)** | Q1 (26), Q2 (39), Q3 (58) and Q4 (74) are each stated and split into parts. Theory, evidence, assumptions and alternatives pass for all four. Steps missing for two calculated results: **108**, the hypothetical 0% and 8% coupon 10-year gilts (−9.12% and −7.00% shown as results only); **114**, approximate convexity 711.82 (stated with no formula and no numbers). |
| H4 External sourced facts | **FAIL (one fact)** | Supported (section 4b): 7, 9, 10, 11, 12, 13, 22, 36, 67, 108, 130, 131, 132, 133, 134, 135, 136, 137 (Bank Rate 3.75%, curve higher at every maturity). **137 "next Bank Rate decision 5 Nov 2026"** has no exact quote in either sources file. sources.md row 98 only asserts it, and its URL is the Bank Rate history table, which does not list meeting dates. |
| H5 No teaching note | PASS | No citation, quotation or reference. 22 now says "simplified classroom data set". |
| H6 Titles | PASS | Every content title states a finding. One runs long: 138 (105 characters, may wrap to 3 lines). The per-bond titles (87–94, 99–106) are "label: number" but still state a result. |
| H7 Finance correct | PASS | Checked: YTM as IRR and its three conditions (28); realised return (29–30); current yield (31); price = PV (32); the premium/discount rule (34); pull to par (35); clean/full/accrued (40); bracketing and interpolation, then an exact solve and a reprice check (49–53); the semi-annual convention (55–56); bootstrap, and the spot-above-YTM logic on a rising curve (64–65); forwards (66); the three theories, with preferred habitat now correct (68); PVBP as the average of ±1bp (86); Macaulay and modified duration (96–98); the CFA closed form (102); annual analytic convexity (111); price-based convexity (112); "matches by construction" (114) is correct algebra; convexity asymmetry (115–124); 136's decomposition (instant shock −36.41%, my recomputation, against duration-only −51.0% and actual −34.4%). No conceptual errors. |
| H8 Numbers right | **FAIL (reproducibility)** | All 52 numbers checked match calcs.py or the sources (section 4a). But the user's rule is that every displayed calculation reproduces from the numbers shown, and on these slides it does not: 75–83 (yields), 115–123 (yields and labels; sums on 119 and 122), 56 (price-given rows), 65, 102–105 (quotients). Details are in B1 and B2. The gaps are beyond rounding: 78.18 vs 78.11, 92.40 vs 92.45, 118.69 vs 118.57, 1.9442 vs 1.9423. Formats follow the rules; PVBP in £ thousand to 1 dp is a stated choice, logged in PROGRESS.md, and clear. |
| H9 User decisions | PASS | Annual coupons plus one semi-annual comparison (40, 55–56). No case bond is given a real gilt name (23); real gilts appear only as labelled context (13, 22, 108, 136). "Mix": PVBP and −1% one slide per bond, semi-annual one comparison with the numbers plugged in. Every other repeat has one slide each (41–53, 75–83, 97–106). |
| H10 Known traps | PASS | Annual-coupon simplification stated (24, 40) and tested (55–56). Per £100 (5, 15, 40). Duration and convexity explain the +1% shift (96–114). |
| H11 Lucidity | PASS | Every term has a "Plain:" line where it first appears; formulas are put in words first; every calculation slide has a so-what; concepts come before use, and the forward references are explicit and correct. No analysis has been cut. Three slides would still slow this reader (non-blocking 1–3): 66 (why the forward formula divides is never put in words), 86 (how 0.1977 per £100 becomes £197.7 thousand per £100m), 30 (the realised-return formula is not put in words). That is fewer than a handful, so H11 passes. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Far beyond the four questions, and claims are tested: reinvestment risk, three yield measures, bootstrap and forwards with a hindsight test, PVBP for every bond, duration two ways, convexity two ways, up/down asymmetry, the exhibit against the real 2014 curve, and a real-bond test of Q4 with the instant shock separated out. |
| Q2 Logic and flow | 4 | Clean arc; every cross-reference is correct in the new numbering. Docked for: 133 and 134 both lead with "over 100bp in four days"; 135 "Then … February 2022" comes after the September 2022 slides. |
| Q3 Evidence | 4 | Strong primary sources (ONS, DMO, BoE, US Treasury, Bundesbank); secondary sources labelled. Docked for the unquoted 5 Nov 2026 date. |
| Q4 Lucidity | 4 | Definitions and so-whats throughout; three small gaps (66, 86, 30). |
| Q5 Calculations | **3** | Q2 and the duration tables are exemplary. But about 20 displays do not reproduce from what is printed (B1, B2), one new label is false (115), and two results have no steps (108, 114). These are exactly the checks the user cares about. |
| Q6 Overview and epilogue | 4 | Current to 27–29 Oct 2026 and tied back to Q4 (134, 136). Docked for the unsourced date on 137. |

## 4a. Number spot-check (52 numbers; my recomputation unless stated)

| # | Number | Slide | Source | Match |
|---|---|---|---|---|
| 1 | 4.75 × 30.9641 = 147.08; 4.75 × 24.2974 = 115.41 | 29 | calcs r4 block; factor at 4.3751% = 30.9642 | yes |
| 2 | (215.41/104.93)^(1/20) − 1 = 3.66%; 3.15% at 0% | 30 | mine 3.662% / 3.147% | yes |
| 3 | 3.25 ÷ 102.50 = 3.17%; 5.00 ÷ 108.91 = 4.59% | 31 | mine | yes |
| 4 | PVs 2.67/2.59/2.52/2.44/88.63 → 98.86 | 42–43 | calcs example A | yes |
| 5 | 2.75 × 4.5797 = 12.5942; + 86.2609 = 98.8551 | 44 | mine 12.594175 | yes |
| 6 | 5.25 × 1.9490 + 96.61 = 106.84 | 45 | mine 106.842 | yes |
| 7 | 3.75 × 8.0948 = 30.3554 | 46 | mine **30.3555** | rounding (last digit) |
| 8 | 4.50 × 16.5606 + 27.80 = 102.32 | 47 | mine 102.3227 | yes |
| 9 | 103.25/102.50 = 1.007317 | 48 | mine | yes |
| 10 | 107.21 / 104.24 → 2.064% → 2.063% | 49–50 | mine 107.2097 / 104.2429 | yes |
| 11 | 3.550 / 4.395 / 4.276% interpolations | 51–53 | mine 3.5495 / 4.3952 / 4.2760 | yes |
| 12 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | mine | yes |
| 13 | 10-year semi: 1.875 × 16.3199 + 100/1.4918 = 97.63 | 56 | mine 97.633 | yes |
| 14 | 50-year semi "at 4.24%": 2.0 × 41.3552 + 100/8.1635 = 94.96 | 56 | factors at 4.24% are 41.3811 / 8.1486; the numbers belong to 4.2437% | **no (B1)** |
| 15 | z2: 106.84 − 5.21 = 101.63 → 1.0356 → 1.77% | 64 | mine 1.7654% | yes |
| 16 | z3: 107.02 − 4.47 − 4.35 = 98.21 | 65 | as printed = **98.20**; exact 98.2075 | **no (B2)** |
| 17 | 1y1y 2.81%, 2y1y 2.75% from 6-dp inputs | 66 | mine 2.8107 / 2.7464% | yes |
| 18 | +331 / +34 / −2 / −12bp | 61 | calcs Q3 | yes |
| 19 | 50-year "at 5.24%" → 78.11 (−17.74%) | 83 | at 5.24%: **78.18**; at 5.2445%: 78.11 | **no (B1)** |
| 20 | 20-year "at 5.38%" → 92.45 | 81 | at 5.38%: **92.40**; at 5.3751%: 92.45 | **no (B1)** |
| 21 | 1-, 2-, 5-, 10-, 30-year +1% prices | 75, 76, 78, 80, 82 | mine at the shown yields | yes |
| 22 | £1.0m / £16.8m on £100m | 85 | calcs £100m block | yes |
| 23 | PVBP 50-year (95.1580 − 94.7626)/2 = 0.1977 → £197.7k | 86 | mine 0.19770 | yes |
| 24 | PVBP 1/2/3/5/7-year: 0.0102/0.0205/0.0302/0.0455/0.0644 | 87–91 | mine from the printed prices; exact 0.01018/0.0205/0.03017/0.04547/0.06438 | yes |
| 25 | PVBP 10/20/30-year: 0.0798/0.1358/0.1684 | 92–94 | printed prices give 0.07975/0.1358/0.16835 | yes (rounding) |
| 26 | "19 times"; "about 4½"; "below 7"; "about 8"; "13 times" | 90–95 | 19.4; 4.46; 6.3; 7.8; 13.3 | yes |
| 27 | MacD 4.74; ModD 4.74/1.03 = 4.60 | 97–98 | mine 4.7377; 4.602 | yes |
| 28 | 5.1602 + 203.3615 = 208.52 → 1.95 → 1.92 | 100 | mine 208.5217; 1.9517; 1.918 | yes |
| 29 | 307.92/107.02 = 2.88 → 2.82 | 101 | mine 2.8772; 2.819 | yes |
| 30 | 7-year closed form 29.2437 − 1.1376/0.04919 = 29.2437 − 23.1236 | 102 | 1.1376/0.04919 = **23.1267** (result 6.117 → 6.12) | result yes, intermediate **no (B2)** |
| 31 | 10-year 1.0114/0.05862 = 17.2526 → 8.50 | 103 | 1.0114/0.05862 = **17.2535** (result 8.499 → 8.50) | result yes, intermediate **no (B2)** |
| 32 | 20/30/50-year closed form → 13.51/17.17/21.70 | 104–106 | quotients printed 10.3491/6.7641/2.8566; from printed inputs 10.3488/6.7639/2.8566 | results yes; 104–105 intermediates off |
| 33 | ModD 5.91/8.17/12.94/16.45/20.82 | 102–106 | mine 5.911/8.170/12.943/16.453/20.817 | yes |
| 34 | Weight 0.137 (14%) on the final £104 | 106 | calcs t=50 0.1370 | yes |
| 35 | −9.12 / −7.78 / −7.00% coupon effect | 108 | mine (61.16/67.30; 122.81/132.06) | yes, **but no steps (B2)** |
| 36 | Convexity table sum 8,620.9 ÷ (97.65 × 1.0824) = 81.56 | 111 | row sum 8,620.87; 81.563 | yes |
| 37 | 6-dp convexity 701.05; 701.03/81.56 = 8.6 | 112 | mine 701.053; P± 95.95727 / 93.98012 exact | yes |
| 38 | −8.17 + 0.41 = −7.76% | 113 | mine | yes |
| 39 | −20.82 + ½ × 701.03 × (1%)² = −17.31% | 114 | printed gives −17.315 (a half-way case) | rounding (non-blocking 8) |
| 40 | (118.57 − 78.11)/(2 × 94.96 × 0.01) = 21.30 | 114 | mine 21.304 | yes |
| 41 | Approx. convexity 711.82 | 114 | (118.5672 + 78.1122 − 189.92)/0.009496 = 711.82 ✓, **but no step on the slide** | **step missing (B2)** |
| 42 | 50-year −1%: "at 3.24%" 4 × 24.5767 + 100/4.9357, "4.9357 = 1.0324⁵⁰" | 115 | 1.0324⁵⁰ = **4.9249**; factor at 3.24% = **24.5973** → 118.69. The printed numbers are for 3.2445% | **no (B1)** |
| 43 | 2-year −1%: 100/1.0149 = 98.54 | 117 | 100/1.0149 = **98.53** (exact 1.014855 → 98.54) | **no (B1)** |
| 44 | 3-year "at 1.06%": 1.0322 | 118 | 1.0106³ = **1.0321**; the number is for 1.0627% | **no (B1)** |
| 45 | 5-year: 12.96 + 90.57 = 103.54 | 119 | as printed = **103.53** | **no (B1)** |
| 46 | 7-year "at 2.54%": 1.1920 | 120 | 1.0254⁷ = **1.1919**; the number is for 2.5406% | **no (B1)** |
| 47 | 20-year "at 3.38%": 14.3744, 1.9423; 68.28 + 51.49 = 119.76 | 122 | at 3.38%: **14.368, 1.9442**; the sum as printed = **119.77** | **no (B1)** |
| 48 | 1-, 10-, 30-year −1% displays | 116, 121, 123 | mine | yes |
| 49 | −36.4% instant shock; −51.0%; −34.4%; +229bp | 136 | mine −36.41% (92 coupons, DMO 114.76 reproduced); 22.24 × 2.293 = 51.0; 75.28/114.76 − 1 = −34.40% | yes |
| 50 | "+3.5 points for 21 times the risk" | 125 | 4.24 − 0.73 = 3.51; 20.82/0.99 = 21.0 | yes |
| 51 | Six premium, three discount; 0.73–4.38% | 54 | calcs Q2 | yes |
| 52 | 127bp / 191bp; +240bp vs +331bp; 82.2% | 13, 22, 11 | mine | yes |

## 4b. External fact spot-check (13 facts)

| Slide | Claim | Sources file evidence | Supported? |
|---|---|---|---|
| 36 | Bank Rate 4.75% (Aug 2006) → 5.75% (Jul 2007) → 0.50% (Mar 2009), unchanged to 2014 | D2 rows `03 Aug 06 4.75`, `05 Jul 07 5.75`, `05 Mar 09 0.50`; D: next change `04 Aug 16` | yes (primary BoE) |
| 132 | 14 rises, 0.10% → 5.25%, Dec 2021 – Aug 2023 | D "Hikes 2021-2023": 14 rows, `16 Dec 21 0.25` … `03 Aug 23 5.25`; Covid low `19 Mar 20 0.10` | yes |
| 134 | ">100bp in four days"; 30-year 3.8% → 5% in three days; "100 basis point … 20 year gilt … roughly a 20% price fall" | E: Bank Underground exact quotes; LBC labelled secondary | yes |
| 133 | £19.3bn bought, 28 Sep – 14 Oct 2022; LDI definition; margin calls | E rows (BoE notices, Bailey remarks); 9c FSR quote | yes |
| 135 | Reinvestment stopped Feb 2022; sales from 1 Nov 2022; £895bn → £488bn | 6a, 6b; APF letter of 17 Sep 2026 | yes |
| 136 | 4% 2060: 114.76 / 3.365% / ModD 22.24 (2014); £75.28 / 5.658% / ModD 15.73 (today) | 8b (DMO, primary); 8a (giltsyield, secondary, labelled) | yes |
| 137 | Bank Rate 3.75%; today's curve above 2014 at every maturity | D `Current official Bank Rate 3.75%`; F rows 4.76–5.71% vs 2014's 0.40–3.39% | yes |
| 137 | Next decision 5 Nov 2026 | row 98 asserts it with no quote; the URL is the Bank Rate table | **no (B3)** |
| 130 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a `04 Aug 2020,0.1239`; series begins 1 Nov 1993 | yes |
| 108 | 0½% 2061: £23.41, ModD 26.75 | sources_research line 206 (secondary, labelled) | yes |
| 13 | 2.77 / 2.62 / 1.50%; 5.30 / 4.98 / 3.39% | 3b, 2a–2d | yes (dates differ, labelled) |
| 9 | £1,365bn → £2,817bn, same basis | 7a–7c | yes |
| 11 | 29% / 27% / 26% | GAR 29.2 / 26.6 / 26.4% | yes |

## 5. Blocking items (exact fixes)

**B1 · H8/Q5 · re-pricing slides print rounded yields but use exact ones (slides 56, 75–83, 115–123).**
Rule for all of them: wherever a yield that was solved from a price (1-, 3-, 7-, 20-, 50-year) is shifted or re-used, print it to 4 dp, and say once (slide 53 or 74) that "we carry the exact yield; 4.24% is 4.2445% rounded".
- **75–83 (+1%):** in the body, give the new yield to 4 dp: 1-year 1.7317%, 3-year 3.0627%, 7-year 4.5406%, 20-year 5.3751%, 50-year 5.2445%. Titles may keep 2 dp only if the body shows the exact yield. Add a line to calcs.py for each bond printing "C × factor + 100/(1+y)^N = … = P" at the exact yield, as `r4_extras` does for −1%.
- **115:** "at 3.2445% (4.2445% − 1%): 4 × 24.5767 + 100/4.9357 = 98.31 + 20.26 = 118.57, where 24.5767 = the annuity factor for 50 years at 3.2445% and 4.9357 = 1.032445⁵⁰." (The current "1.0324⁵⁰ = 4.9357" is false: it is 4.9249.)
- **116:** "at −0.2683%". **118:** "at 1.0627%". **120:** "at 2.5406%". **122:** "at 3.3751%: 4.75 × 14.3744 + 100/1.9423 = 68.2784 + 51.4851 = 119.76".
- **117:** "5.25 × 1.9780 + 100/1.014855 = 10.3845 + 98.5363 = 108.92" (as printed, 100/1.0149 = 98.53).
- **119:** "2.75 × 4.7135 + 100/1.1041 = 12.9621 + 90.5731 = 103.54" (as printed, 12.96 + 90.57 = 103.53).
- **56:** in the price-given rows, show the solved semi-annual yield to 4 dp: 1-year 0.7362%, 3-year 2.0743%, 7-year 3.5512%, 20-year 4.3775%, 50-year 4.2437% ("2.0 × 41.3552 + 100/8.1635 = 94.96 at 4.2437%"). The 2-dp column can stay as the summary.

**B2 · H3/H8 · other displays that do not reproduce, or have no steps (slides 46, 65, 102–105, 108, 114).**
- **65:** "107.02 − 4.4673 − 4.3452 = 98.2075; (1 + z3)³ = 104.5/98.2075 = 1.0641; z3 = 2.09%."
- **102–105:** print the numerator and denominator to 6 dp so the quotient follows: 7-year 1.137564/0.049195 = 23.1236; 10-year 1.011400/0.058623 = 17.2526; 20-year 1.118731/0.108100 = 10.3490; 30-year 1.085600/0.160495 = 6.7641. (Or keep the 4-dp inputs and print the quotients they give: 23.1267, 17.2535, 10.3488, 6.7639. The results do not change.)
- **108:** add the steps: "0% coupon: 100/1.0404¹⁰ = 67.30 → 100/1.0504¹⁰ = 61.16: −9.12%; 8% coupon: 8 × 8.0948 + 67.30 = 132.06 → 8 × 7.7068 + 61.16 = 122.81: −7.00%."
- **114:** add "approximate convexity = (P₋ + P₊ − 2P₀)/(P₀ × (1%)²) = (118.5672 + 78.1122 − 2 × 94.96)/(94.96 × 0.0001) = 6.7594/0.009496 = 711.82" (with 2-dp prices it gives 711.88, so use 4 dp).
- **46:** "3.75 × 8.0948 = 30.3555; + 67.2971 = 97.6526 ≈ 97.65" (or print the factor as 8.09477).

**B3 · H4 · slide 137, "next Bank Rate decision 5 Nov 2026", has no exact quote.**
Log the BoE's own page ("Monetary Policy Committee dates for 2026", https://www.bankofengland.co.uk/news/2024/december/mpc-dates-for-2026, or https://www.bankofengland.co.uk/monetary-policy/upcoming-mpc-dates) in sources.md with the exact row and the access date, then cite it. Otherwise drop the date.

## 6. Non-blocking improvements (most valuable first)
1. **66:** put the forward formula in words before the numbers: "investing for two years at the 2-year spot rate must give the same as one year at today's rate followed by one year at the forward rate, so forward = (1+z2)² ÷ (1+z1) − 1."
2. **86:** say how per £100 becomes per £100m: "£100m is one million lots of £100, so 0.1977 × 1,000,000 = £197,700."
3. **30:** in words: "the realised return is the yearly growth rate that turns 104.93 into 215.41 over 20 years."
4. **133 and 134** both lead with "over 100bp in four days". Make 133 about the mechanism (LDI, margin calls, the Bank's £19.3bn) and keep the size for 134.
5. **135:** "Then … reinvestment stopped in February 2022" comes after the September 2022 slides. Reword to "Alongside the rate rises" or move it before 133.
6. **136:** add "(a real gilt, not the case's 50-year bond)". It shares the 4% coupon, and slide 23 says none of the nine is a real gilt.
7. **22:** "about one point above" holds from 10 years out (1.24 / 0.97 / 0.88 points) but not at 1 year (0.33). Say "up to 1¼ points, from 10 years out". Keep the number order the same as the label (Exhibit vs real).
8. **114:** print "+3.51%" instead of "½ × 701.03 × (1%)²" alone, so the reader gets −17.31 rather than the half-way −17.315.
9. **13:** the 191bp spread mixes 27 Oct (UK) with 29 Oct (Germany). Footnote it, or use the same date for both.
10. **Plan line 9 / calcs.py:** add the +1% displays (B1) and the chart data for 33, 35 and 110 to calcs.py so builders never compute by hand. Trim title 138 (105 characters). Add a one-line so-what to 55.
