NOT READY. Grade estimate A− on content; it fails only H8 (displays that do not reproduce), on two narrow items. All three r5 blocking items are fixed, and every one of the roughly 60 per-bond displays rebuilt in round 6 (+1%, −1%, semi-annual) now reproduces exactly from the numbers shown. Two problems remain, and both are display labels, not analysis. (1) **Slide 29** labels a factor "at 4.38%" but uses the factor at the exact yield 4.3751%. At 4.38% a calculator gives 147.16, not 147.08. r5 marked this fixed, but the fix is wrong. (2) **On the 50-year gilt (slides 86, 112, 114)** the yields are printed to 4 dp while the prices beside them, shown to 4–6 dp, were computed at the exact yield 4.244519%. Re-pricing at the printed 4.1945% gives 95.957267, not 95.956890, and the convexity comes out at about 732, not 701. Slide 114 also prints 118.5672 and 78.1122 for the same two prices that slides 115 and 83 print as 118.5678 and 78.1125. Each fix is one line.

# UK Gilts: strict review of the gate 1 storyline, round 6

Reviewed: `review/gilts/01-storyline.md` (139 slides, round 6). Checked against: the rubric; the grading brief; `case-layout.txt`; `UK Gilts.xlsx.md`; CLAUDE.md and DESIGN.md; PROGRESS.md, including the 2026-10-30 "Mix (Recommended)" entry and the decision to show 4-dp yields and 6-dp factors. Also: a live run of `python3 work/gilts/calcs.py` (2026-10-30; it runs clean and every assert passes), `exhibits.csv`, `answers.md`, `sources.md` (including D2 and D3), `sources_research.md`, and a skim of the G1 NESA benchmark (268 slides). I used `UK Gilts Questions.docx.md` only to check answers; all of them match. I recomputed every displayed calculation in my own Python, from the numbers **as printed in the plan**, not from calcs.py. I also re-fetched BoE D2 and D3 live. I did not take the "Response to the strict review" section as evidence.

## 0. Round 5 blocking items: fixed or not

| r5 item | Status | Evidence (round 6 plan) |
|---|---|---|
| **B1 · 75–83 (+1%), 4-dp yields** | **FIXED** | All nine rebuilt from what is printed: the annuity factor at the printed 4-dp yield, (1+y)^N, both terms, the 4-dp sum and the % change. All match exactly, e.g. 50-year at 5.2445%: 4 × 17.587377 + 100/12.881619 = 70.3495 + 7.7630 = 78.1125 → −17.74%. 3-year at 3.0628% is right: the exact yield is 2.062804%, so r5's suggested 3.0627% was the slip. calcs.py now prints these lines (`r5_displays`), so plan line 9 is now true. |
| B1 · 115, label "4.9357 = 1.0324⁵⁰" | **FIXED** | Now at 3.2445%: 24.576771, and 1.032445⁵⁰ = 4.935672 ✓; 98.3071 + 20.2607 = 118.5678 ✓; +24.86% ✓. |
| B1 · 116, 118, 120, 122 (yields), 117 (100/1.0149), 119 and 122 (sums) | **FIXED** | 116 −0.2683% ✓; 117 100/1.014855 = 98.5362 ✓; 118 1.0628% gives 1.032224 ✓; 119 12.9620 + 90.5731 = 103.5351 ✓; 120 2.5406% gives 1.191986 ✓; 122 4.75 × 14.374374 + 100/1.942311 = 68.2783 + 51.4851 = 119.7634 ✓. 121 and 123 ✓. |
| B1 · 56, price-given rows | **FIXED** | All nine rows reproduce: 0.7362 / 2.0743 / 3.5512 / 4.3775 / 4.2437% solved; factors, discount terms and sums all match (e.g. 50-year 82.7109 + 12.2499 = 94.9608 → 94.96). |
| B2 · 65 | **FIXED** | 107.02 − 4.4673 − 4.3452 = 98.2075; 104.5/98.2075 = 1.0641; z3 = 2.09% ✓. |
| B2 · 102–105 quotients | **FIXED** | From the printed inputs: 1.137563/0.049195 = 23.1235(5) ✓; 1.011400/0.058623 = 17.2526 ✓; 1.118733/0.108100 = 10.3491 ✓; 1.085600/0.160495 = 6.7641 ✓; 106: 0.920186/0.322130 = 2.8566 ✓. Small new point: the yield used is never printed (non-blocking 4). |
| B2 · 108 steps | **FIXED** | 0% and 8% steps added; 132.06 → 122.81 = −7.00% ✓, 67.30 → 61.16 = −9.12% ✓. One last-digit slip on the 3.75% row (non-blocking 3). |
| B2 · 114 steps (711.82, +3.51%) | **FIXED, but a new mismatch** | The step is added. But 118.5672 + 78.1122 − 189.92 = **6.7594** (printed 6.7595). More importantly, these two prices differ from the ones slides 115 and 83 show for the same bond and yields (118.5678, 78.1125). See B2. |
| B2 · 46 | **FIXED** | 3.75 × 8.0948 = 30.3555; + 67.2971 = 97.6526 ≈ 97.65 ✓. |
| **B3 · 137, 5 Nov 2026** | **FIXED** | D3 has a URL, an access date and an exact quote. I re-fetched the page live: "Thursday 5 November \| November MPC Summary and November Monetary Policy Report", published 19 Dec 2024, headed "2026 provisional dates". It is primary (BoE). |
| r5 non-blocking 1–10 | **Taken** | 66 forward rate put in words ✓; 86 "£100m is 1,000,000 × £100" ✓; 30 in words ✓; 133 now about the mechanism ✓; 135 "Meanwhile" ✓; 136 "not the case's bond" ✓; 22 "from 10 years out" ✓ (number order still real-first, non-blocking 9); 114 +3.51% ✓; 13 dates footnoted ✓; 138 trimmed (87 characters) ✓; 55 so-what ✓. |
| r5's "29 FIXED" | **Fix is wrong (new B1)** | Slide 29 prints "at 4.38%, 4.75 × 30.9641 = 147.08". The factor at 4.38% is 30.9800, which gives 147.16 and 247.16. 30.9641 is the factor at the exact yield 4.3751%. r5 itself checked it at 4.3751%. This is the same defect r5 B1 fixed everywhere else. |

**Did the fixes introduce new errors?** Only the 50-year basis mismatch on 114 (B2). Everything else rebuilt in round 6 reproduces exactly.

## 1. Verdict
**NOT READY. Grade estimate A− on content.** One hard requirement fails: H8, through B1 (slide 29) and B2 (slides 86, 112 and 114 on the 50-year gilt). All quality scores are ≥ 4. Once B1 and B2 are fixed, I expect READY at A−.

## 2. Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Opening 1–2 (cover placeholder); Case overview 3–16; Exhibit analysis 17–24; Q1 25–37; Q2 38–56; Q3 57–72; Q4 73–127; Epilogue 128–138; team slide 139 (placeholder). |
| H2 Every exhibit | PASS | The case has one exhibit (p.3, "Source: IMD research"). It is rebuilt natively on 18, with "?" for the blanks, and every value matches `exhibits.csv`. What it shows: 18–19. Key numbers: 19–21 (four of five given prices above 100; given yields 1.74 → 4.36%). Meaning: 22 (against the DMO's 9 May 2014 data: 2.80/4.04, 3.39/4.36, 3.36/4.24; +240bp vs +331bp, all checked). Implication: 23–24. |
| H3 Every question, seven elements | PASS | Stated and split into parts: Q1 26, Q2 39, Q3 58, Q4 74. Theory: 28, 32, 34–35, 44, 49–50, 62, 68, 86, 96, 98, 110–112. Evidence, case and external: 36; 22; 67, 70; 134, 136. Assumptions: 28, 40, 55–56, 66, 74. Alternatives: 31, 44, 55–56, 108, 109–124, 126. Every calculated result now has its steps, including 108 and 114. The one minor gap is the 0% case on 30, whose 195 is not shown (non-blocking 7). |
| H4 External, sourced, current | PASS | Every fact I checked (section 4b) is supported by an exact quote. D2 and D3 were re-verified live. Current to 27–29 Oct 2026. Secondary sources are labelled (7, 131, 134 LBC, 136, 137, 108). |
| H5 No teaching note | PASS | No citation, quotation or reference in the plan. 22 says "simplified classroom data set". |
| H6 Titles | PASS | Every content title states a finding. Longest: 22 (116 characters) and 135 (106), which could wrap to 3 lines at headline size (non-blocking 9). |
| H7 Finance correct | PASS | YTM as IRR and its three conditions (28); realised return and reinvestment risk (29–30); current yield (31); price = PV (32); the premium/discount rule (34); pull to par (35); clean = full on a coupon date (40); bracketing, interpolation, exact solve and reprice (49–53); the semi-annual convention (55–56); bootstrapping, with spot above YTM on a rising curve (64–65); forwards by no-arbitrage (66); expectations, liquidity and preferred habitat (68); PVBP as the average of ±1bp (86); Macaulay and modified duration (96–106); the CFA closed form (102); analytic and price-based convexity (111–112); the duration + convexity estimate (113–114); "matches by construction" (114) is correct algebra; asymmetry (115–124); the coupon effect (108); the real-bond decomposition (136: instant shock −36.4%, duration only −51.0%, actual −34.4%). No conceptual errors. |
| H8 Numbers right | **FAIL (narrow)** | All 58 numbers I checked match calcs.py, exhibits.csv or the sources (section 4a). Every round-6 per-bond display reproduces. Two places do not reproduce from what is printed, beyond last-digit rounding: **29** (147.08 printed; 147.16 at the printed 4.38%) and **the 50-year gilt on 86, 112 and 114** (prices printed to 4–6 dp beside 4-dp yields, at a different basis; on 112 re-pricing at the printed yields gives convexity ≈ 732, not 701; 114 contradicts 83 and 115). Formats follow the rules; the 4-dp yields and 6-dp factors are a logged decision. |
| H9 User decisions | PASS | Annual coupons plus exactly one semi-annual comparison (55 worked, 56 the comparison with every bond's numbers plugged in). No case bond is given a real name (23); real gilts appear only as labelled context. "Mix": PVBP one slide per bond (86–94 + summary 95), −1% one slide per bond (115–123 + summary 124). Every other repeat has its own slide (41–53, 75–83, 97–106). |
| H10 Known traps | PASS | Annual coupons stated (24, 40) and tested (55–56); per £100 (5, 15, 40); duration and convexity explain the +1% shift (96–114). |
| H11 Lucidity | PASS | Every term has a "Plain:" line where it first appears; formulas come in words first; numbers are labelled; every calculation slide has a so-what; concepts come before use. **The 4-dp and 6-dp displays:** readable for this reader because there is one bond per slide, one line of working, the result in 2 dp, and "(old yield + 1%, to 4 dp)" on each. They would be easier still if each per-bond slide carried a one-line label of the two factors. Today only 115 does, and 116–123 have no formula line at all (non-blocking 5). Slide 56 is the densest slide in the deck (9 rows × about 10 columns at 18pt), and the plan does not say how it fits (non-blocking 6). I count no slide that would lose this reader outright. |

## 3. Quality scores

| | Score | Reason |
|---|---|---|
| Q1 Depth | 5 | Far beyond the four questions, and claims are tested: reinvestment risk, three yield measures, bootstrap and forwards with a hindsight test, PVBP for every bond, duration two ways, convexity two ways, up/down asymmetry, the coupon effect, the exhibit against the real 2014 curve, and a real-bond test of Q4 that separates out the instant shock. |
| Q2 Logic and flow | 4 | Clean arc; every cross-reference I followed (e.g. 31 → 51, 74's part ranges, 91 → 108–110, 134 → 108) is correct. Docked slightly for density in Q4 (52 slides) and 56. |
| Q3 Evidence | 5 | Primary sources (ONS, DMO, BoE, US Treasury, Bundesbank) for almost every fact; secondary sources labelled; D2 and D3 both verified live by me. |
| Q4 Lucidity | 4 | Definitions, words-before-numbers and so-whats throughout. Not 5 because 116–123 drop the formula line and factor labels, and 56 is crowded. |
| Q5 Calculations | 4 | The ~60 rebuilt displays all reproduce, and the r5 problems are gone. Docked for B1 and B2, and for a few last-digit sums (43, 85, 108). |
| Q6 Overview and epilogue | 5 | Current to 27–29 Oct 2026; tied back to Q4 by the 2022 move (134), the real 4% 2060 (136) and today's curve vs 2014 (137); next MPC date sourced. |

## 4a. Number spot-check (58 numbers; my recomputation from the printed inputs)

| # | Number | Slide | Source | Match |
|---|---|---|---|---|
| 1 | 4.75 × 30.9641 = 147.08 "at 4.38%" | 29 | factor at 4.38% = **30.9800** → 147.16; 30.9641 is at 4.3751% | **no (B1)** |
| 2 | 4.75 × 24.2974 = 115.41 at 2% | 29 | 24.29737 | yes |
| 3 | (215.41/104.93)^(1/20) − 1 = 3.66%; 3.15% at 0% | 30 | 3.6617%; 3.1470% | yes |
| 4 | 3.25 ÷ 102.50 = 3.17%; 5.00 ÷ 108.91 = 4.59% | 31 | 3.1707; 4.5909 | yes |
| 5 | PVs 2.67/2.59/2.52/2.44/88.63 → 98.86 | 42–43 | the printed PVs sum to **98.85** (exact 98.8551) | rounding, last digit (non-blocking 2) |
| 6 | 2.75 × 4.5797 = 12.5942; + 86.2609 = 98.8551 | 44 | 12.594175 | yes |
| 7 | 5.25 × 1.9490 + 96.61 = 106.84 | 45 | 106.8423 | yes |
| 8 | 3.75 × 8.0948 = 30.3555; + 67.2971 = 97.6526 | 46 | exact | yes |
| 9 | 4.50 × 16.5606 + 27.80 = 102.32 | 47 | 102.3227 | yes |
| 10 | 103.25/102.50 = 1.007317 | 48 | 1.0073171 | yes |
| 11 | 107.21 / 104.24; 2.064% | 49–50 | 107.2097 / 104.2429; 2.0640 | yes |
| 12 | 112.46/106.00 → 3.550% | 51 | 112.4606 / 106.0021; 3.5495 | yes |
| 13 | 110.19/96.88 → 4.395%; "2bp too high" | 52 | 110.1927 / 96.8844; 4.3952 − 4.3751 | yes |
| 14 | 100.00/81.74 → 4.276% | 53 | 100.0000 / 81.7441; 4.2760 | yes |
| 15 | 2.602 + 2.580 + 2.558 + 99.130 = 106.87 | 55 | mine | yes |
| 16 | semi 1-year: 1.625 × 1.989011 + 100/1.007376 = 102.50 at 0.7362% | 56 | 3.2321 + 99.2678 | yes |
| 17 | semi 3-year at 2.0743% → 107.02 | 56 | 13.0232 + 93.9969 | yes |
| 18 | semi 10-year: 30.5998 + 67.0337 = 97.63 | 56 | mine | yes |
| 19 | semi 50-year at 4.2437%: 82.7109 + 12.2499 = 94.96 | 56 | 41.355467; 8.163330 | yes |
| 20 | 106.84 − 5.21 = 101.63 → 1.0356 → 1.77% | 64 | 1.7654% | yes |
| 21 | 107.02 − 4.4673 − 4.3452 = 98.2075 → 2.09% | 65 | 2.0917% | yes |
| 22 | 1.035629/1.007317 − 1 = 2.81%; 1.064074/1.035629 − 1 = 2.75% | 66 | 2.8106; 2.7466 | yes |
| 23 | +331 / +34 / −2 / −12bp | 61 | from 0.7317 / 4.04 / 4.3751 / 4.36 / 4.2445 | yes |
| 24 | 1-year +1%: 3.1947 + 98.2978 = 101.4925; −0.98% | 75 | mine | yes |
| 25 | 3-year +1% at 3.0628%: 12.7134 + 91.3470 = 104.0604 | 77 | 2.825200; 1.094727 | yes |
| 26 | 7-year +1% at 4.5406%: 102.7031; −5.70% | 79 | mine | yes |
| 27 | 20-year +1% at 5.3751%: 57.3572 + 35.0946 = 92.4518; −11.89% | 81 | mine | yes |
| 28 | 50-year +1% at 5.2445%: 70.3495 + 7.7630 = 78.1125; −17.74% | 83 | mine | yes |
| 29 | 2-, 5-, 10-, 30-year +1% | 76, 78, 80, 82 | mine, all four | yes |
| 30 | £16.8m on £100m (50-year) | 85 | 94.96 − 78.1125 = 16.8475 ✓; but £95.0m → £78.1m printed as a row gives 16.9 | yes (row display: non-blocking 1) |
| 31 | PVBP 50-year (95.1580 − 94.7626)/2 = 0.1977 → £197.7k | 86 | arithmetic ✓; but at the printed 4.2345% / 4.2545% the prices are **95.1584 / 94.7630** | arithmetic yes; labels **no (B2)** |
| 32 | PVBP 1/2/3/5/30-year prices at the printed yields | 87–90, 94 | all match to 4 dp | yes |
| 33 | PVBP 7/20-year prices | 91, 93 | 108.9745 / 108.8457; 105.0658 / 104.7942 (printed one lower or higher in the 4th dp) | rounding |
| 34 | "19 times", "about 4½", "below 7", "about 8", "13 times" | 90–95 | 19.4; 4.46; 6.3; 7.8; 13.3 | yes |
| 35 | MacD 4.74; 4.74/1.03 = 4.60 | 97–98 | 4.602 | yes |
| 36 | 5.1602 + 203.3615 = 208.52; 1.95; 1.92 | 100 | 208.5217; 1.9517; 1.9167 | yes |
| 37 | 307.92/107.02 = 2.88; 2.82 | 101 | 307.9219; 2.8772; 2.8219 | yes |
| 38 | 29.2437 − 23.1235 = 6.12; 666.55/108.91 = 6.12; 5.91 | 102 | mine | yes |
| 39 | 8.50 → 8.17; 13.51 → 12.94; 17.17 → 16.45; 21.70 → 20.82 | 103–106 | 8.1699; 12.9431; 16.4527; 20.8173 | yes |
| 40 | 6-dp inputs of the closed form | 102–106 | match only at the exact yields (e.g. 50-year numerator at 4.2445% = 0.920195, printed 0.920186); y is not printed | results yes (non-blocking 4) |
| 41 | weight 0.137 on the final £104 | 106 | calcs t=50 0.1370 | yes |
| 42 | 0%: 67.30 → 61.16 = −9.12%; 8%: 132.06 → 122.81 = −7.00% | 108 | −9.123; −7.004 | yes |
| 43 | 3.75%: 97.65 → 90.06 = −7.78% | 108 | from the printed 2-dp prices **−7.77%** (exact −7.777) | rounding, last digit (non-blocking 3) |
| 44 | 8,620.9 ÷ (97.65 × 1.0824) = 81.56 | 111 | 81.560 | yes |
| 45 | 0.016643 ÷ 0.00002374 = 701.05; 701.03/81.56 = 8.6 | 112 | arithmetic ✓ | yes |
| 46 | P₋ "yield 4.1945%" = 95.956890; P₊ "4.2945%" = 93.979753 | 112 | at the printed yields: **95.957267 / 93.980118**; with P₀ 94.96 → convexity ≈ 732 | **no (B2)** |
| 47 | −8.17% + 0.41% = −7.76% | 113 | −7.762 | yes |
| 48 | −20.82% + 3.51% = −17.31% | 114 | ½ × 701.03 × 0.0001 = 3.505% | yes |
| 49 | (118.57 − 78.11)/(2 × 94.96 × 0.01) = 21.30 | 114 | 21.304 | yes |
| 50 | (118.5672 + 78.1122 − 189.92) = 6.7595 → 711.82 | 114 | printed inputs give **6.7594** → 711.82; and 115/83 print **118.5678 / 78.1125** for the same prices | **no (B2)** |
| 51 | −21.30% + ½ × 711.82 × (1%)² = −17.74% | 114 | −17.741 | yes |
| 52 | 50-year −1% at 3.2445%: 98.3071 + 20.2607 = 118.5678; +24.86% | 115 | 24.576771; 4.935672 | yes |
| 53 | −1% for the other eight | 116–123 | mine, all eight | yes |
| 54 | +3.5 points for 21 times the risk | 125 | 4.24 − 0.73 = 3.51; 20.82/0.99 = 21.0 | yes |
| 55 | prices to ≤ £0.03, yields to ≤ 1bp | 56 | 0.03 max (2-year); 3-year 1.15bp → 1bp whole | yes |
| 56 | −36.4% / −51.0% / −34.4% / +229bp | 136 | calcs (92 coupons, DMO 114.76 reproduced); 22.24 × 2.293 = 51.0; 75.28/114.76 − 1 | yes |
| 57 | 127bp / 191bp; +240bp vs +331bp | 13, 22 | 2.77 − 1.50; 5.30 − 3.39; 2.80 − 0.40; 4.04 − 0.73 | yes |
| 58 | Q2 table (106.84 / 98.86 / 97.65 / 102.32; 0.73 / 2.06 / 3.54 / 4.38 / 4.24) | 54 | calcs, answers.md, and the teaching note (check only) | yes |

## 4b. External fact spot-check (12 facts)

| Slide | Claim | Evidence | Supported? |
|---|---|---|---|
| 36 | 4.75% Aug 2006 → 5.75% Jul 2007 → 0.50% Mar 2009, unchanged to 2014 | D2 rows; **re-fetched live**: `03 Aug 06 4.75`, `05 Jul 07 5.75`, `05 Mar 09 0.50`, next `04 Aug 16 0.25` | yes (primary BoE) |
| 137 | Next decision Thursday 5 Nov 2026 | D3; **re-fetched live**: "Thursday 5 November \| November MPC Summary…", "2026 provisional dates" | yes (primary; say "provisional", non-blocking 8) |
| 137 | Bank Rate 3.75% | D: `Current official Bank Rate 3.75%`; live fetch: 3.75%, last change 18 Dec 25 | yes |
| 67 | Cut to 0.25% in Aug 2016 | D: `04 Aug 16 \| 0.25` | yes |
| 132 | 14 rises, 0.10% → 5.25%, Dec 2021 – Aug 2023 | D: 14 rows `16 Dec 21 0.25` … `03 Aug 23 5.25` | yes |
| 130 | 0.12% on 4 Aug 2020, lowest since 1993 | 3a `04 Aug 2020,0.1239`; series begins 1 Nov 1993 | yes |
| 9 | £1,365bn → £2,817bn, same basis | 7a–7c (DMO tables) | yes |
| 11 | 29% / 27% / 26% | DMO GAR 29.2 / 26.6 / 26.4% | yes |
| 12 | 35.6 / 78.6 / 93.2% of GDP; 2.9 / 5.6 / 4.4% | ONS 1a–1f | yes |
| 133–134 | £19.3bn, 28 Sep – 14 Oct; ">100bp in four days"; "20 year gilt … roughly a 20% price fall"; LBC 3.8% → 5% | E rows (BoE notices; Bank Underground exact quotes; LBC labelled secondary) | yes |
| 136 | 114.76 / 3.365% / ModD 22.24 (2014); £75.28 / 5.658% / 15.73 (today) | 8b DMO primary; 8a giltsyield secondary, labelled | yes |
| 108 | 0½% 2061 at £23.41, ModD 26.75; 21 months after 22 Jan 2060 | sources_research line 206 (giltsyield, secondary, labelled); 22 Oct 2061 − 22 Jan 2060 = 21 months | yes |

## 5. Blocking items (exact fixes)

**B1 · H8 · slide 29: the factor is labelled "at 4.38%" but is the factor at 4.3751%.**
At 4.38%, [(1.0438)²⁰ − 1]/0.0438 = 30.9800, which gives 4.75 × 30.9800 = 147.16 (+100 = 247.16), not 147.08.
**Fix:** "at the exact YTM 4.3751% (slide 52; 4.38% rounded), 4.75 × 30.9642 = 147.08 (+100 = 247.08)". The factor at 4.3751% is 30.964174 → 30.9642. Leave the 2% line unchanged.

**B2 · H8 · the 50-year gilt mixes two bases (slides 86, 112, 114).**
On these slides the yields are printed to 4 dp, but the 4–6 dp prices beside them were computed at the exact yield 4.244519%:
- **112:** at the printed 4.1945% / 4.2945% the prices are 95.957267 / 93.980118, not 95.956890 / 93.979753. With P₀ = 94.96, a reader who re-prices gets convexity ≈ 732, not 701.
- **86:** at the printed 4.2345% / 4.2545% the prices are 95.1584 / 94.7630, not 95.1580 / 94.7626. The PVBP of 0.1977 is unchanged either way.
- **114:** it prints 118.5672 and 78.1122, while 115 and 83 print 118.5678 and 78.1125 for the same prices. Also 118.5672 + 78.1122 − 189.92 = 6.7594, not 6.7595.

**Exact fix:**
- (a) **Slide 53:** add one line: "exact yield 4.244519%; we carry it where 4-dp prices matter (slides 86, 112, 114)".
- (b) **Slide 112:** "P₋ (yield 4.194519%) = 95.956890; P₊ (yield 4.294519%) = 93.979753".
- (c) **Slide 86:** "(4.234519%): 95.1580; (4.254519%): 94.7626".
- (d) **Slide 114:** "approximate convexity = (118.5672 + 78.1122 − 2 × 94.96)/(94.96 × 0.01²) = 6.7594/0.009496 = 711.82, using prices at the exact yield ∓ 1% (3.244519% and 5.244519%); slides 115 and 83, at the 4-dp yields, show 118.5678 and 78.1125, the same to 2 dp".
- Or, simpler for (d): use 115's and 83's numbers with P₀ at 4.2445% (94.9604): (118.5678 + 78.1125 − 189.9208)/(94.9604 × 0.0001) = 6.7595/0.00949604 = 711.83.
- Add these lines to `r5_displays` so they are asserted like the rest.

## 6. Non-blocking improvements (most valuable first)
1. **85 money rows:** four of nine rows do not subtract at 1 dp, including the title number. £95.0m → £78.1m reads as −£16.9m, but −£16.8m is stated. The others: 3-year 107.0 → 104.1 = 2.9 (3.0 stated); 5-year 98.9 → 94.4 = 4.5 (4.4 stated); 20-year 104.9 → 92.5 = 12.4 (12.5 stated). Show the values to 4 dp in the row (£94.9600m → £78.1125m = −£16.8475m ≈ −£16.8m).
2. **42–43:** the 2-dp PVs add to 98.85, not 98.86. This is the deck's first worked example, so show the PVs to 4 dp (2.6699 + 2.5921 + 2.5166 + 2.4433 + 88.6331 = 98.8550 ≈ 98.86), as 44 does.
3. **108 (3.75% row):** 90.06/97.65 − 1 = −7.77%, but −7.78% is stated. Use 4-dp prices (90.0582/97.6525 − 1 = −7.78%), as on 80. **47:** print 27.7957 (not 27.80), so the 30-year base 102.3185 used on 82 and 123 appears on the slide.
4. **102–106:** print the yield used, to 6 dp (e.g. "y = 3.540609%"). At the 4-dp yields the 6-dp pieces differ in the 5th–6th decimal (50-year numerator 0.920195 vs 0.920186). The results do not change.
5. **116–123 (and 76–83):** add the fixed line "price = coupon × annuity factor + £100 ÷ (1 + y)^N", with the two factors named. Today only 115 labels them, and 116–123 have no formula line.
6. **56:** say how nine rows of about 10 columns fit at 18pt. For example, split the rows into "price given" and "yield given" as one comparison over two facing slides, with the user's agreement if that counts as more than "one". DESIGN.md forbids shrinking the text.
7. **30:** show the 0% case: 4.75 × 20 + 100 = 195; (195/104.93)^(1/20) − 1 = 3.15%.
8. **137:** add "(provisional date)", the BoE's own word on D3.
9. **22:** keep the number order the same as the label (Exhibit 1 vs real: 4.04% vs 2.80% …). Shorten title 22 (116 characters) and 135 (106) so each fits in 2 lines.
10. **56 title:** "at most 1bp" holds only after rounding (3-year 1.15bp). Say "by about 1bp".
