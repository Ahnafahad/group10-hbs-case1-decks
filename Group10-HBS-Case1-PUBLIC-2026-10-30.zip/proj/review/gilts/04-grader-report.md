# UK Gilts deck: strict grader report (gate 4, finished deck)

Inputs: `review/gilts/04-qc/deck_text.md` (170 pages), `review/gilts/03-build/png/*.png`, contact sheets 1–9 (sheets 6 and 8 also checked in greyscale), slide HTML in `decks/gilts/project/slides/`, `work/gilts/calcs.py` (run clean), `sources.md`, `sources_research.md`, plan `review/gilts/01-storyline.md`.

## (a) Verdict
**NOT READY**: grade **B+ as built, A− once the 6 blocking items are fixed**. All six are small, local fixes. The analysis, the calculation chain and the exhibit rebuild are A-grade.

## (b) Hard requirements

| # | Result | Evidence |
|---|---|---|
| H1 Structure | PASS | Overview g03–g16 → Exhibits g17–g24 → Q1 g25–g37, Q2 g38–g56d, Q3 g57–g72, Q4 g73–g127c → Epilogue g128–g138 → team g139 (placeholder, allowed). All 139 plan slides exist; the continuation pages (b/c/d) only add content. |
| H2 Exhibit | PASS | g18: every row and column of Exhibit 1 (maturity, coupon as printed and as %, price, YTM, "?" blanks), labelled "Exhibit 1" with its source. Analysis follows on g18b–g24; completed exhibit on g54. |
| H3 Questions | PASS | Q1–Q4 stated (g26, g39, g58, g74/g74b) and broken into parts. Every step is on the slides: g41–g53b (prices and yields), g55–g56d (semi-annual), g63–g66c (bootstrap/forwards), g75–g83, g86–g94, g97–g106b, g111–g114b, g115–g123. No "see Excel". |
| H4 External sourcing | **FAIL** | g137b: "17 Sep 2026 · held at 3.75%" rests only on an unopened search summary (sources.md row "Today's rate": "secondary: search summary of mtsinsights.com … page not opened"). It is unlabelled, and the slide credits "BoE Bank Rate". g134b: "Gilts issued while Bank Rate was 0.10% (2020–21) have low coupons" has no source. |
| H5 No teaching note | PASS | No "Questions.docx" or teaching note in deck_text. |
| H6 Titles | PASS | Every title states a point and fits in ≤ 2 lines in the renders. |
| H7 Finance correct | **FAIL** | g114: the convexity explanation points the wrong way (finding B1). Everything else is correct: clean = full on a coupon date (g40), YTM as IRR with its 3 conditions (g28), spot/forward (g62–g66c), Macaulay/modified (g96–g107), convexity (g110–g113), price-based approximations (g114b). |
| H8 Numbers | **FAIL** | g136b shows "22.24 × 2.29 = 51.0%", but 22.24 × 2.29 = 50.93 (finding B2). The other 40+ recomputations match (section e). |
| H9 User decisions | PASS | Annual coupons plus one semi-annual comparison (g55–g56d, split over 4 pages as logged); no real gilt named as a case bond (g23/g23b); one slide per repeated calculation (g75–g83, g87–g94, g99–g106, g116–g123). |
| H10 Known traps | PASS | Annual-coupon simplification stated and tested (g24, g40, g55–g56d); per £100 (g05, g18, g85 conversion); duration and convexity explain the +1% shift (g96–g114b). |
| H11 Lucidity | PASS (with notes) | Terms are defined where first used: gilt and coupon g04, YTM g02/g18, par yield g13, bp g13b, QE g10, Bank Rate g10, DMO and liquidity g08, IRR g28, bracketing g49, interpolation g50, spot/forward g62, 1y1y g66, term premium g68, parallel shift g74, PVBP and hedge g86, Macaulay g96, modified g98, closed form g102, coupon effect g108b, convexity g110, LDI and margin call g133, QT g135. Three slides would mislead or slow the reader: g114 (wrong mechanism), g82 ("only 3.07" > 2.78) and g98 (actual bar unlabelled). That is below the "handful" threshold. |

## (c) Quality scores
- Q1 Depth: **5**. Bootstrapped spot and forward rates, a hindsight test, three term-structure theories weighed against data, the coupon effect with a real 0½% 2061 vs 4% 2060 pair, a price-based convexity cross-check, and a real 4% 2060 decomposition (duration, then convexity, then ageing).
- Q2 Logic and flow: **4**. Concepts come before use and each section ends with an answer slide. Slight repetition in the Q4 wrap-up (g127, g127b and g127c restate the same findings).
- Q3 Evidence: **4**. Primary BoE, DMO and ONS sources, with secondary sources labelled, except the g137b item.
- Q4 Lucidity: **4**. Excellent overall; g114 is the one real lapse.
- Q5 Calculations: **5**. Every line reproduces from the numbers shown, except g136b (and a 4th-dp tie on g102).
- Q6 Overview and epilogue: **4**. Current to 27–29 Oct 2026 and tied back to Q4 (g134, g136). Needs the g137b sourcing fix.

## (d) Findings

### Blocking
**B1. g114 (gilt_e).** Wrong direction in the explanation and the so-what.
- Evidence: duration −20.82% vs actual −17.74% is a 3.08-point miss. Convexity adds +3.51 points, which is more than the miss, so the two-term estimate −17.31% now understates the fall by 0.43 points. The slide says "convexity closes 2.65 of the 3.08-point miss; 0.43 points remain", and the Plain line says the two terms "miss some of the bending". Both imply under-correction. In fact the quadratic over-credits the bend for a large rise, because convexity itself shrinks as yields rise. The same framing appears in g127b (c) ("cuts the 50-year miss to 0.43"): non-blocking there, but align it.
- Fix: so-what → "convexity adds back 3.51 points, more than the 3.08-point miss, so the estimate now understates the fall by 0.43 points (17.74 − 17.31)". Plain → "a 1% move is large for a 50-year gilt; the curve flattens out as yields rise, so the convexity term over-credits the bend for a big rise (the 10-year shows the same overshoot, by 0.02, on slide 113)."

**B2. g136b (gilt_c).** The displayed product does not reproduce.
- Evidence: the slide shows "22.24 × 2.29 = 51.0%", but 22.24 × 2.29 = 50.93.
- Fix: show "22.24 × 2.293 = 51.0%", using the 3-dp DMO yields shown on g136 (5.658 − 3.365 = 2.293). Optionally say "modified duration 22.24".

**B3. g137b (gilt_c).** An unverified, unlabelled secondary fact.
- Evidence: "17 Sep 2026 · held at 3.75%" comes only from a search summary of mtsinsights.com ("page not opened", sources.md "Today's rate" row). The source line credits the BoE.
- Fix: replace it with the primary fact "no change since 18 Dec 2025 (BoE Bank Rate table; current rate 3.75%)", or open and quote the page and label it "(secondary)".

**B4. g134b (gilt_c).** An external fact without a source.
- Evidence: "Gilts issued while Bank Rate was 0.10% (2020–21) have low coupons, nearer the zero-coupon rows". The zero-coupon starting yields of 3% and 1% are also not labelled illustrative, despite the builder note.
- Fix: cite the sourced example, e.g. "low-coupon gilts such as the 0½% 2061 (modified duration 26.75, slide 108, secondary)", or drop the 2020–21 dating. Add "(illustrative)" to the two zero-coupon row labels.

**B5. g49 (gilt_b).** Overlapping labels.
- Evidence: "2%: £107.21" sits on the dashed target line and the curve; "3%: £104.24" is struck through by the curve (full-size render).
- Fix: move both labels above the line (or below it with leader ticks), clear of the dashed target line.

**B6. g70 (gilt_c).** Overlapping label.
- Evidence: the "4.04%" point label sits on the x-axis line next to the 4.00 tick.
- Fix: place it above-right of the 10-year point, or raise the axis floor note.

### Non-blocking (most valuable first)
1. **g98 (gilt_d).** The "Actual" bar has no value label; −4.47% appears only in the so-what. Add "−4.47%" under the bar.
2. **g82 (gilt_d).** The so-what "20 to 30 years adds 2.78 points of fall, 30 to 50 years only 3.07" calls the larger number "only". Fix: "30 to 50 years adds 3.07 over two decades, about 1.5 a decade".
3. **g33 (gilt_b).** The "119.42" label touches the price–yield line at 2%. Nudge it left or down.
4. **g124 (gilt_e).** The column headers "Yields +1%: price falls" and "Yields −1%: price rises" butt together and read as one run in the render and in greyscale. Add a gap or right-align the left header.
5. **g127b (gilt_e).** Finding (c) needs the same wording fix as B1 ("the two-term estimate now understates the 50-year fall by 0.43").
6. **g136 (gilt_c).** "modified duration has fallen from 22.24 to 15.73 as maturity nears": the fall also reflects the higher yield. Add "and as its yield rose".
7. **g137 (gilt_c).** The title states "Bank Rate is 3.75%", but the slide's source line has no Bank Rate source (only g137b has one). Add "BoE Bank Rate table".
8. **g102 (gilt_e).** 1.137563 ÷ 0.049195 = 23.12355, which rounds half-up to 23.1236; the slide shows 23.1235. The result 6.12 is unchanged. Print 23.1236 and 6.1201, or note "(rounded)".
9. **g07 (gilt_a).** The so-what "the top-grade record is why…" sits next to a current AA− rating. Say "the unbroken payment record is why…".
10. **g09 (gilt_a).** "inflation uplift" appears only in the footer. Define it in a Plain line if space allows.

### Builder notes checked
- **g84b:** the y-axis starts at 70 and says so in the axis label. OK.
- **g134b:** the starting yields are NOT labelled illustrative (see B4).
- **g137/g137b:** 5 Nov 2026 is shown as "PROVISIONAL: re-check before submission" and sourced to the BoE "MPC dates for 2026". OK.
- **g98:** "CFA Fixed Income LM11" is acceptable. In the 2024 Level I curriculum, LM11 is "Yield-Based Bond Duration Measures and Properties" (`materials/cfatxt`).

### Checks that passed
- No body text under 36 px. A Playwright scan of all 170 HTML files found every sub-36 px text node at y ≥ 940 (footer and page tag only).
- Exhibit 1 is rebuilt in full (g18).
- All 139 plan slides are present.
- Every chart I opened states its base or break: g20, g33 (70), g35 (95), g49 (95), g70 (4.0), g84b (70), g110 (65), and the bar charts "from zero".
- Encodings are not colour-only: shape plus colour on g31b; dashed vs solid on g35, g84b and g137; direct labels elsewhere.
- Greyscale legibility is good on sheets 6 and 8.

### Ownership by build script
- **gilt_a (g01–g24):** non-blocking 9 and 10.
- **gilt_b (g25–g56):** B5 (g49); non-blocking 3 (g33).
- **gilt_c (g57–g72, g128–g139):** B2 (g136b), B3 (g137b), B4 (g134b), B6 (g70); non-blocking 6 and 7.
- **gilt_d (g73–g100):** non-blocking 1 (g98) and 2 (g82).
- **gilt_e (g101–g127):** B1 (g114); non-blocking 4 (g124), 5 (g127b) and 8 (g102).

## (e) Recomputed calculations (independent Python, exact yields unless stated)

| # | Slide | Displayed | Recomputed | OK |
|---|---|---|---|---|
| 1 | g29 | 4.75 × 30.9642 = 147.08; +100 = 247.08; at 2%: 115.41 → 215.41; gap 31.67 | 147.08 / 215.41 / 31.67 | yes |
| 2 | g31 | 5.00 ÷ 108.91 = 4.59%; 4.00 ÷ 94.96 = 4.21% | 4.591 / 4.212 | yes |
| 3 | g42–g43 | PVs 2.6699 … 88.6331; sum 98.8550 (rows rounded; unrounded 98.8551) | 98.8550 / 98.8551 | yes |
| 4 | g46 | 1.0404¹⁰ = 1.48594740; factor 8.094769; 30.3554 + 67.2971 = 97.6525 | 1.4859474 / 8.094769 / 97.6525 | yes |
| 5 | g48 | 103.25 ÷ 102.50 = 1.007317 → 0.73% | 1.0073171 | yes |
| 6 | g49 | 12.9775 + 94.2322 = 107.2097; 12.7287 + 91.5142 = 104.2429 | 107.2097 / 104.2429 | yes |
| 7 | g50 | 2% + 0.19/2.97 × 1% = 2.064%; exact 2.0628% | 2.0640 / 2.0628 | yes |
| 8 | g51–g52 | 3.550% (exact 3.5406%); 4.395% (exact 4.3751%) | 3.5495 / 3.5406; 4.3952 / 4.3751 | yes |
| 9 | g53 | 85.9287 + 14.0713 = 100.0000; 73.0237 + 8.7204 = 81.7441; 4.276% (exact 4.2445%) | same | yes |
| 10 | g55 | 2.602 + 2.580 + 2.558 + 99.130 = 106.870 | 106.870 | yes |
| 11 | g56d | 3-year yield gap 2.0743 − 2.0628 = 0.0115; 50-year −0.0008 | same | yes |
| 12 | g61 | 331 of 365bp = 91% | 90.7% | yes |
| 13 | g64 | 106.8409 − 5.2119 = 101.6290; √(105.25/101.6290) = 1.017659 | 101.6290 / 1.0176589 | yes |
| 14 | g65 | 107.02 − 4.4673 − 4.3452 = 98.2075; ∛1.064074 = 1.020917 | 98.2075 / 1.0209173 | yes |
| 15 | g66–g66b | 1y1y 2.81%; 2y1y 2.75% | 2.8107 / 2.7464 | yes |
| 16 | g75 | 101.4925, −0.98% | 101.4924 (4-dp yield gives 101.4925), −0.98 | yes |
| 17 | g80 | 28.9003 + 61.1579 = 90.0582; −7.78% | 90.0583 / −7.78 | yes |
| 18 | g83 | 70.3495 + 7.7630 = 78.1125; −17.74% | 78.1122 exact (4-dp yield 78.1125) / −17.74 | yes |
| 19 | g85 | 50y: 94.9600 − 78.1125 = −16.8475 → £16.8m | 16.8475 | yes |
| 20 | g86 | (95.1580 − 94.7626)/2 = 0.1977 → £197.7k | 0.1977 | yes |
| 21 | g92 | (97.7323 − 97.5728)/2 = 0.07975 ≈ 0.0798 | 79.8k | yes |
| 22 | g95 | 197.7 ÷ 10.2 = 19 times | 19.4 | yes |
| 23 | g97/g98 | MacD 4.74; ModD 4.74 ÷ 1.03 = 4.60 | 4.737 / 4.60 | yes |
| 24 | g102 | 29.2437 − 23.1235 = 6.12 | 23.12355 → 23.1236; 6.12 | yes (4th-dp tie, nb 8) |
| 25 | g103–g106 | 8.50/8.17; 13.51/12.94; 17.17/16.45; 21.70/20.82 | 8.4999 / 13.5076 / 17.1717 / 21.7032; mods match | yes |
| 26 | g106b | 104 ÷ 1.0424⁵⁰ ≈ 13.0; weight 0.137 | 13.01 / 0.137 | yes |
| 27 | g108 | −9.12% / −7.78% / −7.00%; 0% duration 9.61 | 10 ÷ 1.0404 = 9.61 | yes |
| 28 | g110 | 94.96 × (1 − 0.2082) = 75.19 (gap 2.92); × 1.2082 = 114.73 (gap 3.84) | 75.19 / 114.73 | yes |
| 29 | g111/g111b | Σ = 8,620.87; ÷ (97.65 × 1.0824 = 105.70) = 81.56; 89% from year 10 | 8,620.87 / 81.56 / 89.1% | yes |
| 30 | g112 | 0.016643 ÷ 0.00002374 = 701.05; 701.03 ÷ 81.56 = 8.6 | 701.05 / 8.60 | yes |
| 31 | g113 | −8.17 + 0.41 = −7.76 vs −7.78 | same | yes |
| 32 | g114/g114b | −20.82 + 3.51 = −17.31; 40.4550 ÷ 1.8992 = 21.30; 6.7594 ÷ 0.009496 = 711.82; −21.30 + 3.56 = −17.74 | same (arithmetic right; interpretation wrong, B1) | yes |
| 33 | g115 | 98.3071 + 20.2607 = 118.5678; +24.86% | 118.5672 exact / +24.86 | yes |
| 34 | g124 | gaps 0.02 … 7.12 | 24.86 − 17.74 = 7.12, etc. | yes |
| 35 | g125 | +3.51 points; 21 times (20.82 ÷ 0.99) | 3.51 / 21.0 | yes |
| 36 | g09 | 1,039 + 326 = 1,365; 2,144 + 673 = 2,817; ×2.06 | 2.064 | yes |
| 37 | g12 | 78.6 ÷ 35.6 = 2.2 | 2.21 | yes |
| 38 | g13/g13b | +2.53; 127bp, 191bp, 15bp, 32bp | same | yes |
| 39 | g132 | 5.25 − 0.10 = 5.15; six cuts since Aug 2024 | 6 rows in the BoE table | yes |
| 40 | g134b | (1.03/1.04)²⁰ − 1 = −17.6%; (1.01/1.02)²⁰ − 1 = −17.9%; 20/1.03 = 19.42 | −17.57 / −17.88 / 19.42 | yes |
| 41 | g135 | 895 − 488 = 407 | 407 | yes |
| 42 | g136 | 75.28 ÷ 114.76 − 1 = −34.4%; +229bp | −34.40 / 2.293 | yes |
| 43 | g136b | 22.24 × 2.29 = 51.0 | 50.93 (22.24 × 2.293 = 51.00) | **no (B2)** |

## Strongest points
- The calculation chain is airtight. Every displayed working line reproduces from the numbers shown. Rounding handling is exemplary ("rows rounded", the 4-dp vs exact-yield notes on g114b).
- The exhibit is rebuilt in full and then tested against real DMO data (g22, g23/g23b).
- Visuals fit the point (number lines for interpolation, see-saw for duration, butterfly bars for up vs down). Every chart states its base.
- The epilogue ties back to the analysis with real numbers (g134 Bank Underground's "roughly 20%" reconciled with our −11.89%; g136 real 4% 2060 decomposition).
