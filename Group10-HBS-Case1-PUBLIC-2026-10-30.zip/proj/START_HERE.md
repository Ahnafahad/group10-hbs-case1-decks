# START HERE — Group 10, HBS Case 1 (Jaguar + UK Gilts) — COMPLETE as of 2026-10-30 21:00 Dhaka

Status: BOTH DECKS BUILT, CHECKED, FIXED AND PUBLISHED. Waiting only for the user's "Approved" + the placeholders below.

## Use this zip in any Claude account
1. Upload this zip and say: "Read START_HERE.md and continue." (or paste HANDOVER_PROMPT.md)
2. `bash resume.sh` — installs deps, runs both calcs (all asserts), rebuilds both decks from build scripts, re-renders every slide to PNG (renders were left out of the zip to save space), rebuilds text dumps. Prints READY.
3. To put the decks in a NEW account: create two Slides artifacts from the "Slides" artifact type, then publish `decks/<case>/project/deck.json` + every `project/slides/<id>.html` with root = `decks/<case>` (exact recipe: SLIDES_PUBLISHING.md). One call each (149 / 170 files).
4. To edit: change the build script (`build/jlr_s1..s7.py`, `build/gilt_a..e.py`), regenerate, render-check, republish only the changed slides. Numbers must come from `work/<case>/calcs.py`.

## What's inside
- `decks/jaguar/project/` (149 slides) and `decks/gilts/project/` (170 slides): final decks, Claude Slides file format.
- `SLIDE_TEXT/`: all slide text of both decks in deck order (readable without any tools).
- `work/<case>/`: calcs.py (every calculation), exhibits.csv, answers.md, sources.md (every external fact with URL, date, quote).
- `build/`: build scripts + kits + render.py (Playwright check).
- `review/`: PROGRESS.md (all user feedback verbatim + decisions), storylines, all grader reports, 04-qc.md per case, contact sheets.
- `materials/` + original materials zip; `history/` full transcript; `.claude/` skills and agent roles.
- CLAUDE.md, DESIGN.md, HANDOVER.md, AGENT_BRIEFS.md: rules and workflow.

## Published decks (account ahnaf816@gmail.com, 2026-10-30)
- Jaguar: https://claude.ai/artifact/CTkuNNjvQaABm5TmWMNUF3
- UK Gilts: https://claude.ai/artifact/Xq7xitN2rBNFarw1yXgFbR
(Another account can't open these unless shared; republish from decks/ instead.)

## Still open before submission
- Cover details + team slide (photos, names, student IDs) are marked PLACEHOLDERS.
- Re-check Bank Rate, gilt yields, JLR latest results/ratings; g137 MPC 5 Nov 2026 marked PROVISIONAL.
- Export: Share › Export › PowerPoint; embed Inter + IBM Plex Mono.
