#!/usr/bin/env bash
# One-shot setup for a fresh session. Run from the project root:  bash resume.sh
# Installs what is missing, runs both calcs, regenerates both decks from the build scripts,
# render-checks every slide, and rebuilds the text dumps and contact sheets. Takes ~2–4 minutes.
set -e
cd "$(dirname "$0")"
python3 -c "import scipy" 2>/dev/null || pip install -q scipy --break-system-packages
python3 -c "import playwright" 2>/dev/null || pip install -q playwright --break-system-packages
python3 -c "import PIL" 2>/dev/null || pip install -q pillow --break-system-packages
python3 - <<'PY' || python3 -m playwright install chromium
from playwright.sync_api import sync_playwright
with sync_playwright() as p: p.chromium.launch().close()
PY
python3 work/jaguar/calcs.py > /dev/null && echo "jaguar calcs OK"
python3 work/gilts/calcs.py  > work/gilts/calcs_output.txt && echo "gilts calcs OK"
for i in 1 2 3 4 5 6 7; do python3 build/jlr_s$i.py decks/jaguar/project/slides > /dev/null; done; echo "jaguar slides rebuilt"
for x in a b c d e; do python3 build/gilt_$x.py decks/gilts/project/slides > /dev/null; done; echo "gilts slides rebuilt"
echo "== render check (only cover/divider subtitle flags are expected) =="
python3 build/render.py decks/jaguar/project/slides review/jaguar/04-qc/png | grep -v " OK$" || true
python3 build/render.py decks/gilts/project/slides  review/gilts/03-build/png | grep -v " OK$" || true
python3 build/tools.py dump  decks/jaguar/project review/jaguar/04-qc/deck_text.md
python3 build/tools.py dump  decks/gilts/project  review/gilts/04-qc/deck_text.md
python3 build/tools.py sheet decks/jaguar/project review/jaguar/04-qc/png review/jaguar/04-qc/contact
python3 build/tools.py sheet decks/gilts/project  review/gilts/03-build/png review/gilts/03-build/contact
echo "READY. Next: HANDOVER.md §5 step 2."
