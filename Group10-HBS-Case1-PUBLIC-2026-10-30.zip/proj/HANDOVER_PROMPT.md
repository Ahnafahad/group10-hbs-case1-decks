# Paste this into a new chat together with the zip (or just say "continue")

I'm attaching a zip with a project in progress: two finance case decks (Jaguar Land Rover bond refinancing, and UK Gilts) for my HBS Case 1 group assignment, built as Claude Slides decks. Another Claude session did the work and paused it for handover. Continue from exactly where it stopped, without asking me to re-approve anything already approved.

1. Unzip it into your working folder. Read `HANDOVER.md` first (it says what is done and the exact next steps), then `CLAUDE.md` (especially "Standing rules from the user"), `review/PROGRESS.md` (my feedback word for word, newest first), `DESIGN.md` and `build/GILTS_BUILD_BRIEF.md`.
2. Run the setup in HANDOVER.md §5 step 1, then carry on with steps 2–4: check and fix the Gilts deck with an independent checker plus parallel helpers, re-grade and finish the Jaguar deck, then publish both as new Claude Slides decks in this account and show me the links.
3. Work fast and use parallel helper agents (Sonnet to build and fix, Opus to check). I have approved the plans, the looks and the full build; only stop to ask me if something is genuinely blocked (multiple choice, simple words, with a recommendation).

Rules I care about most: lucidity on paper for a CFA Level 1 student, every calculation step shown, every external fact sourced, never cite the teaching notes, 18pt minimum, more visuals where they fit (no forcing), and write my feedback word for word into review/PROGRESS.md before acting on it. Cover details and the team slide stay as marked placeholders until I supply them.
