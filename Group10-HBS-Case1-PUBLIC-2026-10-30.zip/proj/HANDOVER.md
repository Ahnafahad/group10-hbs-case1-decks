> **UPDATE 2026-10-30 21:00: work COMPLETE — read START_HERE.md first; it supersedes §3–§5 below.**

# Handover: Group 10, HBS Case 1 decks (Jaguar + UK Gilts)

**Paused 2026-10-30 20:10 (Asia/Dhaka) on the user's instruction**, to be continued in a NEW chat, possibly on a DIFFERENT Claude account. This file is the single source for picking up exactly where we stopped. The user will paste the prompt in `HANDOVER_PROMPT.md` (or just say "continue").

## 1. What this project is
Two finance case decks for a BBA/MBA class at CFA Level 1 depth:
- **Jaguar Land Rover:** the 2015 refinancing of US$410m 8.125% notes with US$500m 3.5% notes.
- **UK Gilts:** bond pricing, YTM, the yield curve and interest-rate risk.

Both are built as **Claude Slides** decks. The user exports them to .pptx and also prints them one slide per page. Each deck has its own look on one shared theme:
- Jaguar = look B, lime/black editorial.
- Gilts = look A, indigo.

## 0. Fastest start (no wasted tokens)
1. `bash resume.sh`: installs dependencies, runs both calcs, regenerates both decks from the build scripts, render-checks every slide, and rebuilds the text dumps and contact sheets. It prints READY.
2. Read §3 and §5 below and `review/PROGRESS.md` (top part).
3. Launch the ready-made helper briefs in `AGENT_BRIEFS.md`: the Gilts checker first, then the fixers. Publish with `SLIDES_PUBLISHING.md`.
4. Do NOT re-read the case materials, re-derive the analysis or re-review the plans. All of that is done and approved; the decks are built. Look things up only when a finding needs it.

## 2. Read these first, in this order
1. `CLAUDE.md`: the job, the hard rules, the gate workflow and **"Standing rules from the user"**. These override everything else.
2. `review/PROGRESS.md`: status, and **every piece of user feedback word for word (newest first)**, plus every decision. The newest feedback matters most (see §4 below).
3. `DESIGN.md`: the approved look and build spec.
4. `build/GILTS_BUILD_BRIEF.md`: the build rules plus the **"Mistakes found in the Jaguar deck; do NOT repeat them"** list. These apply to both decks.
5. `review/jaguar/04-grader-report.md`: the gate-4 grader report on Jaguar. Findings 1–24 are mostly fixed (see §3).

## 3. Where we are (2026-10-30 20:10)
| | Jaguar | UK Gilts |
|---|---|---|
| Gate 0 brief | Approved | Approved |
| Gate 1 answers + storyline | Approved (strict review READY) | Approved (strict review READY) |
| Gate 2 look | Approved: look B | Approved: look A |
| Gate 3 build | **All sections built and approved** by the user, one at a time | **All 139 plan slides built** (170 pages incl. b/c/d continuation pages). The user pre-approved the build ("assume approval for all"). **Not yet published, and not yet checked by the independent checker.** |
| Gate 4 final check | Grader round 1 = NOT READY (7 blocking). **All 7 blocking and most non-blocking findings are fixed in the build scripts** (149 pages). **Not yet re-graded, not yet republished.** | Not started |

### The deck files (the real deliverables, in this zip)
- `decks/jaguar/project/`: `deck.json` plus `slides/<id>.html` (149 pages). This is the latest build, with all fixes.
- `decks/gilts/project/`: `deck.json` plus `slides/<id>.html` (170 pages).

Both are in the Claude Slides file format: one `<section>` per slide, 1920×1080, inline styles. To regenerate them from source:
- Jaguar: `python3 build/jlr_s1.py <dir>` … `jlr_s7.py`. Helpers are in `build/jlr_kit.py`.
- Gilts: `python3 build/gilt_a.py <dir>` … `gilt_e.py`. Helpers are in `build/gilt_kit.py`.

The scripts compute every number and assert it against `work/<case>/calcs.py`.

Render check: `python3 build/render.py <slides_dir> <png_dir>` (Playwright). It flags text under 36 px in the body, content below y = 920, and horizontal overflow. The only allowed flags are the subtitles on the cover and divider slides.

### Old artifact links (OLD account only; a new account cannot open them)
- Jaguar deck: https://claude.ai/artifact/GBALTAmjXs9vV52U3b6Dmh, at version 9. That version holds the pre-QC build, without the gate-4 fixes. It was also re-saved by the Slides editor, which only normalised table-header padding.
- Gilts deck: https://claude.ai/artifact/WAD1KLzT7yVoZNV5o1GwwG, created but still EMPTY.
- Samples: https://claude.ai/artifact/FDSxNWFitiAfajUBNh6h5X

**On a new account:** create two NEW Slides artifacts, one per deck, from the Slides artifact type ("quickstart"/list types, then publish with its `type_url`). Then publish `decks/<case>/project/deck.json` plus all its slide files, with `root` = `decks/<case>`. Use at most 255 files per call; split if needed.

## 4. The user's latest instructions (verbatim copies are in PROGRESS.md)
- **19:36:** Assume approval for all. "One-shot" the Gilts deck using parallel/sub-agents, with a checker agent. Don't show it section by section. Learn from the Jaguar mistakes and don't repeat them. Visualise more, with no compromise in the analysis. Still run the check workflow.
- **19:44:** Pick the visual form that fits each point; it doesn't have to be a chart, diagram or timeline (also annotated formulas, number lines, before/after pairs, comparisons, icon rows, step strips, callouts). Don't force a visual. "70% is a fine metric, but that does not mean that you have to force it."
- **20:09:** Package everything into one zip so it can be continued from a new chat on a different account by saying "continue". (This file is that package.)
- **Speed:** the user wanted the Gilts deck "within the hour". Work fast and use parallel helpers (Sonnet for building, Opus for checking).

## 5. What to do next, in order
1. **Setup:**
   - Unzip.
   - `pip install scipy playwright --break-system-packages` if needed. Playwright's Chromium may also be needed: `python3 -m playwright install chromium`, only if no Chromium is pre-installed.
   - Run `python3 work/jaguar/calcs.py` and `python3 work/gilts/calcs.py`.
   - Regenerate both decks from the build scripts into `decks/<case>/project/slides/` and run `build/render.py`. Everything should pass, apart from the cover and divider subtitles.
2. **Gilts gate 3/4 check (main remaining work):**
   - Run ONE independent checker agent (Opus) over the whole Gilts deck. Give it a text dump plus PNG renders, the rubric `review/shared/review-rubric.md`, `CLAUDE.md`, the case brief `materials/text/Gilts/Case Presentation Instructions.docx.md`, `work/gilts/calcs.py`, the sources files and the storyline.
   - Brief it like the Jaguar grader (see `review/jaguar/04-grader-report.md` for the expected output format). It must recompute at least 25 calculations, check cross-slide consistency, check the exhibit rebuild is complete, check sources are labelled, check 36 px body text, check chart honesty, and check that visuals fit the point (per the 19:44 rule).
   - Fix what it finds with parallel Sonnet fixers, one per build script `gilt_a`…`gilt_e`, giving them exact findings.
   - Known open notes from the builders:
     - g84b's y-axis starts at 70 (stated on the slide).
     - g134b's zero-coupon example uses illustrative starting yields (labelled).
     - g137's 5 Nov 2026 MPC date is provisional: re-check it before submission.
     - g98 cites "CFA Fixed Income LM11".
     - Slide numbering references between parts follow the plan numbers.
     - gilt_b (g25–g56) passed render.py, but no one has looked at its PNGs yet. Review them.
3. **Jaguar gate 4:**
   - Re-run the grader (round 2) on the fixed 149-page build.
   - Fix what's left. Not yet done: optional finding 22, j48 paired bars; and the "X, not Y" wording on j28, j50, j55, j62, j116, j129, j139.
   - Then write `review/jaguar/04-qc.md`: checklist ticks against the plan's instructions checklist, grader results, the greyscale check (done earlier: OK), humanizer and number-diff notes, and the font-embedding reminder.
4. **Publish** both decks as Slides artifacts. Show the user the links and a one-line summary each, and stop. The user approves with the word "Approved".
5. **Before submission** (remind the user):
   - Cover details and the team slide (photos, full names, student IDs) are still PLACEHOLDERS.
   - Re-check Bank Rate, today's gilt yields, JLR's latest results (Q2 FY27 was not out on 30 Oct 2026) and ratings.
   - Embed fonts when exporting to PowerPoint.

## 6. Rules the user cares about most (short form; full text in CLAUDE.md)
- **Lucidity is pass/fail:** a student part-way through CFA Level 1 must follow every slide on paper with no presenter. Never cut analysis; explain it instead.
- **Show every calculation step on the slides,** with one slide per repeated calculation.
- **Every external fact needs a source, a date and an exact quote** (in `work/<case>/sources*.md`). Label secondary sources. Never cite the teaching notes (`*Questions.docx`).
- **Questions to the user** are multiple choice, in very simple words: why the question arose, what each option means, and a recommendation.
- **Write the user's feedback word for word** into `review/PROGRESS.md` before acting on it.
- **Helper agents** get tough, explicit pass/fail criteria plus all the project rules.
- **Placeholders stay clearly marked** until the user supplies the cover details and team details.
- Body text is at least 18 pt (36 px on the 1920 canvas). Footers are 12 pt (24 px).

## 7. Files map
- `resume.sh`, `AGENT_BRIEFS.md`, `SLIDES_PUBLISHING.md`, `HANDOVER_PROMPT.md`: the restart kit.
- `review/agent-reports.md`: every helper agent's final report, verbatim, including the builders' deviation lists and the numbers each one checked.
- `review/gilts/03-build/png/` and `contact-*.png`, and `review/jaguar/04-qc/png/` and `contact-*.png`: current renders of every slide. `review/<case>/04-qc/deck_text.md` holds the text dumps.
- `history/`: the full transcript and agent logs, for grep only (see `history/README.md`).
- `build/tools.py`: text dump and contact-sheet helper.
- `materials/`: unzipped case materials. The original zip is also included. Text versions are in `materials/text/<Case>/` and `materials/cfatxt/`.
- `work/<case>/`: `exhibits.csv`, `calcs.py`, `answers.md`, `sources.md`, `sources_research.md`.
- `review/`:
  - `PROGRESS.md`
  - `<case>/01-storyline.md` (the approved plans)
  - `jaguar/04-grader-report.md`
  - `jaguar/04-qc/deck_text.md` (text dump; PNGs not included, regenerate them)
  - `jaguar/03-build/` (section contact sheets)
  - `shared/02-look/` (approved look samples)
- `build/`: all deck build scripts, kits, `render.py`, `GILTS_BUILD_BRIEF.md`.
- `decks/`: the built decks in Slides file format (see §3).
- `.claude/skills/`: the design skills (anti-slop-slides, apple-design, mck-ppt-design, humanizer, ib-check-deck, and others).
- `.claude/agents/`: `grader.md` and `sonnet-worker.md`, the role definitions. If these agent types are not registered in the new session, give a general-purpose agent the file as its role.
