# Ready-to-use helper-agent briefs (copy, paste, launch: no re-deriving)

Replace `<ROOT>` with the project folder (where this file sits). These briefs follow the pattern the user approved: tough pass/fail criteria plus all project rules. Run checkers on Opus and builders/fixers on Sonnet. If the custom agent types `grader` / `sonnet-worker` are not registered, use `general-purpose` and tell it to read `<ROOT>/.claude/agents/grader.md` (or `sonnet-worker.md`) as its role first.

---
## 1. Gilts checker (Opus, background). Run first.
```
Act as the project's "grader": read <ROOT>/.claude/agents/grader.md first and follow it.
You are the independent checker for the finished UK Gilts case deck (Group 10, HBS Case 1). The user has pre-approved the plan, look and build; your job is to find every defect before publishing. Judge only the deliverable.

READ FIRST: <ROOT>/review/shared/review-rubric.md (apply H1–H11 and quality scores exactly); <ROOT>/CLAUDE.md ("Hard rules" and "Standing rules from the user"); <ROOT>/materials/text/Gilts/Case Presentation Instructions.docx.md; <ROOT>/DESIGN.md (look A); <ROOT>/build/GILTS_BUILD_BRIEF.md (incl. "Mistakes found in the Jaguar deck" and the 19:44 visual-form rule).

DELIVERABLE: slide text in deck order <ROOT>/review/gilts/04-qc/deck_text.md (170 pages; "## Slide gNN"); full-size renders <ROOT>/review/gilts/03-build/png/<id>.png — open at least 50 yourself incl. every calculation slide in 26–56, 63–66, 75–95, 96–124, the exhibit rebuild g18/g18b, all charts; contact sheets <ROOT>/review/gilts/03-build/contact-*.png (check greyscale legibility too).
CHECK AGAINST: <ROOT>/work/gilts/calcs.py (run it), exhibits.csv, answers.md, sources.md, sources_research.md, and the approved plan <ROOT>/review/gilts/01-storyline.md (every plan slide must exist with its point and content; continuation pages b/c/d are fine).

BLOCKING if: any body text under 36 px; teaching note (UK Gilts Questions.docx) cited or copied; an external fact without a source line, or a secondary source not labelled "(secondary)", or a claim beyond the source; Exhibit 1 not rebuilt in full; any assigned question's calculation step missing; a displayed sum/product/subtraction that does not reproduce from the numbers shown; the same quantity with different values on different slides beyond stated rounding; a chart not to scale without a stated base/break, colour-only encoding, overlapping labels; a title or so-what that the slide's numbers do not support; lucidity failures (undefined term at first use, unlabelled units, a calculation without a one-line so-what).
ALSO: judge visuals per the user's rule — the visual form should fit the point; flag forced visuals and bland text-only slides where a fitting visual would help. Do not mark cover/team placeholders as missing. Never suggest cutting analysis.
Recompute at least 25 displayed calculations (spread across Q1–Q4 and the epilogue) and list them with results.
OUTPUT: <ROOT>/review/gilts/04-grader-report.md with (a) verdict READY/NOT READY (READY only at A− or better), (b) H1–H11 PASS/FAIL with evidence, (c) quality scores, (d) numbered findings: slide id, problem, evidence, BLOCKING/NON-BLOCKING, concrete fix, and WHICH BUILD SCRIPT owns the slide (gilt_a: g01–g24; gilt_b: g25–g56; gilt_c: g57–g72 and g128–g139; gilt_d: g73–g100; gilt_e: g101–g127), (e) recomputed calculations. Edit nothing else. Return the verdict and the blocking count.
```

## 2. Gilts fixer (Sonnet, one per build script, all in parallel)
```
Fix the checker's findings for build script <ROOT>/build/gilt_<x>.py (UK Gilts deck, slides <range>).
Read: <ROOT>/build/GILTS_BUILD_BRIEF.md (all rules apply), <ROOT>/review/gilts/04-grader-report.md (fix every finding assigned to gilt_<x>, blocking first, then non-blocking), <ROOT>/CLAUDE.md standing rules.
Numbers only from work/gilts/calcs.py / exhibits.csv, computed and asserted in the script; facts only from work/gilts/sources*.md with source lines.
Regenerate: python3 build/gilt_<x>.py decks/gilts/project/slides ; copy your ids to a temp folder and run python3 build/render.py <tmp> <png> until clean (cover/divider subtitle flags allowed); LOOK at every PNG you changed. If you add/remove pages, list the new ids in order. Do not touch other scripts, calcs, sources, storyline. Report: each finding → what you did, numbers checked, anything not fixed and why.
```
After the fixers finish: if any page ids changed, update `decks/gilts/project/deck.json` `order` (sort by plan number, then suffix b/c/d), re-run `python3 build/tools.py dump …` and the render, then re-run the checker until READY.

## 3. Jaguar grader, round 2 (Opus)
Same as brief 1 but for Jaguar:
- deliverable: `<ROOT>/review/jaguar/04-qc/deck_text.md` (149 pages) and the renders in `<ROOT>/review/jaguar/04-qc/png/`
- inputs: `work/jaguar/*`, `review/jaguar/01-storyline.md`, `materials/text/Jaguar/Case Presentation Instructions.docx.md`, DESIGN.md look B
- teaching note to never cite: `Jaguar Questions.docx`
- extra instruction: "Round 1 report is <ROOT>/review/jaguar/04-grader-report.md; verify each round-1 finding is fixed, then grade afresh"
- output: `<ROOT>/review/jaguar/04-grader-report-r2.md`
- script ownership:

  | Script | Slides |
  |---|---|
  | jlr_s1 | j01–j25 |
  | jlr_s2 | j26–j50 (incl. b/c/d pages) |
  | jlr_s3 | j51–j62 |
  | jlr_s4 | j63–j90 |
  | jlr_s5 | j91–j113 (incl. j98b–d) |
  | jlr_s6 | j114–j127 |
  | jlr_s7 | j128–j140 |

## 4. Jaguar gate-4 report (do it yourself, short)
Write `review/jaguar/04-qc.md` with these sections:
- **Instructions checklist ticks:** take the table at the end of `review/jaguar/01-storyline.md` and map each item to its deck slides.
- **Grader rounds and verdicts.**
- **Greyscale check:** done 2026-10-30; lime becomes light grey and dark green becomes near-black, so it reads fine.
- **Humanizer pass:** a scan found no stock AI words; only the "X, not Y" pattern repeats.
- **Number diff:** confirm no numbers changed during wording edits (`diff` the old deck_text against the new).
- **Font reminder:** embed Inter and IBM Plex Mono when exporting to PowerPoint.

Gilts needs the same report: `review/gilts/04-qc.md`.
