## Slide j01
Group 10 · HBS Case 1
Jaguar Land Rover
Did refinancing at half the interest rate create value?
[PLACEHOLDER: course name] · [PLACEHOLDER: date]

## Slide j02
00 Opening · 2
JLR halved its interest rate in 2015; can that be a free lunch in an efficient market?
Q1
Why could JLR borrow at less than half its 2011 rate?
Q2
What price would holders of the old 8.125% notes accept?
Q3
Does buying the old notes back save JLR money?
Q4
What else does JLR gain, and who wins: JLR, the holders or Tata?
Plain: efficient market = prices already reflect all public information, so nobody can buy or sell at a “wrong” price for free.
Sections: 01 Overview · 02 Exhibits · 03–06 the four questions · 07 Epilogue
Source: case p.1 (“can such a simple, positive-sum game exist in an efficient market?”).

## Slide j03
01
Case overview
Who JLR is, how it recovered under Tata, and the two 2015 refinancings
3

## Slide j04
01 Overview · 4
Two British brands, born in 1922 and 1948, owned by Ford and then Tata
1922
Jaguar’s roots: the Swallow Sidecar Company
1948
Land Rover debuts at the Amsterdam Motor Show
1989
Ford buys Jaguar (US$2.5bn)
2000
Ford buys Land Rover from BMW (€3bn)
2008
Tata Motors buys both from Ford (US$2.3bn)
So what: since 2008 JLR has been owned by Tata Motors, an Indian group; its debt and ratings stand on their own.
Sources: JLR heritage pages and Annual Report 2014/15; AP, 3 Nov 1989 and Automotive Fleet, 24 May 2000 (secondary); Tata Motors/JLR release, 2 Jun 2008.

## Slide j05
01 Overview · 5
Tata bought JLR from Ford in June 2008 for US$2.3bn, as the crisis hit
US$2.3bn
net price, all cash, 2 June 2008; Ford also put about US$600m into JLR’s pension plans
−32%
drop in JLR volumes in the 10 months after the takeover
−£402.4m
net loss for the year to 31 March 2009
So what: Tata bought at the worst moment; the turnaround that followed is what later made cheaper borrowing possible.
Sources: Tata Motors/JLR release, 2 Jun 2008; case p.2.

## Slide j06
01 Overview · 6
Three years later JLR made £1,115m before tax on £9.9bn of revenue
£1,115m
profit before tax in FY2011 (FY2010: £51m)
£9,871m
revenue, up 51%
243,621
vehicles sold to dealers (wholesales), up 26%
Profit after tax was £1,035.9m (case). FY2011 = the year to 31 March 2011.
So what: a loss-maker in 2009 had become strongly profitable by 2011, just as it issued its 8.125% notes.
Sources: JLR FY2011 results release; case p.2.

## Slide j07
01 Overview · 7
JLR sold 462,209 vehicles in FY2015; China was its biggest market
Retail sales by region, year to 31 March 2015 (vehicles)
China
115,969
Europe
87,863
UK
86,750
North America
78,372
Asia Pacific
26,619
All other
66,636
In October 2014 JLR opened its first plant outside the UK, with Chery in Changshu, China (130,000 vehicles a year).
So what: JLR’s growth now leaned on China, a market it could not fully control.
Sources: JLR Annual Report 2014/15, p.71–72; JLR release, 21 Oct 2014. Regions add to 462,209.

## Slide j08
01 Overview · 8
Premium rivals grew 9–17% in 2014, while the EU set a 95g CO₂/km limit for 2020
Brand | Sales growth |
Porsche | +17.1% |
Mercedes-Benz | +12.9% |
Audi (secondary) | +10.5% |
BMW (secondary) | +9.5% |
Land Rover, FY2015 | +8.9% |
EU Regulation 333/2014: new cars sold in the EU must average 95g of CO₂ per km by 2020.
Plain: the g/km target is an average emissions limit across all the cars a maker sells.
So what: JLR had to keep growing and spend heavily on cleaner cars at the same time.
Sources: Porsche, Daimler releases (Jan 2015); BMW and Audi via reprints (secondary); JLR AR 2014/15 (Land Rover 385,279); Reg. (EU) 333/2014. Rivals: calendar 2014.

## Slide j09
01 Overview · 9
JLR sold about a quarter as many cars as BMW, Audi or Mercedes-Benz
Vehicles sold, 2014 (JLR: year to 31 March 2015)
BMW
1,811,719
Audi
1,741,129
Mercedes-Benz
1,650,010
JLR
462,209
Porsche
189,849
So what: a smaller, focused premium maker: scale and spending power matter for the capex ahead.
Sources: BMW (secondary reprint), Audi (secondary), Daimler and Porsche releases, Jan 2015; JLR AR 2014/15. JLR’s fiscal year differs from rivals’ calendar year.

## Slide j10
01 Overview · 10
JLR is Tata Motors’ cash engine: over 80% of its automotive revenue
>80%
of Tata Motors’ consolidated car sales revenue came from JLR in the year to 31 March 2014
Sole
source of the group’s consolidated operating profit that year
So what: JLR’s credit standing matters to the whole Tata group, so its funding choices are group decisions too.
Source: case p.2.

## Slide j11
01 Overview · 11
JLR borrows in pounds and dollars to match where it earns
Where it earns: about 17% of revenue in the UK and about 17% in North America (the case’s figures). By retail volume (slide 7), China was 25% and Europe 19%.
How it borrows: notes in both £ and US$ (Exhibit 1).
Plain: natural hedge = borrowing in the currency you earn in, so a currency move changes both income and debt payments, and the two partly cancel.
The case assumes this hedge removes exchange-rate risk, and uses US$1.50 per £ for March 2015.
So what: we can work in dollars for the dollar notes and convert once at 1.50.
Source: case p.2–3 (Exhibit 1 note).

## Slide j12
01 Overview · 12
JLR’s credit improved: Moody’s upgraded it to Ba2 in 2013 and outlooks turned positive in 2014
When | What happened |
Sep 2013 | Moody’s upgrades JLR from Ba3 to Ba2, outlook stable |
Late 2014 | S&P (BB) and Moody’s (Ba2) both move their outlooks to positive |
Plain: credit rating = an agency’s grade of default risk; BB/Ba = “high yield”, below investment grade (BBB−/Baa3 and up). Outlook = where the agency expects the rating to move next.
So what: lenders saw JLR as safer, which lowers the extra yield it must pay.
Sources: case p.2; Moody’s, “Moody’s Upgrades Jaguar Land Rover to Ba2; Outlook Stable”, 17 Sep 2013 (cited in the case).

## Slide j13
01 Overview · 13
But heavy spending lay ahead: £3.6–3.8bn of capex planned for FY2016
£3.6–3.8bn
planned capex for the year to 31 March 2016
FCF < 0
Moody’s expected free cash flow to turn negative as investment and R&D rose
Plain: capex = spending on plants and equipment; free cash flow = cash from operations minus capex.
So what: JLR would need to keep borrowing, so locking in cheap long-term money had real value to it.
Source: case p.2.

## Slide j14
01 Overview · 14
In early 2015 the Fed was at zero, but high-yield spreads had widened to about 460bp
Plain: spread = the extra yield a company pays over a government bond; 1 basis point (bp) = 0.01%, so 460bp = 4.60 points.
High-yield, summer 2014
330bp
High-yield, Mar 2015
460bp
JLR’s new 2020 notes
189bp
US Fed funds target: 0–0.25%, unchanged on 18 March 2015 (first rise: December 2015).
So what: the market was not getting easier, yet JLR borrowed at only 189bp over Treasuries (193bp on Exhibit 3’s 16 Mar date, slide 54).
Sources: Fortune, 9 Mar 2015 (index not named; secondary); US Federal Reserve statement, 18 Mar 2015; JLR spread: our calculation (slide 31).

## Slide j15
01 Overview · 15
JLR refinanced twice in two months: sterling in February, dollars in March 2015
| Old notes targeted by the tender | New notes issued |
Feb 2015 (£) | £500m 8.25% due 2020 | £400m 3.875% due 2023 |
Mar 2015 (US$) | US$410m 8.125% due 2021 | US$500m 3.5% due 2020 |
Both new issues were priced at record-low coupons for JLR. This case is the dollar deal (lime row).
So what: in each deal JLR swapped an 8%+ coupon for one under 4%.
Sources: JLR releases, 19 Feb and 3 Mar 2015; JLR offering memorandum (2015); JLR Annual Report 2014/15, p.73 (record-low coupons); case p.1.

## Slide j16
01 Overview · 16
Holders could sell their notes back, swap into the new issue, or keep them without covenant protection
Choice | What the holder gets |
Tender by 16 March | the tender price (incl. US$30 per US$1,000 early premium) + interest |
Tender later (to 30 March) | the same, minus the US$30 early premium |
Keep the notes | the notes stay, but covenants go if most holders consent |
Plain: tender offer = the issuer buys back its own bonds; consent solicitation = asking holders to vote away the covenants (the promises that protect them). Holders could also buy the new 3.5% notes.
So what: the deal was built to push holders to sell early.
Sources: JLR tender offer release, 3 Mar 2015 (PR Newswire); pricing release, 16 Mar 2015.

## Slide j17
01 Overview · 17
US$500m raised; buying back every old note would cost US$472m, leaving US$28m before fees
US$500.0m
raised: new 3.5% notes
→
US$471.9m
to buy every old note: 460.6 price + 11.3 interest earned
→
US$28.1m
left over, before fees
410 × 112.35% = 460.6; 410 × 2.7535% = 11.3; 500.0 − 471.9 = 28.1 (US$m). In fact 79.61% of holders sold, for US$375.7m in total (slide 130). Our Q3 uses the all-sold case.
So what: almost all the new money went to buy back the old notes.
Sources: our calculation (calcs.py); JLR final results release, 31 Mar 2015.

## Slide j18
01b Toolkit · 18
A bond’s price is quoted per 100 of face value; JLR’s notes pay coupons twice a year
Plain: face value = the amount repaid at maturity; coupon = the fixed interest it pays.
8.125% notes, per US$1,000 of face value | US$ |
Interest a year: 8.125% × 1,000 | 81.25 |
Paid every six months (15 May, 15 Nov): 81.25 ÷ 2 | 40.625 |
Repaid at maturity | 1,000.00 |
A price of 111.28 means US$1,112.80 for each US$1,000 of face value.
So what: every price in this deck is “per 100 of face value”.
Source: case Exhibit 1 (coupon, dates).

## Slide j19
01b Toolkit · 19
A basis point (bp) is one hundredth of a percentage point
1bp = 0.01%
so 100bp = 1 percentage point
193bp
example from this deck: 3.50% − 1.57% = 1.93 points = 193bp
So what: spreads and rate changes are quoted in bp, always as whole numbers here.
Source: our notation; the example is slide 54.

## Slide j20
01b Toolkit · 20
Money paid later is worth less today: present value and discounting
In words: shrink each future payment by the interest you could have earned meanwhile.
Present value = future cash ÷ (1 + rate)ᵗ, where t = years until it is paid
Example: US$100 paid in 2 years, at 3.5% a year: 100 ÷ 1.035² = 100 ÷ 1.071225 = US$93.35 today
So what: every valuation in this deck is this one idea, applied to each coupon and to the repayment.
Source: CFA Level I, Time Value of Money; our calculation.

## Slide j21
01b Toolkit · 21
Bonds that pay twice a year are discounted in half-years, starting with a part-period
1
Rate per half-year = annual yield ÷ 2
2.28% ÷ 2 = 1.14%
2
Count time in half-years from the deal date, 17 March 2015
15 May 2015 is 58 of 180 days away = 0.3222; then 1.3222, 2.3222 …
3
Discount factor = 1 ÷ (1 + yield ÷ 2)ⁿ
1 ÷ 1.0114^0.3222 = 0.9964
So what: this is the rule behind every PV table that follows.
Source: CFA Level I, Fixed Income (prices between coupon dates); our calculation (calcs.py).

## Slide j22
01b Toolkit · 22
Yield to maturity: the single rate that makes the PV of a bond’s cash equal its price
Plain: YTM = the bond’s internal rate of return if held to maturity, assuming each coupon is reinvested at that same rate and the issuer pays in full.
8.125% notes on 4 Feb 2015 | Value |
Market price (per 100) | 111.28 |
Yield to maturity, May 2021 | 5.94% |
A higher yield means a lower price, and a lower yield a higher price.
So what: a price and a yield are two ways of saying the same thing.
Sources: case Exhibit 2; our calculation (calcs.py). CFA Level I, Fixed Income.

## Slide j23
01b Toolkit · 23
A company’s yield = a Treasury yield + a credit spread
spread 1.93%
Treasury 1.57%
JLR’s 3.50% (March 2015) = 1.57% Treasury + 1.93% credit spread
Plain: credit spread = the extra yield investors want for the company’s default risk. Yield curve = Treasury yields plotted against time to maturity (Exhibit 3).
So what: a lower company yield can come from either layer, and Q1 separates them.
Sources: CFA Level I, Fixed Income (yield spreads); 5-year Treasury, 16 Mar 2015 (US Treasury).

## Slide j24
01b Toolkit · 24
A call lets JLR repay early, so investors price to the call date
Plain: call option = the issuer’s right to repay early at a set price; yield to call = the yield if repaid on the call date; yield to worst = the lower of yield to call and YTM.
8.125% notes on 4 Feb 2015 | Yield |
To maturity, May 2021 | 5.94% |
To first call, 15 May 2016 at 104.0625 | 2.28% |
Yield to worst | 2.28% |
So what: a callable bond’s price is capped near the value of being repaid at the call date: the call price plus the coupons until then (at most about 113 here).
Sources: case Exhibits 1–2; call terms (JLR offering memorandum); our calculation (calcs.py).

## Slide j25
01b Toolkit · 25
Between coupon dates a buyer pays the price plus the interest earned so far
Plain: clean price = the quoted price; accrued interest = coupon earned since the last payment, counted 30/360 (every month 30 days, a year 360); full price = clean + accrued.
On 17 March 2015 (per 100) | Value |
Days since the 15 Nov 2014 coupon (30/360) | 122 |
Accrued: 122 ÷ 180 × 4.0625 | 2.7535 |
Tender price (clean) | 112.3514 |
Full price: 112.3514 + 2.7535 | 115.1049 |
So what: tender prices are clean; accrued interest is paid on top.
Sources: JLR pricing release, 16 Mar 2015; our calculation (calcs.py). CFA Level I, Fixed Income.

## Slide j26
02
Exhibit analysis
Six exhibits: the debt, the market prices, Treasury yields, and three years of accounts
26

## Slide j27
02 Exhibits · 27
Exhibit 1: £2.4bn of debt, almost all in six notes
Facility (£m at 31 Dec 2014) | Rate | Size | Drawn | Undrawn |
US$700m notes due 2018 | 4.125% | 450 | 450 | 0 |
US$500m notes due 2019 | 4.250% | 321 | 321 | 0 |
£500m notes due 2020 (call Mar 2016) | 8.250% | 500 | 500 | 0 |
US$410m notes due 2021 (call May 2016) | 8.125% | 263 | 263 | 0 |
£400m notes due 2022 | 5.000% | 400 | 400 | 0 |
US$500m notes due 2023 (call Feb 2018) | 5.625% | 321 | 321 | 0 |
Revolving credit (3- and 5-year) | – | 1,485 | 0 | 1,485 |
Receivable factoring | – | 225 | 193 | 32 |
Total |  | 3,965 | 2,448 | 1,517 |
Plain: factoring = selling invoices to a bank for cash now. Lime = this case’s notes. So what: JLR’s debt is fixed-rate bonds, not bank loans.
Source: Exhibit 1, case (JLR FY2015 Q3 interim accounts, p.6). Dollar notes shown in £ at 31 Dec 2014 rates.

## Slide j28
02 Exhibits · 28
Notes are 92% of borrowing; the £1,485m credit line is completely unused
Six fixed-rate notes
£2,255m
Receivable factoring
£193m
Revolving credit line
£0m
Notes: 450 + 321 + 500 + 263 + 400 + 321 = £2,255m; 2,255 ÷ 2,448 = 92% of drawn borrowing. Undrawn: £1,485m of revolving credit + £32m of factoring.
Plain: revolving facility = a pre-agreed credit line the company can draw and repay at will.
So what: JLR had spare liquidity; it refinanced by choice, not because it needed cash.
Source: Exhibit 1, case; our calculation.

## Slide j29
02 Exhibits · 29
The two oldest notes cost most, 8.125% and 8.25%, and both become callable in 2016
Coupon rate of each note (% a year), highest first
£500m, due 2020 · call Mar 2016
8.250%
US$410m, due 2021 · call May 2016
8.125%
US$500m, due 2023 · call Feb 2018
5.625%
£400m, due 2022 · no call
5.000%
US$500m, due 2019 · no call
4.250%
US$700m, due 2018 · no call
4.125%
Both date from 2011–12, when JLR was a weaker credit. “No call” = no call date in Exhibit 1.
So what: these two (dark bars; the US$410m is this case) are the obvious refinancing targets.
Source: Exhibit 1, case.

## Slide j30
02 Exhibits · 30
Those two notes cost £34.5m a year more than JLR’s 2015 rates
Old notes vs JLR’s 2015 rate | Working | £m a year |
US$410m at 8.125% vs 3.5% | 410 ÷ 1.50 = £273.3m × (8.125 − 3.5)% | 12.6 |
£500m at 8.25% vs 3.875% | £500m × (8.25 − 3.875)% | 21.9 |
Total extra interest |  | 34.5 |
2015 rates = the coupons of the new notes: 3.5% (US$, 2020) and 3.875% (£, 2023). US$ converted once at the case’s 1.50.
So what: a clear target for refinancing; whether buying them back creates value is Q3.
Sources: Exhibits 1–2, case; our calculation (calcs.py).

## Slide j31
02 Exhibits · 31
JLR’s spread over Treasuries fell from 497bp (2011) to 189bp (2015)
Spread at issue, bp = (coupon − same-tenor Treasury yield) × 100
497
May 2011
8.125 − 3.15
362
Jan 2013
5.625 − 2.00
260
Dec 2013
4.125 − 1.52
272
Oct 2014
4.250 − 1.53
189
Mar 2015
3.500 − 1.61
Notes: 8.125% 2021 and 5.625% 2023 vs the 10-year Treasury; 4.125% 2018, 4.25% 2019 and 3.5% 2020 vs the 5-year. Assumes issue at par (coupon = yield); half bp rounded down.
So what: lenders demanded far less for JLR’s risk (one small rise in 2014).
Sources: JLR/Tata filings for issue dates and coupons (some dates approximate); US Treasury daily par yields; our calculation (calcs.py).

## Slide j32
02 Exhibits · 32
Repayments are spread from 2018 to 2023, so there is no single wall of debt
Notes falling due each year, £m (dark = the two 2016-callable notes)
450
321
500
263
400
321
2018
2019
2020
2021
2022
2023
So what: no year carries more than £500m: low refinancing pressure.
Source: Exhibit 1, case. Dollar notes at the exhibit’s 31 Dec 2014 £ values.

## Slide j33
02 Exhibits · 33
Exhibit 1 converts dollars at about 1.56; the case tells us to use 1.50 for March 2015
US$410m notes | Value |
Exhibit 1 (31 Dec 2014 rate) | £263m |
Implied rate: 410 ÷ 263 | US$1.559 per £ |
At the case’s March 2015 rate: 410 ÷ 1.50 | £273.3m |
The other dollar notes give the same rate: 500 ÷ 321 = 1.558; 700 ÷ 450 = 1.556.
So what: we keep the bond maths in US$ and convert once, at 1.50, when £ figures are needed.
Sources: Exhibit 1 and its note, case; our calculation (calcs.py).

## Slide j34
02 Exhibits · 34
Exhibit 2: old notes traded at 111.28, an 11% premium
Note | Security (ISIN) | Start | End | Last traded | Price |
8.125% US$ | USG50027AB03 | 19/05/2011 | 15/05/2021 | 04/02/2015 | 111.28 i |
8.125% US$ | US47009XAB55 | 19/05/2011 | 15/05/2021 | 07/08/2014 | 111.58 i |
8.25% £ | XS0765386627 | 27/03/2012 | 15/03/2020 | 30/01/2015 | 110.94 i |
8.25% £ | XS0765386973 | 27/03/2012 | 15/03/2020 | 30/01/2015 | 111.18 i |
3.5% US$ (new) | USG5002FAE63 | 06/03/2015 | 15/03/2020 | 12/03/2015 | 100.00 i |
3.5% US$ (new) | US47010BAE48 | 06/03/2015 | 15/03/2020 | 12/03/2015 | 100.00 i |
3.875% £ (new) | XS1195502031 | 24/02/2015 | 01/03/2023 | 06/03/2015 | 100.00 i |
3.875% £ (new) | XS1195503351 | 24/02/2015 | 01/03/2023 | 06/03/2015 | 100.00 i |
Plain: per 100 of face; “i” = indicative dealer quote, not a trade. Two lines per note = one note sold to US and non-US buyers; the 8.25% lines agree within 0.24.
So what: holders valued the old notes 11.28 points above face; the new ones sit at 100.
Source: Exhibit 2, case (Bourse de Luxembourg). Dates dd/mm/yyyy; prices 2 dp.

## Slide j35
02 Exhibits · 35
At 111.28 the notes yielded 5.94% to 2021 but only 2.28% to the 2016 call
On 4 Feb 2015 a buyer pays 111.28 + accrued 1.7830 (79 ÷ 180 × 4.0625) = 113.0630 per 100. Each yield (found by trial) makes the PV of the cash equal that.
Call, 15 May 2016, at 104.0625
3 coupons of 4.0625, then 104.0625 (1.3 years)
2.28%
Maturity, 15 May 2021, at 100
13 coupons of 4.0625, then 100 (6.3 years)
5.94%
So what: both reprice to 111.28 clean; yield to worst is 2.28%, so the market priced the bond as if JLR would repay in 2016.
Sources: Exhibits 1–2, case; call terms; our calculation (calcs.py).

## Slide j36
02 Exhibits · 36
The sterling 8.25% notes told the same story at 110.94
110.94
price of the £500m 8.25% notes on 30 Jan 2015, also well above 100
Mar 2016
their first call date, like the dollar notes’ May 2016
JLR launched a tender for them on 19 Feb 2015, funded by £400m of new 3.875% notes due 2023 and priced at a fixed 50bp over the UK gilt rate. Its result is not in our sources.
So what: the pattern is not unique to the dollar notes: both old bonds traded as near-certain early repayments.
Sources: Exhibits 1–2, case; JLR offering memorandum 2015, p.9 (“On 19 February 2015, we commenced a tender offer”).

## Slide j37
02 Exhibits · 37
The new 2015 notes trade at 100, so their coupons equal JLR’s market yield
3.500%
US$500m new notes due 2020: price 100.00, so yield = coupon = 3.500%
3.875%
£400m new notes due 2023: price 100.00, so yield = coupon = 3.875%
Plain: a bond priced at 100 (par) has a yield equal to its coupon.
So what: 3.5% is JLR’s 5-year dollar borrowing cost in March 2015, the rate used throughout Q2 and Q3.
Source: Exhibit 2, case.

## Slide j38
02 Exhibits · 38
Exhibit 3: from 2011 to 2015, long Treasury yields fell a lot; short ones barely moved
Yield (%)
0
1
2
3
4
5
0
5
10
20
30
Years to maturity
16 May 2011 (dashed)
16 Mar 2015
Plain: yield curve = Treasury yields plotted against time to maturity.
So what: 10-year 3.15% → 2.10%, 5-year 1.83% → 1.57%, 1-year 0.18% → 0.26%: the long end fell, the short end barely moved.
Source: Exhibit 3, case; rebuilt from US Treasury daily par yields (home.treasury.gov), 16 May 2011 and 16 Mar 2015.

## Slide j39
02 Exhibits · 39
The 10-year Treasury fell 105bp, the 5-year only 26bp
Change in Treasury yield, 16 May 2011 → 16 Mar 2015, in bp (1bp = 0.01%), by time to maturity
0
1M
+1
3M
+8
6M
+8
1Y
+12
2Y
+13
3Y
−26
5Y
−60
7Y
−105
10Y
−154
20Y
−161
30Y
The 14-month Treasury that priced the tender (0.25% note due May 2016) yielded 0.395% on 16 Mar 2015 (slide 81).
So what: at JLR’s 5-year tenor, Treasuries explain only 26bp of the 462bp coupon fall.
Sources: Exhibit 3, case; US Treasury daily par yields; JLR pricing release, 16 Mar 2015.

## Slide j40
02 Exhibits · 40
Exhibit 4: revenue grew 43% and profit before tax 69% in two years
£m, years to 31 March | FY2012 | FY2013 | FY2014 | FY2015 (9m) |
Revenue | 13,512 | 15,784 | 19,386 | 16,040 |
Material and other cost of sales | −8,733 | −9,904 | −11,904 | −9,768 |
Employee cost | −1,039 | −1,334 | −1,654 | −1,427 |
Other expenses | −2,529 | −3,075 | −3,717 | −2,941 |
Development costs capitalised | 751 | 860 | 1,030 | 850 |
Other income | 37 | 70 | 153 | 150 |
Depreciation and amortisation | −465 | −622 | −875 | −743 |
FY2012 → FY2014: revenue 19,386 ÷ 13,512 − 1 = 43.5%; PBT 2,501 ÷ 1,479 − 1 = 69.1%.
So what: profit grew faster than sales.
Source: Exhibit 4, case (income statement, 1 of 2).

## Slide j40b
02 Exhibits · 40b
Exhibit 4, continued: profit before tax rose from £1,479m to £2,501m
£m, years to 31 March | FY2012 | FY2013 | FY2014 | FY2015 (9m) |
Foreign exchange gain/(loss) | 14 | −109 | 236 | 58 |
Finance income | 16 | 34 | 38 | 36 |
Finance expenses (net) | −85 | −18 | −185 | −13 |
Share of loss from joint ventures | – | −12 | −7 | −24 |
Profit before tax | 1,479 | 1,674 | 2,501 | 2,218 |
Income tax expense | −19 | −460 | −622 | −482 |
Profit after tax | 1,460 | 1,214 | 1,879 | 1,736 |
So what: a far bigger, more profitable company than in 2011; slides 41–43 test that profit.
Source: Exhibit 4, case (income statement, 2 of 2). “–” = no amount shown.

## Slide j41
02 Exhibits · 41
EBITDA margin rose from 14.8% to 18.0%
Plain: EBITDA = profit before interest, tax, depreciation and amortisation, a rough measure of cash earnings. Here: PBT + D&A + finance expense − finance income − FX gain (an FX loss is added back).
Year | EBITDA working, £m | EBITDA | Revenue | Margin |
FY2012 | 1,479 + 465 + 85 − 16 − 14 | 1,999 | 13,512 | 14.8% |
FY2013 | 1,674 + 622 + 18 − 34 + 109 | 2,389 | 15,784 | 15.1% |
FY2014 | 2,501 + 875 + 185 − 38 − 236 | 3,287 | 19,386 | 17.0% |
FY2015 (9m) | 2,218 + 743 + 13 − 36 − 58 | 2,880 | 16,040 | 18.0% |
So what: each £ of sales produced more cash to service debt.
Sources: Exhibit 4, case; our calculation (calcs.py). Margin = EBITDA ÷ revenue.

## Slide j42
02 Exhibits · 42
Capitalised development costs equal 38–51% of profit before tax
Plain: capitalising = recording R&D spending as an asset instead of an expense, which lifts this year’s profit; the cost is charged later through amortisation.
Development costs capitalised ÷ profit before tax, £m
FY2012 · 751 ÷ 1,479
51%
FY2013 · 860 ÷ 1,674
51%
FY2014 · 1,030 ÷ 2,501
41%
FY2015 (9m) · 850 ÷ 2,218
38%
So what: profit quality needs care, so we also look at cash flow (Exhibit 5).
Sources: Exhibit 4, case; our calculation (calcs.py).

## Slide j43
02 Exhibits · 43
FY2012’s tax charge was unusually low (1.28%), so its profit after tax overstates normal earnings
Effective tax rate = tax charged ÷ profit before tax, £m
FY2012 · 19 ÷ 1,479
1.28%
FY2013 · 460 ÷ 1,674
27.48%
FY2014 · 622 ÷ 2,501
24.87%
FY2015 (9m) · 482 ÷ 2,218
21.73%
The case does not explain FY2012’s low rate, so we do not guess the cause.
So what: compare years on profit before tax, not after.
Sources: Exhibit 4, case; our calculation (calcs.py).

## Slide j44
02 Exhibits · 44
Exhibit 5: operations brought in £2.4–3.4bn of cash a year
£m, years to 31 March | FY2012 | FY2013 | FY2014 | FY2015 (9m) |
Profit for the year | 1,460 | 1,214 | 1,879 | 1,736 |
Depreciation and amortisation | 466 | 622 | 875 | 743 |
Finance expenses/(income) | 69 | −16 | 100 | −23 |
Others | 96 | 475 | 577 | 610 |
Cash from operations before working capital | 2,091 | 2,295 | 3,431 | 3,066 |
Net cash from operations (CFO) | 2,500 | 2,429 | 3,422 | 2,572 |
Plain: CFO = cash from operations: the cash the business itself generated. The case omits the working-capital and tax rows: they net to +409 / +134 / −9 / −494.
So what: JLR’s cash generation was large and steady.
Source: Exhibit 5, case (cash flow statement, 1 of 4).

## Slide j44b
02 Exhibits · 44b
Exhibit 5, continued: investment ran at £1.5–2.7bn a year
£m, years to 31 March | FY2012 | FY2013 | FY2014 | FY2015 (9m) |
Investment in joint ventures | −1 | −71 | −92 | −124 |
Property, plant and equipment | −596 | −891 | −1,201 | −1,147 |
Intangible assets (incl. development) | −814 | −958 | −1,155 | −885 |
Other investments | −131 | −689 | −288 | 131 |
Net cash used for investing | −1,542 | −2,609 | −2,736 | −2,025 |
So what: most of the cash from operations went straight back into plants and new models.
Source: Exhibit 5, case (cash flow statement, 2 of 4).

## Slide j44c
02 Exhibits · 44c
Exhibit 5, continued: JLR paid £97–269m of cash interest a year, and £150m of dividends a year from FY2013
£m, years to 31 March | FY2012 | FY2013 | FY2014 | FY2015 (9m) |
Finance expenses and fees paid | −128 | −179 | −269 | −97 |
Short-term debt raised | 105 | 88 | 1 | 21 |
Short-term debt repaid | −655 | −250 | −158 | −6 |
Long-term debt raised | 1,500 | 317 | 829 | 313 |
Long-term debt repaid | −374 | – | −746 | – |
Lease payments | −4 | −4 | −5 | −4 |
Dividends paid | – | −150 | −150 | −150 |
Net cash from financing | 444 | −178 | −498 | 77 |
So what: cash interest is small next to the cash JLR generates (tested on slide 46).
Source: Exhibit 5, case (cash flow statement, 3 of 4). FY2015 = 9 months. “–” = no amount shown.

## Slide j44d
02 Exhibits · 44d
Exhibit 5, continued: JLR’s cash rose from £1,028m to £2,884m
£m, years to 31 March | FY2012 | FY2013 | FY2014 | FY2015 (9m) |
Net cash from operations (CFO) | 2,500 | 2,429 | 3,422 | 2,572 |
Net cash used for investing | −1,542 | −2,609 | −2,736 | −2,025 |
Net cash from financing | 444 | −178 | −498 | 77 |
Net change in cash | 1,402 | −358 | 188 | 624 |
Cash at the start of the year | 1,028 | 2,430 | 2,072 | 2,260 |
Cash at the end of the year | 2,430 | 2,072 | 2,260 | 2,884 |
Each year: CFO + investing + financing = net change in cash; start + change = end.
So what: operations paid for the heavy investment and still left cash to spare.
Source: Exhibit 5, case (cash flow statement, 4 of 4). CFO and investing repeated from pages 44 and 44b.

## Slide j45
02 Exhibits · 45
Free cash flow stayed positive but thin, and Moody’s expected it to turn negative
Plain: free cash flow (FCF) = CFO − capex; capex here includes spending on intangibles such as development.
Year | CFO − PP&E − intangibles | FCF | After interest and dividends |
FY2012 | 2,500 − 596 − 814 | 1,090 | 1,090 − 128 − 0 = 962 |
FY2013 | 2,429 − 891 − 958 | 580 | 580 − 179 − 150 = 251 |
FY2014 | 3,422 − 1,201 − 1,155 | 1,066 | 1,066 − 269 − 150 = 647 |
FY2015 (9m) | 2,572 − 1,147 − 885 | 540 | 540 − 97 − 150 = 293 |
So what: heavy investment ate most of the cash, so cheap long-term funding mattered.
Sources: Exhibit 5, case; our calculation (calcs.py). £m.

## Slide j46
02 Exhibits · 46
Cash interest is small next to earnings: EBITDA covers it 12 to 30 times
Plain: interest cover = how many times earnings could pay the interest. Here: EBITDA (slide 41) ÷ cash finance expenses paid (Exhibit 5).
EBITDA ÷ cash interest, £m
FY2012 · 1,999 ÷ 128
15.6×
FY2013 · 2,389 ÷ 179
13.3×
FY2014 · 3,287 ÷ 269
12.2×
FY2015 (9m) · 2,880 ÷ 97
29.7×
So what: default risk from interest is low (FY2015: 9 months; coupon timing flatters its cover).
Sources: Exhibits 4–5, case; our calculation (calcs.py).

## Slide j47
02 Exhibits · 47
Exhibit 6: equity more than doubled, from £2.9bn to £6.8bn
£m, at 31 March | 2012 | 2013 | 2014 | Dec 2014 |
Ordinary share capital | 1,501 | 1,501 | 1,501 | 1,501 |
Reserves and surplus | 1,423 | 2,038 | 4,363 | 5,296 |
Equity (shareholders’ funds) | 2,924 | 3,539 | 5,864 | 6,797 |
Total liabilities | 7,293 | 9,298 | 9,725 | 10,732 |
Total liabilities and equity | 10,217 | 12,837 | 15,589 | 17,529 |
Equity: 2,924 → 6,797, up 132% (6,797 ÷ 2,924 − 1). Assets and liabilities in full on the next two pages.
So what: a thicker cushion of owners’ money now protects lenders.
Source: Exhibit 6, case (balance sheet, 1 of 3). Year-ends 31 March; FY2015 = 31 Dec 2014.

## Slide j47b
02 Exhibits · 47b
Exhibit 6, continued: assets grew from £10.2bn to £17.5bn
£m, at 31 March | 2012 | 2013 | 2014 | Dec 2014 |
Property, plant and equipment | 1,586 | 2,335 | 3,184 | 4,137 |
Intangible assets | 2,801 | 3,522 | 4,240 | 4,769 |
Other non-current assets | 595 | 771 | 935 | 817 |
Total non-current assets | 4,982 | 6,628 | 8,359 | 9,723 |
Cash and cash equivalents | 2,430 | 2,072 | 2,260 | 2,884 |
Short-term deposits | – | 775 | 1,199 | 1,143 |
Trade receivables | 662 | 927 | 831 | 879 |
Inventories | 1,497 | 1,795 | 2,174 | 2,238 |
Other current assets | 646 | 640 | 766 | 662 |
Total current assets | 5,235 | 6,209 | 7,230 | 7,806 |
Total assets | 10,217 | 12,837 | 15,589 | 17,529 |
So what: assets grew 72% in under three years (17,529 ÷ 10,217 − 1).
Source: Exhibit 6, case (balance sheet, 2 of 3).

## Slide j47c
02 Exhibits · 47c
Exhibit 6, continued: loans are only 21–27% of liabilities
£m, at 31 March | 2012 | 2013 | 2014 | Dec 2014 |
Accounts payable | 3,285 | 4,227 | 4,787 | 4,699 |
Short-term borrowings | 490 | 328 | 167 | 193 |
Provisions and other current liabilities | 1,266 | 1,442 | 1,180 | 1,461 |
Total current liabilities | 5,041 | 5,997 | 6,134 | 6,353 |
Long-term debt | 1,484 | 1,839 | 1,843 | 2,230 |
Provisions | 344 | 468 | 582 | 638 |
Retirement benefit obligations | 327 | 657 | 674 | 743 |
Other non-current liabilities | 97 | 337 | 492 | 768 |
Total non-current liabilities | 2,252 | 3,301 | 3,591 | 4,379 |
Total liabilities | 7,293 | 9,298 | 9,725 | 10,732 |
So what: most liabilities are suppliers and provisions; loans (bold) are 21–27% of the total.
Working: 193 + 2,230 = £2,423m = 23% of 10,732; Exhibit 1 shows £2,448m (likely issue costs netted; our inference).
Source: Exhibit 6, case (balance sheet, 3 of 3).

## Slide j48
02 Exhibits · 48
JLR held more cash than debt: net cash rose from £456m to £1,604m
Year | Cash + deposits − short-term debt − long-term debt | Net cash |
FY2012 | 2,430 + 0 − 490 − 1,484 | 456 |
FY2013 | 2,072 + 775 − 328 − 1,839 | 680 |
FY2014 | 2,260 + 1,199 − 167 − 1,843 | 1,449 |
FY2015 (9m) | 2,884 + 1,143 − 193 − 2,230 | 1,604 |
Plain: net cash = cash and deposits minus all borrowings; positive means the company could repay every loan from cash.
So what: JLR could repay all its debt from cash; lenders face little default risk.
Sources: Exhibit 6, case; our calculation (calcs.py). £m.

## Slide j49
02 Exhibits · 49
Debt/equity halved, from 0.68 to 0.36
Plain: debt/equity = all borrowings ÷ shareholders’ equity, a measure of leverage (how much is borrowed per £1 of owners’ money).
(Short-term + long-term debt) ÷ equity, £m
FY2012 · (490 + 1,484) ÷ 2,924
0.68
FY2013 · (328 + 1,839) ÷ 3,539
0.61
FY2014 · (167 + 1,843) ÷ 5,864
0.34
FY2015 (9m) · (193 + 2,230) ÷ 6,797
0.36
So what: much lower leverage supports a better rating and a lower spread.
Sources: Exhibit 6, case; our calculation (calcs.py).

## Slide j50
02 Exhibits · 50
The exhibits together: a stronger borrower, expensive callable notes, and a market already pricing the call
Exhibit 1 · debt
Six fixed-rate notes; the 8.125% and 8.25% cost £34.5m a year extra
Feeds Q3, Q4
Exhibit 2 · prices
Old notes at 111.28 = 2.28% to the 2016 call; new notes at 100
Feeds Q2, Q3
Exhibit 3 · Treasuries
5-year Treasury down only 26bp; long end down much more
Feeds Q1
Exhibits 4–6 · accounts
Higher margins, net cash, debt/equity halved
Feeds Q1
So what: a lower coupon reflects a stronger borrower; the call caps the old notes’ value. Q1–Q4 test both.
Sources: Exhibits 1–6, case; slides 27–49.

## Slide j51
03
Q1: why the coupon halved
From 8.125% in 2011 to 3.5% in 2015: lower Treasury rates, a shorter loan, or a safer JLR?
51

## Slide j52
03 Q1 · 52
Q1: what let JLR’s coupon fall from 8.125% to 3.5%?
A new bond’s coupon ≈ the Treasury yield for the same tenor (length of loan) + a credit spread for the borrower’s risk. So three things could have changed:
Cause 1
Treasury rates fell: the whole market’s risk-free rate was lower in 2015
Tested on 53–56
Cause 2
The loan is different: 5 years in 2015 vs 10 in 2011, and the 2011 notes had a call
Tested on 55, 61
Cause 3
JLR became safer, so lenders asked a smaller credit spread
Tested on 57–60
Assumptions: each note was issued at par (coupon = yield at issue); each is compared with the Treasury of the same tenor on its pricing day.
Sources: Exhibits 1–3, case; CFA Level 1, fixed income (yield spreads).

## Slide j53
03 Q1 · 53
2011: 8.125% = 3.15% Treasury + 497bp spread
Plain: credit spread = the extra yield lenders demand over a Treasury of the same tenor, to cover the risk the borrower does not pay. 1bp = 0.01%.
May 2011: 8.125% coupon (US$410m due 2021, 10 years)
Treasury 3.15%
+ spread 497bp
Working: 8.125% − 3.15% (10-year Treasury, 16 May 2011) = 4.975% = 497bp (half bp rounded down).
So what: in 2011 most of the coupon, 497 of 812bp, was JLR’s credit spread.
Sources: Exhibit 1, case; US Treasury daily par yields, 16 May 2011; our calculation (calcs.py).

## Slide j54
03 Q1 · 54
2015: 3.50% = 1.57% Treasury + 193bp spread
May 2011: 8.125% coupon (for comparison, same scale)
Treasury 3.15%
+ spread 497bp
Mar 2015: 3.500% coupon (US$500m due 2020, 5 years)
Treasury 1.57%
+ spread 193bp
Working: 3.50% − 1.57% (5-year Treasury, 16 Mar 2015, Exhibit 3’s date) = 1.93% = 193bp. On the 3 Mar pricing day the 5-year was 1.61%, giving 189bp (slide 31); the 4bp gap changes nothing.
So what: the spread shrank far more than the Treasury part.
Sources: Exhibits 2–3, case; US Treasury daily par yields; our calculation (calcs.py).

## Slide j55
03 Q1 · 55
Two thirds of the 462bp fall came from a narrower credit spread
8.125%
2011 coupon
−158bp
Treasury + tenor
−304bp
Credit spread
3.50%
2015 coupon
Working: 8.125% − 3.50% = 462bp. Spread: 497 − 193 = 304bp (304 ÷ 462 = 66%). Treasury level + shorter tenor: 3.15% − 1.57% = 158bp (34%).
Plain: the 304bp also holds the value of the 2011 call and the extra spread a 10-year loan carries; the case’s data cannot split these out. The 158bp is one block: how it splits depends on the order chosen.
So what: JLR’s own credit did most of the work.
Sources: Exhibits 1–3, case; US Treasury daily par yields; our calculation (calcs.py). Half bp rounded down.

## Slide j56
03 Q1 · 56
At the same 5-year tenor, Treasuries fell only 26bp
−26bp
5-year Treasury: 1.83% (16 May 2011) → 1.57% (16 Mar 2015)
−462bp
JLR’s coupon: 8.125% (10-year, 2011) → 3.50% (5-year, 2015)
Working: 1.57% − 1.83% = −0.26% = −26bp; 26 ÷ 462 = 6% of the coupon fall.
Plain: comparing the same tenor strips out the effect of JLR borrowing for 5 years instead of 10.
So what: lower government rates explain little of the fall.
Sources: Exhibit 3, case; US Treasury daily par yields; our calculation (calcs.py).

## Slide j57
03 Q1 · 57
Test 1: the same bond’s spread over Treasuries fell from 497bp at issue to 199bp in Feb 2015
Step | Working | Result |
1 Horizon to the call | 4 Feb 2015 → 15 May 2016 = 466 days ÷ 365 | 1.276 years |
2 Treasury for 1.276 years | 0.20% + 0.276 × (0.52% − 0.20%) | 0.29% |
3 Spread, Feb 2015 | 2.28% (yield to call, slide 35) − 0.29% | 199bp |
4 Change since issue | 199 − 497 | −298bp |
Step 2 is a straight line between the 1-year (0.20%) and 2-year (0.52%) Treasury yields of 4 Feb 2015. Caveat: 497bp was a 10-year spread and 199bp a 15-month one, so part of the fall is the extra spread long loans carry. (Slides 69–70: 14 months from 17 Mar.)
So what: the market itself cut the spread on this very bond by about 300bp.
Sources: Exhibits 1–2, case; US Treasury daily par yields, 4 Feb 2015; our calculation (calcs.py).

## Slide j58
03 Q1 · 58
Test 2: across five dollar issues, JLR’s spread fell by 308bp
Plain: tenor = the length of a loan; each coupon is compared with the same-tenor Treasury. Bars = change in spread between dollar issues, bp (levels on slide 31).
−135
May 2011 → Jan 2013
−102
Jan 2013 → Dec 2013
+12
Dec 2013 → Oct 2014
−83
Oct 2014 → Mar 2015
Total: −135 − 102 + 12 − 83 = −308bp on the 3 Mar pricing day (= −304bp on Exhibit 3’s 16 Mar date).
So what: a steady fall, issue after issue; only Oct 2014 ticked up.
Sources: JLR/Tata filings (issue dates, some approximate); US Treasury daily par yields; our calculation (calcs.py).

## Slide j59
03 Q1 · 59
Test 3: market-wide high-yield spreads fell about 40bp; JLR’s fell 304bp
Plain: high-yield index spread = the average spread of all below-investment-grade (“junk”) bonds over Treasuries. JLR was rated in this group in 2011 and 2015.
Fall in spread, May 2011 → March 2015, bp
All US high-yield bonds
42bp fall
JLR
304bp fall
Market: about 502bp (BofA Merrill Lynch index, ~10 May 2011) → about 460bp (overall junk market, Fortune, 9 Mar 2015) = about −42bp. Different indices and dates: indicative only. JLR-specific ≈ 304 − 42 ≈ 260bp.
So what: about 260bp of the fall belongs to JLR alone.
Sources: Bloomberg via Business Standard, 10 May 2011 (secondary; “…down 112 basis points this year to 502, according to Bank of America Merrill Lynch index data”); Fortune, 9 Mar 2015 (secondary; “…stands at about 4.6 percentage points”); our calculation.

## Slide j60
03 Q1 · 60
The reason: JLR became a far safer borrower
18.0%
from 14.8% (FY2012)
EBITDA margin
£1,604m
from £456m
Net cash
0.36
from 0.68
Debt/equity
12–30×
every year
Interest cover
All FY2012 → FY2015 (9 months), from slides 41, 46, 48 and 49.
Rating: Moody’s upgraded JLR from Ba3 to Ba2 in Sep 2013, citing “strong and fairly stable credit metrics over the past three years”. Still below investment grade (Baa3 or better).
So what: the falling spread matches the improving numbers.
Sources: Exhibits 4–6, case; Business Standard, 18 Sep 2013 (Moody’s upgrade; secondary); JLR offering memorandum (investment-grade definition); our calculation (calcs.py).

## Slide j61
03 Q1 · 61
The 2015 notes are also shorter, and the 2011 notes’ call had to be paid for
Shorter loan
10 years (2011) vs 5 years (2015). Lenders usually ask less for a shorter loan: Treasuries themselves were 2.10% at 10 years and 1.57% at 5 on 16 Mar 2015, a 53bp gap.
The 2011 call
The 2021 notes were sold as “callable after five” years. A call helps the borrower, so buyers want a higher coupon for it, and that is part of the 8.125%.
The 2020 notes’ own early-repayment terms were not found, so we make no claim about them.
So what: part of the 462bp is a different loan, not a cheaper borrower; the 158bp block and part of the 304bp hold it.
Sources: US Treasury daily par yields, 16 Mar 2015; Bloomberg via Business Standard, 10 May 2011 (secondary; “the 2021 notes callable after five, the banker said”).

## Slide j62
03 Q1 · 62
Q1 answer: mostly JLR’s better credit; lower rates and a shorter tenor explain the rest
The 462bp fall in JLR’s coupon, 2011 → 2015
304bp · 66%
158bp · 34%
Narrower credit spread
Treasury level + shorter tenor
Three tests agree: the same bond’s spread fell ~300bp (57); spreads fell issue after issue (58); the market moved only ~40bp (59). At equal tenor, Treasuries fell just 26bp (56).
So what: lower coupon = better credit, not cheaper money. Refinancing at a fair price therefore creates little value by itself, as Q2 and Q3 test.
Sources: slides 53–61; our calculation (calcs.py).

## Slide j63
04
Q2: the price holders would accept
What the 8.125% notes were worth on 17 March 2015, and how JLR set its tender price
63

## Slide j64
04 Q2 · 64
Q2: what price makes holders give up their 8.125% notes?
A holder of the 8.125% notes due 2021 had four choices in March 2015. JLR’s offer only works if tendering beats the others:
Keep
Collect coupons and, almost certainly, be repaid at 104.0625 in May 2016
Value: slides 69–80
Sell
Sell in the market at the going price (111.28 on 4 Feb 2015)
Market rate: slide 70
Tender early
Accept JLR’s offer by 16 March for US$1,123.52 per US$1,000
Offer: slides 81–83
Tender late
Accept by 30 March for US$30 less: US$1,093.52
Slide 83
So what: the fair price is what the notes are worth if kept; the offer must at least match it.
Sources: Exhibits 1–2, case; JLR tender releases (PR Newswire, 3 and 17 Mar 2015).

## Slide j65
04 Q2 · 65
The cash still due: US$40.625 every May and November, then US$1,000
Cash per US$1,000 note, 15 May 2015 to 15 May 2021 (13 payments; final bar not to scale)
40.625
’15
’16
’17
’18
’19
’20
40.625
1,040.625
’21
Coupon = 8.125% ÷ 2 × US$1,000 = US$40.625 each half-year; the last payment is 1,000 + 40.625. Dark = the three payments due up to the May 2016 call date.
So what: these are the cash flows any valuation discounts.
Sources: Exhibit 1, case (coupon, maturity 15 May 2021); our calculation (calcs.py).

## Slide j66
04 Q2 · 66
JLR can repay these notes from 15 May 2016 at 104.0625%
104.0625
per 100 of face: the price at which JLR may repay from 15 May 2016 = 100 + half the 8.125% coupon
15 May ’16
first call date, 14 months after the 17 Mar 2015 deal
Plain: offering memorandum (OM) = the legal document describing a bond. The 2015 OM prints 104.663%; we use 104.0625% because only it reproduces the tender price to the cent (slide 82), and the 8.25% notes follow the same rule (104.125).
So what: on the call date a holder gets 104.0625 plus the last coupon: 108.125 per 100.
Sources: JLR offering memorandum 2015, p.105 (“On or after 15 May 2016, the Issuer may redeem … initially at 104.663%”); JLR pricing release, 16 Mar 2015; our calculation.

## Slide j67
04 Q2 · 67
With 8.125% to pay and 3.5% available, JLR will almost certainly repay in 2016
Interest rate a year on US$410m
Keep the old notes
8.125%
Borrow anew (2015 notes)
3.500%
Calling in May 2016 and refinancing at about 3.5% would save about 4.6% a year on US$410m: roughly US$19m a year before funding the premium (slide 96 nets it to US$16.8m), far more than the 4.0625-point call premium (US$16.7m once).
Working: (8.125 − 3.5)% × 410 = US$19.0m a year; 4.0625% × 410 = US$16.7m.
Plain: the call is JLR’s choice; it uses it only when refinancing is cheaper, and here it is by a wide margin. So the notes behave like a 14-month bond.
So what: value them to May 2016, not 2021.
Sources: Exhibits 1–2, case; our calculation.

## Slide j68
04 Q2 · 68
Accrued interest at 17 March 2015: 122 days → US$27.53 per US$1,000
Plain: 30/360 = every month counts as 30 days and a year as 360, so each half-year has 180 days.
15 Nov 2014
17 Mar: 122 days
15 May 2015: 180
Working: 15 Nov → 17 Mar = 15 + 30 + 30 + 30 + 17 = 122 days. 122 ÷ 180 × 40.625 = US$27.53 (2.7535 per 100). Late tenders, settled 31 Mar: 136 days → US$30.69.
So what: a buyer pays this on top of the clean price; it matches the US$27.53 and US$30.69 JLR paid.
Sources: JLR tender releases (PR Newswire, 17 and 31 Mar 2015: “equivalent to $30.69 per $1,000”); our calculation (calcs.py).

## Slide j69
04 Q2 · 69
To value the notes, discount their three remaining payments at a 14-month rate
Payments left until the call: 4.0625 (May 2015), 4.0625 (Nov 2015), 104.0625 + 4.0625 = 108.125 (May 2016), per 100
1
Pick the discount rate: the yield a holder needs for 14 months of JLR risk
Two anchors: the market’s 2.28% (slide 70) and JLR’s own 3.5%; then a grid
2
Discount each of the three payments in half-years from 17 March (slide 21)
n = 0.3222, 1.3222, 2.3222; DF = 1 ÷ (1 + rate ÷ 2)ⁿ
3
Add the PVs to get the full price; subtract accrued 2.7535
Clean price = full − 2.7535, per 100 of face
So what: one method, many rates: slides 71–82 run it step by step.
Sources: CFA Level I, Fixed Income (pricing between coupon dates); our calculation (calcs.py).

## Slide j70
04 Q2 · 70
The market’s 14-month rate for JLR was about 2.28%
2.28%
yield to the 2016 call at the 4 Feb 2015 market price of 111.28 (slide 35)
111.28
Exhibit 2’s last price before the offer was announced on 3 Mar
Plain: this is the rate at which buyers were actually willing to hold JLR’s notes until the call. A price set at this rate is what holders could get by selling.
So what: 2.28% is our main discount rate; JLR’s 3.5% and a grid from 0.5% test how much the answer depends on it.
Sources: Exhibit 2, case; our calculation (calcs.py).

## Slide j71
04 Q2 · 71
At 2.28%, the notes are worth 110.61
Rate 2.28% a year → 1.14% per half-year. DF = 1 ÷ (1 + 0.0114)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.996354 | 4.0477 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.985124 | 4.0021 |
15 May 2016 | 2.3222 | 108.1250 | 0.974020 | 105.3159 |
Full price |  |  |  | 113.3657 |
Clean = full 113.3657 − accrued 2.7535 = 110.61 per 100
So what: holders should accept about 110.6 if they need the market’s 2.28%. Same yield as the 4 Feb price of 111.28: the value drifts toward the call price as the call nears.
110.61 at 2.28%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j72
04 Q2 · 72
At JLR’s own 3.5% borrowing rate, the value to call is lower: 109.11
Rate 3.5% a year → 1.75% per half-year. DF = 1 ÷ (1 + 0.0175)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.994425 | 4.0399 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.977322 | 3.9704 |
15 May 2016 | 2.3222 | 108.1250 | 0.960513 | 103.8555 |
Full price |  |  |  | 111.8657 |
Clean = full 111.8657 − accrued 2.7535 = 109.11 per 100
So what: a higher discount rate means holders can ask less.
109.11 at 3.5%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j73
04 Q2 · 73
At 0.50%, the value to call is 112.85
Rate 0.5% a year → 0.25% per half-year. DF = 1 ÷ (1 + 0.0025)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9992 | 4.06 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9967 | 4.05 |
15 May 2016 | 2.3222 | 108.1250 | 0.9942 | 107.50 |
Full price |  |  |  | 115.6082 |
Clean = full 115.6082 − accrued 2.7535 = 112.85 per 100 (rows rounded)
So what: a holder’s needed 14-month rate could be anywhere from near risk-free (0.5%) to JLR’s 3.5%, so we work each step. Near risk-free, holders could ask almost 113.
112.85 at 0.5%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j74
04 Q2 · 74
At 0.75%, the value to call is 112.54
Rate 0.75% a year → 0.375% per half-year. DF = 1 ÷ (1 + 0.00375)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9988 | 4.06 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9951 | 4.04 |
15 May 2016 | 2.3222 | 108.1250 | 0.9913 | 107.19 |
Full price |  |  |  | 115.2893 |
Clean = full 115.2893 − accrued 2.7535 = 112.54 per 100 (rows rounded)
So what: each 0.25% higher rate takes about 0.3 off the value.
112.54 at 0.75%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j75
04 Q2 · 75
At 1.00%, the value to call is 112.22
Rate 1% a year → 0.5% per half-year. DF = 1 ÷ (1 + 0.005)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9984 | 4.06 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9934 | 4.04 |
15 May 2016 | 2.3222 | 108.1250 | 0.9885 | 106.88 |
Full price |  |  |  | 114.9717 |
Clean = full 114.9717 − accrued 2.7535 = 112.22 per 100 (rows rounded)
So what: still above the market’s 111.28.
112.22 at 1%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j76
04 Q2 · 76
At 1.50%, the value to call is 111.59
Rate 1.5% a year → 0.75% per half-year. DF = 1 ÷ (1 + 0.0075)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9976 | 4.05 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9902 | 4.02 |
15 May 2016 | 2.3222 | 108.1250 | 0.9828 | 106.27 |
Full price |  |  |  | 114.3403 |
Clean = full 114.3403 − accrued 2.7535 = 111.59 per 100 (rows rounded)
So what: close to the 4 Feb market price.
111.59 at 1.5%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j77
04 Q2 · 77
At 2.00%, the value to call is 110.96
Rate 2% a year → 1% per half-year. DF = 1 ÷ (1 + 0.01)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9968 | 4.05 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9869 | 4.01 |
15 May 2016 | 2.3222 | 108.1250 | 0.9772 | 105.66 |
Full price |  |  |  | 113.7141 |
Clean = full 113.7141 − accrued 2.7535 = 110.96 per 100 (rows rounded)
So what: near the value at the market’s own 2.28% (110.61).
110.96 at 2%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j78
04 Q2 · 78
At 2.50%, the value to call is 110.34
Rate 2.5% a year → 1.25% per half-year. DF = 1 ÷ (1 + 0.0125)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9960 | 4.05 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9837 | 4.00 |
15 May 2016 | 2.3222 | 108.1250 | 0.9716 | 105.05 |
Full price |  |  |  | 113.0930 |
Clean = full 113.0930 − accrued 2.7535 = 110.34 per 100 (rows rounded)
So what: below the value at the market rate: holders would refuse this.
110.34 at 2.5%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j79
04 Q2 · 79
At 3.00%, the value to call is 109.72
Rate 3% a year → 1.5% per half-year. DF = 1 ÷ (1 + 0.015)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.9952 | 4.04 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.9805 | 3.98 |
15 May 2016 | 2.3222 | 108.1250 | 0.9660 | 104.45 |
Full price |  |  |  | 112.4769 |
Clean = full 112.4769 − accrued 2.7535 = 109.72 per 100 (rows rounded)
So what: only 0.6 above the 3.5% value: the range is narrow.
109.72 at 3%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j80
04 Q2 · 80
The value to call ranges from 112.85 at 0.5% to 109.11 at 3.5%
Clean value to the 2016 call, 17 Mar 2015, per 100, by discount rate (bars start at 108)
112.85
0.5%
112.54
0.75%
112.35
0.895%
112.22
1%
111.59
1.5%
110.96
2%
110.61
2.28%
110.34
2.5%
109.72
3%
109.11
3.5%
Dark: 2.28% = market rate (110.61, slide 71); 0.895% = JLR’s tender rate (112.35, slide 82). Worked on slides 71–79 and 82.
So what: the lower the 14-month rate, the more holders can ask, but only within about 4 points.
Source: our calculation (calcs.py), slides 71–79 and 82.

## Slide j81
04 Q2 · 81
JLR priced its offer the same way: to the 2016 call, at a Treasury yield + 0.50%
0.395%
0.25% Treasury due 15 May 2016, 16 Mar
+
0.50%
fixed spread
=
0.895%
offer discount rate
Plain: reference Treasury = the government bond whose yield sets the price; it matures on 15 May 2016, the call date. Fixed spread = a set margin added on top.
So what: JLR offered the value to the call at 0.895%, a rate well below the market’s 2.28%, so the offer sat above the market value.
Source: JLR pricing release, PR Newswire, 16 Mar 2015 (“0.25% U.S. Treasury Notes due 15 May 2016 … 0.395% 50 bps $30 $1,123.52 $1,093.52”).

## Slide j82
04 Q2 · 82
At 0.895% the price is 112.35, JLR’s offer to within US$0.01 per US$1,000
Rate 0.895% a year → 0.4475% per half-year. DF = 1 ÷ (1 + 0.004475)ⁿ; PV = cash × DF.
Payment date | n | Cash | DF | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.998562 | 4.0567 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.994114 | 4.0386 |
15 May 2016 | 2.3222 | 108.1250 | 0.989685 | 107.0097 |
Full price |  |  |  | 115.1049 |
Clean = full 115.1049 − accrued 2.7535 = 112.35 per 100
So what: our method reproduces the real offer (US$1,123.51 vs 1,123.52).
112.35 at 0.895%
Among all ten values (109–113)
Source: our calculation (calcs.py): settle 17 Mar 2015, 30/360, call 15 May 2016 at 104.0625. Same layout on slides 71–79 and 82.

## Slide j83
04 Q2 · 83
Early tenders got US$1,123.52 per US$1,000, late ones US$1,093.52, both plus accrued interest
1,123.52
US$ per US$1,000 by 16 Mar (early) + US$27.53 accrued, paid 17 Mar
1,093.52
US$ per US$1,000 by 30 Mar (late) = 1,123.52 − US$30 early premium, + US$30.69 accrued, paid 31 Mar
Result: US$326.1m (79.5%) tendered early; only US$0.3m more came late; US$83.6m stayed outstanding.
So what: the US$30 early premium pushed holders to answer by 16 March, and it worked.
Sources: JLR releases, PR Newswire, 16, 17 and 31 Mar 2015 (“valid tenders … of $326,117,000 … approximately 79.54%”).

## Slide j84
04 Q2 · 84
A callable bond = plain bond minus JLR’s option to repay
100
120
140
0%
2%
4%
6%
8%
Plain bond to 2021 (dashed)
Clean price per 100
Callable: capped near 113
rate
Plain: callable bond = plain bond − call option (CFA). Drawn as the lower of the value to 2021 and to the 2016 call (yield-to-worst; this ignores the option’s time value, so the true price sits slightly lower). The dashed plain-bond line runs off the top below about 1%. As rates fall it flattens (“negative convexity”).
So what: the call caps what holders can expect, near the value of being repaid in 2016.
Source: our calculation (calcs.py method) for every point, 17 Mar 2015; CFA Level I, Fixed Income (callable bonds).

## Slide j85
04 Q2 · 85
Ignoring the call, discounting to 2021 at 3.5% gives 125.43
Discount at JLR’s 3.5% (1.75% per half-year) to May 2021. Payments 1–7 of 13:
Payment date | n | Cash | DF at 1.75% | PV |
15 May 2015 | 0.3222 | 4.0625 | 0.994425 | 4.0399 |
15 Nov 2015 | 1.3222 | 4.0625 | 0.977322 | 3.9704 |
15 May 2016 | 2.3222 | 4.0625 | 0.960513 | 3.9021 |
15 Nov 2016 | 3.3222 | 4.0625 | 0.943993 | 3.8350 |
15 May 2017 | 4.3222 | 4.0625 | 0.927758 | 3.7690 |
15 Nov 2017 | 5.3222 | 4.0625 | 0.911801 | 3.7042 |
15 May 2018 | 6.3222 | 4.0625 | 0.896119 | 3.6405 |
Subtotal, 1–7 |  |  |  | 26.8610 |
So what: the first seven coupons are worth just 26.86 of the 128.18 full price; the last six, with the 100 repayment, add 101.32.
Source: our calculation (calcs.py). Same method as slide 71, run to 15 May 2021.

## Slide j86
04 Q2 · 86
The naive view, continued: clean value 125.43
Payment date | n | Cash | DF at 1.75% | PV |
Subtotal, 1–7 (slide 85) |  |  |  | 26.8610 |
15 Nov 2018 | 7.3222 | 4.0625 | 0.880707 | 3.5779 |
15 May 2019 | 8.3222 | 4.0625 | 0.865559 | 3.5163 |
15 Nov 2019 | 9.3222 | 4.0625 | 0.850673 | 3.4559 |
15 May 2020 | 10.3222 | 4.0625 | 0.836042 | 3.3964 |
15 Nov 2020 | 11.3222 | 4.0625 | 0.821663 | 3.3380 |
15 May 2021 | 12.3222 | 104.0625 | 0.807531 | 84.0337 |
Full price |  |  |  | 128.1792 |
Less accrued interest |  |  |  | −2.7535 |
Clean price |  |  |  | 125.43 |
So what: 12.6–16.3 points above every call-aware value (109.11–112.85): it pretends JLR pays 8.125% to 2021.
Source: our calculation (calcs.py).

## Slide j87
04 Q2 · 87
JLR’s option to repay was worth about 15 points
Per 100 of face, 17 Mar 2015. Dashed box = the gap up to the naive 125.43
Naive, to 2021 at 3.5%
125.43
Call-aware, same 3.5%
109.11
16.32
Call-aware, market 2.28%
110.61
14.82
Offer, 0.895%
112.35
13.07
Option value at the same 3.5% rate = 125.43 − 109.11 = 16.32
Mixed rates, approximate: 125.43 − 110.61 = 14.82
Overpayment vs the offer: 125.4257 − 112.3514 = 13.0743 points = US$53.6m
Gaps use the rounded prices; US$ = points × US$4.10m.
So what: the option was worth 14.8–16.3 points; the naive price would have overpaid holders by about US$54m.
Source: our calculation (calcs.py); slides 71, 72, 82, 86.

## Slide j88
04 Q2 · 88
JLR’s filings date the maturity 15 November 2021; that moves only the naive value, to 127.26
125.43
naive value with the case’s maturity, 15 May 2021 (used throughout)
127.26
naive value with the filings’ 15 Nov 2021: one more coupon
The call-aware values do not change: they stop at the 15 May 2016 call either way.
So what: the maturity date question does not touch the Q2 answer.
Sources: Exhibit 1, case; Tata Motors 6-K (30 Sep 2013) and JLR offering memorandum p.39 (“$410 million 8.125% Senior Notes due 2021 … 15 November 2021”); our calculation (calcs.py).

## Slide j89
04 Q2 · 89
Every call-aware value lands at 109–113; only the naive 2021 view reaches 125
Clean price per 100; scale 106 to 128
Value to call at JLR’s 3.5%
109.11
Value to call at market 2.28%
110.61
Market price, 4 Feb (Exhibit 2)
111.28
Offer: to call at 0.895%
112.35
Naive: to 2021 at 3.5%
125.43
So what: ignoring the call adds 13–16 points, while any sensible rate moves the value by only about 4, so the call explains most of the gap.
Sources: slides 71, 72, 82, 86; Exhibit 2, case.

## Slide j90
04 Q2 · 90
Q2 answer: about 110.6–112.4 per 100 plus accrued interest, US$453.5–460.6m for the issue
110.61 floor
112.35 ceiling
111.28 market
Floor = value to the call at the market’s 2.28% on 17 Mar (slide 71). Ceiling = value at the offer’s 0.895% (slide 82), what JLR paid to win early tenders. US$: 110.61 × 4.10 = 453.5; 112.35 × 4.10 = 460.6, plus accrued interest.
The consent solicitation added a push: notes left behind lost their covenants (lender protections).
So what: holders could not reasonably ask much more than 112–113: the call caps the value, whatever the 2021 coupons look like.
Sources: slides 71, 82; JLR tender releases (PR Newswire, 3 Mar 2015: consents “to eliminate substantially all of the restrictive covenants”).

## Slide j91
05
Q3: does the buyback save money?
Cash with the deal minus cash without it, before and after tax, against two views of what JLR would otherwise do
91

## Slide j92
05 Q3 · 92
Q3: does buying back all the notes at 112.35 save JLR money?
“Saving” can mean two different things, and they give different answers:
Accounting view
Does yearly interest fall? Compares coupons: 8.125% before, 3.5% after.
Slides 96–97
Economic view
Is JLR richer today? Compares present values (NPV), with two baselines for what JLR would otherwise do.
Slides 98–104
After tax
Interest and the premium cut JLR’s tax bill, so repeat the economic view after tax.
Slides 105–111
So what: we answer both, and say which one decides.
Source: CFA Level I, Corporate Issuers (capital investments, NPV).

## Slide j93
05 Q3 · 93
How we judge it: net present value of the change in cash flows
Plain: incremental cash flow = JLR’s cash with the deal minus its cash without it. NPV = the PV of those differences; positive means JLR is better off.
NPV
of the buyback
=
PV of old payments avoided
coupons and repayment JLR no longer owes
−
Cash paid now
price + accrued
The new 3.5% debt drops out: it is borrowed at a fair market rate (slide 98).
So what: the answer turns on the baseline, what JLR would have paid without the deal, so we show two.
Source: CFA Level I, Corporate Issuers (incremental cash flows, NPV).

## Slide j94
05 Q3 · 94
We assume JLR buys all US$410m at 112.35 on 17 March, funded at 3.5%
Deal
all US$410m bought at the early price, 112.35, plus accrued, on 17 Mar 2015 (in fact 79.6% tendered)
Funding
new US$ debt at 3.5%, the 2020 notes’ coupon
Tax
21% on the deal date (UK rate to 31 Mar 2015), 20% after
Fees
ignored in the numbers; they would make the NPV slightly worse
Baselines
naive: notes kept to May 2021; realistic: called May 2016 (slide 67)
So what: simple, stated assumptions; slide 111 shows that tax does not change the conclusion.
Sources: JLR tender releases (PR Newswire, Mar 2015); Finance Act 2013 s.4 (“21% on profits”); Pinsent Masons, 20 Mar 2013 (“20% from 1 April 2015”).

## Slide j95
05 Q3 · 95
JLR needs US$471.9m to buy the notes, leaving US$28.1m from the US$500m before fees
Uses of the new US$500m, US$m; every segment is labelled under the bar
410.0
50.6
Face value 410.0
Premium 50.6
Accrued 11.3
Left over 28.1
Working: 410 × (112.3514 + 2.7535)% = 410 × 1.151049 = 471.93: face 410.0 + premium 50.6 (of which early premium 12.3) + accrued 11.3. Left over: 500 − 471.93 = 28.1.
Accrued: 410 × 122 ÷ 180 × 4.0625% = 11.3.
So what: almost all the new money goes to the buyback.
Sources: Exhibit 2, case; JLR tender releases; our calculation (calcs.py).

## Slide j96
05 Q3 · 96
The accounting view: interest falls by US$16.8m a year after borrowing US$471.9m at 3.5%
Interest a year, US$m
Old: 8.125% × 410
33.3
New: 3.5% × 471.9
16.5
Working: 33.3 − 16.5 = 16.8 a year (about £11.2m at 1.50).
So what: the saving looks large only if the old notes would have run to 2021; on the realistic view (call in May 2016) it lasts 14 months.
Source: our calculation (calcs.py).

## Slide j97
05 Q3 · 97
But JLR pays US$50.6m above face value up front, three years of savings
US$m
Premium paid now
50.6
Yearly saving × 3
3 × 16.8
Working: premium = 410 × (112.35 − 100)% = 50.6, including the 12.3 early premium (410 × 3%). 50.6 ÷ 16.8 = 3.0 years of savings, undiscounted.
So what: the premium must be weighed against the savings in present-value terms, which is what NPV does.
Source: our calculation (calcs.py).

## Slide j98
05 Q3 · 98
Debt at the market rate adds almost no value on its own
471.93
US$m borrowed at 3.5%
472.02
US$m: PV at 3.5% of the ten repayments (slide 98b)
Coupon 471.93 × 3.5% ÷ 2 = 8.26 each 15 Mar and 15 Sep. The first coupon pays a full half-year after only 178 of 180 days, so the PV is 0.09 above the 471.93 borrowed.
Plain: zero NPV = the debt’s present value equals the cash received, so borrowing at the market rate gains or loses nothing.
So what: the new debt is worth what it raised (472.02 vs 471.93), so NPV = PV of old payments avoided − cash paid.
Source: our calculation (calcs.py: “PV at 3.50% of the new-debt flows on 471.93 borrowed = 472.02”).

## Slide j98b
05 Q3 · 98b
The new debt’s ten payments are worth US$472.02m
PV at 3.5%: payment = 471.93 × 3.5% ÷ 2 = 8.26; last = 8.26 + 471.93 = 480.19. n = 178/180 + k half-years from 17 Mar 2015; DF = 1 ÷ 1.0175ⁿ.
Payment date | n | Cash, US$m | DF at 1.75% | PV |
15 Sep 2015 | 0.9889 | 8.26 | 0.982990 | 8.12 |
15 Mar 2016 | 1.9889 | 8.26 | 0.966084 | 7.98 |
15 Sep 2016 | 2.9889 | 8.26 | 0.949468 | 7.84 |
15 Mar 2017 | 3.9889 | 8.26 | 0.933138 | 7.71 |
15 Sep 2017 | 4.9889 | 8.26 | 0.917089 | 7.57 |
15 Mar 2018 | 5.9889 | 8.26 | 0.901316 | 7.44 |
15 Sep 2018 | 6.9889 | 8.26 | 0.885815 | 7.32 |
15 Mar 2019 | 7.9889 | 8.26 | 0.870579 | 7.19 |
15 Sep 2019 | 8.9889 | 8.26 | 0.855606 | 7.07 |
15 Mar 2020 | 9.9889 | 480.19 | 0.840891 | 403.79 |
Total PV (rows rounded) |  |  |  | 472.02 |
So what: at its own 3.5% rate the new debt is worth what it raised (472.02 vs 471.93).
Source: our calculation (calcs.py). US$m on the US$410m deal; the 0.09 gap is the part-period (slide 98).

## Slide j98c
05 Q3 · 98c
Naive baseline: +16.66 each May and Nov, −8.26 each Mar and Sep
US$m by date (+ = JLR better off): old payment avoided, new payment. Longest bars cut at 60
+16.66
−8.26
−480.19
+426.66
’15
’16
’17
’18
’19
’20
’21
+16.66
each May, Nov: old coupon avoided
−8.26
each Mar, Sep: new coupon
−480.19
Mar 2020: new principal + coupon
+426.66
May 2021: old principal + coupon
So what: at 3.5%, NPV = PV of old payments avoided − PV of new-debt payments (472.02, about the cash borrowed; slide 98): 525.53 − 472.02 = +53.5 (slide 101’s +53.6 less the 0.09 part-period gap).
Source: our calculation (calcs.py, “Q3 incremental cash flows”: 23 dates, whole US$410m, new debt 471.93 at 3.5%).

## Slide j98d
05 Q3 · 98d
Realistic baseline: +443.31 in May 2016, −480.19 in 2020
US$m by date (+ = JLR better off); old notes called May 2016. Longest bars cut at 60
+16.66
−8.26
−480.19
+443.31
May
Sep
Nov
Mar
May
Sep
Mar
Sep
Mar
Sep
Mar
Sep
Mar
’15
’16
’17
’18
’19
’20
+16.66
May, Nov 2015: old coupons avoided
+443.31
May 2016: old call price + coupon
−8.26
each Mar, Sep: new coupon
−480.19
Mar 2020: new principal + coupon
So what: at 3.5%, NPV = PV avoided − PV of new-debt payments (slide 98): 458.65 − 472.02 = −13.4; slide 103’s −7.1 uses 2.28%.
Source: our calculation (calcs.py: old called May 2016 @ 3.50% = −13.4).

## Slide j99
05 Q3 · 99
The first six payments JLR avoids are worth US$95.2m today, at 3.5%
Naive baseline (kept to 2021): coupon 410 × 8.125% ÷ 2 = 16.656; DF = 1 ÷ 1.0175ⁿ.
Payment date | n | Cash, US$m | DF | PV |
15 May 2015 | 0.3222 | 16.656 | 0.994425 | 16.56 |
15 Nov 2015 | 1.3222 | 16.656 | 0.977322 | 16.28 |
15 May 2016 | 2.3222 | 16.656 | 0.960513 | 16.00 |
15 Nov 2016 | 3.3222 | 16.656 | 0.943993 | 15.72 |
15 May 2017 | 4.3222 | 16.656 | 0.927758 | 15.45 |
15 Nov 2017 | 5.3222 | 16.656 | 0.911801 | 15.19 |
Subtotal, 1–6 |  |  |  | 95.20 |
So what: the first three years of coupons alone are worth US$95.2m.
Source: our calculation (calcs.py). Same method as slide 85, in US$m on US$410m.

## Slide j100
05 Q3 · 100
Keeping the notes to 2021 costs JLR US$525.5m today
Payment date | n | Cash, US$m | DF | PV |
Payments 1–6 (slide 99) |  |  |  | 95.20 |
15 May 2018 | 6.3222 | 16.656 | 0.896119 | 14.93 |
15 Nov 2018 | 7.3222 | 16.656 | 0.880707 | 14.67 |
15 May 2019 | 8.3222 | 16.656 | 0.865559 | 14.42 |
15 Nov 2019 | 9.3222 | 16.656 | 0.850673 | 14.17 |
15 May 2020 | 10.3222 | 16.656 | 0.836042 | 13.93 |
15 Nov 2020 | 11.3222 | 16.656 | 0.821663 | 13.69 |
15 May 2021 | 12.3222 | 426.656 | 0.807531 | 344.54 |
Total (rows rounded) |  |  |  | 525.53 |
Working: the last payment = 410 + 16.656 = 426.656.
So what: the naive baseline has JLR avoiding US$525.5m today (95.20 + 430.33, unrounded rows) for 471.9 paid.
Source: our calculation (calcs.py).

## Slide j101
05 Q3 · 101
Against keeping the notes to 2021, the NPV looks like +US$53.6m
PV of payments avoided (naive)
525.5
Cash paid now
471.9
NPV = 525.5 − 471.9 = +53.6
So what: this is the illusion: JLR would never keep 8.125% debt it can repay at 3.5%, so this baseline overstates the cost avoided.
Source: our calculation (calcs.py).

## Slide j102
05 Q3 · 102
Realistic baseline: JLR repays in May 2016, valued at the market’s 2.28%
Two coupons of 16.656, then 410 × 104.0625% + 16.656 = 443.313 in May 2016. DF = 1 ÷ 1.0114ⁿ (2.28% ÷ 2).
Payment date | n | Cash, US$m | DF | PV |
15 May 2015 | 0.3222 | 16.656 | 0.996354 | 16.60 |
15 Nov 2015 | 1.3222 | 16.656 | 0.985124 | 16.41 |
15 May 2016 | 2.3222 | 443.313 | 0.974020 | 431.80 |
Total (rows rounded) |  |  |  | 464.80 |
So what: the realistic cost of keeping the notes is US$464.8m (= 410 × full value 113.37, slide 71).
Source: our calculation (calcs.py); same rate and method as slide 71.

## Slide j103
05 Q3 · 103
Against the realistic baseline, the NPV is −US$7.1m
PV of payments avoided (realistic)
464.8
Cash paid now
471.9
NPV = 464.8 − 471.9 = −7.1
Per 100: 112.35 paid − 110.61 value (slide 71) = 1.74 × 4.10 = 7.1.
So what: JLR paid a little more than the debt was worth.
Source: our calculation (calcs.py).

## Slide j104
05 Q3 · 104
At the offer’s own 0.895% rate, the NPV is zero
Same three payments, DF = 1 ÷ 1.004475ⁿ (0.895% ÷ 2).
Payment date | n | Cash, US$m | DF | PV |
15 May 2015 | 0.3222 | 16.656 | 0.998562 | 16.63 |
15 Nov 2015 | 1.3222 | 16.656 | 0.994114 | 16.56 |
15 May 2016 | 2.3222 | 443.313 | 0.989685 | 438.74 |
PV of payments avoided |  |  |  | 471.93 |
NPV = 471.9 − 471.9 = 0.0, zero by construction: the same rate set the price. The real test is 0.895% against the market’s 2.28% (slide 103).
So what: JLR paid a near-risk-free price for a claim the market valued at 2.28%.
Source: our calculation (calcs.py).

## Slide j105
05 Q3 · 105
After tax, step 1: the premium and the accrued interest are tax-deductible, saving US$13.0m
50.6
premium
+
11.3
accrued interest
×
21%
UK rate for the year to 31 Mar 2015
=
13.0
tax saved, US$m
After-tax cash paid now: 471.9 − 13.0 = 458.9
Plain: a deductible cost cuts taxable profit, so JLR pays less tax. Accrued interest = interest owed up to 17 March. The deal falls in the year to 31 Mar 2015, taxed at 21%.
So what: tax relief cuts the up-front cost by about 3%.
Sources: Finance Act 2013 s.4 (“21% on profits of companies other than ring fence profits”); our calculation (calcs.py).

## Slide j106
05 Q3 · 106
After tax, both the coupons and the discount rate shrink by the 20% tax rate
Plain: after-tax rate = rate × (1 − tax rate), because interest cuts tax. Coupons and the call premium are deductible; the principal is not. From April 2015 the rate is 20%.
13.325
after-tax coupon, US$m: 16.656 × 0.8
1.824%
realistic: 2.28% × 0.8 = 1.824% a year ÷ 2 = 0.912% per half-year
2.80%
naive: 3.5% × 0.8 = 2.80% a year ÷ 2 = 1.40% per half-year
So what: both the cash flows and the rate shrink after tax, so the NPV changes size but not sign (slide 111).
Sources: Pinsent Masons, 20 Mar 2013 (“20% from 1 April 2015”); CFA Level I, Corporate Issuers (cost of debt after tax).

## Slide j107
05 Q3 · 107
After tax, realistic baseline: the old notes cost US$454.0m
Tax saved = 20% of each coupon (3.331), and of the last coupon plus the call premium (16.656 + 16.656) × 20% = 6.663. DF = 1 ÷ 1.00912ⁿ.
Date | n | Pre-tax | Tax saved | After tax | DF | PV |
15 May 2015 | 0.3222 | 16.656 | 3.331 | 13.325 | 0.997079 | 13.29 |
15 Nov 2015 | 1.3222 | 16.656 | 3.331 | 13.325 | 0.988068 | 13.17 |
15 May 2016 | 2.3222 | 443.313 | 6.663 | 436.650 | 0.979138 | 427.54 |
Total (rows rounded) |  |  |  |  |  | 453.99 |
So what: compare with the US$458.9m paid after tax: −4.9.
Source: our calculation (calcs.py). US$m on US$410m.

## Slide j108
05 Q3 · 108
After tax at the offer’s own 0.716% rate, the old notes cost US$459.6m
Rate 0.895% × 0.8 = 0.716% a year = 0.358% per half-year; DF = 1 ÷ 1.00358ⁿ. Same cash columns as slide 107.
Date | n | Pre-tax | Tax saved | After tax | DF | PV |
15 May 2015 | 0.3222 | 16.656 | 3.331 | 13.325 | 0.998849 | 13.31 |
15 Nov 2015 | 1.3222 | 16.656 | 3.331 | 13.325 | 0.995286 | 13.26 |
15 May 2016 | 2.3222 | 443.313 | 6.663 | 436.650 | 0.991736 | 433.04 |
Total |  |  |  |  |  | 459.61 |
NPV = 459.6 − 458.9 = +0.7
So what: near zero again; tax adds only US$0.7m.
Source: our calculation (calcs.py).

## Slide j109
05 Q3 · 109
After tax, each avoided coupon costs JLR only US$13.3m
Naive baseline after tax, discounted at 2.80%: DF = 1 ÷ 1.014ⁿ (2.80% ÷ 2). Payments 1–6 of 13:
Date | n | Pre-tax | Tax saved | After tax | DF | PV |
15 May 2015 | 0.3222 | 16.656 | 3.331 | 13.325 | 0.995530 | 13.27 |
15 Nov 2015 | 1.3222 | 16.656 | 3.331 | 13.325 | 0.981785 | 13.08 |
15 May 2016 | 2.3222 | 16.656 | 3.331 | 13.325 | 0.968230 | 12.90 |
15 Nov 2016 | 3.3222 | 16.656 | 3.331 | 13.325 | 0.954862 | 12.72 |
15 May 2017 | 4.3222 | 16.656 | 3.331 | 13.325 | 0.941678 | 12.55 |
15 Nov 2017 | 5.3222 | 16.656 | 3.331 | 13.325 | 0.928677 | 12.37 |
Subtotal (rows rounded) |  |  |  |  |  | 76.90 |
So what: 20% tax relief cuts each coupon to 13.3: six payments are worth 76.90, not 95.20.
Source: our calculation (calcs.py).

## Slide j110
05 Q3 · 110
After tax, holding the notes to 2021 would cost JLR US$504.3m in today’s money
Date | n | Pre-tax | Tax saved | After tax | DF | PV |
1–6 (slide 109) |  |  |  |  |  | 76.90 |
15 May 2018 | 6.3222 | 16.656 | 3.331 | 13.325 | 0.915855 | 12.20 |
15 Nov 2018 | 7.3222 | 16.656 | 3.331 | 13.325 | 0.903210 | 12.04 |
15 May 2019 | 8.3222 | 16.656 | 3.331 | 13.325 | 0.890740 | 11.87 |
15 Nov 2019 | 9.3222 | 16.656 | 3.331 | 13.325 | 0.878441 | 11.71 |
15 May 2020 | 10.3222 | 16.656 | 3.331 | 13.325 | 0.866313 | 11.54 |
15 Nov 2020 | 11.3222 | 16.656 | 3.331 | 13.325 | 0.854352 | 11.38 |
15 May 2021 | 12.3222 | 426.656 | 3.331 | 423.325 | 0.842556 | 356.68 |
Total (rows rounded) |  |  |  |  |  | 504.31 |
So what: against the US$458.9m paid: +45.4 on the naive view. (Principal not deductible.)
Source: our calculation (calcs.py).

## Slide j111
05 Q3 · 111
After tax, the answer holds: −US$4.9m realistic, +US$45.4m naive
NPV after tax, US$m (left of the line = JLR worse off)
Realistic: 454.0 − 458.9
−4.9
At the offer’s rate: 459.6 − 458.9
+0.7
Naive: 504.3 − 458.9
+45.4
So what: taxes change the size, not the conclusion.
Source: our calculation (calcs.py); slides 105–110.

## Slide j112
05 Q3 · 112
The answer depends on the baseline, and the realistic one shows no saving
NPV of the buyback, US$m, before and after tax (left of the line = JLR worse off)
Naive · before tax
+53.6
Naive · after tax
+45.4
Realistic · before tax
−7.1
Realistic · after tax
−4.9
Offer’s rate · before tax
0.0
Offer’s rate · after tax
+0.7
Stale 4 Feb price · before tax
−4.4
So what: only the naive baseline shows a material saving. Stale row: (111.28 − 112.35) × 4.10 = −4.4, same 2.28% yield, six weeks earlier.
Source: our calculation (calcs.py); slides 101–111.

## Slide j113
05 Q3 · 113
Q3 answer: a real cash-interest saving, but no economic saving; JLR paid the gain away up front
£11.2m
a year less interest (US$16.8m ÷ 1.50): the accounting saving
£33.8m
premium paid up front (US$50.64m ÷ 1.50)
−£4.8m
NPV, realistic baseline (−US$7.13m); after tax −£3.3m
The naive view shows +£35.7m (US$53.6m ÷ 1.50), but only by assuming JLR would pay 8.125% until 2021.
So what: the premium prices in almost all of the interest saved: refinancing at a fair price created no value for JLR, as Q1 predicted.
Sources: slides 96–112; our calculation (calcs.py). £ at the case’s 1.50, converted once.

## Slide j114
06
Q4: other benefits, and who gains
What JLR got besides lower interest, and how the value split between JLR, the bondholders and Tata Motors
114

## Slide j115
06 Q4 · 115
Q4: what else does JLR gain, and who wins: JLR, the bondholders or Tata Motors?
JLR
Soft benefits beyond interest: reported profit, covenants, liquidity, refinancing risk, signalling
Slides 116–124
Bondholders
Did tendering holders get more than their notes were worth?
Slide 125
Tata Motors
JLR’s only shareholder: who pays for any gain to holders?
Slide 126
Assumptions: all notes tendered at 112.35; holders’ alternative = keep the notes and be repaid at the May 2016 call, valued at the market’s 2.28%; Tata Motors owns 100% of JLR; fees ignored.
Sources: slides 71, 82, 103; the case (JLR, “a wholly owned subsidiary of … Tata Motors”).

## Slide j116
06 Q4 · 116
In an efficient market, swapping debt at fair prices creates no value
Market efficiency
Prices already reflect public information, so a fairly priced bond cannot be bought cheaply.
Modigliani–Miller
Before taxes and costs, how a firm is financed does not change its value: one fair-priced loan replaced by another leaves the firm the same size.
What can break it: taxes (interest is deductible), fees, and information managers have that the market lacks (signalling, slide 123).
So what: expect an NPV near zero; Q3 found −US$7.1m, so the theory holds.
Source: CFA Level I, Corporate Issuers (capital structure, Modigliani–Miller); Equity (market efficiency).

## Slide j117
06 Q4 · 117
JLR’s choices: do nothing, wait and repay in 2016, buy notes in the market, or tender now
Do nothing
8.125%
keep paying to 2021: the naive baseline
Wait for call
104.06
repay May 2016, plus two more coupons; worth 110.61 today
Buy in market
111.28
the 4 Feb price; buying US$410m would push it up
Tender now
112.35
what JLR chose: + accrued, all holders at once
Prices per 100 of face. “Do nothing” is not a real option: JLR would call in 2016 (slide 67).
So what: the real choice was tender now or wait 14 months for the call.
Sources: Exhibit 2, case; slides 66, 67, 71, 82.

## Slide j118
06 Q4 · 118
Tendering now instead of waiting for the 2016 call cost about 1.7 per 100 (US$7.1m)
1.74
per 100: 112.35 tender − 110.61 value of waiting (slide 71); × 4.10 = US$7.1m
−31bp
5-year Treasury, 1.57% (16 Mar 2015) → 1.26% (16 May 2016)
Bridge: waiting is worth 110.61 = PV of the three payments left (113.3657) − accrued interest (2.7535), slide 71; 112.35 − 110.61 = 1.74. The 8.29 points over the call price (112.35 − 104.0625) buy 14 months of avoided 8.125% coupons, so the net cost is only 1.74. Locking in 3.5% before the Fed’s Dec 2015 rise was a rate bet: Treasuries were lower by the call date.
So what: the timing benefit was not a sure thing; it cost US$7.1m.
Sources: our calculation (calcs.py); US Treasury daily par yields, 16 Mar 2015 and 16 May 2016; Federal Reserve, 16 Dec 2015 (“raise the target range … to 1/4 to 1/2 percent”).

## Slide j119
06 Q4 · 119
Reported profit rises: interest falls US$16.8m a year after a one-off charge of about US$50.6m
Effect on JLR’s profit before tax, US$m
One-off charge (premium), FY2015
50.6
Interest saved, each later year
16.8
Plain: carrying amount = the value of the notes in JLR’s own books. The exact one-off loss depends on it, so 50.6 (£33.8m) is approximate.
Working: premium 410 × 12.35% = 50.6; interest 33.3 − 16.5 = 16.8 a year.
Interest cover and earnings per period look better from FY2016, but on the realistic view the old notes would have gone in May 2016 anyway.
So what: the accounts look better; the economics do not change.
Source: our calculation (calcs.py).

## Slide j120
06 Q4 · 120
Holders who stayed lost their covenant protection
Plain: covenants = promises in a bond’s legal terms that limit what the borrower may do, for example how much it can pay out as dividends or borrow.
What they restricted
JLR’s dividends to Tata Motors, among other “customary covenants”
OM; Tata 6-K
The consent
Tendering holders also voted to remove “substantially all of the restrictive covenants”
Needed a majority
Result
US$83.6m stayed outstanding, now without covenants, until repaid in May 2016
PR Newswire, 31 Mar
So what: JLR gained freedom; the threat of holding a covenant-free bond pushed holders to tender.
Sources: JLR tender release, 3 Mar 2015 (“to eliminate substantially all of the restrictive covenants”); Tata Motors 6-K (“covenants … restricting such payments”); results, 31 Mar 2015.

## Slide j121
06 Q4 · 121
US$28m of extra cash (about £18.7m at 1.50) is small next to £3.6–3.8bn of capex
£m
Extra cash from the deal
18.7
Capex + R&D spent, FY2015
3,147.0
Capex planned, FY2016 (low end)
3,600.0
Working: 500 − 471.9 = US$28.1m ÷ 1.50 = £18.7m, before fees. 18.7 ÷ 3,600 = 0.5% of one year’s planned capex (slide 13).
So what: the deal was not about raising money.
Sources: case p.2 (£3.6–3.8bn capex planned for FY2016); JLR full-year results FY2015 (“Capital Expenditure and Research and Development investment for the year was £3,147 million”); our calculation.

## Slide j122
06 Q4 · 122
The deal fixed 3.5% to 2020: longer than the 2016 call, a year shorter than 2021
Plain: refinancing risk = the risk that when debt falls due, new money costs more or is hard to get.
Old notes, realistic
to May 2016
New 3.5% notes
fixed to March 2020
Old notes, naive
to May 2021
2016
2017
2018
2019
2020
2021
So what: against the realistic view the deal lengthened cheap funding by four years; against the naive view it brought repayment forward one. The 2020 date later fell in a crisis (epilogue).
Sources: Exhibits 1–2, case; JLR notice, 2 Mar 2017 (3.500% notes due 2020).

## Slide j123
06 Q4 · 123
The deal signals confidence to investors and rating agencies
Plain: signalling = managers know more than investors, so a costly action can reveal what they believe.
The signal
Paying a premium to clear expensive 2011 debt says management expects JLR to stay a strong borrower.
Its limit
A deal priced at fair value costs JLR little (−US$7.1m), so it is a weak signal: cheap to send whatever the truth.
So what: a small, real benefit, too small to justify the deal on its own.
Source: CFA Level I, Corporate Issuers (capital structure: signalling); our calculation (slide 103).

## Slide j124
06 Q4 · 124
JLR as a firm: roughly no value created, as theory predicts
−7.1
US$m NPV before tax, realistic view (slide 103)
−4.9
US$m after tax (slide 111)
−3.4
US$m a year less tax relief (20% × 16.8); already inside the after-tax NPV (slide 111); not an extra cost
A lower coupon also means a smaller interest tax shield (tax saved because interest is deductible). Both effects are small next to JLR’s £2.6bn profit before tax in FY2015.
So what: swapping fair-priced debt left JLR’s value about where it was.
Sources: slides 103, 111; JLR full-year results FY2015 (“Profit Before Tax was £2,614 million”); our calculation.

## Slide j125
06 Q4 · 125
Tendering holders got about 1.7 per 100 (US$7.1m) more than the market’s own yield implied
Per 100 of face, 17 Mar 2015 (bars start at 109 to show the gaps)
Tender price · 112.35
Market, 4 Feb (stale) · 111.28
Value at market’s 2.28% · 110.61
Working: 112.35 − 110.61 = 1.74 × 4.10 = US$7.1m. Against the stale 4 Feb price: 112.3514 − 111.276 = 1.08 × 4.10 = US$4.4m. Those who stayed were repaid in May 2016 (price not published; we assume the call price, 104.0625).
So what: tendering holders captured the small gain, about 1.7 per 100.
Sources: Exhibit 2, case; slides 71, 82; Tata Motors 20-F FY2016 (“remaining balance of US$84 million prepaid in May 2016”).

## Slide j126
06 Q4 · 126
Tata Motors, the only shareholder, ends up slightly worse off
Who gains, US$m, realistic view before tax
Tendering bondholders
+7.1
JLR, so Tata Motors (100% owner)
−7.1
The holders’ US$7.1m gain is JLR’s US$7.1m cost: a transfer, not new value. Fees (dealer manager, tender agent) add to Tata’s side; their amount was not published.
Plain: dealer manager = the bank that markets the offer to holders; tender agent = the firm that collects the notes holders tender and pays them.
So what: what one side gains the other pays; the shareholder pays.
Sources: slides 103, 125; JLR results release, 31 Mar 2015 (J.P. Morgan dealer manager; D.F. King tender agent).

## Slide j127
06 Q4 · 127
Q4 answer: soft benefits for JLR, a small gain for bondholders, a small loss for Tata Motors
JLR
≈ 0 value
NPV −7.1; gains: higher reported profit, no covenants, funding fixed to 2020, a weak signal
Bondholders
+US$7.1m
1.74 per 100 over the value of their notes at the market’s yield
Tata Motors
−US$7.1m
pays the holders’ gain and the fees, as sole shareholder
So what: the deal tidied JLR’s debt but created no value; the small gain went to the bondholders.
Sources: slides 115–126.

## Slide j128
07
Epilogue
What happened to the tender, to JLR’s borrowing costs and to JLR itself, 2015 to today
128

## Slide j129
07 Epilogue · 129
The four answers in one page
Q1 · why cheaper
Two thirds of the 462bp fall was JLR’s narrower credit spread; same-tenor Treasuries fell only 26bp
Slide 62
Q2 · fair price
About 110.6–112.4 per 100: the 2016 call caps the value; the naive 125.43 ignores it
Slide 90
Q3 · saving?
Interest falls US$16.8m a year, but the NPV is −US$7.1m: the premium paid the saving away
Slide 113
Q4 · who gains
Bondholders +US$7.1m; JLR about zero; Tata Motors pays
Slide 127
So what: the four answers fit together; slide 139 draws the conclusion.
Sources: slides 62, 90, 113, 127.

## Slide j130
07 Epilogue · 130
79.61% of the notes were tendered, almost all early, for US$375.7m including interest
The US$410m of 8.125% notes after the offer, US$m (late tenders: 0.3, too thin to see)
326.1
83.6
Tendered early
Not tendered
Cash paid: early 326.117 × 112.352% = 366.40; late 0.300 × 109.352% = 0.33; accrued 8.99. Total = 375.7. Tendered: 326.417 ÷ 410 = 79.61%.
So what: the US$30 early premium worked: 99.9% of the tendered notes came in by 16 March.
Sources: JLR releases, PR Newswire, 17 Mar 2015 (“$326,117,000 … approximately 79.54%”) and 31 Mar 2015 (“$326,417,000 … approximately 79.61%”); our calculation (calcs.py).

## Slide j131
07 Epilogue · 131
The remaining US$83.6m was repaid in May 2016, from the first call date (15 May)
May 2016
remaining notes repaid, at the first call date
≈ 87.0
US$m: 83.583 × 104.0625% at the call price (our assumption; the price was not published)
Holders who did not tender kept collecting 8.125% for 14 months, then were repaid at the call price: the realistic path we valued in Q2.
So what: every holder was out by May 2016, as the realistic baseline assumed.
Source: Tata Motors 20-F FY2016 (“In March 2015, US$326 million of the senior notes due 2021 were prepaid with the remaining balance of US$84 million prepaid in May 2016”); our calculation.

## Slide j132
07 Epilogue · 132
Sales rose for three years to a record 614,309 in FY2018, then fell for three
JLR retail sales, thousand vehicles, years to 31 March
462
FY15
522
FY16
604
FY17
614
FY18
579
FY19
509
FY20
440
FY21
So what: the strong JLR that borrowed at 3.5% in 2015 peaked three years later; weaker China sales, then COVID, followed.
Sources: JLR full-year results releases, FY2015–FY2021 (e.g. 23 May 2018: “Full-year retail sales reach 614,309 cars”).

## Slide j133
07 Epilogue · 133
FY2019–21: a £3.6bn loss, then COVID and the chip shortage
FY2019
Pre-tax loss £3.6bn, including a £3.1bn non-cash write-down, as China sales fell
“Project Charge”: £2.5bn of savings, later raised to £5bn
FY2021
COVID closed JLR’s plants for two months; full-year loss £861m
Then a global chip shortage
Debt
The 3.5% notes were repaid in March 2020, in the middle of the crisis
Slide 134
Plain: exceptional items = one-off costs or gains, such as write-downs, that a company reports apart from its normal profit.
So what: JLR’s credit weakened sharply within five years of the 2015 deal.
Sources: JLR results, 20 May 2019 (“full-year pre-tax loss of £3.6 billion”) and 18 May 2021 (“plants were closed for two months due to Covid”); JLR annual reports FY2020–21.

## Slide j134
07 Epilogue · 134
Hindsight: by 2019–20 JLR paid 5.875–7.75% on new debt, not 3.5%
Coupon on JLR’s new bonds, % a year
Mar 2015 · US$ 5-year (this case)
3.500%
Nov 2019 · € due 2024
5.875%
Nov 2019 · € due 2026
6.875%
Oct 2020 · US$ due 2025
7.750%
Dec 2020 · US$ due 2028
5.875%
Euro coupons are not like-for-like with dollar ones. Ratings by March 2020: S&P B+, Moody’s B1, both well below 2015.
So what: the deal fixed cheap money to 2020; that date then fell in the 2019–20 crisis, when new debt cost 1.7–2.2 times as much.
Sources: JLR annual report FY2020 (bonds repaid and issued; “B+ … from S&P, B1 … from Moody’s”); JLR pricing releases, 21 Nov 2019 and 8 Dec 2020; interim report Q2 FY2021.

## Slide j135
07 Epilogue · 135
2021: “Reimagine” turns Jaguar into an all-electric brand from 2025
£1.5bn
exceptional charges: £952m write-downs + £534m restructuring
−£861m
FY2021 loss before tax, after those charges
JLR’s February 2021 plan: “Jaguar completely reimagined as a pure electric brand, from 2025”, six all-electric Land Rovers in five years, and net cash by FY2024/25.
So what: a costly reset of the business that had looked so strong in 2015.
Sources: JLR annual report FY2021, pp.2–3; results release, 18 May 2021 (“a pre-tax loss of £952 million for the quarter and £861 million for the full year”).

## Slide j136
07 Epilogue · 136
S&P rated JLR investment grade in August 2024; Moody’s sits one notch below
BBB- / Baa3
BB+ / Ba1
BB / Ba2
BB- / Ba3
B+ / B1
B / B2
BB late ’14
B+ Mar ’19
B Apr ’20
BB− Apr ’23
BBB− Aug ’24
Ba3 to Sep ’13
Ba2 Sep ’13
B1 by Mar ’20
Ba1 Jun ’25
● S&P, solid line   ■ Moody’s, dashed line   thick line = lowest investment grade
2013
2016
2019
2022
2025
So what: JLR’s credit swung down and back up (lines join only the dated points). After the 2025 cyber-attack Moody’s kept Ba1 but turned its outlook negative (29 Sep 2025, reported by Forbes).
Sources: case p.2 (Moody’s Ba3 to Ba2, Sep 2013; S&P BB, late 2014); Business Standard, 18 Sep 2013 (secondary); JLR statement 29 Mar 2019; JLR annual report FY2020 (Moody’s B1; S&P B, Apr 2020); JLR notices 26 Apr 2023, 20 Aug 2024, 13 Jun 2025; Forbes, 29 Sep 2025 (secondary).

## Slide j137
07 Epilogue · 137
2025: a cyber-attack stopped production for five weeks
2 Sep 2025
Cyber incident: systems shut, production stops
8 Oct
Phased restart of manufacturing
mid-Nov
Production back to normal levels
£196m
cyber-related costs in Q2 FY2026
−£485m
Q2 loss before tax and exceptional items
£3.5bn
extra liquidity backstop facilities secured
Plain: liquidity backstop facilities = credit lines a company can draw on if it runs short of cash.
So what: the attack cost £196m directly and pushed Q2 to a £485m loss; JLR added £3.5bn of back-up credit.
Sources: JLR Q2 FY2026 results release, Nov 2025 (“manufacturing restarted on a phased basis from 8 October 2025”; “cyber related costs of £196m”); JLR annual report 2026 (“returning to normal levels by mid-November”).

## Slide j138
07 Epilogue · 138
Today JLR is barely profitable: Q1 FY2027 revenue £6.0bn, profit before tax and exceptional items £109m
£6.0bn
Q1 FY27 revenue (to 30 Jun 2026), down 9.6%
£109m
profit before tax and exceptional items, −68.9%
2.8%
adjusted EBIT margin: operating profit before exceptional items ÷ revenue
FY2026: revenue £22.9bn (−20.9%), profit before tax and exceptional items £14m. Owner since the Oct 2025 demerger (Tata Motors split into separately listed companies): Tata Motors Passenger Vehicles. Q2 FY2027 results are not yet out.
So what: a 2.8% margin (0.7% in FY2026) leaves little cushion: the credit strength behind the 2015 coupon must be rebuilt (Moody’s outlook negative, slide 136).
Sources: JLR Q1 FY27 release, 13 Aug 2026 (“Revenue for Q1 was £6.0bn, down 9.6%”); JLR Q4 FY26 release, May 2026; Storyboard18, 24 Oct 2025 (demerger, secondary).

## Slide j139
07 Epilogue · 139
Better credit cut JLR’s borrowing cost; buying back fairly priced debt created no value
The coupon fell because JLR became safer. The buyback just paid holders, at a fair price, for that.
−304bp
credit spread, 2011 → 2015
−US$7.1m
NPV of the buyback
So what: refinancing creates value only when the price is wrong; in March 2015 it was not.
Sources: slides 55, 103.

## Slide j140
08 Team · 140
Group 10
[Photo]
[Full name 1]
[Student ID]
[Photo]
[Full name 2]
[Student ID]
[Photo]
[Full name 3]
[Student ID]
[Photo]
[Full name 4]
[Student ID]
[PLACEHOLDER] Members’ photos, full names and student IDs to be supplied; one card per member.
HBS Case 1 · Jaguar Land Rover
