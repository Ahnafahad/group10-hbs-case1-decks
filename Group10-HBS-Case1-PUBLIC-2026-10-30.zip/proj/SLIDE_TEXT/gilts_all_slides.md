## Slide g01
Group 10 · HBS Case 1
[PLACEHOLDER: course name][PLACEHOLDER: date]
UK Gilts: pricing, yields and interest-rate risk
How a trader prices nine UK government bonds and measures what a rise in rates would cost

## Slide g02
A trader must price nine UK government bonds and know what each could lose if rates rise
Q1
How do the coupon rate and the yield to maturity (YTM) differ, and what does that do to price?
Q2
Fill in the missing prices and yields in Exhibit 1.
Q3
Plot the yield curve the nine gilts make, and explain its shape.
Q4
What happens to the nine prices if every yield rises by 1%?
01–02
Case overview and exhibit
→
03–06
The four questions
→
07
Epilogue: what happened next
→
Team
Group 10
Plain: interest-rate risk = how far a bond’s price falls when market interest rates rise. YTM (yield to maturity) = the yearly return from buying at today’s price and holding to the end.
Source: UK Gilts case (IMD-7-1577), p. 1 and Exhibit 1.
00 Opening · 2

## Slide g03
01
Case overview
The gilt market, how it works, and the problem the case sets
3

## Slide g04
A gilt is a loan to the UK government that pays fixed interest twice a year
Last five payments on £1,000 of the 4% Treasury Gilt 2016 (case, p. 2): 4% × £1,000 = £40 a year, paid as two £20 coupons.
£20
7 Sep 2014
£20
7 Mar 2015
£20
7 Sep 2015
£20
7 Mar 2016
£1,020
7 Sep 2016
Last bar cut, not to scale: final £20 coupon + £1,000 repaid.
Plain: face value = the amount repaid at the end; coupon = the fixed interest, a % of face value per year; maturity = the repayment date.
Source: UK Gilts case, p. 2 (text from the DMO, dmo.gov.uk): coupons on 7 March and 7 September; principal repaid on 7 September 2016.
01 Overview · 4

## Slide g05
A gilt’s name gives its coupon and repayment year; its price is quoted per £100 of face value
4%
coupon rate
£4 a year for each £100 of face value, paid as two £2.00 payments
Treasury Gilt
who borrows
issued by HM Treasury, the UK government
2060
repayment year
the face value is repaid on 22 January 2060
Price quote: a price of 102.50 means £102.50 for each £100 of face value, so £1,000 of face value costs 10 × 102.50 = £1,025.00.
So what: the name tells you the cash a gilt will pay; the price tells you what the market asks for that cash today.
Sources: UK Gilts case, p. 2 (prices quoted per £100 nominal); DMO reference prices 9 May 2014 (4% Treasury Gilt 2060, redemption 22 Jan 2060).
01 Overview · 5

## Slide g06
Conventional gilts pay fixed cash; index-linked gilts pay cash that rises with inflation
Conventional
Every coupon is the same fixed £ amount, and the repayment is fixed too. This case covers conventional gilts only.
Index-linked
Coupons and repayment are raised in line with the UK Retail Prices Index (RPI), a measure of inflation. Bar heights are an illustration, not data.
Share of gilts in issue, 31 March 2014, by nominal value (£1,039bn and £326bn of £1,365bn):
Conventional 76.1%
Index-linked 23.9%
Sources: UK Gilts case, p. 2; DMO Annual Review 2013-14, Annex C, Table C1 (nominal value incl. inflation uplift, gross).
01 Overview · 6

## Slide g07
The UK has never missed a gilt payment, so gilts set the UK’s risk-free rate
“The British Government has never failed to make interest or principal payments on gilts as they fall due.” (case, p. 2)
Plain: risk-free rate = the return on a loan with no real chance of default; gilts are the UK’s benchmark for it. A credit rating is an agency’s grade of a borrower’s ability to repay: the scale runs AAA (top), AA+, AA, AA−, …, so AA− is one notch below AA and three below AAA.
AAA
S&P, 14 Jun 2014: AAA reaffirmed (secondary: PTI)
top grade
AA+
AA
AA−
Fitch, 14 Aug 2026: AA− kept (secondary: Reuters)
three notches below AAA
So what: the unbroken payment record is why gilt yields are the base for UK borrowing.
Sources: UK Gilts case, p. 2; S&P AAA: Business Standard/PTI, 14 Jun 2014 (secondary); Fitch AA−: Reuters via globalbankingandfinance.com, 14 Aug 2026 (secondary). Other agencies not verified, not shown.
01 Overview · 7

## Slide g08
The Treasury issues gilts mostly at 5, 10 and 30 years, and since 2005 also at 50
The case says the government “has concentrated issuance around the 5-, 10- and 30-year maturity areas” and issued a 50-year gilt in May 2005, but “the liquidity in the secondary market is low”.
5-year
10-year
30-year
50-year
0
10
20
30
40
50
Years to maturity
Plain: Debt Management Office (DMO) = the body that announces gilt sales and publishes gilt prices. Liquidity = how easily a bond can be sold at a fair price; a thinly traded gilt is hard to sell quickly.
Sources: UK Gilts case, p. 2; DMO press release 21 Oct 2009 (4% Treasury Gilt 2060 launched as a “50-year benchmark gilt”); DMO Annual Review 2005-06 (50-year issuance resumed in May 2005, first since 1960).
01 Overview · 8

## Slide g09
The gilt market has doubled: £1,365bn in 2014, £2,817bn in 2026
Plain: inflation uplift = the extra face value index-linked gilts gain as prices rise.
March 2014
£1,365bn
Conventional £1,039bn (dark) + index-linked £326bn (light)
March 2026
£2,817bn
Conventional £2,144bn (dark) + index-linked £673bn (light)
×2.06
2,817 ÷ 1,365: the market is about twice as large, and bars start at zero on the same scale
So what: more gilts for investors to hold means more money exposed to interest-rate changes.
Source: DMO Annual Review 2013-14, Table C1 (31 Mar 2014) and 2025-26, Table 20 (31 Mar 2026): nominal value incl. inflation uplift on index-linked gilts, gross. Rows rounded.
01 Overview · 9

## Slide g10
QE: since 2009 the Bank of England has bought gilts to push their yields down
Plain: QE (quantitative easing) = the central bank buys bonds, which raises their prices and lowers their yields (the yearly return a buyer earns at the price paid).
Plain: Bank Rate = the Bank of England’s main interest rate; it sets the cost of short-term borrowing in the UK.
0.50%
Bank Rate from 5 March 2009, unchanged until 4 August 2016
£375bn
of gilts bought through the Bank’s Asset Purchase Facility by 2014
So what: by 2014 the Bank held 26.4% of all gilts (slide 11).
Sources: BoE, “Quantitative easing” (QE began March 2009); BoE Bank Rate history (5 Mar 2009: 0.50; next change 4 Aug 2016: 0.25); DMO Annual Review 2013-14 (APF £375bn; holdings £370.8bn at market value).
01 Overview · 10

## Slide g11
In 2014 three groups held over 80% of gilts: overseas investors, pension funds and insurers, and the Bank
Share of all gilts held, end-March 2014, % (market value)
Overseas investors
29.2
Pension funds and insurers
26.6
Bank of England
26.4
Banks and building societies
9.5
Everyone else (remainder)
8.3
82.2%
held by the top three: 29.2 + 26.6 + 26.4 (accent bars)
So what: buying made the Bank as big a holder as the pension funds.
Source: DMO Annual Review 2013-14 (overseas £410.0bn; pensions and insurers £372.7bn; Bank £370.8bn, which the DMO dates “end-2014”; banks £132.9bn). Remainder is our subtraction.
01 Overview · 11

## Slide g12
UK government debt more than doubled as a share of GDP, from 35.6% in 2008 to 78.6% in 2014
Net debt, % of GDP, end of March
35.6
2008
78.6
2014
93.2
2026
Net borrowing in the year to March, % of GDP
2.9
2008
5.6
2014
4.4
2026
Plain: net debt = what the government owes minus its liquid assets; net borrowing = the new debt added in a year. GDP = the value of everything the UK produces in a year.
So what: debt in 2014 was 2.2 times 2008’s (78.6 ÷ 35.6): many more gilts to sell.
Source: ONS series HF6X (net debt ex public sector banks, % of GDP, current vintage) and J5IJ (net borrowing, % of GDP), release 21 Oct 2026. Bars start at zero; the two charts use different scales.
01 Overview · 12

## Slide g13
In May 2014 a 10-year gilt paid 2.77%, against 2.62% in the US and 1.50% in Germany
Yield on a 10-year government bond, % a year (bars start at zero)
9 May 2014
UK
2.77
US
2.62
Germany
1.50
Late Oct 2026
UK
5.30
US
4.98
Germany
3.39
Plain: par yield = the coupon a bond would need to be priced at exactly £100. Late October 2026 = UK 27 Oct, US and Germany 29 Oct.
So what: all three yields are far higher today, and the UK’s has risen the most (+2.53 points).
Sources: BoE series IUDMNPY (UK 10-year nominal par yield); US Treasury daily par yield curve; Bundesbank 10-year par yield BBSIS (annual coupons). UK 2.77 on this basis; DMO’s 2¾% 2024 yields 2.80 (slide 22).
01 Overview · 13

## Slide g13b
Gilts, continued: the extra yield over German Bunds grew from 127bp to 191bp
Sovereign spread = gilt yield minus the other government’s yield, in basis points (bars start at zero)
Gilt − Bund, 2014
127bp
Gilt − Bund, now
191bp
Gilt − Treasury, 2014
15bp
Gilt − Treasury, now
32bp
Plain: Treasuries = US government bonds; Bunds = German government bonds; sovereign spread = the extra yield one government pays over another; basis point (bp) = 0.01 percentage point. 2.77 − 1.50 = 1.27 points = 127bp.
So what: investors ask the UK for more extra yield than in 2014, most of all against Germany. The ‘now’ spread mixes the UK’s 27 Oct yield with Germany’s of 29 Oct.
Sources: BoE series IUDMNPY; US Treasury daily par yield curve; Bundesbank BBSIS 10-year par yield (see slide 13). Spreads are our subtraction of the 2-dp yields shown.
01 Overview · 13b

## Slide g14
The case: Petr Cech must price nine gilts and measure their risk for his trading desk
Petr Cech is a financial analyst at MU Securities, in charge of fixed-income strategies trading and the firm’s investments in gilts. He must value nine gilts with maturities from 1 to 50 years (case, p. 1).
1 · VALUE
Find the right price and the yield to maturity for each of the nine gilts
Questions 1 to 3
2 · COMPARE
A fair price shows whether a quoted price is too high or too low, so the desk can spot gilts that look over- or under-priced
Why prices matter
3 · MEASURE RISK
Compute how much each price would fall if rates rise, so the desk can set limits and hedge
Question 4
So what: the case asks for two things on each gilt: a fair price and a risk number.
Source: UK Gilts case (IMD-7-1577), p. 1.
01 Overview · 14

## Slide g15
Five ideas run through the deck: price, coupon, YTM, premium or discount, basis point
Price per £100
Bond prices are quoted for £100 of face value: 102.50 means £102.50 for each £100 repaid at maturity.
Coupon
The fixed yearly interest as a % of face value: a 4¾% coupon pays £4.75 a year on £100.
YTM
Yield to maturity: the one yearly interest rate at which the bond’s future cash, discounted, equals its price today.
Premium · discount
Premium = price above £100; discount = price below £100; par = exactly £100.
Basis point (bp)
1bp = 0.01 percentage point, so 100bp = 1 percentage point.
Source: UK Gilts case, p. 2 (price quotes, coupons); CFA Institute fixed-income curriculum (YTM).
01 Overview · 15

## Slide g16
Each question needs one CFA tool: time value of money, YTM, the yield curve, duration and convexity
Q1
How the coupon rate and the YTM differ
Time value of money
Q2
Fill in four prices and five yields
Present value and YTM search
Q3
Plot and explain the yield curve
Spot and forward rates
Q4
Reprice all nine if yields rise 1%
Duration and convexity
Each tool is explained just before the first slide that uses it.
So what: the questions build on each other: the prices from Q2 feed the curve in Q3 and the risk test in Q4.
Source: CFA Institute fixed-income curriculum; case questions as given to the class.
01 Overview · 16

## Slide g17
02
Exhibit analysis
Rebuilding the case’s one exhibit and reading what it shows
17

## Slide g18
Exhibit 1 gives nine gilts, each with either a price or a yield, never both
Exhibit 1. UK Gilts (rebuilt from the case; “?” = blank in the case)
Maturity (years) | 1 | 2 | 3 | 5 | 7 | 10 | 20 | 30 | 50 |
Coupon as printed | 3¼ | 5¼ | 4½ | 2¾ | 5 | 3¾ | 4¾ | 4½ | 4 |
Coupon (% of face) | 3.25 | 5.25 | 4.50 | 2.75 | 5.00 | 3.75 | 4.75 | 4.50 | 4.00 |
Price (£ per £100) | 102.50 | ? | 107.02 | ? | 108.91 | ? | 104.93 | ? | 94.96 |
YTM (% a year) | ? | 1.74 | ? | 3.00 | ? | 4.04 | ? | 4.36 | ? |
Plain: YTM = the one yearly return that makes the bond’s future cash worth its price today.
So what: the gaps, four prices and five yields, are what Q2 fills in.
Source: Exhibit 1, UK Gilts case (IMD research), p. 3. The case prints Price, YTM, Coupon and Maturity as columns; they are rows here. YTMs as printed to 2 dp.
02 Exhibits · 18

## Slide g18b
Exhibit 1, continued: five prices and four yields are given, so four prices and five yields are missing
5
prices given: the 1, 3, 7, 20 and 50-year gilts
4
yields given: the 2, 5, 10 and 30-year gilts
9
gilts in all, each with one of the two blank
Price and yield carry the same information once the coupon and maturity are known: give one and the other follows. That is why the case can leave one blank for each gilt.
So what: from the five prices we solve five yields; from the four yields we compute four prices (Q2).
Source: Exhibit 1, UK Gilts case, p. 3.
02 Exhibits · 18b

## Slide g19
Coupons range from 2¾% to 5¼% because each gilt was issued when rates were different
Coupon, % of face value a year (bars start at zero; accent = highest, lowest)
3.25
1y
3¼%
5.25
2y
5¼%
4.50
3y
4½%
2.75
5y
2¾%
5.00
7y
5%
3.75
10y
3¾%
4.75
20y
4¾%
4.50
30y
4½%
4.00
50y
4%
Case: the coupon “usually reflects the market interest rate at the time of the first issue”.
So what: a coupon tells you about the past, not about today’s market.
Source: Exhibit 1, UK Gilts case, p. 3; case text, p. 2. Second label row = coupon as printed.
02 Exhibits · 19

## Slide g20
Four of the five given prices are above £100, so those gilts must yield less than their coupon
Given price minus 100, £ per £100 of face value. Right = premium (price above 100), left = discount (below 100).
1-year: 102.50
+2.50
3-year: 107.02
+7.02
7-year: 108.91
+8.91
20-year: 104.93
+4.93
50-year: 94.96
−5.04
100 = par
So what: only the 50-year gilt (94.96) sells at a discount; for the other four, buyers pay more than £100 and so must accept a yield below the coupon. A first clue for Q1.
Source: Exhibit 1, UK Gilts case, p. 3 (prices); our subtraction.
02 Exhibits · 20

## Slide g21
The four given yields rise with maturity, from 1.74% at 2 years to 4.36% at 30
Given yield to maturity (%)
0
1
2
3
4
5
0
10
20
30
40
50
Years to maturity
1.74
3.00
4.04
4.36
Dashed lines mark the five maturities (1, 3, 7, 20 and 50 years) whose yield is missing. From 2 to 10 years the given yields climb 230bp (1.74% to 4.04%); from 10 to 30 years only 32bp.
So what: longer loans pay more, which sets up Q3.
Source: Exhibit 1, UK Gilts case, p. 3. bp = basis point (0.01 percentage point).
02 Exhibits · 21

## Slide g22
Exhibit 1 is a classroom data set: from 10 years out it sits about a point above the real market
Yield (%)
0
1
2
3
4
5
0
10
20
30
40
50
Years to maturity
4.04
2.80
4.36
3.39
4.24
3.37
Real gilts, 9 May 2014 (DMO)
Exhibit 1 (solved in Q2)
Gap at 10, 30 and 50 years: 4.04 − 2.80 = 124bp; 4.36 − 3.39 = 97bp; 4.24 − 3.37 = 87bp. From about 1 to 10 years the real curve rises 240bp (0.40% to 2.80%), Exhibit 1 rises 331bp (0.73% to 4.04%).
So what: we analyse the exhibit’s numbers, and use the real data only as context.
Sources: Exhibit 1 (yields solved in Q2); DMO gilt reference prices 9 May 2014: 2¾% 2015, 2% 2016, 4½% 2019, 2¾% 2024, 4½% 2034, 4½% 2042, 4% 2060 (semi-annual basis).
02 Exhibits · 22

## Slide g23
None of the nine is an exact real gilt, so we keep the case’s labels
Closest real gilts on 9 May 2014 (years left in brackets), 1 to 7 years:
Case gilt | Closest real gilts (years left) | Why it is not an exact match |
1y · 3¼% | 2¾% 2015 (0.7y), 4¾% 2015 (1.3y) | No 3¼% gilt matured in 2015 |
2y · 5¼% | 2% 2016 (1.7y); 4% 2016 (2.3y) | No 5¼% gilt was in issue |
3y · 4½% | 4½% 2019 (4.8y), 1¾% 2017 (2.7y) | Only 4½% 2019 has the coupon: 1.8y longer |
5y · 2¾% | 4½% 2019 (4.8y), 1¾% 2019 (5.2y) | 2¾% gilts: 2015 (0.7y), 2024 (10.3y) |
7y · 5% | 8% 2021 (7.1y), 3¾% 2021 (7.3y) | 5% gilts: 2014, 2018, 2025 |
So what: the case’s coupons are teaching values, so we name no real gilt as one of the nine.
Source: DMO gilt reference prices 9 May 2014 (dmo.gov.uk); our matching: exact = same coupon and maturity within about a year.
02 Exhibits · 23

## Slide g23b
Real gilts, continued: for 10 to 50 years, the coupons match only at 30 and 50, and both fall short
Closest real gilts on 9 May 2014 (years left in brackets), 10 to 50 years:
Case gilt | Closest real gilts (years left) | Why it is not an exact match |
10y · 3¾% | 2¾% 2024 (10.3y), 2¼% 2023 (9.3y) | 3¾% gilts: 2019 to 2021 |
20y · 4¾% | 4½% 2034 (20.3y), 4¾% 2030 (16.6y) | The 20.3-year gilt pays 4½% |
30y · 4½% | 4½% 2042 (28.6y) | Coupon matches, but it is 1.4 years short |
50y · 4% | 4% 2060 (45.7y) | Coupon matches, but it is 4.3 years short |
So what: the 4½% 2042 and 4% 2060 are the best fits, yet 1.4 and 4.3 years short. Slide 136 uses the 4% 2060 as a real-world example, not as the case’s bond.
Source: DMO gilt reference prices 9 May 2014; DMO press release 21 Oct 2009 (4% 2060 launched as a 50-year benchmark).
02 Exhibits · 23b

## Slide g24
The task: work out four prices and five yields, then test all nine against a rate rise
4
prices to compute
5
yields to solve
9
gilts repriced if every yield rises 1%
Q1
Coupon vs YTMslides 25–37
→
Q2
Fill the gapsslides 38–56
→
Q3
Yield curveslides 57–72
→
Q4
+1% testslides 73–127
Exhibit 1 treats coupons as paid once a year, although real gilts pay twice a year. We use annual coupons throughout and test the difference on slides 55–56.
Source: Exhibit 1, UK Gilts case, p. 3; case questions.
02 Exhibits · 24

## Slide g25
03
Q1: coupon rate vs yield to maturity
Two numbers describe every gilt. One fixes the cash it pays; the other fixes what it is worth today.
25

## Slide g26
Q1: how do the coupon rate and the YTM differ, and what does that do to price?
The case asks one question with three parts. We answer them in this order:
1  Define
What the coupon rate is, what the yield to maturity (YTM) is, and the conditions under which the YTM is earned.
Slides 27–28
2  Compare
How the two differ in size and in what they do, using all nine gilts and the 20-year gilt in detail. Why they differ: Bank Rate.
Slides 29–31, 36
3  Effect on price
How price moves with the YTM: the formula, the price–yield curve, and the premium, par and discount rule.
Slides 32–35
So what: the answer is on slide 37; every number it uses is built on the slides before it.
Source: UK Gilts case, question 1; slide structure is ours.
03 Q1 · 26

## Slide g27
The coupon rate fixes the cash; the YTM is the return the market demands today
£4.75
paid every year on the 20-year gilt: coupon rate 4.75% × £100 face value, fixed at issue.
4.38%
a year: the return buyers want on that gilt today, its YTM (slide 52). It moves with the market.
Plain: coupon rate = the yearly interest as a % of face value. Yield to maturity (YTM) = the single yearly rate at which the gilt’s future cash, discounted, adds up to today’s price.
So what: the coupon is a fixed promise made in the past; the YTM is today’s price of waiting for that promise.
Source: our calculation (calcs.py) from Exhibit 1, UK Gilts case, p.3.
03 Q1 · 27

## Slide g28
YTM is the bond’s internal rate of return, and it is only earned under three conditions
Plain: internal rate of return (IRR) = the one rate at which the present value (PV, today’s worth) of the cash flows equals the price paid.
Price paid = CF₁/(1+y) + CF₂/(1+y)² + … + CF_N/(1+y)^N,   y = YTM
1  Held to maturity
Keep it until repayment. Sell early and the sale price decides your return.
Breaks: price risk
2  No default
Every payment arrives in full, on time (gilts never have missed one: slide 7).
Breaks: lost cash
3  Coupons reinvested at the YTM
Each coupon earns the YTM until the end. If rates move, you earn something else.
Slides 29–30
So what: the YTM is a promise that holds only if all three conditions hold.
Source: CFA Level I, Fixed Income (yield measures); IRR definition as in CFA Level I, Quantitative Methods.
03 Q1 · 28

## Slide g29
Reinvesting coupons below the YTM lowers the return actually earned
Plain: realised return = what you actually earn, given the rate at which each coupon is reinvested.
Coupons at the end = C × [(1+r)^N − 1] ÷ r      (r = reinvestment rate)
The bracket is the “future-value annuity factor”: what £1 a year for N years grows to.
Reinvested at the YTM, 4.3751%: 4.75 × 30.9642 = 147.08; + 100 = 247.08
Principal100.00
Coupons95.00
Interest52.08
Reinvested at 2%: 4.75 × 24.2974 = 115.41; + 100 = 215.41
Principal100.00
Coupons95.00
Interest20.41
So what: at 2% the pot ends £31.67 smaller per £100 of face (bars to scale, from zero).
Source: our calculation (calcs.py, final_displays). Coupons added without interest: 4.75 × 20 = 95.00.
03 Q1 · 29

## Slide g30
At 2% reinvestment, the 20-year gilt returns 3.66%
In words: the yearly rate that grows the £104.93 paid today into the cash held at the end.
Realised return = (end value ÷ price paid)^(1/20) − 1
At 2%: (215.41 ÷ 104.93)^(1/20) − 1 = 3.66%
At 0%: 4.75 × 20 = 95; + 100 = 195;  (195 ÷ 104.93)^(1/20) − 1 = 3.15%
At the YTM: (247.08 ÷ 104.93)^(1/20) − 1 = 4.38%, the promised return (slide 29).
3.66%
a year, vs 4.38% promised
Yearly return (bars start at zero):
At the YTM
4.38%
At 2%
3.66%
At 0%
3.15%
So what: if market rates fall, a holder earns less than the YTM promised: reinvestment risk.
Source: our calculation (calcs.py, final_displays); price paid 104.93 from Exhibit 1.
03 Q1 · 30

## Slide g31
Coupon rate, current yield and YTM give three answers for one bond
Plain: current yield = annual coupon ÷ price; it ignores the gain or loss at repayment.
Gilt | Coupon rate | Price, £ | Current yield = coupon ÷ price | YTM |
1-year | 3.25% | 102.50 | 3.25 ÷ 102.50 = 3.17% | 0.73% |
2-year | 5.25% | 106.84 | 5.25 ÷ 106.84 = 4.91% | 1.74% |
3-year | 4.50% | 107.02 | 4.50 ÷ 107.02 = 4.20% | 2.06% |
5-year | 2.75% | 98.86 | 2.75 ÷ 98.86 = 2.78% | 3.00% |
7-year | 5.00% | 108.91 | 5.00 ÷ 108.91 = 4.59% | 3.54% |
10-year | 3.75% | 97.65 | 3.75 ÷ 97.65 = 3.84% | 4.04% |
20-year | 4.75% | 104.93 | 4.75 ÷ 104.93 = 4.53% | 4.38% |
30-year | 4.50% | 102.32 | 4.50 ÷ 102.32 = 4.40% | 4.36% |
50-year | 4.00% | 94.96 | 4.00 ÷ 94.96 = 4.21% | 4.24% |
So what: only the YTM counts the whole return.
Source: Exhibit 1, UK Gilts case; prices and YTMs not given there are worked on slides 41–53 (calcs.py).
03 Q1 · 31

## Slide g31b
Coupon vs YTM, continued: six below, three above
■ coupon rate    ● YTM
0%
2%
4%
6%
0.73%
3.25%
1-year
premium
1.74%
5.25%
2-year
premium
2.06%
4.50%
3-year
premium
2.75%
3.00%
5-year
discount
3.54%
5.00%
7-year
premium
3.75%
4.04%
10-year
discount
4.38%
4.75%
20-year
premium
4.36%
4.50%
30-year
premium
4.00%
4.24%
50-year
discount
So what: the gap between the two rates puts a gilt above or below £100 (slides 32–34).
Source: Exhibit 1, UK Gilts case; YTMs worked on slides 41–53 (calcs.py). Axis starts at 0%.
03 Q1 · 31

## Slide g32
A bond’s price is the present value of its cash flows at the YTM
In words: a payment is worth less the later it comes; shrink each back to today and add.
P = Σ [ C ÷ (1+y)^t ] + 100 ÷ (1+y)^N
P
price per £100
C
coupon, £ a year
y
the YTM as a decimal
t
year a payment arrives
N
years left
Σ
add up, t = 1 to N
£1 paid in year t, worth today at 4%:
0.9615
yr 1
0.8219
yr 5
0.6756
yr 10
0.4564
yr 20
0.3083
yr 30
0.1407
yr 50
So what: a higher y shrinks every term, so a higher YTM always means a lower price.
Source: CFA Level I, Fixed Income (bond pricing); illustration computed as 1 ÷ 1.04^t.
03 Q1 · 32

## Slide g33
When the yield rises, the price falls
Price of the 7-year, 5% gilt at every yield from 0% to 10%, from the formula on slide 32:
80
100
120
140
0%
2%
4%
6%
8%
10%
Yield to maturity
Price per £100 (axis starts at 70)
Given price 108.91 at 3.54%
At 5.00% (= coupon): £100.00
119.42
94.42
84.38
So what: price and yield always move in opposite directions, and the curve bends: a given rise in yield costs less price at high yields than at low ones.
Source: our calculation (calcs.py method) for every point; given price from Exhibit 1, its yield worked on slide 51.
03 Q1 · 33

## Slide g34
YTM below the coupon means a price above £100; above it, below £100
YTM below coupon
price above £100: premium
YTM equals coupon
price of exactly £100: par
YTM above coupon
price below £100: discount
■ coupon rate    ● YTM (given in Exhibit 1)
0%
2%
4%
6%
1.74%
5.25%
2-year
premium
4.36%
4.50%
30-year
premium
2.75%
3.00%
5-year
discount
3.75%
4.04%
10-year
discount
4.00%
4.00%
Par (made-up)
par
So what: compare the two rates to know which side of £100 the price lies.
Source: Exhibit 1, UK Gilts case (given yields only); made-up par example: 10-year, 4% coupon, 4% YTM, priced with the slide 32 formula.
03 Q1 · 34

## Slide g35
A premium or discount shrinks to zero as the gilt nears repayment
Plain: pull to par = the steady move of a gilt’s price to £100 as repayment nears, if its YTM stays put.
100
105
110
0
2
4
6
8
10
Years left until repayment
Price per £100 (axis starts at 95)
7-year, 5%: premium
10-year, 3.75%: discount
So what: with yields unchanged, a premium or discount fades year by year; on the repayment date every gilt is worth exactly £100.
Source: our calculation (calcs.py method): each year’s price = the slide 32 formula with N years left, YTM fixed at 3.54% and 4.04%.
03 Q1 · 35

## Slide g35b
Pull to par, continued: the year-by-year prices behind the chart
Price per £100 as the years left fall from 10 to 0 (7-year gilt: 5% coupon, YTM 3.54%; 10-year gilt: 3.75% coupon, YTM 4.04%):
Years left | 10 | 9 | 8 | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
7-year |  |  |  | 108.91 | 107.77 | 106.58 | 105.36 | 104.09 | 102.77 | 101.41 | 100.00 |
10-year | 97.65 | 97.85 | 98.05 | 98.26 | 98.48 | 98.71 | 98.95 | 99.20 | 99.45 | 99.72 | 100.00 |
The 7-year premium loses about £1 a year at first and less near the end (108.91 → 107.77 → … → 100.00). The 10-year discount gains about £0.20–0.30 a year (97.65 → 97.85 → … → 100.00).
So what: both paths end at exactly 100.00, whatever the starting point.
Source: our calculation (calcs.py method), prices to 2 dp.
03 Q1 · 35

## Slide g36
Coupons and yields differ because Bank Rate fell from 5.75% in 2007 to 0.50% in 2009
Case p.2: “the coupon rate usually reflects the market interest rate at the time of the first issue”. Later, rates move; the coupon stays.
3%
6%
2006
2008
2010
2012
2014
Year
Bank Rate, % a year (axis starts at 0)
4.75% (Aug 2006)
Peak 5.75% (Jul 2007)
0.50% (Mar 2009)
unchanged to 2014
So what: a gilt issued while Bank Rate was high has a high coupon, and trades above £100 once yields fall.
Source: Bank of England, Official Bank Rate history (14 changes, Aug 2006–Mar 2009; next change Aug 2016); UK Gilts case, p.2.
03 Q1 · 36

## Slide g37
Q1 answer: the coupon sets the cash; the yield sets the price
£4.75
coupon rate on the 20-year gilt: cash per £100 each year, fixed at issue.
4.38%
YTM: the return the market demands today.
£104.93
price: £4.75 a year and £100 at the end, discounted at 4.38%.
YTM below coupon: premium (above £100). Above: discount. Equal: par. Here 4.38% So what: a trader quotes price or yield; either one fixes the other.
Source: Exhibit 1, UK Gilts case; YTM worked on slide 52 (calcs.py).
03 Q1 · 37

## Slide g38
04
Q2: the missing prices and yields
Exhibit 1 has four blank prices and five blank yields. We fill every gap, one step per slide.
38

## Slide g39
Q2: four prices and five yields are missing
Exhibit 1, rebuilt: price in £ per £100 face; coupon and YTM in % a year.
Gilt | Coupon, % | Price, £ | YTM, % |
1-year | 3.25 | 102.50 | ? |
2-year | 5.25 | ? | 1.74 |
3-year | 4.50 | 107.02 | ? |
5-year | 2.75 | ? | 3.00 |
7-year | 5.00 | 108.91 | ? |
10-year | 3.75 | ? | 4.04 |
20-year | 4.75 | 104.93 | ? |
30-year | 4.50 | ? | 4.36 |
50-year | 4.00 | 94.96 | ? |
4
prices to find: the 2-, 5-, 10- and 30-year gilts (slides 41–47)
5
yields to find: the 1-, 3-, 7-, 20- and 50-year gilts (slides 48–53)
So what: price and yield are tied by one formula, so knowing one gives the other.
Source: Exhibit 1, UK Gilts case, p.3 (IMD research).
04 Q2 · 39

## Slide g40
Assumptions: annual coupons, on a coupon date, per £100
1  Annual coupons
Exhibit 1 treats the coupon as one payment a year. Real gilts pay twice a year; slides 55–56 test the difference.
A case simplification
2  A coupon date
A coupon was just paid, so no interest has built up since: clean price = full price.
No accrued interest
3  Per £100 of face
Every price is what you pay for £100 of face value, as the case quotes it.
Face value £100
Plain: clean price = the quoted price. Full price = clean price + accrued interest. Accrued interest = interest earned since the last coupon, paid on top when a gilt is sold between coupon dates.
So what: on a coupon date the price is simply the present value of the cash still to come.
Source: UK Gilts case, p.3 (Exhibit 1 prices per £100); CFA Level I, Fixed Income (clean and full price).
04 Q2 · 40

## Slide g41
Price from yield, step 1: the 5-year gilt’s cash flows
The 5-year gilt has a 2.75% coupon: 2.75% × £100 = £2.75 a year. In year 5 it also repays the £100 face value.
Cash per £100 of face; bars to scale from zero (grey = the £2.75 coupon):
2.75
Yr 1
2.75
Yr 2
2.75
Yr 3
2.75
Yr 4
102.75
Yr 5
Years 1–4: £2.75 each.     Year 5: £2.75 + £100 = £102.75.
So what: five cash payments to value; slide 42 discounts each at the 3.00% yield.
Source: Exhibit 1, UK Gilts case (5-year gilt: coupon 2.75%, YTM 3.00%).
04 Q2 · 41

## Slide g42
Step 2: discount each cash flow at 3.00%
Plain: discount factor = what £1 paid in year t is worth today = 1 ÷ 1.03^t. PV = cash flow × discount factor.
Year t | Cash flow, £ | Discount factor | PV, £ |
1 | 2.75 | 0.970874 | 2.6699 |
2 | 2.75 | 0.942596 | 2.5921 |
3 | 2.75 | 0.915142 | 2.5166 |
4 | 2.75 | 0.888487 | 2.4433 |
5 | 102.75 | 0.862609 | 88.6331 |
Discount factor by year (bars start at zero):
0.9709
1
0.9426
2
0.9151
3
0.8885
4
0.8626
5
So what: the later the payment, the less it is worth today; the £102.75 in year 5 is worth £88.63.
Source: our calculation (calcs.py); cash flows from slide 41.
04 Q2 · 42

## Slide g43
Step 3: add them up: the 5-year gilt is worth £98.86
2.6699 + 2.5921 + 2.5166 + 2.4433 + 88.6331 = 98.8550  (rows rounded; unrounded 98.8551)
Rounded to pence: £98.86.
PV of each payment, £ (bars start at zero):
Year 1
2.6699
Year 2
2.5921
Year 3
2.5166
Year 4
2.4433
Year 5
88.6331
£98.86
per £100 of face: the price at a 3.00% yield
So what: below £100, because the 3.00% yield is above the 2.75% coupon.
Source: our calculation (calcs.py); working rows rounded to 4 dp.
04 Q2 · 43

## Slide g44
A shortcut gives the same answer: the coupons as an annuity plus the PV of £100
Plain: annuity = equal payments every year. Its PV = coupon × [1 − (1+y)^−N] ÷ y.
P = C × [1 − (1+y)^−N] ÷ y + 100 ÷ (1+y)^N
1 ÷ 1.03⁵ = 0.86260878;  factor = (1 − 0.86260878) ÷ 0.03 = 4.579707
P = 2.75 × 4.579707 = 12.5942;  + 100 × 0.86260878 = 86.2609;  = 98.8551
Same total, two routes (£, bars to scale from zero):
1
2
3
4
Year 5: 88.6331
12.5942
86.2609
So what: two methods, one answer, £98.86; the shortcut saves work on the long gilts.
Source: our calculation (calcs.py, final_displays). Top bar: five PVs from slide 42; bottom bar: coupon annuity and PV of £100.
04 Q2 · 44

## Slide g45
The 2-year gilt at 1.74% is worth £106.84
In words: coupon × annuity factor, plus the PV of the £100 repaid, at 1.74%.
P = 5.25 × [1 − 1.0174^−2] ÷ 0.0174 + 100 ÷ 1.0174^2
1.0174² = 1.03510276;  factor = (1 − 1 ÷ 1.03510276) ÷ 0.0174 = 1.948985
5.25 × 1.948985 = 10.2322;  + 100 ÷ 1.0174² = 96.6088;  total 106.8410 = 106.84
£106.84
per £100: a premium
Price vs £100, nine gilts (bars start at £100):
1y
106.84
2y
3y
5y
7y
10y
20y
30y
50y
So what: a premium: 1.74% is below the 5.25% coupon, so buyers pay more than £100.
Source: our calculation (calcs.py, final_displays) from Exhibit 1.
04 Q2 · 45

## Slide g46
The 10-year gilt at 4.04% is worth £97.65
In words: coupon × annuity factor, plus the PV of the £100 repaid, at 4.04%.
P = 3.75 × [1 − 1.0404^−10] ÷ 0.0404 + 100 ÷ 1.0404^10
1.0404¹⁰ = 1.48594740;  factor = (1 − 1 ÷ 1.48594740) ÷ 0.0404 = 8.094769
3.75 × 8.094769 = 30.3554;  + 100 ÷ 1.0404¹⁰ = 67.2971;  total 97.6525 = 97.65
£97.65
per £100: a discount
Price vs £100, nine gilts (bars start at £100):
1y
2y
3y
5y
7y
97.65
10y
20y
30y
50y
So what: a discount: 4.04% is above the 3.75% coupon, so buyers pay less than £100.
Source: our calculation (calcs.py, final_displays) from Exhibit 1.
04 Q2 · 46

## Slide g47
The 30-year gilt at 4.36% is worth £102.32
In words: coupon × annuity factor, plus the PV of the £100 repaid, at 4.36%.
P = 4.50 × [1 − 1.0436^−30] ÷ 0.0436 + 100 ÷ 1.0436^30
1.0436³⁰ = 3.59767653;  factor = (1 − 1 ÷ 3.59767653) ÷ 0.0436 = 16.560615
4.50 × 16.560615 = 74.5228;  + 100 ÷ 1.0436³⁰ = 27.7957;  total 102.3185 = 102.32
£102.32
per £100: a premium
Price vs £100, nine gilts (bars start at £100):
1y
2y
3y
5y
7y
10y
20y
102.32
30y
50y
So what: a small premium: 4.36% is a little below the 4.50% coupon.
Source: our calculation (calcs.py, final_displays) from Exhibit 1.
04 Q2 · 47

## Slide g48
Yield from price, the easy case: the 1-year gilt yields 0.73%
Pay £102.50 today (the price)
→
Hold the gilt for 1 year
→
Receive £103.25: £3.25 coupon + £100
In words: the yield is the rate that turns £102.50 into £103.25 in one year.
102.50 = 103.25 ÷ (1 + y)
1 + y = 103.25 ÷ 102.50 = 1.007317;   y = 0.7317% ≈ 0.73%
0.73%
YTM of the 1-year gilt
YTM of all nine gilts (bars start at 0%):
0.73%
1y
2y
3y
5y
7y
10y
20y
30y
50y
So what: buyers accept 0.73% because the £2.50 paid above £100 is lost at repayment.
Source: Exhibit 1, UK Gilts case (1-year gilt: coupon 3.25%, price 102.50); our calculation (calcs.py).
04 Q2 · 48

## Slide g49
Longer gilts need a search: try two yields whose prices sit either side of the target
Plain: bracketing = trying one yield with a price above the target and one below it.
At 2%: 4.5 × 2.883883 + 100 ÷ 1.061208 = 12.9775 + 94.2322 = 107.2097
At 3%: 4.5 × 2.828611 + 100 ÷ 1.092727 = 12.7287 + 91.5142 = 104.2429
100
110
0%
1%
2%
3%
4%
5%
Yield to maturity
Price per £100 (axis starts at 95)
2%: £107.21
3%: £104.24
target £107.02
So what: £107.02 lies between £107.21 and £104.24, so the yield is between 2% and 3%.
Source: Exhibit 1, UK Gilts case (3-year gilt: coupon 4.5%, price 107.02); our calculation (calcs.py method). Price from the slide 44 formula.
04 Q2 · 49

## Slide g50
Estimate in proportion, then check: the 3-year gilt yields 2.06%
Plain: interpolation = assuming the price falls in a straight line between the two tries.
In words: the price falls 0.19 of 2.97 between tries, so 6.4% of the way from 2% to 3%.
y ≈ 2% + (107.21 − 107.02) ÷ (107.21 − 104.24) × 1% = 2.064%
target price £107.02
£107.21
£104.24
at 2%
at 3%
estimate 2.064%
So what: the yield is a little above 2%; the check on slide 50b confirms 2.06%.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays method).
04 Q2 · 50

## Slide g50b
Estimate and check, continued: repricing at 2.0628% gives £107.02
In words: reprice the gilt at the exact yield; it must return the target price.
At 2.0628%: 4.5 × 2.880359 + 100 ÷ 1.063169 = 12.9616 + 94.0584 = 107.0200
Rounds to £107.02, the Exhibit 1 price. The estimate 2.064% was under 1bp above the exact 2.0628%.
2.06%
YTM of the 3-year gilt, from £107.02
YTM of all nine gilts (bars start at 0%):
1y
2y
2.06%
3y
5y
7y
10y
20y
30y
50y
So what: the check reprices to £107.02, so 2.06% is right.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py).
04 Q2 · 50

## Slide g51
The 7-year gilt at £108.91 yields 3.54%
At 3%: 5.0 × 6.230283 + 100 ÷ 1.229874 = 31.1514 + 81.3091 = 112.4605
At 4%: 5.0 × 6.002055 + 100 ÷ 1.315932 = 30.0103 + 75.9918 = 106.0021
Rounded to pence: £112.46 at 3%, £106.00 at 4%. Target: Exhibit 1’s £108.91.
In words: the price falls 3.55 of 6.46 between tries, so 55.0% of the way from 3% to 4%.
y ≈ 3% + (112.46 − 108.91) ÷ (112.46 − 106.00) × 1% = 3.550%
target price £108.91
£112.46
£106.00
at 3%
at 4%
estimate 3.550%
So what: the yield is about halfway between 3% and 4%; the check on slide 51b gives 3.54%.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays method).
04 Q2 · 51

## Slide g51b
7-year gilt, continued: repricing at 3.5406% gives £108.91
In words: reprice the gilt at the exact yield; it must return the target price.
At 3.5406%: 5.0 × 6.105290 + 100 ÷ 1.275777 = 30.5265 + 78.3836 = 108.9101
Rounds to £108.91, the Exhibit 1 price. The estimate 3.550% was 1bp above the exact 3.5406%.
3.54%
YTM of the 7-year gilt, from £108.91
YTM of all nine gilts (bars start at 0%):
1y
2y
3y
5y
3.54%
7y
10y
20y
30y
50y
So what: 3.54% is below the 5% coupon, so the gilt sells at a premium, as slide 34’s rule says.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py).
04 Q2 · 51

## Slide g52
The 20-year gilt at £104.93 yields 4.38%
At 4%: 4.75 × 13.590326 + 100 ÷ 2.191123 = 64.5540 + 45.6387 = 110.1927
At 5%: 4.75 × 12.462210 + 100 ÷ 2.653298 = 59.1955 + 37.6889 = 96.8844
Rounded to pence: £110.19 at 4%, £96.88 at 5%. Target: Exhibit 1’s £104.93.
In words: the price falls 5.26 of 13.31 between tries, so 39.5% of the way from 4% to 5%.
y ≈ 4% + (110.19 − 104.93) ÷ (110.19 − 96.88) × 1% = 4.395%
target price £104.93
£110.19
£96.88
at 4%
at 5%
estimate 4.395%
So what: the yield is about 4.4%; the check on slide 52b narrows it to 4.38%.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays method).
04 Q2 · 52

## Slide g52b
20-year gilt, continued: repricing at 4.3751% gives £104.93
In words: reprice the gilt at the exact yield; it must return the target price.
At 4.3751%: 4.75 × 13.149869 + 100 ÷ 2.354714 = 62.4619 + 42.4680 = 104.9299
Rounds to £104.93, the Exhibit 1 price. The estimate 4.395% was 2bp above the exact 4.3751%.
4.38%
YTM of the 20-year gilt, from £104.93
YTM of all nine gilts (bars start at 0%):
1y
2y
3y
5y
7y
10y
4.38%
20y
30y
50y
So what: below the 4¾% coupon, so a premium; the straight-line guess was 2bp too high.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py).
04 Q2 · 52

## Slide g53
The 50-year gilt at £94.96 yields 4.24%
At 4%: 4.0 × 21.482185 + 100 ÷ 7.106683 = 85.9287 + 14.0713 = 100.0000
At 5%: 4.0 × 18.255925 + 100 ÷ 11.467400 = 73.0237 + 8.7204 = 81.7441
Rounded to pence: £100.00 at 4%, £81.74 at 5%. Target: Exhibit 1’s £94.96.
In words: the price falls 5.04 of 18.26 between tries, so 27.6% of the way from 4% to 5%.
y ≈ 4% + (100.00 − 94.96) ÷ (100.00 − 81.74) × 1% = 4.276%
target price £94.96
£100.00
£81.74
at 4%
at 5%
estimate 4.276%
So what: the yield is about 4.3%; the check on slide 53b narrows it to 4.24%.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays method).
04 Q2 · 53

## Slide g53b
50-year gilt, continued: repricing at 4.2445% gives £94.96
In words: reprice the gilt at the exact yield; it must return the target price.
At 4.2445%: 4.0 × 20.611979 + 100 ÷ 7.992038 = 82.4479 + 12.5125 = 94.9604
Rounds to £94.96, the Exhibit 1 price. The estimate 4.276% was 3bp above the exact 4.2445%.
4.24%
YTM of the 50-year gilt, from £94.96
YTM of all nine gilts (bars start at 0%):
1y
2y
3y
5y
7y
10y
20y
30y
4.24%
50y
So what: for long gilts the straight-line estimate is further off, so the check matters.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py).
04 Q2 · 53

## Slide g54
Exhibit 1 complete: six gilts above £100, three below
Exhibit 1 completed (bold indigo = computed). Bars: price minus £100.
Gilt
Coupon, %
Price, £
YTM, %
Price minus £100
1-year
3.25
102.50
0.73
+2.50
2-year
5.25
106.84
1.74
+6.84
3-year
4.50
107.02
2.06
+7.02
5-year
2.75
98.86
3.00
−1.14
7-year
5.00
108.91
3.54
+8.91
10-year
3.75
97.65
4.04
−2.35
20-year
4.75
104.93
4.38
+4.93
30-year
4.50
102.32
4.36
+2.32
50-year
4.00
94.96
4.24
−5.04
So what: yields run from 0.73% (1-year) to 4.38% (20-year); up-bars are premiums.
Source: Exhibit 1, UK Gilts case, p.3; computed cells from slides 43–53 (calcs.py).
04 Q2 · 54

## Slide g55
Real gilts pay twice a year: a worked example
Plain: the 1.74% yield is still a yearly rate, compounded twice a year: 1.74% ÷ 2 = 0.87% per half-year.
The 2-year gilt now pays £5.25 ÷ 2 = £2.625 every six months, four payments.
Half-year k | Cash, £ | Discount factor | PV, £ |
1 | 2.625 | 0.991375 | 2.602 |
2 | 2.625 | 0.982824 | 2.580 |
3 | 2.625 | 0.974348 | 2.558 |
4 | 102.625 | 0.965944 | 99.130 |
Total |  |  | 106.870 |
£106.84
paid once a year
£106.87
paid twice a year
So what: twice-a-year payments are worth £0.03 more, because the cash arrives a little sooner.
Source: our calculation (calcs.py, strict_extras); the 106.84 is the slide 45 price.
04 Q2 · 55

## Slide g56
Paying twice a year changes prices by at most £0.03 and yields by about 1bp
P = C/2 × [1 − (1+y/2)^−2N] ÷ (y/2) + 100 ÷ (1+y/2)^2N
Gilt, known value | Semi-annual yield (annual-pay) | Coupons: C/2 × factor | Final £100 | Price | Annual-pay price |
1-yearprice 102.50 | 0.7362%(0.7317%) | 1.625 × 1.989011= 3.2321 | 100 ÷ 1.007376= 99.2678 | 102.50 | 102.50 |
2-yearyield 1.74% | 1.7400% | 2.625 × 3.914491= 10.2755 | 100 ÷ 1.035257= 96.5944 | 106.87 | 106.84 |
3-yearprice 107.02 | 2.0743%(2.0628%) | 2.25 × 5.788085= 13.0232 | 100 ÷ 1.063865= 93.9969 | 107.02 | 107.02 |
So what: the biggest price gap here is £0.03 (2-year: 106.87 vs 106.84).
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays). Price-given gilts: yield solved by search in half-year steps, then repriced.
04 Q2 · 56

## Slide g56b
Twice a year, continued: the 5-, 7- and 10-year gilts
Gilt, known value | Semi-annual yield (annual-pay) | Coupons: C/2 × factor | Final £100 | Price | Annual-pay price |
5-yearyield 3.00% | 3.0000% | 1.375 × 9.222185= 12.6805 | 100 ÷ 1.160541= 86.1667 | 98.85 | 98.86 |
7-yearprice 108.91 | 3.5512%(3.5406%) | 2.5 × 12.299657= 30.7491 | 100 ÷ 1.279415= 78.1607 | 108.91 | 108.91 |
10-yearyield 4.04% | 4.0400% | 1.875 × 16.319918= 30.5998 | 100 ÷ 1.491786= 67.0337 | 97.63 | 97.65 |
So what: prices differ by £0.02 at most (10-year, 97.63 against 97.65); rows 4–6 of 9.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays).
04 Q2 · 56

## Slide g56c
Twice a year, continued: the 20-, 30- and 50-year gilts
Gilt, known value | Semi-annual yield (annual-pay) | Coupons: C/2 × factor | Final £100 | Price | Annual-pay price |
20-yearprice 104.93 | 4.3775%(4.3751%) | 2.375 × 26.471409= 62.8696 | 100 ÷ 2.377516= 42.0607 | 104.93 | 104.93 |
30-yearyield 4.36% | 4.3600% | 2.25 × 33.294196= 74.9119 | 100 ÷ 3.647152= 27.4187 | 102.33 | 102.32 |
50-yearprice 94.96 | 4.2437%(4.2445%) | 2.0 × 41.355467= 82.7109 | 100 ÷ 8.163330= 12.2499 | 94.96 | 94.96 |
So what: prices differ by £0.01 at most (30-year, 102.33 against 102.32); rows 7–9 of 9.
Source: Exhibit 1, UK Gilts case; our calculation (calcs.py, r5_displays).
04 Q2 · 56

## Slide g56d
Twice a year, continued: every gap is tiny
Price gap, £ (semi minus annual)
+0.03
2y
−0.01
5y
−0.02
10y
+0.01
30y
Yield gap, percentage points
+0.0045
1y
+0.0115
3y
+0.0106
7y
+0.0024
20y
−0.0008
50y
So what: the largest price gap is £0.03 and the largest yield gap 0.0115 points (about 1bp): the annual simplification is safe.
Source: our calculation (calcs.py, r5_displays). Gaps use the prices and yields printed in the tables: price from yield-given gilts, yield from price-given gilts. Bars start at zero.
04 Q2 · 56

## Slide g57
05
Q3: the yield curve
Plot the nine yields, describe the shape in numbers, and explain it with spot rates, forward rates and three theories
57

## Slide g58
Q3: plot the yield curve the nine gilts make, then describe and explain its shape
The question has three parts. Each part gets its own slides:
1 · Plot
Mark the nine yields to maturity (YTMs) against years to maturity and join them.
Slides 59–60
2 · Describe
Say what the shape is, in numbers: where it rises, levels off or falls.
Slide 61
3 · Explain
Spot and forward rates, three theories, and one caution about what the curve measures.
Slides 62–71
So what: the answer to all three parts is summarised on slide 72.
Source: case question 3; our answers from Q2 (slides 38–54).
05 Q3 · 58

## Slide g59
A yield curve shows the yield on one borrower’s bonds at each maturity
Plain: yield curve = the yield to maturity (vertical) of bonds from one borrower, plotted against years to maturity (horizontal). For gilts it is the UK government’s borrowing cost at each term, the risk-free benchmark of slide 7. A curve can rise, level off or fall; Exhibit 1 does all three (same vertical scale, 0% to 5%, in each panel).
Rises
1 to 10 years0.73% → 4.04%
Levels off
10 to 30 years4.04% → 4.36%
Dips
30 to 50 years4.36% → 4.24%
So what: a curve shows at a glance whether lenders ask more for lending longer.
Source: Exhibit 1, case; yields from our Q2 answers (calcs.py). Annual-pay yields.
05 Q3 · 59

## Slide g60
Exhibit 1’s curve rises steeply to 10 years, is flat to 30, and falls to 4.24% at 50
Yield to maturity (%)
0
1
2
3
4
5
0
10
20
30
40
50
Years to maturity
0.73%
4.04%
4.38%
4.36%
4.24%
1y
0.73%
2y
1.74%
3y
2.06%
5y
3.00%
7y
3.54%
10y
4.04%
20y
4.38%
30y
4.36%
50y
4.24%
Source: Exhibit 1, case; missing yields from our Q2 answers (calcs.py). Horizontal axis is to scale.
05 Q3 · 60

## Slide g61
In numbers: +331bp from 1 to 10 years, +34bp to 20, then −2bp and −12bp
+331bp
1y → 10y
+34bp
10y → 20y
−2bp
20y → 30y
−12bp
30y → 50y
Change in YTM between the two maturities, in basis points (1bp = 0.01 percentage point); one scale throughout.
So what: 331 of the 365bp of upward move (91%) comes in the first ten years; after 20 years the curve slips 14bp.
Source: Exhibit 1, case; our calculation (calcs.py): 4.04 − 0.73, 4.38 − 4.04, 4.36 − 4.38, 4.24 − 4.36 (rounded to whole bp).
05 Q3 · 61

## Slide g62
A YTM mixes many payment dates; a spot rate is the yield for a single payment date
The 3-year 4.5% gilt pays three amounts. The YTM gives them one average rate; spot rates give each its own:
YTM: one rate for all three payments
£4.50
end of year 1
spot rate z₁
£4.50
end of year 2
spot rate z₂
£104.50
end of year 3
spot rate z₃
Plain: spot rate = the yield on a single payment due at one date, like a zero-coupon bond. forward rate = the one-year rate for a future year that today’s prices lock in.
So what: spot rates are the clean building blocks; slides 63–66 recover them one by one.
Source: CFA Level I, Fixed Income (spot and forward rates); gilt from Exhibit 1, case.
05 Q3 · 62

## Slide g63
Step 1: the 1-year spot rate is the 1-year yield, 0.73%
Step 1
Solve z₁
→
Step 2
z₂ = ?
→
Step 3
z₃ = ?
→
Step 4
Forward rates
In words: the 1-year gilt makes one payment, so there is nothing to average. Its price and its one payment fix the rate directly.
102.50 = 103.25 ÷ (1 + z₁)
1 + z₁ = 103.25 ÷ 102.50 = 1.007317
0.73%
1-year spot rate z₁ (the 1-year YTM, slide 48)
So what: with one payment, spot rate and YTM are the same number; z₁ anchors the next step.
Source: Exhibit 1, case (1-year gilt: coupon 3.25%, price 102.50); our calculation (calcs.py).
05 Q3 · 63

## Slide g64
Step 2: the 2-year gilt reveals a 2-year spot rate of 1.77%
Step 1
z₁ = 0.73%
→
Step 2
Solve z₂
→
Step 3
z₃ = ?
→
Step 4
Forward rates
In words: the 2-year price is the PV of its year-1 coupon (discounted at z₁, known) plus the PV of its year-2 payment (discounted at z₂, unknown). Take away the known part; the rest belongs to z₂. This is bootstrapping: using shorter rates to unlock the next one.
106.8409 = 5.25 ÷ 1.007317 + 105.25 ÷ (1 + z₂)²
Price of the 2-year gilt = 106.8409
5.2119 = PV of the year-1 coupon (known)
101.6290 = PV of the year-2 payment (unknown z₂)
Source: Exhibit 1, case; price 106.84 from slide 45 (unrounded 106.8409); our calculation (calcs.py).
05 Q3 · 64

## Slide g64b
Step 2, continued: £105.25 in two years is worth 101.6290 today, so z₂ = 1.77%
Step 1
z₁ = 0.73%
→
Step 2
Solve z₂
→
Step 3
z₃ = ?
→
Step 4
Forward rates
In words: 101.6290 grows to 105.25 over two years, so (1 + z₂)² is the ratio of the two.
(1 + z₂)² = 105.25 ÷ 101.6290 = 1.035630
1 + z₂ = √1.035630 = 1.017659
1.77%
2-year spot rate z₂ (the 2-year YTM is 1.74%)
So what: z₂ sits 3bp above the 2-year YTM, because the YTM also averages in the lower 1-year rate.
Source: our calculation (calcs.py): 106.8409 − 5.2119 = 101.6290; 105.25 ÷ 101.6290 = 1.035630.
05 Q3 · 64

## Slide g65
Step 3: the 3-year gilt reveals a 3-year spot rate of 2.09%
Step 1
z₁ = 0.73%
→
Step 2
z₂ = 1.77%
→
Step 3
Solve z₃
→
Step 4
Forward rates
In words: the 3-year price is the PV of three payments. The first two coupons are discounted at z₁ and z₂, which we now know. Take them away; the rest belongs to z₃.
107.02 = 4.5 ÷ 1.007317 + 4.5 ÷ 1.017659² + 104.5 ÷ (1 + z₃)³
Price of the 3-year gilt = 107.0200
4.4673 + 4.3452 = 8.8125 = PV of the two coupons already priced (known)
98.2075 = PV of the year-3 payment (unknown z₃)
Source: Exhibit 1, case (3-year gilt: coupon 4.5%, price 107.02); our calculation (calcs.py).
05 Q3 · 65

## Slide g65b
Step 3, continued: £104.50 in three years is worth 98.2075 today, so z₃ = 2.09%
Step 1
z₁ = 0.73%
→
Step 2
z₂ = 1.77%
→
Step 3
Solve z₃
→
Step 4
Forward rates
In words: 98.2075 grows to 104.50 over three years, so (1 + z₃)³ is the ratio of the two.
(1 + z₃)³ = 104.5 ÷ 98.2075 = 1.064074
1 + z₃ = 1.064074^(1/3) = 1.020917
2.09%
3-year spot rate z₃ (the 3-year YTM is 2.06%)
So what: again just above the YTM; on a rising curve, spot rates sit above the yields of coupon bonds.
Source: our calculation (calcs.py): 107.02 − 4.4673 − 4.3452 = 98.2075; 104.5 ÷ 98.2075 = 1.064074.
05 Q3 · 65

## Slide g66
Step 4: the curve implies a 1-year rate of 2.81% next year, against 0.73% now
Step 1
z₁ = 0.73%
→
Step 2
z₂ = 1.77%
→
Step 3
z₃ = 2.09%
→
Step 4
Forward rates
Plain: “1y1y” = the one-year rate that starts in one year. Two years at the 2-year spot rate must earn the same as one year at the 1-year rate and then one year at the 1y1y rate.
1y1y = (1 + z₂)² ÷ (1 + z₁) − 1
1y1y = 1.017659² ÷ 1.007317 − 1 = 1.035630 ÷ 1.007317 − 1
2.81%
the rate the curve locks in for year 2
So what: you can lend for year 2 at 2.81% by lending for two years, rather than waiting.
Source: our calculation (calcs.py): 1.035630 ÷ 1.007317 = 1.028107. CFA Level I, Fixed Income.
05 Q3 · 66

## Slide g66b
Step 4, continued: and 2.75% for the year after (the 2y1y rate)
Step 1
z₁ = 0.73%
→
Step 2
z₂ = 1.77%
→
Step 3
z₃ = 2.09%
→
Step 4
Forward rates
Plain: “2y1y” = the one-year rate that starts in two years. Three years at the 3-year spot rate must earn the same as two years at the 2-year spot rate and then one year at the 2y1y rate.
2y1y = (1 + z₃)³ ÷ (1 + z₂)² − 1
2y1y = 1.020917³ ÷ 1.017659² − 1 = 1.064073 ÷ 1.035630 − 1
2.75%
the rate the curve locks in for year 3
So what: year 3 is priced at about the same rate as year 2, so the expected rise comes early.
Source: our calculation (calcs.py): 1.064073 ÷ 1.035630 = 1.027464.
05 Q3 · 66

## Slide g66c
Step 4, continued: the exhibit’s curve implies one-year rates jumping from 0.73% to about 2.8%
0.73%
Year 1
known today (z₁)
2.81%
Year 2
1y1y
2.75%
Year 3
2y1y
Check: growing 1 for year 1 at 0.73% and year 2 at 2.81% gives 1.007317 × 1.028107 = 1.035630, the same as two years at z₂ (1.017659² = 1.035630). Bars start at zero.
So what: the curve implies rates rising sharply. Caveat: this is the exhibit’s classroom curve, not the 2014 market (slide 22).
Source: our calculation (calcs.py); Exhibit 1, case.
05 Q3 · 66

## Slide g67
Hindsight test: rates did not rise; Bank Rate was cut to 0.25% in August 2016
Rate (%)
0
1
2
3
9 May 2014
May 2015
May 2016
May 2017
Years from the case date
0.73%
2.81%
2.75%
Bank Rate 0.50%
0.25% from 4 Aug 2016
Indigo: one-year rates the exhibit’s curve implies (slide 66). Black: Bank Rate as it turned out.
So what: a curve shows expectations plus a premium, not a forecast that comes true.
Sources: Bank of England Bank Rate database (04 Aug 16: 0.25%; accessed 29 Oct 2026); implied rates from slide 66. Exhibit 1 is a classroom curve (slide 22).
05 Q3 · 67

## Slide g68
Three theories explain why curves rise, and each predicts a different shape
Expectations
Long yields average the short rates expected. Rates expected to rise: the curve rises.
Liquidity preference
Lenders want extra yield for tying money up longer, so the curve rises even if rates stay put.
Segmentation
Each maturity has its own buyers and sellers, so its yield follows its own supply and demand.
Plain: term premium = the extra yield for lending longer. preferred habitat = investors who favour certain maturities and need extra yield to move; under pure segmentation they never move. Sketches are illustrative.
So what: no one theory explains the whole curve; slides 69–70 use all three.
Source: CFA Level I, Fixed Income (term structure theories).
05 Q3 · 68

## Slide g69
The steep short end fits rising rate expectations plus a term premium
Rates a lender could lock in at each horizon (%; bars start at zero):
Bank Rate, May 2014
0.50%
1-year rate today
0.73%
1-year rate in 1 year
2.81%
1-year rate in 2 years
2.75%
10-year YTM
4.04%
Expectations: with Bank Rate at 0.50%, the curve prices a jump to about 2.8% within a year (slide 66). Term premium: yields keep rising to 4.04% at 10 years even after that jump.
So what: the steep short end is consistent with both stories; the curve alone cannot say how much of each.
Sources: Bank of England Bank Rate database (0.50% from 5 Mar 2009 to 4 Aug 2016; accessed 29 Oct 2026); slides 51 and 63–66.
05 Q3 · 69

## Slide g70
The long end flattens and dips, most likely because pension funds and insurers want long gilts
YTM (%): axis starts at 4.0%
4.00
4.25
4.50
10
20
30
40
50
Years to maturity
4.04%
4.38%
4.36%
4.24%
27%
of all gilts were held by pension funds and insurers at end-March 2014 (26.6%)
They owe pensions and claims decades ahead, so they favour long gilts (preferred habitat, slide 68). Strong demand pushes long prices up and yields down.
So what: a plausible cause for the levelling and the dip, not a proven one (next slide).
Sources: DMO Annual Review 2013-14 (pension funds and insurers 26.6% of gilts, £372.7bn); Exhibit 1, case. Zoomed axis: the chart does not start at zero.
05 Q3 · 70

## Slide g70b
Long end, continued: the dip is 12bp in Exhibit 1 but only about 3bp in the real 2014 market
Fall in yield from about 30 years to about 50 years (bars start at zero):
Exhibit 1: 30y → 50y
12bp
Real, 9 May 2014: 28.6y → 45.7y
3bp (2.8)
The 50-year is thinly traded (slide 8), so it would normally need more yield; a lower yield points to strong long-end demand. Rival explanations, explained in Q4 (slides 108–110): investors pay up for long bonds’ extra price gains when rates fall, and coupon differences shift yields.
So what: the evidence is suggestive, not proof; the real dip was small: 4½% 2042 at 3.393% against 4% 2060 at 3.365%.
Sources: DMO gilt reference prices, 9 May 2014 (yields 3.393% and 3.365%); Exhibit 1, case; our calculation (calcs.py).
05 Q3 · 70

## Slide g71
Caution: this is a curve of coupon-bond yields; the spot curve sits slightly higher
0.73%
0.73%
YTM
Spot
1-year gilt
spot − YTM: +0bp
1.74%
1.77%
YTM
Spot
2-year gilt
spot − YTM: +3bp
2.06%
2.09%
YTM
Spot
3-year gilt
spot − YTM: +3bp
Bars start at zero. We bootstrapped only the first three spot rates, so the comparison stops at 3 years.
So what: the gap is only 3bp, so the YTM curve shows the shape well; the spot rate is the cleaner measure.
Source: our calculation (calcs.py); Exhibit 1, case.
05 Q3 · 71

## Slide g72
Q3 answer: a curve that rises steeply, flattens, and dips slightly at the long end
YTM (%)
0
1
2
3
4
5
0
10
20
30
40
50
Years to maturity
Rises
+331bp from 1 to 10 years: 0.73% → 4.04%
Flattens
+34bp to 20 years (4.38%), then −2bp to 30
Dips
−12bp to 4.24% at 50 years
Why
expectations plus a term premium; long-end demand
Source: Exhibit 1, case; our answers (slides 60–71, calcs.py). Spot rates z₁ 0.73%, z₂ 1.77%, z₃ 2.09%.
05 Q3 · 72

## Slide g73
06
Q4: what if every yield rises by 1%?
Nine gilts repriced, the money at risk per basis point, duration and convexity, and what it means for investors
73

## Slide g74
Q4: every yield rises by one percentage point, all at once
Plain: a parallel shift moves the whole yield curve up by the same amount at every maturity; 1% here means one percentage point, so 3.00% becomes 4.00% (100 basis points, bp). Instantaneous means no time passes, so no gilt has moved closer to repayment.
0
2
4
6
0
10
20
30
40
50
Years to maturity
Yield to maturity (%)
After: 5.24%
Before: 4.24%
↑ every yield moves up by 1.00
Real curves can also twist (short and long yields move by different amounts), which Q4 does not ask about.
Source: Exhibit 1, case; missing yields from our Q2 answers (calcs.py). Dashed = before.
06 Q4 · 74

## Slide g74b
Q4, continued: four parts, answered in this order
The question has four parts. The order below is the order of the slides that follow.
(a)
Reprice all nine gilts at yields 1% higher
slides 75–85
→
(a)
Money lost per 1bp rise (PVBP)
slides 86–95
→
(b)
Which falls most, and why? Duration
slides 96–108
(c)
How good is the estimate? Convexity
slides 109–114
→
(c)
Check with a 1% fall in yields
slides 115–124
→
(d)
What it means for investors
slides 125–126
So what: first the price changes (a), then the reason (b), how reliable it is (c), and the lesson (d).
Source: question wording, case; plan of this deck.
06 Q4 · 74b

## Slide g75
At 1.73%, the 1-year gilt falls from 102.50 to 101.49 (−0.98%)
In words: discount each payment at the new yield, 0.7317% + 1% = 1.7317%. The annuity factor (slide 44) adds all the coupons’ discounts in one number.
Price = coupon × annuity factor + 100 ÷ (1 + y)¹
= 3.25 × 0.982978 + 100 ÷ 1.017317 = 3.1947 + 98.2978 = 101.4925
101.49
per £100, down from 102.50
101.4925 ÷ 102.5000 − 1 = −0.98%
Price change, all nine (this gilt in indigo)
1y
−0.98%
2y
3y
5y
7y
10y
20y
30y
50y
So what: a tiny move for the shortest gilt: under 1% of its price is lost.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0173)⁻¹] ÷ 0.0173.
06 Q4 · 75

## Slide g76
At 2.74%, the 2-year gilt falls from 106.84 to 104.82 (−1.89%)
In words: as on slide 75, discount at the new yield, 1.74% + 1% = 2.7400%.
Price = coupon × annuity factor + 100 ÷ (1 + y)²
= 5.25 × 1.920703 + 100 ÷ 1.055551 = 10.0837 + 94.7373 = 104.8210
104.82
per £100, down from 106.84
104.8210 ÷ 106.8409 − 1 = −1.89%
Price change, all nine (this gilt in indigo)
1y
2y
−1.89%
3y
5y
7y
10y
20y
30y
50y
So what: about twice the 1-year’s fall (−1.89% vs −0.98%): its money comes back later.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0274)⁻²] ÷ 0.0274.
06 Q4 · 76

## Slide g77
At 3.06%, the 3-year gilt falls from 107.02 to 104.06 (−2.77%)
In words: as on slide 75, discount at the new yield, 2.0628% + 1% = 3.0628%.
Price = coupon × annuity factor + 100 ÷ (1 + y)³
= 4.5 × 2.825200 + 100 ÷ 1.094727 = 12.7134 + 91.3470 = 104.0604
104.06
per £100, down from 107.02
104.0604 ÷ 107.0200 − 1 = −2.77%
Price change, all nine (this gilt in indigo)
1y
2y
3y
−2.77%
5y
7y
10y
20y
30y
50y
So what: about three times the 1-year’s fall (−2.77% vs −0.98%).
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0306)⁻³] ÷ 0.0306.
06 Q4 · 77

## Slide g78
At 4.00%, the 5-year gilt falls from 98.86 to 94.44 (−4.47%)
In words: as on slide 75, discount at the new yield, 3.0000% + 1% = 4.0000%.
Price = coupon × annuity factor + 100 ÷ (1 + y)⁵
= 2.75 × 4.451822 + 100 ÷ 1.216653 = 12.2425 + 82.1927 = 94.4352
94.44
per £100, down from 98.86
94.4352 ÷ 98.8551 − 1 = −4.47%
Price change, all nine (this gilt in indigo)
1y
2y
3y
5y
−4.47%
7y
10y
20y
30y
50y
So what: about 4½ times the 1-year’s fall (−4.47% vs −0.98%).
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0400)⁻⁵] ÷ 0.0400.
06 Q4 · 78

## Slide g79
At 4.54%, the 7-year gilt falls from 108.91 to 102.70 (−5.70%)
In words: as on slide 75, discount at the new yield, 3.5406% + 1% = 4.5406%.
Price = coupon × annuity factor + 100 ÷ (1 + y)⁷
= 5.0 × 5.883956 + 100 ÷ 1.364567 = 29.4198 + 73.2833 = 102.7031
102.70
per £100, down from 108.91
102.7031 ÷ 108.9100 − 1 = −5.70%
Price change, all nine (this gilt in indigo)
1y
2y
3y
5y
7y
−5.70%
10y
20y
30y
50y
So what: 5.8 times the 1-year’s fall, not 7: the 5% coupon returns money early.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0454)⁻⁷] ÷ 0.0454.
06 Q4 · 79

## Slide g80
At 5.04%, the 10-year gilt falls from 97.65 to 90.06 (−7.78%)
In words: as on slide 75, discount at the new yield, 4.04% + 1% = 5.0400%.
Price = coupon × annuity factor + 100 ÷ (1 + y)¹⁰
= 3.75 × 7.706757 + 100 ÷ 1.635111 = 28.9003 + 61.1579 = 90.0582
90.06
per £100, down from 97.65
90.0582 ÷ 97.6525 − 1 = −7.78%
Price change, all nine (this gilt in indigo)
1y
2y
3y
5y
7y
10y
−7.78%
20y
30y
50y
So what: the 10-year loses about 8 times what the 1-year loses (−0.98%).
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0504)⁻¹⁰] ÷ 0.0504.
06 Q4 · 80

## Slide g81
At 5.38%, the 20-year gilt falls from 104.93 to 92.45 (−11.89%)
In words: as on slide 75, discount at the new yield, 4.3751% + 1% = 5.3751%.
Price = coupon × annuity factor + 100 ÷ (1 + y)²⁰
= 4.75 × 12.075203 + 100 ÷ 2.849443 = 57.3572 + 35.0946 = 92.4518
92.45
per £100, down from 104.93
92.4518 ÷ 104.9300 − 1 = −11.89%
Price change, all nine (this gilt in indigo)
1y
2y
3y
5y
7y
10y
20y
−11.89%
30y
50y
So what: about 12 times the 1-year’s fall (−0.98%).
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0538)⁻²⁰] ÷ 0.0538.
06 Q4 · 81

## Slide g82
At 5.36%, the 30-year gilt falls from 102.32 to 87.31 (−14.67%)
In words: as on slide 75, discount at the new yield, 4.36% + 1% = 5.3600%.
Price = coupon × annuity factor + 100 ÷ (1 + y)³⁰
= 4.5 × 14.761224 + 100 ÷ 4.789309 = 66.4255 + 20.8798 = 87.3053
87.31
per £100, down from 102.32
87.3053 ÷ 102.3185 − 1 = −14.67%
Price change, all nine (this gilt in indigo)
1y
2y
3y
5y
7y
10y
20y
30y
−14.67%
50y
So what: growth slows: +2.78 points of fall (20 to 30 years), +3.07 over twice as long (30 to 50).
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0536)⁻³⁰] ÷ 0.0536.
06 Q4 · 82

## Slide g83
At 5.24%, the 50-year gilt falls from 94.96 to 78.11 (−17.74%)
In words: as on slide 75, discount at the new yield, 4.2445% + 1% = 5.2445%.
Price = coupon × annuity factor + 100 ÷ (1 + y)⁵⁰
= 4.0 × 17.587377 + 100 ÷ 12.881619 = 70.3495 + 7.7630 = 78.1125
78.11
per £100, down from 94.96
78.1125 ÷ 94.9600 − 1 = −17.74%
Price change, all nine (this gilt in indigo)
1y
2y
3y
5y
7y
10y
20y
30y
50y
−17.74%
So what: the longest gilt loses 18 times as much as the shortest (−17.74% vs −0.98%).
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1.0524)⁻⁵⁰] ÷ 0.0524.
06 Q4 · 83

## Slide g84
All nine together: the longer the gilt, the bigger the fall
Gilt
Yield, %
Price, £ per 100
Price change (bars hang left from 0%)
1y
0.73 → 1.73
102.50 → 101.49
−0.98%
2y
1.74 → 2.74
106.84 → 104.82
−1.89%
3y
2.06 → 3.06
107.02 → 104.06
−2.77%
5y
3.00 → 4.00
98.86 → 94.44
−4.47%
7y
3.54 → 4.54
108.91 → 102.70
−5.70%
10y
4.04 → 5.04
97.65 → 90.06
−7.78%
20y
4.38 → 5.38
104.93 → 92.45
−11.89%
30y
4.36 → 5.36
102.32 → 87.31
−14.67%
50y
4.24 → 5.24
94.96 → 78.11
−17.74%
So what: each longer gilt falls further than the one before it. The reason is how late its money arrives, which duration measures (slides 96–108).
Source: slides 75–83; yields from Exhibit 1 and our Q2 answers (calcs.py). Bars start at 0%.
06 Q4 · 84

## Slide g84b
On the price–yield curve, 1% costs the 50-year gilt the most
Each line is one gilt’s price (today = 100) as all yields move; dots mark today and the +1% case.
70
80
90
100
110
120
130
−1
−0.5
0.0
+0.5
+1
Change in every yield (percentage points)
Price, today = 100 (axis starts at 70)
1-year −0.98%
10-year −7.78%
50-year −17.74%
today
+24.86%
+8.59%
+1.00%
So what: the 50-year line is steeper and bends: a 1% fall adds 24.86%, a 1% rise takes off 17.74%.
Source: our calculation (calcs.py) from Exhibit 1 and our Q2 yields.
06 Q4 · 84b

## Slide g85
In money: on £100m of each gilt, a 1% rise costs £1.0m (1-year) to £16.8m (50-year)
Plain: £100m of face is 1,000,000 units of £100, so a price of 102.50 per £100 means £102.5m.
Gilt
Now, £m
After, £m
Change, £m
To 1 dp, £m (bars hang left from 0)
1y
102.5000
101.4925
−1.0075
−1.0
2y
106.8409
104.8210
−2.0199
−2.0
3y
107.0200
104.0604
−2.9596
−3.0
5y
98.8551
94.4352
−4.4199
−4.4
7y
108.9100
102.7031
−6.2069
−6.2
10y
97.6525
90.0582
−7.5943
−7.6
20y
104.9300
92.4518
−12.4782
−12.5
30y
102.3185
87.3053
−15.0132
−15.0
50y
94.9600
78.1125
−16.8475
−16.8
So what: a trading desk watches this number: £16.8m lost on the 50-year, £1.0m on the 1-year.
Source: prices of slides 75–83 and Exhibit 1 (calcs.py). £m on £100m face. Bars start at 0.
06 Q4 · 85

## Slide g86
PVBP: the 50-year gilt loses about £197.7 thousand per £100m for every 1bp rise
Plain: PVBP (price value of a basis point) is the money lost when the yield rises by 0.01%, one basis point (1bp). A desk hedges by taking an opposite position that gains what the gilts lose.
In words: reprice the gilt at a yield 1bp lower and at a yield 1bp higher, and take half the gap between the two prices.
4.2345%
95.1580
1bp lower
4.2445%
94.9600
today
4.2545%
94.7626
1bp higher
price
yield
So what: pricing on both sides of today’s yield gives a fair cost for one basis point.
Source: our calculation (calcs.py); exact yield 4.244519% (slide 53) ± 0.01%.
06 Q4 · 86

## Slide g86b
PVBP, continued: half the gap is £197.7 thousand per £100m
In words: price 1bp lower minus price 1bp higher, halved; then scale from £100 to £100m.
PVBP = [P(y − 1bp) − P(y + 1bp)] ÷ 2
(95.1580 − 94.7626) ÷ 2 = 0.3954 ÷ 2 = 0.1977 per £100
197.7
£ thousand lost per £100m for each 1bp rise
0.1977 × 1,000,000 = £197,700
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
5y
7y
10y
20y
30y
50y
−197.7
So what: £100m of the 50-year loses about £0.2m per basis point; a desk hedges that amount.
Source: our calculation (calcs.py) from Exhibit 1. £100m face = 1,000,000 units of £100.
06 Q4 · 86b

## Slide g87
1-year PVBP: £10.2 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 0.7317% and take half the gap.
(102.5102 − 102.4898) ÷ 2 = 0.0204 ÷ 2 = 0.0102 per £100
10.2
£ thousand lost per £100m for each 1bp rise
0.0102 × 1,000,000 = £10,200
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
−10.2
2y
3y
5y
7y
10y
20y
30y
50y
So what: almost no rate risk: 1bp costs about £10,000 on £100m.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 0.7217% and 0.7417%, 1bp either side of 0.7317%.
06 Q4 · 87

## Slide g88
2-year PVBP: £20.5 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 1.7400% and take half the gap.
(106.8614 − 106.8204) ÷ 2 = 0.0410 ÷ 2 = 0.0205 per £100
20.5
£ thousand lost per £100m for each 1bp rise
0.0205 × 1,000,000 = £20,500
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
−20.5
3y
5y
7y
10y
20y
30y
50y
So what: twice the 1-year’s £10.2 thousand.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 1.7300% and 1.7500%, 1bp either side of 1.7400%.
06 Q4 · 88

## Slide g89
3-year PVBP: £30.2 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 2.0628% and take half the gap.
(107.0502 − 106.9898) ÷ 2 = 0.0604 ÷ 2 = 0.0302 per £100
30.2
£ thousand lost per £100m for each 1bp rise
0.0302 × 1,000,000 = £30,200
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
−30.2
5y
7y
10y
20y
30y
50y
So what: about three times the 1-year’s £10.2 thousand.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 2.0528% and 2.0728%, 1bp either side of 2.0628%.
06 Q4 · 89

## Slide g90
5-year PVBP: £45.5 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 3.0000% and take half the gap.
(98.9006 − 98.8096) ÷ 2 = 0.0910 ÷ 2 = 0.0455 per £100
45.5
£ thousand lost per £100m for each 1bp rise
0.0455 × 1,000,000 = £45,500
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
5y
−45.5
7y
10y
20y
30y
50y
So what: about 4½ times the 1-year’s £10.2 thousand.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 2.9900% and 3.0100%, 1bp either side of 3.0000%.
06 Q4 · 90

## Slide g91
7-year PVBP: £64.4 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 3.5406% and take half the gap.
(108.9744 − 108.8456) ÷ 2 = 0.1288 ÷ 2 = 0.0644 per £100
64.4
£ thousand lost per £100m for each 1bp rise
0.0644 × 1,000,000 = £64,400
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
5y
7y
−64.4
10y
20y
30y
50y
So what: 6.3 times the 1-year, below 7: the high coupon returns money early.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 3.5306% and 3.5506%, 1bp either side of 3.5406%.
06 Q4 · 91

## Slide g92
10-year PVBP: £79.8 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 4.0400% and take half the gap.
(97.7323 − 97.5728) ÷ 2 = 0.1595 ÷ 2 = 0.07975 ≈ 0.0798 per £100
79.8
£ thousand lost per £100m for each 1bp rise
0.0798 × 1,000,000 = £79,800
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
5y
7y
10y
−79.8
20y
30y
50y
So what: about 8 times the 1-year’s £10.2 thousand.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 4.0300% and 4.0500%, 1bp either side of 4.0400%.
06 Q4 · 92

## Slide g93
20-year PVBP: £135.8 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 4.3751% and take half the gap.
(105.0659 − 104.7943) ÷ 2 = 0.2716 ÷ 2 = 0.1358 per £100
135.8
£ thousand lost per £100m for each 1bp rise
0.1358 × 1,000,000 = £135,800
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
5y
7y
10y
20y
−135.8
30y
50y
So what: 13 times the 1-year’s £10.2 thousand.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 4.3651% and 4.3851%, 1bp either side of 4.3751%.
06 Q4 · 93

## Slide g94
30-year PVBP: £168.4 thousand per £100m
In words: as on slide 86, reprice 1bp either side of today’s 4.3600% and take half the gap.
(102.4870 − 102.1503) ÷ 2 = 0.3367 ÷ 2 = 0.16835 ≈ 0.1684 per £100
168.4
£ thousand lost per £100m for each 1bp rise
0.1684 × 1,000,000 = £168,400
Loss per 1bp rise, £ thousand per £100m (this gilt in indigo)
1y
2y
3y
5y
7y
10y
20y
30y
−168.4
50y
So what: still rising, but more slowly: 30 to 50 years adds only £29.3 thousand.
Source: our calculation (calcs.py) from Exhibit 1. Prices at 4.3500% and 4.3700%, 1bp either side of 4.3600%.
06 Q4 · 94

## Slide g95
PVBP rises from £10.2 thousand to £197.7 thousand per £100m: 19 times from shortest to longest
Gilt
PVBP per £100
£ thousand per £100m (bars hang left from 0)
1y
0.0102
−10.2
2y
0.0205
−20.5
3y
0.0302
−30.2
5y
0.0455
−45.5
7y
0.0644
−64.4
10y
0.0798
−79.8
20y
0.1358
−135.8
30y
0.1684
−168.4
50y
0.1977
−197.7
So what: a £100m position in the 50-year needs about 19 times the hedge of a £100m position in the 1-year.
Source: slides 86–94 (calcs.py). £100m face. Bars start at 0; shortest and longest in indigo.
06 Q4 · 95

## Slide g96
Duration measures how long, on average, you wait for a bond’s money
Plain: Macaulay duration is the average time until a bond pays you, where each payment counts in proportion to its present value (PV, what it is worth today). A coupon of £2.67 in year 1 counts little; the £88.63 due in year 5 counts a lot.
2.67
1
2.59
2
2.52
3
2.44
4
88.63
5
balance point: 4.74 years
year
So what: this gilt pays most of its value in year 5, so the balance point sits near it, at 4.74 years.
Source: our calculation (calcs.py): 5-year 2.75% gilt at 3.00% (slides 41–43). Labels: PV in £.
06 Q4 · 96

## Slide g97
The 5-year gilt: Macaulay duration 4.74 years
In words: weight each year by its share of the price (PV ÷ 98.8551), multiply the year by its weight, and add up.
Duration = Σ t × (PV ÷ price)
Year t
Cash flow
PV
Weight
t × weight
1
2.75
2.6699
0.027008
0.027008
2
2.75
2.5921
0.026221
0.052442
3
2.75
2.5166
0.025457
0.076371
4
2.75
2.4433
0.024716
0.098864
5
102.75
88.6331
0.896596
4.482980
Sum (rows rounded)
98.8551
1.000000
4.7377
4.74
years
4.7377 rounded
So what: 90% of the value arrives in year 5, so the duration is close to the 5-year maturity.
Source: our calculation (calcs.py): 2.75% coupon, yield 3.00%, per £100 (PVs: slide 42).
06 Q4 · 97

## Slide g98
Modified duration turns waiting time into price sensitivity: 4.60% per 1% of yield
Plain: modified duration is the % price change for a 1% change in yield; Δy is the change in yield.
Modified duration = Macaulay ÷ (1 + y);  %ΔP ≈ −modified × Δy
= 4.74 ÷ 1.0300 = 4.60;  %ΔP ≈ −4.60 × 1% = −4.60%
4.60
% fall in price per 1% rise in yield
CFA Level 1, Fixed Income, LM11
Estimate vs actual change (slide 78)
Estimate
−4.60%
Actual
−4.47%
So what: the estimate is 0.13 points too big (−4.60% vs −4.47%), close enough to use.
Source: our calculation (calcs.py); CFA Level 1 curriculum, Fixed Income (yield-based duration measures, LM11).
06 Q4 · 98

## Slide g99
The 1-year gilt: duration 1.00 year, modified 0.99
In words: add up year × PV, then divide by the price. One payment, so there is only one term.
Year t
Cash flow
PV
t × PV
1
103.25
102.5000
102.5000
Sum
102.5000
102.5000
102.50
1
balance point: 1.00 year
year
1.00
102.5000 ÷ 102.5000 = 1.00 yearmodified: 1.00 ÷ 1.0073 = 0.99
So what: one payment, so duration equals maturity.
Source: our calculation (calcs.py) from Exhibit 1. 3.25% coupon, yield 0.7317%, per £100.
06 Q4 · 99

## Slide g100
The 2-year gilt: duration 1.95, modified 1.92
In words: add up year × PV, then divide by the price (the sum of the PVs).
Year t
Cash flow
PV
t × PV
1
5.25
5.1602
5.1602
2
105.25
101.6807
203.3614
Sum
106.8409
208.5216
5.16
1
101.68
2
balance point: 1.95 years
year
1.95
208.5216 ÷ 106.8409 = 1.95 yearsmodified: 1.95 ÷ 1.0174 = 1.92
So what: just under the 2-year maturity, because the early coupon pulls the average wait down.
Source: our calculation (calcs.py) from Exhibit 1. 5.25% coupon, yield 1.74%, per £100.
06 Q4 · 100

## Slide g101
The 3-year gilt: duration 2.88 years, modified 2.82
In words: weight each year t by its share of the price (PV ÷ price) and add up. Modified = Macaulay ÷ (1 + y).
t | Cash flow | PV | t × PV |
1 | 4.50 | 4.4090 | 4.4090 |
2 | 4.50 | 4.3199 | 8.6399 |
3 | 104.50 | 98.2910 | 294.8730 |
Sum |  | 107.0199 | 307.9219 |
4%
1
4%
2
92%
3
balance point: 2.88 years
2.82
modified duration307.92 ÷ 107.02 = 2.88 years; 2.88 ÷ 1.0206 = 2.82
So what: 92% of the price arrives in year 3, so the average wait is 2.88 years, just under 3.
Source: our calculation (calcs.py) from Exhibit 1. PV = cash flow ÷ 1.0206ᵗ; PVs add to 107.0199, the price is 107.02 (rows rounded). Bars: share of price.
06 Q4 · 101

## Slide g102
For longer gilts a CFA shortcut gives duration in one line: the 7-year’s is 6.12
Plain: closed-form formula = a ready-made formula that gives the same answer as adding t × PV for every payment, so no table is needed.
c = 0.0500 (coupon rate), y = 0.03540609 (exact yield, slide 51), N = 7 (years to repayment).
Macaulay = (1 + y) ÷ y − [(1 + y) + N(c − y)] ÷ [c((1 + y)ᴺ − 1) + y]
(1 + y) ÷ y = 1.03540609 ÷ 0.03540609 = 29.2437
(1 + y)⁷ = 1.03540609⁷ = 1.275778
top = (1 + y) + N(c − y) = 1.03540609 + 7 × (0.0500 − 0.03540609) = 1.137563
bottom = c((1 + y)⁷ − 1) + y = 0.0500 × (1.275778 − 1) + 0.03540609 = 0.049195
Macaulay = 29.2437 − 1.137563 ÷ 0.049195 = 29.2437 − 23.1235 ≈ 6.12 years
So what: the long way agrees: Σ(t × PV) ÷ price = 666.55 ÷ 108.91 = 6.12, so for long gilts the table can be skipped.
Source: our calculation (calcs.py) from Exhibit 1. Formula: CFA Level I, Fixed Income (Macaulay duration, annual coupons).
06 Q4 · 102

## Slide g102b
The 7-year gilt: modified duration 5.91, so −5.91% for a 1% rise
In words: modified duration = Macaulay ÷ (1 + y); the price change is about −modified duration × the change in yield.
Modified = 6.12 ÷ 1.0354 = 5.91;  price change ≈ −5.91 × 1% = −5.91%
5.91
modified durationduration predicts −5.91%, actual −5.70% (slide 79)
Duration
−5.91%
Actual
−5.70%
So what: duration overshoots by 0.21 points (5.91 vs 5.70): a slightly gloomy guess.
Source: our calculation (calcs.py) from Exhibit 1. Bars start at zero and show the size of the fall; negative values go left.
06 Q4 · 102

## Slide g103
The 10-year gilt: duration 8.50, modified 8.17
(1 + y) ÷ y = 1.0404 ÷ 0.0404 = 25.7525
(1 + y)¹⁰ = 1.0404¹⁰ = 1.485947
top = (1 + y) + N(c − y) = 1.0404 + 10 × (0.0375 − 0.0404) = 1.011400
bottom = c((1 + y)¹⁰ − 1) + y = 0.0375 × (1.485947 − 1) + 0.0404 = 0.058623
Macaulay = 25.7525 − 1.011400 ÷ 0.058623 = 25.7525 − 17.2526 = 8.50 years
8.17
modified duration8.50 ÷ 1.0404 = 8.17
Duration
−8.17%
Actual
−7.78%
So what: a 1% rise should cost about 8.2%; the actual fall is 7.78% (slide 80), 0.39 points less.
Source: our calculation (calcs.py) from Exhibit 1. Same formula as slide 102; c = 0.0375, N = 10, y = 4.04%, given. Bars start at zero; falls go left.
06 Q4 · 103

## Slide g104
The 20-year gilt: duration 13.51, modified 12.94
(1 + y) ÷ y = 1.04375092 ÷ 0.04375092 = 23.8567
(1 + y)²⁰ = 1.04375092²⁰ = 2.354710
top = (1 + y) + N(c − y) = 1.04375092 + 20 × (0.0475 − 0.04375092) = 1.118733
bottom = c((1 + y)²⁰ − 1) + y = 0.0475 × (2.354710 − 1) + 0.04375092 = 0.108100
Macaulay = 23.8567 − 1.118733 ÷ 0.108100 = 23.8567 − 10.3491 = 13.51 years
12.94
modified duration13.51 ÷ 1.0438 = 12.94
Duration
−12.94%
Actual
−11.89%
So what: a 1% rise should cost about 12.9%; the actual fall is 11.89% (slide 81), 1.05 points less.
Source: our calculation (calcs.py) from Exhibit 1. Same formula as slide 102; c = 0.0475, N = 20, exact y = 4.375092%, slide 52. Bars start at zero; falls go left.
06 Q4 · 104

## Slide g105
The 30-year gilt: duration 17.17, modified 16.45
(1 + y) ÷ y = 1.0436 ÷ 0.0436 = 23.9358
(1 + y)³⁰ = 1.0436³⁰ = 3.597677
top = (1 + y) + N(c − y) = 1.0436 + 30 × (0.0450 − 0.0436) = 1.085600
bottom = c((1 + y)³⁰ − 1) + y = 0.0450 × (3.597677 − 1) + 0.0436 = 0.160495
Macaulay = 23.9358 − 1.085600 ÷ 0.160495 = 23.9358 − 6.7641 = 17.17 years
16.45
modified duration17.17 ÷ 1.0436 = 16.45
Duration
−16.45%
Actual
−14.67%
So what: a 1% rise should cost about 16.5%; the actual fall is 14.67% (slide 82), 1.78 points less.
Source: our calculation (calcs.py) from Exhibit 1. Same formula as slide 102; c = 0.0450, N = 30, y = 4.36%, given. Bars start at zero; falls go left.
06 Q4 · 105

## Slide g106
The 50-year gilt: duration 21.70, modified 20.82
(1 + y) ÷ y = 1.04244519 ÷ 0.04244519 = 24.5598
(1 + y)⁵⁰ = 1.04244519⁵⁰ = 7.992111
top = (1 + y) + N(c − y) = 1.04244519 + 50 × (0.0400 − 0.04244519) = 0.920186
bottom = c((1 + y)⁵⁰ − 1) + y = 0.0400 × (7.992111 − 1) + 0.04244519 = 0.322130
Macaulay = 24.5598 − 0.920186 ÷ 0.322130 = 24.5598 − 2.8566 = 21.70 years
20.82
modified duration21.70 ÷ 1.0424 = 20.82
Duration
−20.82%
Actual
−17.74%
So what: duration forecasts a 20.82% fall; the actual fall is 17.74% (slide 83), 3.08 points less.
Source: our calculation (calcs.py) from Exhibit 1. Same formula as slide 102; c = 0.0400, N = 50, exact y = 4.244519%, slide 53. Bars start at zero; falls go left.
06 Q4 · 106

## Slide g106b
Why the 50-year acts like a 22-year loan: only 14% of its value is the final £104
0
10
20
30
40
50
average wait: 21.70 years
repayment: year 50
Years from today. The 50-year gilt’s money arrives on average after 21.70 years.
Where the 94.96 comes from (share of the price, PV ÷ price):
86%: the 49 earlier £4 coupons
14%
So what: the last payment’s PV is 104 ÷ 1.0424⁵⁰ ≈ 13.0 of 94.96, a weight of 0.137, so most of the value arrives much sooner than year 50.
Source: our calculation (calcs.py); y = exact 4.244519% (slide 53). Dark block = final £104 (£4 coupon + £100).
06 Q4 · 106

## Slide g107
Modified duration ranks the risk from 0.99 (1-year) to 20.82 (50-year)
Macaulay = average wait in years; modified = % price change per 1-point change in yield.
Gilt
Macaulay
Modified
Modified duration, bars from zero
1-year
1.00
0.99
2-year
1.95
1.92
3-year
2.88
2.82
5-year
4.74
4.60
7-year
6.12
5.91
10-year
8.50
8.17
20-year
13.51
12.94
30-year
17.17
16.45
50-year
21.70
20.82
So what: the same order as the actual falls on slides 75–83.
Source: our calculation (calcs.py) from Exhibit 1. Slides 99–106.
06 Q4 · 107

## Slide g108
Same maturity, lower coupon, more risk
In words: price three made-up 10-year gilts at 4.04% and at 5.04%: price = coupon × annuity factor + PV of the £100.
Yield 4.04%
Coupon | C × 8.094769 | + PV of 100 | = Price |
0% | 0.0000 | 67.2971 | 67.2971 |
3.75% | 30.3554 | 67.2971 | 97.6525 |
8% | 64.7582 | 67.2971 | 132.0553 |
Yield 5.04% (+1%)
Coupon | C × 7.706757 | + PV of 100 | = Price |
0% | 0.0000 | 61.1579 | 61.1579 |
3.75% | 28.9003 | 61.1579 | 90.0582 |
8% | 61.6541 | 61.1579 | 122.8120 |
0% coupon: 61.1579 ÷ 67.2971 − 1 = −9.12%
3.75% coupon: 90.0582 ÷ 97.6525 − 1 = −7.78%
8% coupon: 122.8120 ÷ 132.0553 − 1 = −7.00%
So what: the 0% gilt loses 9.12% and the 8% gilt 7.00% from the same 1% rise.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻¹⁰] ÷ y; PV of 100 = 100 ÷ (1 + y)¹⁰ (as slide 46). Hypothetical gilts.
06 Q4 · 108

## Slide g108b
The lower the coupon, the bigger the fall: duration 9.61 at 0%, 7.34 at 8%
Plain: coupon effect = a lower coupon pushes more of the gilt’s value into the final £100, which is paid later, so the price reacts more to yields.
0% coupon
−9.12%  (duration 9.61)
3.75% coupon
−7.78%  (duration 8.17)
8% coupon
−7.00%  (duration 7.34)
So what: less coupon means later cash, a higher modified duration and a bigger price swing, at the same maturity and yield.
Source: our calculation (calcs.py) from Exhibit 1. Bars start at zero; falls go left. Modified duration (calcs.py): 9.61, 8.17, 7.34.
06 Q4 · 108

## Slide g108c
A real pair shows the coupon effect: duration 26.75 for the 0½% 2061, 15.73 for the 4% 2060
0½% 2061
26.75
4% 2060
15.73
£23.41
price today of the 0½% 2061 (the 4% 2060: £75.28)
21 months
the 0½% gilt (22 Oct 2061) matures 21 months after the 4% (22 Jan 2060)
So what: 21 months longer, yet a modified duration 70% higher (26.75 vs 15.73), because the coupon is so low.
Source (secondary): giltsyield.com, prices of 28 Oct 2026; modified duration is the site’s own calculation. Bars start at zero.
06 Q4 · 108

## Slide g109
For long gilts, duration overstates the fall: −20.82% predicted vs −17.74% actual
Gilt
Duration
Actual
Duration too high by (points), bars from zero
1-year
−0.99%
−0.98%
0.01
2-year
−1.92%
−1.89%
0.03
3-year
−2.82%
−2.77%
0.05
5-year
−4.60%
−4.47%
0.13
7-year
−5.91%
−5.70%
0.21
10-year
−8.17%
−7.78%
0.39
20-year
−12.94%
−11.89%
1.05
30-year
−16.45%
−14.67%
1.78
50-year
−20.82%
−17.74%
3.08
So what: the miss grows with maturity, 0.01 points (1-year) to 3.08 (50-year).
Source: our calculation (calcs.py) from Exhibit 1. Duration = −modified duration × 1% (slide 107); actual = repricing (slides 75–83).
06 Q4 · 109

## Slide g110
Convexity: prices fall less than a straight line predicts
Plain: convexity = how much the price–yield line bends. Duration is the straight line that just touches the curve at today’s yield (50-year gilt shown).
80
100
120
3%
4%
5%
Yield to maturity (price axis starts at 65)
Price per £100
94.96 at 4.24%
curve 118.57
line 114.73
curve 78.11
line 75.19
- - -  straight line (duration alone)
━━━  actual price (the curve)
Yield +1%: line 75.19, curve 78.11, which is 2.92 higher.
Yield −1%: line 114.73, curve 118.57, which is 3.84 higher.
So what: the curve lies above the line on both sides, so convexity always helps the holder.
Source: our calculation (calcs.py) from Exhibit 1. Line = 94.96 × (1 − 20.82% per 1% × change in yield). Curve = repricing (slides 83, 115).
06 Q4 · 110

## Slide g111
Convexity of the 10-year gilt: first the table
In words: multiply each payment’s PV by t × (t + 1), so late payments count most. Convexity = Σ[t(t+1) × PV] ÷ [P × (1 + y)²].
t | Cash flow | PV | t(t+1) × PV |
1 | 3.75 | 3.6044 | 7.21 |
2 | 3.75 | 3.4644 | 20.79 |
3 | 3.75 | 3.3299 | 39.96 |
4 | 3.75 | 3.2006 | 64.01 |
5 | 3.75 | 3.0763 | 92.29 |
t | Cash flow | PV | t(t+1) × PV |
6 | 3.75 | 2.9568 | 124.19 |
7 | 3.75 | 2.8420 | 159.15 |
8 | 3.75 | 2.7317 | 196.68 |
9 | 3.75 | 2.6256 | 236.30 |
10 | 103.75 | 69.8208 | 7,680.29 |
Σ t(t+1) × PV = 7.21 + 20.79 + … + 236.30 + 7,680.29 = 8,620.87   (rows rounded)
So what: year 10 supplies almost all of the total: its weight t(t+1) = 110 is the largest and it holds the £103.75.
Source: our calculation (calcs.py) from Exhibit 1. PV = cash flow ÷ 1.0404ᵗ at y = 4.04% (slide 46). Formula: CFA Level I, Fixed Income.
06 Q4 · 111

## Slide g111b
10-year convexity: 81.56, 89% of it from the last payment
Convexity = 8,620.87 ÷ (97.65 × 1.0824) = 8,620.87 ÷ 105.70 = 81.56
t(t+1) × PV by year t (whole numbers; bars start at zero). 1.0824 = 1.0404², that is (1 + y)².
7
1
21
2
40
3
64
4
92
5
124
6
159
7
197
8
236
9
7,680
10
So what: the 10-year bends only a little: convexity adds back just 0.41% on a 1% rise (slide 113).
Source: our calculation (calcs.py) from Exhibit 1. Horizontal: year t. Vertical: t(t+1) × PV.
06 Q4 · 111

## Slide g112
50-year convexity is 701, almost nine times the 10-year’s
In words: a 50-row table would not fit, so reprice the gilt at yields 0.05% lower and higher. The extent to which the two prices together beat twice today’s price measures the bend.
Convexity = (P₋ + P₊ − 2 × P₀) ÷ (P₀ × Δy²), with Δy = 0.0005
P₋ at 4.194519% = 95.956890;  P₊ at 4.294519% = 93.979753;  P₀ = 94.960000
95.956890 + 93.979753 − 2 × 94.960000 = 0.016643
701
0.016643 ÷ (94.96 × 0.0005² = 0.00002374) = 701.05the cash-flow formula gives 701.03, the figure we use
10-year
81.56
50-year
701.03
So what: the 50-year bends almost nine times as much as the 10-year (701.03 ÷ 81.56 = 8.6).
Source: our calculation (calcs.py) from Exhibit 1. Method: CFA Level I price-based convexity. Bars start at zero.
06 Q4 · 112

## Slide g113
Duration plus convexity: −7.76% vs −7.78% actual (10-year)
In words: start from the duration estimate and add the credit for the bend: half the convexity times the yield change squared.
%ΔP ≈ −modified duration × Δy + ½ × convexity × (Δy)²
= −8.17 × 1% + ½ × 81.56 × (1%)² = −8.17% + 0.41% = −7.76%
Duration only
−8.17%
Duration + convexity
−7.76%
Actual (slide 80)
−7.78%
So what: adding convexity brings the estimate to within 0.02 points of the actual fall (7.78 − 7.76).
Source: our calculation (calcs.py) from Exhibit 1. Bars start at zero and show the size of the fall; negative values go left.
06 Q4 · 113

## Slide g114
For the 50-year, duration plus convexity overshoots: −17.31% vs −17.74% actual
%ΔP ≈ −20.82% + ½ × 701.03 × (1%)² = −20.82% + 3.51% = −17.31%
Duration only
−20.82%
Duration + convexity
−17.31%
Actual (slide 83)
−17.74%
Plain: a 1% move is large for a 50-year gilt. The price curve flattens as yields rise, so the convexity term over-credits the bend for a big rise (the 10-year overshoots too, by 0.02, slide 113).
So what: convexity adds back 3.51 points, more than the 3.08-point miss, so the estimate now understates the fall by 0.43 points (17.74 − 17.31).
Source: our calculation (calcs.py) from Exhibit 1. Bars start at zero and show the size of the fall; negative values go left.
06 Q4 · 114

## Slide g114b
Cross-check: prices at ±1% give 21.30 and 711.82, which reproduce −17.74% exactly
Plain: approximate duration and convexity = the same two measures, built from the prices after a 1% fall and a 1% rise instead of from cash-flow formulas.
Prices at the exact yield ∓ 1% (3.244519%, 5.244519%): 118.5672 and 78.1122. Slides 115 and 83 use 4-dp yields and show 118.57 and 78.11.
Duration = (118.5672 − 78.1122) ÷ (2 × 94.96 × 0.01) = 40.4550 ÷ 1.8992 = 21.30
Convexity = (118.5672 + 78.1122 − 2 × 94.96) ÷ (94.96 × 0.01²) = 6.7594 ÷ 0.009496 = 711.82
−21.30% + ½ × 711.82 × (1%)² = −21.30% + 3.56% = −17.74%
So what: it matches the actual fall only because it is built from the actual prices: a check on slides 83 and 115, not a forecast.
Source: our calculation (calcs.py) from Exhibit 1. Method: CFA Level I approximate duration and convexity.
06 Q4 · 114

## Slide g115
Falling yields help more than rising yields hurt: +24.86% vs −17.74% on the 50-year
In words: reprice the 50-year gilt at a yield 1 point lower, 4.2445% − 1% = 3.2445%, with the same formula as the +1% case (slide 83).
Price = coupon × annuity factor + 100 ÷ (1 + y)⁵⁰
= 4.00 × 24.576771 + 100 ÷ 4.935672 = 98.3071 + 20.2607 = 118.5678
118.57
per £100, up from 94.96118.5678 ÷ 94.9600 − 1 = +24.86%
−17.74% (yields +1%)
+24.86% (yields −1%)
So what: convexity is good for the holder: the same 1% move gains 24.86% when yields fall and loses 17.74% when they rise, 7.12 points apart.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 3.2445%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 115

## Slide g116
If yields fell 1%, the 1-year would gain only 1.00%, to 103.53
In words: discount £3.25 a year and the final £100 at the new yield: 0.7317% − 1% = −0.2683%.
Price = coupon × annuity factor + 100 ÷ (1 + y)¹
= 3.25 × 1.002690 + 100 ÷ 0.997317 = 3.2587 + 100.2690 = 103.5277
Plain: a negative yield means buyers pay more than they will get back; the price formula still works.
103.53
per £100, up from 102.50103.5277 ÷ 102.5000 − 1 = +1.00%
−0.98% (yields +1%)
+1.00% (yields −1%)
So what: gain (+1.00%) and loss (−0.98%) are almost equal for a short gilt.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = −0.2683%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 116

## Slide g117
If yields fell 1%, the 2-year would gain 1.95%, to 108.92
In words: discount £5.25 a year and the final £100 at the new yield: 1.7400% − 1% = 0.7400%.
Price = coupon × annuity factor + 100 ÷ (1 + y)²
= 5.25 × 1.978017 + 100 ÷ 1.014855 = 10.3846 + 98.5362 = 108.9208
108.92
per £100, up from 106.84108.9208 ÷ 106.8409 − 1 = +1.95%
−1.89% (yields +1%)
+1.95% (yields −1%)
So what: +1.95% against −1.89%: the first small gap appears, 0.06 points.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 0.7400%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 117

## Slide g118
If yields fell 1%, the 3-year would gain 2.87%, to 110.10
In words: discount £4.50 a year and the final £100 at the new yield: 2.0628% − 1% = 1.0628%.
Price = coupon × annuity factor + 100 ÷ (1 + y)³
= 4.50 × 2.937344 + 100 ÷ 1.032224 = 13.2180 + 96.8782 = 110.0962
110.10
per £100, up from 107.02110.0962 ÷ 107.0200 − 1 = +2.87%
−2.77% (yields +1%)
+2.87% (yields −1%)
So what: +2.87% against −2.77%: a fall in yields now helps 0.10 points more than a rise hurts.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 1.0628%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 118

## Slide g119
If yields fell 1%, the 5-year would gain 4.73%, to 103.54
In words: discount £2.75 a year and the final £100 at the new yield: 3.0000% − 1% = 2.0000%.
Price = coupon × annuity factor + 100 ÷ (1 + y)⁵
= 2.75 × 4.713460 + 100 ÷ 1.104081 = 12.9620 + 90.5731 = 103.5351
103.54
per £100, up from 98.86103.5351 ÷ 98.8551 − 1 = +4.73%
−4.47% (yields +1%)
+4.73% (yields −1%)
So what: +4.73% against −4.47%: a gap of 0.26 points.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 2.0000%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 119

## Slide g120
If yields fell 1%, the 7-year would gain 6.13%, to 115.59
In words: discount £5.00 a year and the final £100 at the new yield: 3.5406% − 1% = 2.5406%.
Price = coupon × annuity factor + 100 ÷ (1 + y)⁷
= 5.00 × 6.339590 + 100 ÷ 1.191986 = 31.6980 + 83.8936 = 115.5916
115.59
per £100, up from 108.91115.5916 ÷ 108.9100 − 1 = +6.13%
−5.70% (yields +1%)
+6.13% (yields −1%)
So what: +6.13% against −5.70%: a gap of 0.43 points.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 2.5406%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 120

## Slide g121
If yields fell 1%, the 10-year would gain 8.59%, to 106.04
In words: discount £3.75 a year and the final £100 at the new yield: 4.0400% − 1% = 3.0400%.
Price = coupon × annuity factor + 100 ÷ (1 + y)¹⁰
= 3.75 × 8.512816 + 100 ÷ 1.349145 = 31.9231 + 74.1210 = 106.0441
106.04
per £100, up from 97.65106.0441 ÷ 97.6525 − 1 = +8.59%
−7.78% (yields +1%)
+8.59% (yields −1%)
So what: +8.59% against −7.78%: the gap widens with maturity, to 0.81 points.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 3.0400%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 121

## Slide g122
If yields fell 1%, the 20-year would gain 14.14%, to 119.76
In words: discount £4.75 a year and the final £100 at the new yield: 4.3751% − 1% = 3.3751%.
Price = coupon × annuity factor + 100 ÷ (1 + y)²⁰
= 4.75 × 14.374374 + 100 ÷ 1.942311 = 68.2783 + 51.4851 = 119.7634
119.76
per £100, up from 104.93119.7634 ÷ 104.9300 − 1 = +14.14%
−11.89% (yields +1%)
+14.14% (yields −1%)
So what: +14.14% against −11.89%: a 2.25-point advantage to falling yields.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 3.3751%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 122

## Slide g123
If yields fell 1%, the 30-year would gain 18.59%, to 121.34
In words: discount £4.50 a year and the final £100 at the new yield: 4.3600% − 1% = 3.3600%.
Price = coupon × annuity factor + 100 ÷ (1 + y)³⁰
= 4.50 × 18.718940 + 100 ÷ 2.695101 = 84.2352 + 37.1044 = 121.3396
121.34
per £100, up from 102.32121.3396 ÷ 102.3185 − 1 = +18.59%
−14.67% (yields +1%)
+18.59% (yields −1%)
So what: +18.59% against −14.67%: a 3.92-point advantage.
Source: our calculation (calcs.py) from Exhibit 1. Annuity factor = [1 − (1 + y)⁻ᴺ] ÷ y, y = 3.3600%. Bars on one scale for all nine gilts, from zero.
06 Q4 · 123

## Slide g124
Up vs down for all nine: the longer the gilt, the more a fall helps than a rise hurts
Yields +1%: price falls
Yields −1%: price rises
Gain − loss
1-year
−0.98%
+1.00%
0.02
2-year
−1.89%
+1.95%
0.06
3-year
−2.77%
+2.87%
0.10
5-year
−4.47%
+4.73%
0.26
7-year
−5.70%
+6.13%
0.43
10-year
−7.78%
+8.59%
0.81
20-year
−11.89%
+14.14%
2.25
30-year
−14.67%
+18.59%
3.92
50-year
−17.74%
+24.86%
7.12
So what: convexity grows with maturity: the gain-minus-loss gap widens from 0.02 points (1-year) to 7.12 (50-year).
Source: our calculation (calcs.py) from Exhibit 1. Both sides share one scale and start at zero; gap = gain − size of loss (percentage points).
06 Q4 · 124

## Slide g125
Long gilts paid little extra yield for much more risk
0%
1%
2%
3%
4%
5%
0
5
10
15
20
Modified duration (% price change per 1% yield)
Yield to maturity
1y
2y
3y
5y
7y
10y
20y
30y
50y
+3.51 points
extra yield from the 1-year (0.73%) to the 50-year (4.24%)
21 times
the rate risk: modified duration 0.99 to 20.82
So what: from the 10-year on, yield barely moves (4.04% to 4.24%) while duration climbs from 8.17 to 20.82.
Source: our calculation (calcs.py) from Exhibit 1. Yields: Exhibit 1 and slides 45–53 (YTM); duration: slides 99–107.
06 Q4 · 125

## Slide g126
Short gilts suit investors who may need cash soon; long gilts suit those with long-term promises
Plain: duration matching = holding assets whose duration is close to that of the promises they must meet, so a change in yields moves both about equally.
Bank treasury: cash soon
Pension fund: promises decades away
1y
2y
3y
5y
7y
10y
20y
30y
50y
Each gilt placed at its Macaulay duration, in years (slides 99–107). Bands are illustrative.
Bank treasury (cash needed soon): £100m of the 1-year loses £1.0m if yields rise 1%; £100m of the 50-year loses £16.8m.
Pension fund (pays out in decades): its promises lose value when yields rise, like a long bond, so long gilts fall alongside them.
So what: choose the gilt whose duration matches when the money is needed.
Source: our calculation (calcs.py) from Exhibit 1. Money: slide 85 (our calculation). Duration matching: CFA Level I, Fixed Income.
06 Q4 · 126

## Slide g127
Q4 answer: all prices fall, long gilts by far the most; duration predicts it, convexity refines it
Gilt
Price per £100
Change if yields +1% (falls go left)
Mod. dur.
50-year
94.96 → 78.11
−17.74%
20.82
30-year
102.32 → 87.31
−14.67%
16.45
20-year
104.93 → 92.45
−11.89%
12.94
10-year
97.65 → 90.06
−7.78%
8.17
7-year
108.91 → 102.70
−5.70%
5.91
5-year
98.86 → 94.44
−4.47%
4.60
3-year
107.02 → 104.06
−2.77%
2.82
2-year
106.84 → 104.82
−1.89%
1.92
1-year
102.50 → 101.49
−0.98%
0.99
So what: every gilt loses, in step with duration: −0.98% (£1.0m per £100m) for the 1-year, −17.74% (£16.8m) for the 50-year.
Source: our calculation (calcs.py) from Exhibit 1. Prices: slides 75–83; modified duration: slide 107. Bars start at zero.
06 Q4 · 127

## Slide g127b
Q4 in four findings: every gilt falls, the 50-year most
(a)
Every price falls: from 102.50 to 101.49 for the 1-year (−0.98%) and from 94.96 to 78.11 for the 50-year (−17.74%).
(b)
The 50-year falls most: its modified duration is 20.82 against 0.99: £100m loses £16.8m against £1.0m, and £197.7 thousand per 1bp against £10.2 thousand.
(c)
Duration is a good first estimate: it overstates the fall by 0.01 points (1-year) to 3.08 (50-year); adding convexity overshoots slightly: the two-term estimate understates the 50-year fall by 0.43 and the 10-year’s by 0.02.
(d)
For investors: falling yields help more than rising yields hurt (+24.86% vs −17.74% for the 50-year), and long gilts add 3.51 points of yield for 21 times the risk.
So what: a one-point rise in yields cuts every price; duration gives the size of the cut and convexity most of the correction.
Source: our calculation (calcs.py), slides 75–126.
06 Q4 · 127

## Slide g127c
Paying twice a year moves prices by at most £0.03
Gilt
Annual
Twice a year
Difference, £ per £100 (bars from zero)
1-year
102.50
102.50
0.00
2-year
106.84
106.87
+0.03
3-year
107.02
107.02
0.00
5-year
98.86
98.85
−0.01
7-year
108.91
108.91
0.00
10-year
97.65
97.63
−0.02
20-year
104.93
104.93
0.00
30-year
102.32
102.33
+0.01
50-year
94.96
94.96
0.00
So what: pennies on prices, and about 1bp on yields (3-year: 2.0628% vs 2.0743%); Q4 stays on annual coupons, not re-run twice a year.
Source: our calculation (calcs.py), slide 56. Twice a year = half the coupon and half the yield, paid twice as often.
06 Q4 · 127

## Slide g128
07
Epilogue
What we found, what happened to gilts after 2014, and where things stand today
128

## Slide g129
What we found: coupon ≠ return, a rising curve, and risk that grows with maturity
Q1
The coupon sets the cash; the yield sets the price. The 20-year pays 4.75% but yields 4.38%.
Slides 26–37
Q2
Six gilts price above £100 and three below; yields run from 0.73% to 4.38%.
Slides 38–56
Q3
The curve rises 331bp to 10 years, levels off, then dips to 4.24% at 50.
Slides 57–72
Q4
A 1% rise cuts the 1-year gilt’s price by 0.98% and the 50-year’s by 17.74%.
Slides 73–127
So what: the rest of this section asks what happened to gilts after May 2014, and whether the Q4 risk was real.
Sources: slides 37, 54, 72 and 127; our calculations (calcs.py).
07 Epilogue · 129

## Slide g130
After 2014 gilt yields kept falling, to a record low of 0.12% in August 2020
Bank of England 10-year gilt par yield on four dates (selected dates, not a continuous series; bars start at zero):
7.05%
1 Nov 1993
series start
2.77%
9 May 2014
case date
0.12%
4 Aug 2020
record low
5.30%
27 Oct 2026
latest
Plain: par yield = the coupon a bond would need to be priced at exactly £100 (slide 13).
So what: 0.12% is the lowest value since the series began in 1993; by October 2026 the yield was 5.30%.
Source: Bank of England database, series IUDMNPY (10-year nominal par yield), rows for the four dates; accessed 29 Oct 2026.
07 Epilogue · 130

## Slide g131
After the 2016 Brexit vote, S&P cut the UK from AAA to AA
AAA
AA+
AA
AA-
S&P, June 2014: AAA
S&P, June 2016: AA
Fitch, Aug 2026: AA-
two notches down in one move
Plain: credit rating = an agency’s grade of a borrower’s chance of default. The scale runs AAA (top), AA+, AA, AA-, …, so AA is two notches below AAA.
So what: even the risk-free benchmark can lose its top grade; Fitch rates the UK AA- today, one notch lower again.
Sources: Euronews, 28 Jun 2016 (secondary); PTI via Business Standard, 14 Jun 2014 (secondary); Reuters via Global Banking & Finance, 14 Aug 2026 (secondary).
07 Epilogue · 131

## Slide g132
From December 2021 the Bank raised Bank Rate 14 times, from 0.10% to 5.25% by August 2023
Bank Rate (%)
0
1
2
3
4
5
6
2010
2012
2014
2016
2018
2020
2022
2024
2026
Year
5.25%
14 rises, Dec 2021 – Aug 2023
0.10%
3.75%
0.50%
So what: a 5.15-point rise in under two years; six cuts since August 2024 have brought Bank Rate back to 3.75%.
Source: Bank of England, official Bank Rate history (rows dated 05 Mar 09 to 18 Dec 25); accessed 29 Oct 2026. Line runs to 29 Oct 2026.
07 Epilogue · 132

## Slide g133
September 2022: pension funds’ borrowed bets forced gilt sales, and the Bank had to step in
23 Sep
Mini-budget: expansionary fiscal policy
→
Days after
Gilt yields rise over 100bp in four days
→
Forced sales
Falling prices trigger margin calls; LDI funds sell gilts to raise cash
→
28 Sep – 14 Oct
Bank buys £19.3bn of gilts to restore order
Plain: LDI (liability-driven investment) = strategies pension schemes use to match their assets to their long-term promises, often with borrowed money. margin call = a demand to post more cash when the value of collateral falls.
So what: this was the Q4 risk in action: a fast rise in yields hit leveraged holders of long gilts hardest.
Sources: Bank of England Financial Stability Report, Dec 2022; Bank Underground, 26 Jul 2024; BoE news releases 28 Sep and 14 Oct 2022 (£19.3bn: 12.1 conventional, 7.2 index-linked).
07 Epilogue · 133

## Slide g134
Our 1% scenario happened in 2022: gilt yields rose more than 100bp in four days
100bp+
rise in gilt yields in four days, Sept 2022 (Bank Underground, a Bank of England staff blog)
3.8% → 5%
30-year gilt yield “in just three days” (LBC, secondary)
Price fall for a 1-point rise in the yield of a 20-year gilt (bars start at zero):
Our 20-year gilt (Q4)
−11.89%
Bank Underground’s rule of thumb
“roughly 20%”
So what: the risk Q4 measures was real; why the Bank’s figure is bigger than ours is on the next slide.
Sources: Bank Underground, 26 Jul 2024 (“over 100 basis points in four days”); LBC, Oct 2022 (secondary); our calculation, slide 81.
07 Epilogue · 134

## Slide g134b
Our 20-year, continued: a 20% fall needs a modified duration near 20, which a low coupon gives
20-year gilt, +1% yield | Modified duration | Price change |
Our 20-year gilt: coupon 4.75%, YTM 4.38% | 12.94 | −11.89% |
Zero-coupon 20-year, yield 3% (illustrative) | 19.42 | −17.6% |
Zero-coupon 20-year, yield 1% (illustrative) | 19.80 | −17.9% |
Bank Underground: “roughly 20%” | about 20 | about −20% |
“Roughly 20%” is a straight-line rule (duration × 1%); with convexity even a zero-coupon 20-year falls 17–18%. Our 4.75% coupon lowers duration to 12.94 (slide 108); the low-coupon 0½% 2061 has 26.75 today (secondary).
So what: the fall depends on the gilt’s coupon and yield, so Q4 priced all nine.
Sources: Bank Underground, 26 Jul 2024; giltsyield.com, 28 Oct 2026 (secondary: 0½% 2061 duration 26.75); jdawiseman.com gilt statics (issue date 20 May 2020); our calculations (calcs.py): zero-coupon fall at 3% = (1.03 ÷ 1.04)^20 − 1.
07 Epilogue · 134

## Slide g135
Meanwhile the Bank reversed QE: reinvesting stopped in Feb 2022, selling began that November
£895bn
Turn of 2022
peak
£488bn
17 Sep 2026
remaining
Feb 2022
Bank stops reinvesting maturing gilts
1 Nov 2022
First active gilt sale (postponed from late Sept)
Sep 2026
£488bn remain; plan: sales of £20bn a year plus maturities
Plain: QT (quantitative tightening) = the reverse of QE: the Bank lets its gilts mature or sells them. Bars start at zero.
So what: the Bank went from buying gilts to supplying them; holdings are down £407bn from the peak.
Sources: Bank of England, MPC minutes Feb 2022; market notice 20 Oct 2022; letter from the Governor to the Chancellor, 17 Sep 2026 (£895bn peak, £488bn, £20bn a year).
07 Epilogue · 135

## Slide g136
A real 50-year gilt shows Q4 in practice: the 4% 2060 fell from £114.76 to £75.28
£114.76
9 May 2014
yield 3.37%
£75.28
28 Oct 2026
yield 5.66%
+229bp
rise in its DMO yield, 3.365% → 5.658% (semi-annual basis). Clean price change: −34.4%.
A real gilt, not the case’s bond: it shares the 4% coupon, and was priced by the DMO on the case date. Its modified duration has fallen from 22.24 to 15.73 as maturity nears and its yield rose (today’s figure is secondary).
So what: a 229bp rise took more than a third off the price of a long gilt, over about 12 years.
Sources: DMO gilt reference prices, 9 May 2014 (114.76; 3.365%; duration 22.24); giltsyield.com, prices of 28 Oct 2026 (secondary: £75.28, DMO yield 5.658%, duration 15.73).
07 Epilogue · 136

## Slide g136b
The 4% 2060, continued: duration alone predicts −51.0%; convexity and ageing explain the gap
Duration alone
−51.0%
Modified duration 22.24 × yield rise 2.293 points (5.658 − 3.365) = 51.0%. Convexity gives back 14.6 points: the price–yield line curves (slide 110).
Instant +229bp shock on the 2014 bond
−36.4%
12 years passing give back about 2.0 points: the gilt moves toward £100 as it ages (slide 35).
Actual, 2014 to 2026
−34.4%
So what: duration is a good first guide, but for a big move it overstates the fall; convexity and ageing both help the holder.
Sources: DMO 2014 reference prices (yield 3.365%, duration 22.24); giltsyield.com, 28 Oct 2026 (secondary); our calculation (calcs.py): instant shock repriced at 5.658%.
07 Epilogue · 136

## Slide g137
Today Bank Rate is 3.75% and gilt yields are higher than in 2014 at every maturity
Yield (%)
0
1
2
3
4
5
6
0
10
20
30
40
50
Years to maturity
Today, 28 Oct 2026
Exhibit 1 (dashed)
Real, 9 May 2014
So what: a gilt near 2 years yields 4.76% today; the real gilt nearest 2 years yielded 0.75% on 9 May 2014 (Exhibit 1: 1.74%).
Sources: giltsyield.com, DMO yields, prices of 28 Oct 2026 (secondary); DMO gilt reference prices, 9 May 2014; BoE Bank Rate table (3.75%, last change 18 Dec 2025); Exhibit 1, case. Real points are actual gilts.
07 Epilogue · 137

## Slide g137b
Today, continued: a 5.30% 10-year gilt and a Bank Rate decision due on 5 November (provisional)
5.30%
10-year gilt par yield, 27 Oct 2026 (2.77% in 2014)
4.98%
US 10-year Treasury, 29 Oct 2026 (2.62% in 2014)
3.39%
German 10-year Bund, 29 Oct 2026 (1.50% in 2014)
18 Dec 2025 · cut to 3.75%; no change since
5 Nov 2026 · next decision
PROVISIONAL: re-check before submission
To scale, Dec 2025 to Nov 2026; other meetings not shown
So what: at 10 years, gilts now pay more than US Treasuries and Bunds.
Sources: Bank of England IUDMNPY (27 Oct 2026); US Treasury (29 Oct 2026); Bundesbank (29 Oct 2026); BoE Bank Rate table (no change since 18 Dec 2025); BoE “MPC dates for 2026”: Thursday 5 November, marked provisional.
07 Epilogue · 137

## Slide g138
Lessons: coupon is not return, the curve carries information, long gilts carry far more risk
4.38%
Coupon is not return. The 4.75% 20-year gilt yields 4.38% (4.53% current yield).
+331bp
The curve carries information. It rises to 10 years and implies rates near 2.8% after year 1.
19×
Long gilts carry more risk. PVBP: £197.7 thousand (50-year) vs £10.2 thousand (1-year) per £100m.
2022 showed it: gilt yields rose more than 100bp in four days, and leveraged holders of long gilts were forced sellers (slides 133–134).
Sources: slides 31, 61, 66, 95 and 134; our calculations (calcs.py).
07 Epilogue · 138

## Slide g139
Group 10
[Photo]
[Full name 1]
[Student ID]
[Photo]
[Full name 2]
[Student ID]
[Photo]
[Full name 3]
[Student ID]
[Photo]
[Full name 4]
[Student ID]
[PLACEHOLDER] Members’ photos, full names and student IDs to be supplied; one card per member.
HBS Case 1 · UK Gilts
08 Team · 139
